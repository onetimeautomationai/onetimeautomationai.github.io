# 5-Agent CEO System

This folder holds the owner's AI team. The owner talks to one hire only: the Chief of Staff.

First install: if `chief-of-staff/_shared/owner-profile.md` does not say `setup_done: yes`, read `README.md` first, then use the table below. The owner starts with "Install The 5-Agent CEO System" (or "hi", or "Start my Chief of Staff"), or installs one hire by name ("Install my Email Manager").

Start here, every session: open `chief-of-staff/CLAUDE.md` and follow it. The file is named for one AI agent, but its rules are for any agent that reads files. It checks whether setup is done, runs setup if not, and routes everything else.

Bonus: if `bonus-watch-to-ai/` exists and the owner says "Watch memo" or "check my memos", follow `bonus-watch-to-ai/CLAUDE.md`. Memos from the owner's Apple Watch arrive there and go to the Chief of Staff as jobs.

## Which file to open

| If | Open |
|---|---|
| Normal use, or the owner names the Chief of Staff, or the owner names one hire and `chief-of-staff/_shared/owner-profile.md` says `setup_done: yes` | `chief-of-staff/CLAUDE.md` |
| The owner names one hire ("Install my Email Manager", "Start my Email Manager", "Time Manager, ...") and `chief-of-staff/_shared/owner-profile.md` does not say `setup_done: yes`, or the owner says "on its own" or "alone" | That hire's `CLAUDE.md`: `email-manager/`, `time-manager/`, `focus-manager/` or `ceo-scoreboard/` |
| The agent was opened inside one hire's folder | That folder's `CLAUDE.md` |

With the Chief of Staff set up, the owner talks to it and it runs the other hires. A hire used on its own works in standalone mode (its own `CLAUDE.md` says how).

Every path in this toolkit starts from this folder (the `ceo-ai-toolkit` folder).
