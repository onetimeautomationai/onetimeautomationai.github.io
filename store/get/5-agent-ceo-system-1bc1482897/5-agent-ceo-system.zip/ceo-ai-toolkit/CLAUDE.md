# 5-Agent CEO System

This folder holds the owner's AI team. The owner talks to one hire only: the Chief of Staff.

First install: if `chief-of-staff/_shared/owner-profile.md` does not say `setup_done: yes`, read `README.md` first, then use the table below. The owner starts with "Install The 5-Agent CEO System" (or "hi", or "Start my Chief of Staff"), or installs one hire by name ("Install my Email Manager").

Start here, every session: check the rows of "Which file to open" below in order and open the file of the first row that matches. The first matching row wins. The Chief of Staff checks whether setup is done, runs setup if not, and routes everything else.

For the owner: `README.md`, `FAQ.md`, `TROUBLESHOOTING.md`, `PRIVACY.md`. `PROMISES.md` lists every sales page promise and which agent keeps it.

Bonus: if `bonus-watch-to-ai/` exists and the owner says "Watch memo" or "check my memos", follow `bonus-watch-to-ai/CLAUDE.md`. Memos from the owner's Apple Watch arrive there and go to the Chief of Staff as jobs.

## Which file to open

| If (first matching row wins) | Open |
|---|---|
| The agent was opened inside one hire's folder | That folder's `CLAUDE.md` |
| The owner says "on its own" or "alone", or `chief-of-staff/_shared/owner-profile.md` does not say `setup_done: yes` and the owner names one hire ("Install my Email Manager", "Start my Email Manager", "Time Manager, ...") or asks for one hire's job ("Check my email", "Plan my day", "Top 3") | That hire's `CLAUDE.md`: `email-manager/`, `time-manager/`, `focus-manager/` or `ceo-scoreboard/`. Its first run check offers the Chief of Staff setup or the hire alone |
| Anything else: normal use, the owner names the Chief of Staff, or `chief-of-staff/_shared/owner-profile.md` says `setup_done: yes` | `chief-of-staff/CLAUDE.md` |

With the Chief of Staff set up, the owner talks to it and it runs the other hires. A hire used on its own works in standalone mode (its own `CLAUDE.md` says how).

Every path in this toolkit starts from this folder (the `ceo-ai-toolkit` folder).
