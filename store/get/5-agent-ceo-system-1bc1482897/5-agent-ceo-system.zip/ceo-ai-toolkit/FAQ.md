# Questions

**Which AI agent do I need?**
Any AI agent that can read and write files in a folder. Tested agents are listed in `chief-of-staff/REQUIREMENTS.md`. If yours cannot open folders, use `chief-of-staff/INJECT-PROMPT.md`.

**Do I need to code?**
No. The Basic install has three steps: copy the folder, open your agent, and answer the questions. Two small scripts run safety checks, and each one has a by-hand version you can follow instead.

**Will it send emails or spend money on its own?**
No. Sending, posting, publishing, paying, buying, deleting and booking with other people always wait for your yes. You cannot turn that off in setup.

**How does it know what is important?**
It ranks everything against your number one goal from setup. Ideas that move that goal this month come first. The rest wait, with a reason logged so nothing is lost. When your plate is full, say "Prioritize my plate": it asks what you are carrying, then your items are compared two at a time and it counts the wins. You choose once who picks each pair: you, or your Chief of Staff, which gives a reason for every pick and waits for you to say the order looks right. You never have to sort a long list yourself.

**How does it avoid mistakes?**
Every piece of work gets a light. Green: small and reversible, it does it. Yellow: an AI reviewer checks it before you see it. Red: you decide. Hard checks in `chief-of-staff/scripts/check_gates.py` catch a skipped approval or review.

**Does it learn?**
Yes. Every time you correct it, it writes one line in its lessons file and reads that file every session.

**Will it sound like me?**
At setup it asks where your real writing lives and learns your voice from it. Say "relearn my voice" any time.

**Can I use it for personal life, not a business?**
Yes. Setup question 2 asks which one you want. Say "personal" and the questions change to fit.

**What about the other four hires (Email Manager, Time Manager, Focus Manager, CEO Scoreboard)?**
They are all in the toolkit, each in its own folder. The Chief of Staff runs them for you. If you remove one, the Chief of Staff does that job itself in a simpler way. Each one also works on its own: say "Start my [hire name] on its own".

**Can I change how it works?**
Yes. See `chief-of-staff/CUSTOMIZE.md`. The safety floor stays.

**How do I remove it?**
Say "Uninstall the Chief of Staff". It puts back anything it changed outside the folder. Then delete the `chief-of-staff` folder. See `chief-of-staff/UNINSTALL.md`.

**Is there a refund?**
No. This is a one-time digital purchase, so all sales are final.

**How do I get help?**
See `chief-of-staff/SUPPORT.md`.
