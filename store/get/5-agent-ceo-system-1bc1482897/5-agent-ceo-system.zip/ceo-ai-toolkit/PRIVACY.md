# Your data

**Where it lives.** Everything your team writes stays in this folder on your computer: your profile, your board, your decision log, your lessons, your voice profile. We never receive it.

**Who sees it.** Your AI agent reads these files to do its work. What your agent's company does with that is set by your agent's own privacy terms, not ours. Check them.

**Email and calendar.** If you connect them, your agent reads them through its own connection. The toolkit only writes summaries and drafts into this folder. It never stores your passwords.

**Your writing samples.** The voice profile keeps short notes on how you write and a few one-line examples. It never copies whole emails. Anything you mark private is skipped.

**Support.** If you use the support form, we see only what you type into it: your name, your email and your question. We use it to reply to you and nothing else.

**Removing it.** Say "Uninstall the Chief of Staff" first, so any change it made outside the folder is put back. Then delete the folder. See `chief-of-staff/UNINSTALL.md`.
