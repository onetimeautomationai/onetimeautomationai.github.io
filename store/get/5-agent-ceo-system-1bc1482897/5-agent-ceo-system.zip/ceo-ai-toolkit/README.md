# README: start here

Your 5-Agent CEO System is a team of AI hires that lives in this folder. You talk to one of them, your Chief of Staff. It runs the rest.

## What you need
- An AI agent that can read and write files in a folder (most desktop and command-line AI assistants can).
- About 20 minutes for setup.
- Optional: your email and calendar connected to that agent. Without them, your team works from plain files.

## Three steps
1. Unzip this folder somewhere you keep work files. Do not rename the files inside.
2. Load the `ceo-ai-toolkit` folder into your favorite AI agent platform (open the agent in that folder).
3. Say "Install The 5-Agent CEO System" (or "hi", or "Start my Chief of Staff"). Your Chief of Staff asks 18 short questions, one at a time, then gives you your first morning brief (next morning if you set up after work hours).

Want only one hire? Install it by name instead: "Install my Email Manager", "Install my Time Manager", "Install my Focus Manager" or "Install my CEO Scoreboard".

If your AI tool cannot open folders, use `chief-of-staff/INJECT-PROMPT.md` instead. Fill in the blanks and paste it in.

## What to say after setup
- "Morning" for your brief: your Top 3, your calendar, who is waiting, what needs your yes.
- Any idea, task or worry, in your own words. It lands on your board and gets ranked against your number one goal.
- "Prioritize my plate" when you have too much going on. It asks what is on your plate. Then you pick between two items at a time, or your Chief of Staff ranks them for you to review. You get one page with your Top 3 for the week.
- "Wrap up my day" for your night wrap: your score, what got done, what moves to tomorrow.

Full list: `chief-of-staff/wake-phrases.md`.

## What it never does without your yes
It never sends, posts, publishes, pays, buys, deletes, or books time with another person without your yes. It drafts and asks. You decide.

## Your five hires

| Folder | Hire | What it does |
|---|---|---|
| `chief-of-staff/` | Chief of Staff | Your one point of contact. Runs the others, brings you only what needs you |
| `email-manager/` | Email Manager | Sorts your inbox, drafts replies in your voice, never sends unless you turn sending on |
| `time-manager/` | Time Manager | Builds and protects your calendar, blocks time for your Top 3 |
| `focus-manager/` | Focus Manager | Turns your brain dump into a Top 3 and one result per work block |
| `ceo-scoreboard/` | CEO Scoreboard | Scores your day at night and drafts tomorrow's list |
| `bonus-watch-to-ai/` | Watch-to-AI Team Edition (bonus) | Speak a task into your Apple Watch and your Chief of Staff hands it to the right agent. Only available with the 5-Agent CEO System |

Each hire also works on its own. Say "Start my [hire name] on its own".

## Where to go next
- How it works: `chief-of-staff/docs/how-it-works.md`
- A sample day: `chief-of-staff/examples/sample-day.md`
- Questions: `FAQ.md`
- Something wrong: `TROUBLESHOOTING.md`
- Your data: `PRIVACY.md`
