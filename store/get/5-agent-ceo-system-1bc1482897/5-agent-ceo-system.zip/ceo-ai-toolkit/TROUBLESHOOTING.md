# Something is wrong

Start with this: tell your Chief of Staff "Something is wrong with [what]. Check your files." It reads its own rules and logs and tells you what it finds.

| What you see | Most likely cause | Fix |
|---|---|---|
| It does not act like a Chief of Staff | The agent was opened in the wrong folder | Open the agent in the `ceo-ai-toolkit` folder itself, then say "hi" |
| It asks the setup questions again | Setup is not finished. `chief-of-staff/_shared/owner-profile.md` still shows `setup_done: no` or empty `{{ }}` blanks | Answer the remaining questions, or say "redo setup" to start fresh |
| It forgot something you told it | It was not written to a file | Say "From now on, [it]". It goes to the lessons file and stays |
| The brief is missing your calendar or email | Those tools are not connected to your agent | Connect them in your agent, or use the plain-file calendar (setup question 9) |
| The brief shows old numbers | A handoff file was not updated today | Check the dates on the files in `handoffs/`. Say "Status" to see what is out of date |
| It did something without asking | It skipped one of its rules | Say "undo that and add a lesson". Then run `python3 chief-of-staff/scripts/check_gates.py` to see which rule it missed |
| A draft does not sound like you | Few or old writing samples | Say "relearn my voice" and point it to more of your writing |
| A script will not run | Python is not installed or your agent cannot run it | Skip it. Each script's job has a by-hand version in `chief-of-staff/scripts/README.md` |
| It edited a file outside the toolkit | It skipped the safe change rules in `chief-of-staff/INSTALL.md` | Check `.ceo-toolkit/install-log.md`. Every outside change has a saved copy in `.ceo-toolkit/snapshots/` |

Still stuck? See `chief-of-staff/SUPPORT.md`.
