# Pipeline

Stage 00 runs once at install. After that, one run handles every memo recorded since the last run. launchd checks for new memos every 15 minutes. A check with no new memo exits without starting the agent. Paths start from the `ceo-ai-toolkit` folder.

| Stage | Who runs it | Reads | Writes |
|---|---|---|---|
| `00_onboarding` | The agent with the owner, once | `bonus-watch-to-ai/README.md`, `setup/`, `scripts/check_setup.py` | `config.json`, `setup/onboarding-log.md`, loaded schedule |
| `01_capture` | `scripts/voice_memo_ingest.py` | Voice Memos folder, `config.json`, state file | A memo file for each recording in `memos/` |
| `02_hand-off` | `claude -p` as the Chief of Staff, started by the script | `stages/02_hand-off/CONTEXT.md`, `_shared/filing-rules.md`, the memo files, the Chief of Staff's own files | Board rows, `handoffs/jobs.md`, each manager's files, decision log |
| `03_review` | The owner, with the Chief of Staff | The board, `memos/ledger.md`, `handoffs/` | The owner's decisions |

## Where state lives
| Path | What it is |
|---|---|
| `~/.local/share/watch-to-ai-team/state.json` | Recordings already handled, and failure counts |
| `~/.local/share/watch-to-ai-team/run.log` | One line per run event |
| `~/.local/share/watch-to-ai-team/staging/` | Audio copies for the current run. Cleared after a good run |
| `bonus-watch-to-ai/memos/` | One file per memo, and `ledger.md` |

Status at any moment: read the last lines of `run.log`. A memo is done when its name is in `state.json` and its row is in `memos/ledger.md`.

## Factory and product
Factory (stable, edit on purpose): `_shared/`, `stages/`, `scripts/`, `config.json`.
Product (new every run): the memo files, and the board rows and jobs the Chief of Staff makes from them.
