# Change how your Watch-to-AI System works

## The easy way
Tell your Chief of Staff. "From now on, a memo that says 'remind me' goes on my list, not the board." It adds a line to `chief-of-staff/_shared/lessons.md`, and every memo run reads that file.

## Safe to change

| What | Where |
|---|---|
| How a memo is handled and worded | `_shared/filing-rules.md` |
| Which transcriber runs | `config.json`, `transcribe_command` |
| Where `claude` is | `config.json`, `claude_path` |
| What the agent may run while you are away | `config.json`, `claude_args` (question 3 in `setup/questionnaire.md`) |
| How long a run may take | `config.json`, `agent_timeout_seconds` (starts at 1800) |
| A text when a run finishes | `config.json`, `notify_imessage` and `notify_number` (off by default) |
| How often it checks | `StartInterval` in the schedule file, in seconds (starts at 900) |

## Change with care (your agent asks for your yes and keeps a snapshot first)

| What | Why |
|---|---|
| `stages/02_hand-off/CONTEXT.md` | It is what makes the Chief of Staff route a memo the normal way. A mistake can skip the board or the checks |
| `claude_args` with more tools | The agent runs while you are away. Add only what you trust. Red actions stay red |
| The pointer line in your toolkit's start file | It is a file outside this folder (`INSTALL.md`, safe change rules) |
| `scripts/voice_memo_ingest.py` | It guards the setup check and the state. Run `scripts/test_ingest.py` after any edit |

## Do not change
`chief-of-staff/_shared/decision-tiers.md` is not a setting for this bonus. The red floor stays: no memo can send, post, publish, pay, buy, delete or book with another person.
