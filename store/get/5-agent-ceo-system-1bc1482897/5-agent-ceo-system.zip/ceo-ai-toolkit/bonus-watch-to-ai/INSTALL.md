# Install

Pick one path. Basic needs no terminal and no watch. Expert runs by itself from your watch.

## Before you start
Your Chief of Staff must be set up. If it is not, open your agent in the `ceo-ai-toolkit` folder and say "Start my Chief of Staff" first.

## Basic (no terminal)

1. Keep the `bonus-watch-to-ai` folder inside your `ceo-ai-toolkit` folder.
2. Open your AI agent in the `ceo-ai-toolkit` folder.
3. Say: **"Start my Watch-to-AI System."**
4. Your agent checks your Chief of Staff setup, then tells you how Basic works. It does not ask for your Mac settings.
5. Try it. Say: **"Watch memo: Block Friday morning for proposals. Done means it is on my calendar."** Your agent saves the words in `memos/` and your Chief of Staff routes them like a memo from your wrist.

## Make it known to your toolkit

Add this one line to the root start file of your toolkit (`CLAUDE.md` or `AGENTS.md`):

`If bonus-watch-to-ai/ exists and the owner says "Watch memo" or "check my memos", follow bonus-watch-to-ai/CLAUDE.md.`

This edits a file outside `bonus-watch-to-ai/`, so your agent follows the safe change rules below first. The toolkit you downloaded already has this line.

## Expert (from your watch)

Do Basic first, then say **"Set up my Watch-to-AI System."** Your agent follows `stages/00_onboarding/CONTEXT.md`, one step at a time. In short:

1. It runs `python3 bonus-watch-to-ai/scripts/check_setup.py` and fixes what fails with you.
2. You turn on Voice Memos sync in iCloud on your phone and Mac, and give your terminal Full Disk Access.
3. It copies `config.example.json` to `config.json` and asks four short questions.
4. It runs the script once. The first run marks your old recordings as seen and handles none of them.
5. You record a test memo on your watch. The script hands it to your Chief of Staff and you see the result on your board.
6. With your yes, it loads the schedule (`setup/com.example.watch-to-ai-team.plist`). It checks for new memos every 15 minutes.

## Safe change rules

Your agent follows these for any change outside the `ceo-ai-toolkit` folder (the schedule, your agent's settings, Full Disk Access) and for any edit to a toolkit start file.

1. If it cannot read and write files here, it says so and gives you manual steps instead.
2. Before changing anything, it tells you the time and lists every file it will create or change. It waits for your yes.
3. It copies each existing file it will change into `.ceo-toolkit/snapshots/watch-to-ai-<YYYYMMDD-HHMMSS>/`, keeping its path. It adds a row to `.ceo-toolkit/install-log.md`: time, action, snapshot, files changed, files created, notes. It creates the log with a header row if it is missing.
4. It never overwrites your agent's own settings or rules file. It adds a block between `<!-- ceo-toolkit:watch-to-ai:start -->` and `<!-- ceo-toolkit:watch-to-ai:end -->` instead. The schedule is one new file, and the log records its path.
5. It never changes macOS privacy settings for you. You click them, it checks them.
6. It never deletes your data and never deletes anything in `.ceo-toolkit/`.

`.ceo-toolkit/` lives in the `ceo-ai-toolkit` folder. It is your record of every change.

## Go back from Expert to Basic

Say "Stop the Watch-to-AI schedule." It unloads the schedule file it added (using the log) and keeps the rest.
