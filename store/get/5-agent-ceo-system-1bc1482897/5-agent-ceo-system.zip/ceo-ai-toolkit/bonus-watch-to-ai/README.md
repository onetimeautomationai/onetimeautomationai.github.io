# Watch-to-AI Team Edition (bonus)

Speak a task into your Apple Watch and your Chief of Staff hands it to the right agent. Only available with the 5-Agent CEO System.

Within about 15 minutes it is on the board and often already done.

Example memo: "Reply to Tom Becker and say yes to Thursday. Block Friday morning for proposals. Done means a draft in my drafts folder and a block on my calendar."

## Why it is a Team Edition

The free Watch-to-AI System files a memo as a note and one agent does the work. This one needs your toolkit. A memo is handed to your Chief of Staff as a job, the same way anything you say to it is. The Chief of Staff then does what it always does:

| Step | What happens |
|---|---|
| Intake | Your words land on the board as an Inbox row, exactly as you said them |
| Decide | It ranks the idea against your number one goal and finds its trust light |
| Dispatch | It hands the job to the Email Manager, Time Manager, Focus Manager or CEO Scoreboard. No manager fits? The Chief of Staff does it itself. If you have ranked your plate, a new task first waits for up to 3 quick picks at your next morning brief, and goes out once it is in your top 3 |
| Check | Yellow work is reviewed first. Red work (send, post, pay, book, delete) waits for your yes |
| Review | Results show up in your normal morning brief and "What needs me?" |

It does not run without a finished Chief of Staff. The script checks this every time and stops if it is not set up.

## What you get

| When | What happens |
|---|---|
| You record a memo on your watch | It syncs to your Mac and is transcribed there. Your audio never leaves your Mac |
| The next check runs (every 15 minutes) | Your Chief of Staff gets the transcript and routes it |
| You open your agent and say "Morning" | The memo's results are in your brief |
| You say "Check my memos" | A list of memos handed over, and what each one became |

## Requirements

### Platform
- A Mac running macOS 13 Ventura or later. The scheduled runs need the Mac on and signed in. A check missed while the Mac sleeps happens when it wakes.
- An Apple Watch with the Voice Memos app, or an iPhone. Both must use the same Apple ID as the Mac.
- Voice Memos sync turned on in iCloud on the phone and on the Mac.
- Internet for the AI step.

### Hardware
| | Minimum | Recommended |
|---|---|---|
| Chip | Intel | Apple silicon (M1 or newer). Transcription is several times faster |
| Memory | 8 GB | 16 GB |
| Free disk | 5 GB | 10 GB |

### AI platform
The AI has to run on your Mac, read local files, and run on a schedule with no one at the keyboard. Claude Code does all three. You need a Claude plan that includes Claude Code, and `claude -p "say hi"` must work in Terminal. Web chat apps cannot read files on your Mac, so use Basic in `INSTALL.md` with them.

### Software
- Python 3.9 or later.
- Homebrew and ffmpeg (`brew install ffmpeg`).
- One local transcriber. The default is openai-whisper (`pip3 install openai-whisper`).

### The toolkit
- Your Chief of Staff set up (`setup_done: yes`). Required.
- Any of the four managers. Optional. A job with no manager installed is done by the Chief of Staff with fewer tools. It says so.

Check all of this in one step: `python3 bonus-watch-to-ai/scripts/check_setup.py`

## Two ways to use it

| | Basic | Expert |
|---|---|---|
| How | You paste a transcript and say "Watch memo" | The watch memo flows in by itself every 15 minutes |
| Needs | Just your toolkit and an AI agent | A Mac, Claude Code, a transcriber, a scheduled task |

Start with Basic to see how a memo gets routed. Add Expert when you want the wrist.

## Install in 3 steps (Basic)

1. Keep the `bonus-watch-to-ai` folder inside your `ceo-ai-toolkit` folder.
2. Open your AI agent in the `ceo-ai-toolkit` folder.
3. Say: **"Start my Watch-to-AI System."**

Full steps, and Expert: `INSTALL.md`.

## The one tip that matters
Say what done looks like at the end of each memo. For example: "Done means a draft in my drafts folder and nothing sent." Your Chief of Staff uses that as the finish line on the job. Start a memo with "work now" if it is during your protected time and you want it done anyway.

## What it will never do
It never sends, posts, publishes, pays, buys, deletes or books time with another person. A memo that says "send it" gets a finished draft and a question on your board. It never asks you a question while you are away. It guesses, flags the guess, and goes on. It never writes in a manager's folder. It never touches memos that existed before you installed it.

## More
- What you can change: `CUSTOMIZE.md`
- What it can touch: `permissions.md`
- What it cannot do yet: `known-limitations.md`
- Help: `SUPPORT.md`
- Remove it: `UNINSTALL.md`

If you also have the free Watch-to-AI System, turn its schedule off first. Two systems on the same Voice Memos would each handle every memo.

Version 0.1.13, 2026-11-21. Changes: `CHANGELOG.md`.
