# Help and updates

## Get help
1. Run `python3 bonus-watch-to-ai/scripts/check_setup.py`. Check `known-limitations.md` and `TROUBLESHOOTING.md` in the toolkit folder.
2. Ask your agent: "My Watch memos are not working. Check your files." It reads `bonus-watch-to-ai/CLAUDE.md`, the last lines of `run.log`, and tells you what it finds.
3. Still stuck? Use the contact form at https://gh.onetimeautomation.ai/support/. Give your name, your email, what you said in the memo, what happened, and which AI agent you use. We reply by email.

## What updates you get
- **Fixes to this version are free.** If the Watch-to-AI System does not do what this folder says it does, we fix it and you get the new files.
- **New features are not promised.**
- **We do not control your AI agent, your watch or macOS.** If they change how they work, we will try to adapt, but we cannot promise a fix by a date.

## How to update
Download the new version. Copy your `config.json` and your `memos/` folder into it. Check `CHANGELOG.md` for what changed.
