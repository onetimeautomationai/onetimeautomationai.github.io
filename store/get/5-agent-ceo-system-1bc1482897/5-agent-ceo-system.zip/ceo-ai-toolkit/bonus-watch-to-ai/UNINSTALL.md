# Remove the Watch-to-AI Team Edition

## The simple way
Stop the schedule first (next section if you turned on Expert). Then delete the `bonus-watch-to-ai` folder. Nothing else depends on it. Your board rows, jobs and decision log stay, because they belong to your Chief of Staff. Remove the pointer line from your toolkit start file if you like.

## If your AI made changes outside the folder
Say: **"Uninstall the Watch-to-AI System."** Your AI then:

1. Copies anything it will remove into `.ceo-toolkit/removed/watch-to-ai-<YYYYMMDD-HHMMSS>/`. This includes your `memos/` folder, so your memo words are kept.
2. Unloads the schedule: `launchctl unload ~/Library/LaunchAgents/com.example.watch-to-ai-team.plist`, then removes that one file.
3. Restores each file it changed from its snapshot in `.ceo-toolkit/snapshots/`.
4. In shared files, removes only the block between `<!-- ceo-toolkit:watch-to-ai:start -->` and `<!-- ceo-toolkit:watch-to-ai:end -->`, or the one pointer line it added. Other hires' blocks stay.
5. Adds a row to `.ceo-toolkit/install-log.md` and tells you what was restored, removed and kept.

Say **"Show what uninstalling would change"** to see the list without changing anything.

## Roll back one change
Each snapshot folder in `.ceo-toolkit/snapshots/` holds the files as they were before that change. Say "Roll back the change from [time]" and your AI restores those files.

## What stays on your computer
Everything in `.ceo-toolkit/` stays. So does `~/.local/share/watch-to-ai-team/` (the state and run log). Delete that folder yourself when you are sure. You can also take Full Disk Access away from your terminal in System Settings.
