# Watch-to-AI Team Edition: map

Paths start from the `ceo-ai-toolkit` folder.

| Path in `bonus-watch-to-ai/` | One line |
|---|---|
| `CLAUDE.md` | The instruction your agent follows for memos |
| `README.md` | The owner's one-page guide and requirements |
| `CONTEXT.md` | The pipeline and where state lives |
| `INSTALL.md` | Basic and Expert install, safe change rules |
| `UNINSTALL.md` | Safe removal and rollback |
| `CUSTOMIZE.md` | What you can change, `config.json` |
| `permissions.md` | What it can read and write |
| `known-limitations.md` | What it cannot do yet |
| `SUPPORT.md` | Help and the update promise |
| `LICENSE.md` | Use and resale terms |
| `CHANGELOG.md`, `manifest.json` | Version, file list, checksums |
| `_shared/` | The memo rules every run follows |
| `stages/` | Onboarding, capture, hand-off, review |
| `setup/` | Questionnaire and schedule template |
| `scripts/` | The ingest script, the setup checker, the self-test |
| `memos/` | The script's memo files and ledger |
| `tests/` | Test cases |
