# Memo rules

These rules apply to every memo. The script sends this file to the agent with the stage 02 contract, so edit it here and every run follows. Paths start from the `ceo-ai-toolkit` folder.

## How the owner talks to you
- Each memo is a one-way message from the owner, usually recorded on a watch while away from a screen.
- The owner will not read questions until later. Never ask. Make the best guess and keep going, using the grounding rule under "Guesses and gaps".
- If the memo says what "done" looks like, that is the finish line. Do not stop before it. Do not go past it. A job is `done` only when a real run reached that line. If its manager could not read the source or could not run, the job stays `open` with the reason (see "Limits").
- A memo that starts with "work now" skips the protected time hold (standing rule SR14). Any other memo recorded during protected time is logged and held. Judge "during protected time" by the Recorded time in the batch list, not by the time of the run.

## The Chief of Staff handles it, not you alone
- Every memo is the owner's latest message (SR5). Run it through intake, decide and dispatch exactly as the Chief of Staff stages say. Do not skip a stage because the owner is away.
- Use the exact transcript as the owner's words (SR8). Replace any pipe character with a slash and join the transcript's lines with a space, so it stays one row. Add the memo file name to the Inbox row, for example `(Watch memo 2026-11-24-081502-ab12.md)`.
- Route each job with the table in `chief-of-staff/_shared/roster.md`. Email goes to the Email Manager. Time on the calendar goes to the Time Manager. Ranking and capture go to the Focus Manager. Scoring goes to the CEO Scoreboard. No fit, or the manager is not installed: you do it, under the same lights and review.
- Put the owner's "done means" line in the job row. A memo with no "done means" line gets the manager's own normal result as the finish line, written on the job row as `done means: not stated, the manager's normal result`. Never invent a finish line, and never stop before the manager's own check passes. An item that waits for the owner to rank it (`waiting: your picks` in stage 02) has no job row yet (`stages/02_hand-off/CONTEXT.md`): put the line and any `Flagged:` guess in its "Goes to" cell in `chief-of-staff/board/plate.md` instead.

## Guesses and gaps
- Where a manager would ask how to do a task the memo states, guess and write `Flagged:` and the guess on the job row.
- A guess uses only facts found in the owner's files and names its source on the job row. A person counts as known only when the name appears in `chief-of-staff/_shared/owner-profile.md` or on the board's plate. A name that appears only in the memo is the owner's own instruction when the memo states the task ("reply to Tom Becker"). It never makes a guessed person known. Never address a draft to a person the owner did not name and who is in no file.
- A memo that names a person (known or not) but does not state the task ("do the thing with Tom", "do the thing with Priya"): do only what the memo names, cite the file where the person appears if there is one, add the `QN missing:` row asking what the task is, make no job and make no draft. One rule for every such memo. A job that already exists for other reasons stays `open`.
- A line the owner must settle goes to the board's "Waiting on you" with the next D number and your recommendation (`needs owner:`).
- Missing facts have one home, the Chief of Staff's own (`chief-of-staff/stages/02_decide/CONTEXT.md` step 6): write `missing: <fact>` on the A row or job row the memo made, and the next brief shows it there. Only a memo that makes no job and no A row has nowhere to carry the note (a person named with no task, a Top 3 with no items). That memo gets one "Waiting on you" row with the next D number, starting `QN missing:`, and its recommendation names no task, only "tell me the task". Never both for the same memo. Do not wait for an answer.
- When the memo does not say who does a must, add no `QN missing:` row. Write `(who does it: asked)` in its Goes to cell, as `you (who does it: asked)`. The next brief asks the Chief of Staff's PL17 question (`chief-of-staff/_shared/plate-rules.md`, PL17).

## Limits
- The trust lights apply as written (`chief-of-staff/_shared/decision-tiers.md`). Sending, posting, publishing, paying, buying, deleting and booking with other people are red. A memo that says "send it" gets a finished draft in `handoffs/drafts/`. "Send it" is the owner's ask, never the yes to send. The send question has one home, `chief-of-staff/stages/03_dispatch/CONTEXT.md` step 5 (`chief-of-staff/stages/02_decide/CONTEXT.md` step 4): a "Send it?" at show time when a manager can send, or, when sending is off or nobody can send, the draft path plus the "Your list" row "Send the [draft] from your own mail", made in the same run. It is never a D row. Follow those files and do not restate them here. Nothing is sent.
- Do not delete or overwrite existing files. Add to them.
- Do not write in a manager's folder yourself. When stage 02 says to run a job, the manager's own stage writes its files.
- Calls and anything needing a login go on the board's "Your list".
- A buy or pay memo follows `chief-of-staff/stages/02_decide/CONTEXT.md` steps 1 and 6 and `chief-of-staff/_shared/decision-tiers.md` as written: the memo is the owner's own words, logged T3 with those words, nothing bought, and the owner doing the buying or the paying themselves is the "Your list" row logged `A#: Owner task:`. A "Waiting on you" D row is for a memo that leaves open whether to buy ("should I renew it?").
- A must whose last step is red (filing, paying, sending) has one home, `chief-of-staff/stages/10_re-rank/CONTEXT.md` section B step 1 ("Its last step is red"): that step alone waits as a D row or the "Send it?" at the send, and the Time Manager block goes out now. Never write both a D row and a "Your list" row for it.
- A read-only inbox ask ("what did Tom write?") with no Email Manager has one home: say "No Email Manager, I can't see your inbox" (`chief-of-staff/_shared/roster.md`), add one "Your list" row logged `Owner task:` (`chief-of-staff/stages/02_decide/CONTEXT.md` step 4), and make no job and no second row.
- A job that cannot run stays `open`. If a manager's stage or its check cannot run (not installed, not set up, no access), leave the job row `open` with the reason, never `done`. "Checks not run" means the job is not done.
- Do not edit anything in `bonus-watch-to-ai/` except by the script. It owns `memos/`. The one exception is Basic (no script): there you write the memo file and one ledger row for it.

## Top 3 for another day
- A Top 3 for a future day is a Focus Manager job. Its result goes to `focus-manager/capture/capture.md` as carried rows and to the board's "Your list". Never write `top3-today.md` for tomorrow.
- Where the owner's three items come from: the ranked plate on the board, if there is one. With no plate, use only what the memo itself names, in the order said, and use fewer than 3 if it names fewer. Never invent items. If the memo names none and there is no plate, write no list: add a "Waiting on you" row (`QN missing:`) asking what the 3 are, and still create the Focus Manager job to carry that row.
