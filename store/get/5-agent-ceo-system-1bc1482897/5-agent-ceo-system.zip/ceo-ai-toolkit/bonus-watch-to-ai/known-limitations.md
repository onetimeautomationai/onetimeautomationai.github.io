# Known limitations

- **It needs your toolkit.** Without a finished Chief of Staff the script stops and does nothing. There is no paste-in prompt for chat apps. Basic still needs an agent that can read your toolkit folder.
- **It needs a Mac that is on.** Checks run while the Mac is on and signed in. A memo recorded while the Mac sleeps is handled when it wakes. Nothing runs on the watch itself.
- **About 15 minutes, not instant.** The watch must sync the recording by iCloud, then the next check picks it up.
- **It cannot ask you anything.** A vague memo gets a best guess, flagged on the job row. The guess can be wrong. Fix it in your own words and the Chief of Staff saves a lesson.
- **With a ranked plate, a new task waits for your picks.** When you have ranked your plate, a memo with a new task is placed against your top 3 before it goes to a manager. The memo run cannot ask you, so the task waits under "New since the ranking" and your next morning brief asks you up to 3 quick picks. If you chose "rank it for me", your Chief of Staff places it during the memo run instead, with a reason for each pick, and your next brief shows where it went so you can flip it. A task with a hard date and a real cost is handled right away.
- **Red stays red.** A memo that says "send it", "pay it" or "book it" gets a draft and a question on your board. This is on purpose.
- **A manager that is not installed does not run.** The Chief of Staff does the job itself with fewer tools. Without an Email Manager it cannot see your inbox.
- **Email and calendar need connectors.** A scheduled run can use only what your agent can reach with nobody at the keyboard. If it cannot reach your email or calendar, the job waits with the reason on your board.
- **Rule following depends on your AI agent and model.** Stronger agents follow the Chief of Staff's rules more closely. The script's own checks (setup done, board changed, state only moves on success) work with any agent.
- **The agent can run only the toolkit's own scripts.** If your agent cannot run Python, the Chief of Staff's checks are done by hand and marked "checks not run".
- **Time zone.** The recording time comes from your Mac's clock. Keep the Mac in the same time zone as your owner profile.
- **One memo is one message.** A very long memo is split into items by the Chief of Staff. Recordings over about 10 minutes transcribe slowly on an Intel Mac.
- **Voice quality matters.** A noisy street can ruin a transcript. The memo file keeps the transcript so you can see what the AI heard.
- **Free version and Team Edition do not mix.** Run one schedule only.
