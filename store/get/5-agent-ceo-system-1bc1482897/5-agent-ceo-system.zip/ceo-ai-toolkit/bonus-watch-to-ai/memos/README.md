# Memos

The script saves one file here for each Watch memo, named `YYYY-MM-DD-HHMMSS-tag.md`. It also keeps `ledger.md`, one row for each memo handed to the Chief of Staff and one for each recording skipped after 3 failed tries. With the script, it writes both. In Basic (no script) the agent writes the memo file and its ledger row. Do not edit them by hand. The memo files hold your own words, so keep them private.
