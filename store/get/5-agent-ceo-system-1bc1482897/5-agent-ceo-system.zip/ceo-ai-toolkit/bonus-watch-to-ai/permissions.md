# What the Watch-to-AI System can touch

Paths start from the `ceo-ai-toolkit` folder. There are two actors. The script captures. The agent run is your Chief of Staff, under its own permissions.

| Area | Read | Write | Notes |
|---|---|---|---|
| Voice Memos folder on your Mac | Yes (script) | No | Needs Full Disk Access. Recordings are copied, never changed |
| `~/.local/share/watch-to-ai-team/` | Yes (script) | Yes (script) | State, run log, staging copies |
| `bonus-watch-to-ai/memos/` | Yes | Yes (script only, except in Basic where the agent writes the memo file and one ledger row) | One file per memo, and `ledger.md` |
| `bonus-watch-to-ai/config.json` | Yes | Only when you ask for a change | No passwords or keys go in it |
| `chief-of-staff/` | Yes | Yes, as the Chief of Staff normally does | Board, decision log, runs, lessons |
| `handoffs/` | Yes | Yes, as the Chief of Staff and the managers normally do | `jobs.md`, drafts, reports |
| `logs/activity.md` | Yes | Adds one line per memo run (agent run) | Never edits or removes a line |
| Each manager's folder | Yes | Only the manager itself, never the Chief of Staff | Same rule as the rest of the toolkit |
| Scripts the agent may run | Only the `scripts/` folders of `chief-of-staff/`, `time-manager/`, `email-manager/`, `focus-manager/` and `ceo-scoreboard/` | | Each manager's own checks, such as `calendar_tools.py check`. Set in `claude_args`. Nothing else runs |
| Your email and calendar | Only through a manager, under its own permissions | Only through a manager, never sending or booking with others | Red |
| The internet | Local transcriber: no. Agent web search: off unless you allow it (`CUSTOMIZE.md`) | | The AI step itself needs internet |
| `.ceo-toolkit/` | Yes | Adds snapshots and log rows only, and only if you do the Expert steps | Never deletes anything there |
| Your Mac's settings | No | Only the schedule file in `~/Library/LaunchAgents/`, with your yes, following the safe change rules in `INSTALL.md` | You click the privacy settings yourself |
| Passwords, keys, tokens | Never stored | Never stored | |

## Actions that always need your yes

Loading the schedule, changing your agent's settings or rules file, and anything outside the `ceo-ai-toolkit` folder. Sending, posting, publishing, paying, buying, deleting and booking with other people are always red and never happen from a memo.
