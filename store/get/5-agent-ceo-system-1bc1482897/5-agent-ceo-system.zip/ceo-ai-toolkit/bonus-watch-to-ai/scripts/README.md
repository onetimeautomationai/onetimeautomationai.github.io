# Scripts

Three small scripts. Standard Python 3, nothing to install. They work from any folder. The docs show them run from the `ceo-ai-toolkit` folder.

| Script | What it does | By hand |
|---|---|---|
| `voice_memo_ingest.py` | Finds new Voice Memos, transcribes them, saves a memo file for each, starts your agent as the Chief of Staff | Paste a transcript and say "Watch memo" (Basic) |
| `check_setup.py` | Prints PASS, WARN or FAIL for every requirement, with the fix. Exit code 0 means no FAIL | Read each line of the requirements in `README.md` |
| `test_ingest.py` | Tests the ingest script and the checker with a made-up owner and fake recordings | Do each case in `tests/test-cases.md` by hand |

Run: `python3 bonus-watch-to-ai/scripts/check_setup.py`

## voice_memo_ingest.py

Options for testing: `--dry-run` (makes memo files and prints the prompt, changes no state), `--config`, `--toolkit`, `--recordings`, `--state-dir`.

What it guards:
1. It stops unless `chief-of-staff/_shared/owner-profile.md` says `setup_done: yes` and `handoffs/jobs.md` exists.
2. The first run marks every old recording as seen and handles none.
3. State moves forward only when the agent run succeeded and the board changed.
4. A recording that fails 3 times is skipped.
