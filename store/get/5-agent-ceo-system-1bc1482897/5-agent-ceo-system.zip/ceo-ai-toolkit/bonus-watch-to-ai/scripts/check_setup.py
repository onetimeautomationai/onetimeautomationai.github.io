#!/usr/bin/env python3
"""Watch-to-AI Team Edition. Setup checker.

Prints PASS, WARN or FAIL for every requirement, with the fix for each one.
Run it before setup, after each fix, and any time something stops working
(from the ceo-ai-toolkit folder):
    python3 bonus-watch-to-ai/scripts/check_setup.py
Test options: --toolkit PATH, --config PATH, --recordings PATH, --state-dir PATH
Exits 1 if any check fails. Standard library only. Reads files, never changes them.
"""
import argparse
import json
import os
import platform
import re
import shlex
import shutil
import subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parent.parent
results = []


def check(status, name, detail, fix=""):
    results.append(status)
    line = f"{status:<4}  {name}: {detail}"
    if fix and status != "PASS":
        line += f"\n      Fix: {fix}"
    print(line)


def run(cmd, timeout=20):
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return r.returncode, (r.stdout or r.stderr).strip()
    except Exception as e:
        return 1, str(e)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--toolkit", default=str(HERE.parent))
    ap.add_argument("--config", default=str(HERE / "config.json"))
    ap.add_argument("--recordings", default=str(Path.home() / "Library/Group Containers/group.com.apple.VoiceMemos.shared/Recordings"))
    ap.add_argument("--state-dir", default=str(Path.home() / ".local/share/watch-to-ai-team"))
    args = ap.parse_args()
    toolkit, recordings = Path(args.toolkit), Path(args.recordings)
    state_file = Path(args.state_dir) / "state.json"
    config_file = Path(args.config)

    print("Watch-to-AI Team Edition setup check\n")
    cfg = {}
    if config_file.exists():
        try:
            cfg = json.loads(config_file.read_text())
        except Exception as e:
            print(f"(config.json could not be read: {e})")

    # The toolkit (this is what makes it Team Edition)
    profile = toolkit / "chief-of-staff/_shared/owner-profile.md"
    if not (toolkit / "chief-of-staff/CLAUDE.md").is_file():
        check("FAIL", "Chief of Staff", "not found", "Keep bonus-watch-to-ai inside your ceo-ai-toolkit folder.")
    else:
        text = profile.read_text(encoding="utf-8", errors="replace") if profile.is_file() else ""
        done = bool(text) and "{{" not in text and re.search(r"^setup_done:\s*yes\s*$", text, re.M)
        check("PASS" if done else "FAIL", "Chief of Staff set up", "yes" if done else "not finished",
              'Open your agent in the toolkit folder and say "Start my Chief of Staff".')
    check("PASS" if (toolkit / "handoffs/jobs.md").is_file() else "FAIL", "Job file", "handoffs/jobs.md",
          "Restore handoffs/jobs.md from your toolkit download.")
    check("PASS" if (toolkit / "chief-of-staff/board/board.md").is_file() else "FAIL", "Board", "chief-of-staff/board/board.md",
          "Restore chief-of-staff/board/board.md from your toolkit download.")
    names = {"Email Manager": "email-manager", "Time Manager": "time-manager",
             "Focus Manager": "focus-manager", "CEO Scoreboard": "ceo-scoreboard"}
    have = [n for n, d in names.items() if (toolkit / d / "CLAUDE.md").is_file()]
    miss = [n for n in names if n not in have]
    check("PASS" if not miss else "WARN", "Managers installed", ", ".join(have) or "none",
          "Missing: " + ", ".join(miss) + ". The Chief of Staff does those jobs itself, with fewer tools.")

    # Platform
    if platform.system() != "Darwin":
        check("FAIL", "Mac", platform.system(), "This system needs macOS. Use Basic in INSTALL.md with pasted transcripts instead.")
    else:
        ver = platform.mac_ver()[0] or "0"
        major = int(ver.split(".")[0])
        check("PASS" if major >= 13 else "WARN", "macOS version", ver, "Update to macOS 13 Ventura or later.")

    # Hardware
    chip = platform.machine()
    check("PASS" if chip == "arm64" else "WARN", "Chip", "Apple silicon" if chip == "arm64" else chip,
          "Intel Macs work, but transcription is slower. Use the tiny or base model.")
    code, out = run(["sysctl", "-n", "hw.memsize"])
    gb = int(out) / 1024**3 if code == 0 and out.isdigit() else 0
    check("PASS" if gb >= 16 else "WARN" if gb >= 8 else "FAIL", "Memory", f"{gb:.0f} GB",
          "8 GB is the minimum. With 8 GB, use the base model and close heavy apps during runs.")
    free = shutil.disk_usage(Path.home()).free / 1024**3
    check("PASS" if free >= 5 else "FAIL", "Free disk", f"{free:.0f} GB", "Free up at least 5 GB for the transcriber and its model.")

    # Software
    py = platform.python_version_tuple()
    check("PASS" if (int(py[0]), int(py[1])) >= (3, 9) else "FAIL", "Python", platform.python_version(),
          "Install Command Line Tools (xcode-select --install) or Python 3.9+.")
    check("PASS" if shutil.which("brew") else "WARN", "Homebrew", shutil.which("brew") or "not found",
          "Install from https://brew.sh. It is the easy way to get ffmpeg.")
    check("PASS" if shutil.which("ffmpeg") else "FAIL", "ffmpeg", shutil.which("ffmpeg") or "not found", "brew install ffmpeg")
    tcmd = cfg.get("transcribe_command", "whisper {audio}")
    try:
        tool = shlex.split(tcmd)[0]
    except (ValueError, IndexError):
        tool = tcmd.split()[0] if tcmd.split() else "whisper"
    tpath = shutil.which(os.path.expanduser(tool))
    check("PASS" if tpath else "FAIL", "Transcriber", tpath or f"'{tool}' not found",
          "pip3 install openai-whisper, or set transcribe_command in config.json to the full path of your tool.")

    # AI platform
    claude = shutil.which(str(cfg.get("claude_path") or "").strip() or "claude")
    if not claude:
        check("FAIL", "Claude Code", "not found", "Install Claude Code and sign in. Then run: which claude")
    else:
        code, out = run([claude, "--version"])
        check("PASS" if code == 0 else "FAIL", "Claude Code", out.splitlines()[0] if out else claude,
              "Run claude once in Terminal and sign in.")

    # Access to Voice Memos
    try:
        memos = list(recordings.glob("*.m4a")) if recordings.is_dir() else None
    except PermissionError:
        memos = "denied"
    if memos == "denied":
        check("FAIL", "Read Voice Memos", "permission denied",
              "System Settings > Privacy & Security > Full Disk Access: add your terminal app, then quit and reopen it.")
    elif memos is None:
        check("FAIL", "Read Voice Memos", "folder not visible",
              "Grant Full Disk Access to your terminal. If it is on, open Voice Memos on this Mac once and turn on iCloud sync.")
    else:
        check("PASS" if memos else "WARN", "Read Voice Memos", f"{len(memos)} recordings visible",
              "Record a memo on your watch or phone and wait for it to show in Voice Memos on this Mac.")

    # Install state
    check("PASS" if cfg else "FAIL", "config.json", "found" if cfg else "missing",
          "Run setup/questionnaire.md (or copy config.example.json to config.json).")
    check("PASS" if state_file.exists() else "WARN", "First run done", "yes" if state_file.exists() else "not yet",
          "python3 bonus-watch-to-ai/scripts/voice_memo_ingest.py")
    code, out = run(["launchctl", "list"])
    loaded = "watch-to-ai-team" in out
    check("PASS" if loaded else "WARN", "Schedule loaded", "yes" if loaded else "not yet",
          "Onboarding step 10 (copy the plist to ~/Library/LaunchAgents and load it).")

    fails, warns = results.count("FAIL"), results.count("WARN")
    print(f"\n{len(results)} checks: {results.count('PASS')} pass, {warns} warn, {fails} fail.")
    return 1 if fails else 0


if __name__ == "__main__":
    raise SystemExit(main())
