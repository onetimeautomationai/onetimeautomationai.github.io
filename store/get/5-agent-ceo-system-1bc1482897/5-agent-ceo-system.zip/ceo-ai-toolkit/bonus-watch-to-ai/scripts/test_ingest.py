#!/usr/bin/env python3
"""Self-test for the Watch-to-AI Team Edition script.

Run from the ceo-ai-toolkit folder:
    python3 bonus-watch-to-ai/scripts/test_ingest.py

It builds a throwaway copy of the toolkit in a temp folder with a made-up owner
(Dana Ruiz), a made-up Recordings folder, a fake transcriber and a fake agent.
It never reads your real Voice Memos, never calls a real AI and never changes
your toolkit. Covers test cases TC1 to TC15 and TC30 to TC32 and TC34 in tests/test-cases.md, plus the live-run fixes
LR-D1 (empty claude_path), LR-D2 (damaged state), LR-D3 (skipped memo notice),
LR-D4 (safe quoting), LR-D14 (one ledger summary for each memo), F-W1 (dry run
changes nothing even when every transcript fails) and F-W12 (state saved before the ledger,
idempotent ledger, staging copy removed after an agent failure) and L-W5 (a crash between state and ledger
leaves one hand-off and exactly one ledger row), L-W2 (the ledger summary keeps the waits part), L-W13 (one row per file in one call),
P2-W4 (reply line format and parser), P2-W8 (a bare touch of the board is a failure, retry limit and notice, no duplicate rows after a partial run) and P2-W10 (a made-up clock for the ledger and the agent).
Exit code 0 means every case passed.
"""
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path

SRC = Path(__file__).resolve().parent.parent.parent  # the toolkit folder
SCRIPT = "bonus-watch-to-ai/scripts/voice_memo_ingest.py"
CHECK = "bonus-watch-to-ai/scripts/check_setup.py"
passed, failed = [], []

PROFILE_DONE = "---\ntype: factory\nsetup_done: yes\n---\n\n# Owner profile\n- Name the team should use: Dana Ruiz\n- Time zone: America/Los_Angeles\n"
PROFILE_NOT = "---\ntype: factory\nsetup_done: no\n---\n\n- Name: {{owner_name}}\n"

FAKE_AGENT = """#!/usr/bin/env python3
import sys, os, time
if "--version" in sys.argv:
    print("fake-claude 1.0.0"); sys.exit(0)
prompt = sys.stdin.read()
open(os.environ["FAKE_AGENT_LOG"], "w").write(prompt)
mode = os.environ.get("FAKE_AGENT_MODE", "ok")
if mode == "fail":
    sys.stderr.write("simulated failure"); sys.exit(3)
if mode == "silent":
    print("done"); sys.exit(0)
if mode == "touch":
    os.utime("chief-of-staff/board/board.md", None)
    print("done"); sys.exit(0)
if mode == "writefail":
    with open("chief-of-staff/board/board.md", "a") as f:
        f.write("| IN1 | 2026-11-24 | memo words | needs decision |\\n")
    sys.stderr.write("simulated failure after the board write"); sys.exit(3)
with open("chief-of-staff/board/board.md", "a") as f:
    f.write("| IN1 | 2026-11-24 | memo words | needs decision |\\n")
if mode == "permemo":
    import re
    for name in re.findall(r"Memo file: \\S*?([^/\\s]+\\.md)", prompt):
        print(name + " | handled " + name[11:17] + " alone")
    sys.exit(0)
print("Filed 1 memo | one job for the Time Manager.")
"""


def case(name, ok, detail=""):
    (passed if ok else failed).append(name)
    print(("PASS  " if ok else "FAIL  ") + name + (f"  ({detail})" if detail and not ok else ""))


def build(tmp, setup_done=True, jobs=True):
    tk = tmp / "ceo-ai-toolkit"
    shutil.copytree(SRC, tk, ignore=shutil.ignore_patterns("__pycache__", ".git", "memos", ".DS_Store"))
    (tk / "bonus-watch-to-ai/memos").mkdir(exist_ok=True)
    prof = tk / "chief-of-staff/_shared/owner-profile.md"
    prof.write_text(PROFILE_DONE if setup_done else PROFILE_NOT)
    if not jobs:
        (tk / "handoffs/jobs.md").unlink()
    return tk


def env_files(tmp):
    rec, state = tmp / "Recordings", tmp / "state"
    rec.mkdir(exist_ok=True)
    agent = tmp / "fake_agent.py"
    agent.write_text(FAKE_AGENT)
    agent.chmod(0o755)
    (tmp / "fake_transcribe.py").write_text(
        "import sys\nfrom pathlib import Path\n"
        "p = Path(sys.argv[1])\n"
        "if 'BAD' in p.name:\n    sys.stderr.write('boom'); sys.exit(1)\n"
        "print('  Block Thursday morning for proposals. Done means it is on my calendar.  ')\n")
    cfg = tmp / "config.json"
    cfg.write_text('{"transcribe_command": "%s %s/fake_transcribe.py {audio}", "claude_path": "%s", "claude_args": []}'
                   % (sys.executable, tmp, agent))
    return rec, state, cfg


def run(tk, cfg, rec, state, tmp, mode="ok", *extra, env_extra=None):
    env = dict(os.environ, FAKE_AGENT_MODE=mode, FAKE_AGENT_LOG=str(tmp / "agent_prompt.txt"), **(env_extra or {}))
    return subprocess.run([sys.executable, str(tk / SCRIPT), "--config", str(cfg), "--toolkit", str(tk),
                           "--recordings", str(rec), "--state-dir", str(state), *extra],
                          capture_output=True, text=True, env=env, cwd=str(tk))


def add_rec(rec, name):
    p = rec / name
    p.write_bytes(b"fake audio")
    return p


def tree(tk, skip=("bonus-watch-to-ai/memos", "chief-of-staff/board/board.md")):
    out = {}
    for p in tk.rglob("*"):
        rel = str(p.relative_to(tk))
        if p.is_file() and not any(rel.startswith(s) for s in skip):
            out[rel] = p.read_bytes()
    return out


def main():
    base = Path(tempfile.mkdtemp(prefix="watch-to-ai-test-"))
    try:
        # TC1, TC2: refuses without a finished Chief of Staff or the job file
        for tc, kw, label, said in (("TC1", {"setup_done": False}, "setup not done", "setup is not finished"),
                                    ("TC2", {"jobs": False}, "no jobs file", "handoffs/jobs.md is missing")):
            t = base / tc
            t.mkdir()
            tk = build(t, **kw)
            rec, state, cfg = env_files(t)
            add_rec(rec, "20261124 081500-AAAA.m4a")
            r = run(tk, cfg, rec, state, t)
            case(f"{tc} refuses to run: {label}", r.returncode == 2 and not (state / "state.json").exists()
                 and said in r.stdout and not (t / "agent_prompt.txt").exists()
                 and not list((tk / "bonus-watch-to-ai/memos").glob("*.md")) and not state.exists(), r.stdout[-200:])

        # R3-W9: a refused run (setup not done) creates no state folder and no run.log
        case("R3-W9 a refused run leaves no state folder behind",
             not (base / "TC1/state").exists(), str(list((base / "TC1").iterdir())))

        # Shared good toolkit for TC3 to TC8
        t = base / "main"
        t.mkdir()
        tk = build(t)
        rec, state, cfg = env_files(t)
        old = add_rec(rec, "20261123 090000-OLD0.m4a")
        r = run(tk, cfg, rec, state, t)
        st3 = json.loads((state / "state.json").read_text())
        case("TC3 first run baselines old recordings, files nothing",
             r.returncode == 0 and "First run" in r.stdout and not list((tk / "bonus-watch-to-ai/memos").glob("*.md"))
             and not (t / "agent_prompt.txt").exists() and st3["processed"] == [old.name], str(st3))
        r = run(tk, cfg, rec, state, t)
        case("TC4 no new recording ends quietly", r.returncode == 0 and "No new recordings" in r.stdout and not (t / "agent_prompt.txt").exists()
             and not list((tk / "bonus-watch-to-ai/memos").glob("*.md")))

        new = add_rec(rec, "20261124 081502-NEW1.m4a")
        before_audio = (new.read_bytes(), new.stat().st_mtime)
        before = tree(tk)
        rec_before = {p.name: p.read_bytes() for p in rec.iterdir()}
        board_path = tk / "chief-of-staff/board/board.md"
        board_before = board_path.read_text()
        r = run(tk, cfg, rec, state, t)
        memos = [m for m in (tk / "bonus-watch-to-ai/memos").glob("*.md") if m.name != "ledger.md"]
        prompt = (t / "agent_prompt.txt").read_text() if (t / "agent_prompt.txt").exists() else ""
        body = memos[0].read_text() if memos else ""
        block = body.split("## Transcript\n\n", 1)[1] if "## Transcript\n\n" in body else None
        case("TC5 new memo: memo file has the exact transcript", len(memos) == 1
             and block == "Block Thursday morning for proposals. Done means it is on my calendar.\n"
             and "recorded: 2026-11-24 08:15" in body
             and "source: 20261124 081502-NEW1.m4a" in body and "from: bonus-watch-to-ai" in body, body[:200])
        case("TC6 agent started as Chief of Staff with the handoff files named",
             "chief-of-staff/CLAUDE.md" in prompt and "handoffs/jobs.md" in prompt and "roster.md" in prompt
             and memos and memos[0].name in prompt, prompt[-300:])
        ledger = tk / "bonus-watch-to-ai/memos/ledger.md"
        case("TC7 ledger row written, state advanced",
             r.returncode == 0 and ledger.exists() and memos and memos[0].name in ledger.read_text()
             and "20261124 081502-NEW1.m4a" in (state / "state.json").read_text() and "Filed 1 memo / one job" in ledger.read_text(),
             r.stdout[-200:])
        case("TC8 prompt carries the rules: no questions, red stays red, nothing sent",
             (SRC / "bonus-watch-to-ai/_shared/filing-rules.md").read_text() in prompt
             and "Sending, posting, publishing, paying, buying, deleting and booking with other people are red." in prompt
             and "Nothing is sent." in prompt and "Never ask. Make the best guess and keep going" in prompt
             and 'A line the owner must settle goes to the board\'s "Waiting on you" with the next D number' in prompt
             and "Never ask the owner a question" in prompt)
        after = tree(tk)
        case("TC9 nothing outside memos/ and the board changed, and the board got only the agent's line",
             before == after and {p.name: p.read_bytes() for p in rec.iterdir()} == rec_before and board_path.read_text() == board_before + "| IN1 | 2026-11-24 | memo words | needs decision |\n",
             str([k for k in set(before) | set(after) if before.get(k) != after.get(k)]))
        case("TC10 original recording untouched", (new.read_bytes(), new.stat().st_mtime) == before_audio)

        # TC11 agent failure keeps state, then retry succeeds. TC12 agent that changes nothing also fails
        t2 = base / "fail"
        t2.mkdir()
        tk2 = build(t2)
        rec2, state2, cfg2 = env_files(t2)
        run(tk2, cfg2, rec2, state2, t2)
        add_rec(rec2, "20261124 100000-NEW2.m4a")
        r = run(tk2, cfg2, rec2, state2, t2, "fail")
        case("TC11 and TC32 agent fails: state not advanced, no ledger row, retries later",
             r.returncode == 1 and "NEW2" not in str(json.loads((state2 / "state.json").read_text())["processed"])
             and not (tk2 / "bonus-watch-to-ai/memos/ledger.md").exists()
             and not (state2 / "staging").exists())
        time.sleep(1.1)
        r = run(tk2, cfg2, rec2, state2, t2, "ok")
        led2 = (tk2 / "bonus-watch-to-ai/memos/ledger.md").read_text() if (tk2 / "bonus-watch-to-ai/memos/ledger.md").exists() else ""
        case("TC11b retry at the next check succeeds, one memo file, one ledger row",
             r.returncode == 0 and "NEW2" in (state2 / "state.json").read_text()
             and len(list((tk2 / "bonus-watch-to-ai/memos").glob("2*.md"))) == 1
             and len([l for l in led2.splitlines() if l.startswith("| 2026-11-24-100000-")]) == 1, led2[-200:])
        add_rec(rec2, "20261124 110000-NEW3.m4a")
        time.sleep(1.1)
        r = run(tk2, cfg2, rec2, state2, t2, "silent")
        case("TC12 agent exits 0 but the board did not change: counts as failed",
             r.returncode == 1 and "NEW3" not in str(json.loads((state2 / "state.json").read_text())["processed"])
             and "the board did not change" in r.stdout
             and "| 2026-11-24-110000-" not in (tk2 / "bonus-watch-to-ai/memos/ledger.md").read_text(), r.stdout[-300:])

        # TC13 bad transcript three times is skipped, the good one still goes
        t3 = base / "quarantine"
        t3.mkdir()
        tk3 = build(t3)
        rec3, state3, cfg3 = env_files(t3)
        run(tk3, cfg3, rec3, state3, t3)
        add_rec(rec3, "20261124 120000-BAD1.m4a")
        add_rec(rec3, "20261124 121000-GOOD.m4a")
        codes, states3 = [], []
        good_first = False
        for n in range(3):
            time.sleep(1.1)
            codes.append(run(tk3, cfg3, rec3, state3, t3).returncode)
            states3.append(json.loads((state3 / "state.json").read_text()))
            if n == 0:
                led3 = (tk3 / "bonus-watch-to-ai/memos/ledger.md")
                good_first = ("GOOD" in (state3 / "state.json").read_text() and led3.exists()
                              and "| 2026-11-24-121000-" in led3.read_text())
        bad, good = "20261124 120000-BAD1.m4a", "20261124 121000-GOOD.m4a"
        s1, s2, s3 = states3
        case("TC13 a recording that fails 3 times is skipped, the good one is filed on the first run",
             good_first and codes == [1, 1, 0] and good in s1["processed"] and bad not in s1["processed"]
             and s1["failures"] == {bad: 1} and s2["failures"] == {bad: 2} and bad not in s2["processed"]
             and bad in s3["processed"] and good in s3["processed"] and s3["failures"] == {}, str((codes, states3)))

        # TC14 dry run
        t4 = base / "dry"
        t4.mkdir()
        tk4 = build(t4)
        rec4, state4, cfg4 = env_files(t4)
        run(tk4, cfg4, rec4, state4, t4)
        add_rec(rec4, "20261124 130000-DRY1.m4a")
        before_state = (state4 / "state.json").read_text()
        r = run(tk4, cfg4, rec4, state4, t4, "ok", "--dry-run")
        case("TC14 dry run prints the prompt, changes no state, calls no agent",
             r.returncode == 0 and "Stage 02" in r.stdout and (state4 / "state.json").read_text() == before_state
             and not (t4 / "agent_prompt.txt").exists() and not (tk4 / "bonus-watch-to-ai/memos/ledger.md").exists()
             and len(list((tk4 / "bonus-watch-to-ai/memos").glob("2*.md"))) == 1)

        # TC15 setup checker reads the toolkit
        r = subprocess.run([sys.executable, str(tk / CHECK), "--toolkit", str(tk), "--config", str(cfg),
                            "--recordings", str(rec), "--state-dir", str(state)], capture_output=True, text=True)
        good = ("PASS  Chief of Staff set up: yes" in r.stdout and "FAIL  Chief of Staff" not in r.stdout
                and "PASS  Claude Code" in r.stdout and "FAIL  Claude Code" not in r.stdout)
        fails_good = r.stdout.count("FAIL  ")
        (tk / "chief-of-staff/_shared/owner-profile.md").write_text(PROFILE_NOT)
        r2 = subprocess.run([sys.executable, str(tk / CHECK), "--toolkit", str(tk), "--config", str(cfg),
                             "--recordings", str(rec), "--state-dir", str(state)], capture_output=True, text=True)
        case("TC15 check_setup passes a finished toolkit and fails an unfinished one, the Chief of Staff check drives it",
             good and "FAIL  Chief of Staff set up: not finished" in r2.stdout and r2.returncode == 1
             and r2.stdout.count("FAIL  ") == fails_good + 1, r2.stdout[:200])
        (tk / "chief-of-staff/_shared/owner-profile.md").write_text(PROFILE_DONE)
        os.rename(tk / "chief-of-staff", tk / "chief-of-staff.off")
        r3 = subprocess.run([sys.executable, str(tk / CHECK), "--toolkit", str(tk), "--config", str(cfg),
                             "--recordings", str(rec), "--state-dir", str(state)], capture_output=True, text=True)
        os.rename(tk / "chief-of-staff.off", tk / "chief-of-staff")
        case("TC15 check_setup fails when the Chief of Staff folder is missing",
             "FAIL  Chief of Staff: not found" in r3.stdout and r3.returncode == 1
             and r3.stdout.count("FAIL  ") > fails_good, r3.stdout[:300])

        # LR-D1: shipped config has claude_path "". Empty means unset: find claude on the PATH, or stop with one clear line
        t5 = base / "d1"
        t5.mkdir()
        tk5 = build(t5)
        rec5, state5, cfg5 = env_files(t5)
        agent5 = t5 / "fake_agent.py"
        bindir, emptybin = t5 / "bin", t5 / "emptybin"
        bindir.mkdir()
        emptybin.mkdir()
        (bindir / "claude").write_text(agent5.read_text().replace("#!/usr/bin/env python3", "#!" + sys.executable))
        (bindir / "claude").chmod(0o755)
        cfg5.write_text('{"transcribe_command": "%s %s/fake_transcribe.py {audio}", "claude_path": "", "claude_args": []}'
                        % (sys.executable, t5))
        add_rec(rec5, "20261124 090000-OLD5.m4a")
        r = run(tk5, cfg5, rec5, state5, t5, "ok", env_extra={"PATH": str(emptybin)})
        case("LR-D1 empty claude_path and no claude on the PATH: one clear line, exit 2, nothing saved",
             r.returncode == 2 and "claude was not found" in r.stdout and not (state5 / "state.json").exists()
             and r.stdout.count("Cannot run") == 1, r.stdout[-200:])
        r = run(tk5, cfg5, rec5, state5, t5, "ok", env_extra={"PATH": str(bindir)})
        add_rec(rec5, "20261124 100500-NEW5.m4a")
        r = run(tk5, cfg5, rec5, state5, t5, "ok", env_extra={"PATH": str(bindir)})
        case("LR-D1 empty claude_path is resolved from the PATH and the agent runs",
             r.returncode == 0 and (t5 / "agent_prompt.txt").exists() and "NEW5" in (state5 / "state.json").read_text(), r.stdout[-200:])

        # LR-D2: a damaged state.json is not a first run. Back it up, warn, keep the pending memo
        t6 = base / "d2"
        t6.mkdir()
        tk6 = build(t6)
        rec6, state6, cfg6 = env_files(t6)
        add_rec(rec6, "20261124 090000-OLD6.m4a")
        run(tk6, cfg6, rec6, state6, t6)
        add_rec(rec6, "20261124 101500-NEW6.m4a")
        (state6 / "state.json").write_text('{"processed": ["2026')
        r = run(tk6, cfg6, rec6, state6, t6)
        memos6 = [m for m in (tk6 / "bonus-watch-to-ai/memos").glob("*.md")]
        case("LR-D2 damaged state: backed up, warned, exit 1, not baselined, no recording lost",
             r.returncode == 1 and "damaged" in r.stdout and (state6 / "state.json.bad").read_text() == '{"processed": ["2026'
             and (state6 / "state.json").read_text() == '{"processed": ["2026' and not memos6 and "First run" not in r.stdout, r.stdout[-300:])
        (state6 / "state.json").write_text('{"processed": ["20261124 090000-OLD6.m4a"], "failures": {}}')
        r = run(tk6, cfg6, rec6, state6, t6)
        case("LR-D2 after the owner restores state, the pending memo is filed",
             r.returncode == 0 and "NEW6" in (state6 / "state.json").read_text()
             and (tk6 / "bonus-watch-to-ai/memos/ledger.md").exists())

        # LR-D3: a recording dropped after 3 tries leaves a ledger row and a notice
        t7 = base / "d3"
        t7.mkdir()
        tk7 = build(t7)
        rec7, state7, cfg7 = env_files(t7)
        cfg7.write_text('{"transcribe_command": "%s %s/fake_transcribe.py {audio}", "claude_path": "%s", "claude_args": [],'
                        ' "notify_imessage": true, "notify_number": "+15550100"}' % (sys.executable, t7, t7 / "fake_agent.py"))
        fbin = t7 / "bin"
        fbin.mkdir()
        (fbin / "osascript").write_text("#!%s\nimport sys\nopen(%r, 'a').write(' '.join(sys.argv[1:]) + '\\n')\n" % (sys.executable, str(t7 / "sent.txt")))
        (fbin / "osascript").chmod(0o755)
        envp = {"PATH": str(fbin) + os.pathsep + os.environ.get("PATH", "")}
        run(tk7, cfg7, rec7, state7, t7, env_extra=envp)
        add_rec(rec7, "20261124 120000-BAD7.m4a")
        add_rec(rec7, "20261124 121000-GOOD.m4a")
        for _ in range(3):
            time.sleep(1.1)
            run(tk7, cfg7, rec7, state7, t7, env_extra=envp)
        led7 = (tk7 / "bonus-watch-to-ai/memos/ledger.md").read_text()
        sent7 = (t7 / "sent.txt").read_text() if (t7 / "sent.txt").exists() else ""
        case("LR-D3 a recording skipped after 3 tries gets a ledger row and a notice",
             "20261124 120000-BAD7.m4a" in led7 and "skipped: transcription failed 3 times" in led7 and "skipped 1 recording" in sent7
             and led7.count("BAD7") == 1, led7[-300:] + sent7)

        # LR-D4: paths with spaces, quotes or shell characters stay one argument, nothing runs
        t8 = base / "d4"
        t8.mkdir()
        tk8 = build(t8)
        rec8, _, cfg8 = env_files(t8)
        state8 = t8 / "state dir it's here"
        run(tk8, cfg8, rec8, state8, t8)
        add_rec(rec8, "20261124 140000-a;touch PWNED $(touch PWNED2).m4a")
        r = run(tk8, cfg8, rec8, state8, t8)
        case("LR-D4 a state folder with a space and quote and a hostile file name transcribe safely, nothing runs",
             r.returncode == 0 and "attempt" not in r.stdout and not (tk8 / "PWNED").exists() and not (tk8 / "PWNED2").exists()
             and not (state8 / "PWNED").exists() and len([m for m in (tk8 / "bonus-watch-to-ai/memos").glob("2*.md")]) == 1, r.stdout[-300:])

        # LR-D14: each ledger row gets its own memo's summary
        t9 = base / "d14"
        t9.mkdir()
        tk9 = build(t9)
        rec9, state9, cfg9 = env_files(t9)
        run(tk9, cfg9, rec9, state9, t9)
        add_rec(rec9, "20261124 150000-ONE9.m4a")
        add_rec(rec9, "20261124 160000-TWO9.m4a")
        r = run(tk9, cfg9, rec9, state9, t9, "permemo")
        rows = [l for l in (tk9 / "bonus-watch-to-ai/memos/ledger.md").read_text().splitlines() if l.startswith("| 2026-")]
        case("LR-D14 two memos in one run get two different ledger summaries",
             r.returncode == 0 and len(rows) == 2 and "handled 150000 alone" in rows[0] and "handled 160000 alone" in rows[1],
             str(rows) + r.stdout[-200:])

        # R2-D5: a pipe or newline in a file name cannot break the ledger table
        t10 = base / "d5"
        t10.mkdir()
        sys.path.insert(0, str(SRC / "bonus-watch-to-ai/scripts"))
        import voice_memo_ingest as vmi
        md = t10 / "memos"
        md.mkdir()
        vmi.append_ledger(md, [{"file": "a|b\nc.md", "recorded": "2026-11-24 10:00", "summary": "ok"}])
        rows = [l for l in (md / "ledger.md").read_text().splitlines() if l.startswith("| a")]
        case("R2-D5 a pipe and newline in the memo file name keep one row with four columns",
             len(rows) == 1 and rows[0].count("|") == 5, str(rows))
        # F-W1: a dry run changes nothing, even when every transcript fails (no counts, no skip, no ledger, no notice)
        t11 = base / "fw1"
        t11.mkdir()
        tk11 = build(t11)
        rec11, state11, cfg11 = env_files(t11)
        cfg11.write_text('{"transcribe_command": "%s %s/fake_transcribe.py {audio}", "claude_path": "%s", "claude_args": [],'
                         ' "notify_imessage": true, "notify_number": "+15550100"}' % (sys.executable, t11, t11 / "fake_agent.py"))
        fbin11 = t11 / "bin"
        fbin11.mkdir()
        (fbin11 / "osascript").write_text("#!%s\nimport sys\nopen(%r, 'a').write(' '.join(sys.argv[1:]) + '\\n')\n" % (sys.executable, str(t11 / "sent.txt")))
        (fbin11 / "osascript").chmod(0o755)
        env11 = {"PATH": str(fbin11) + os.pathsep + os.environ.get("PATH", "")}
        run(tk11, cfg11, rec11, state11, t11, env_extra=env11)
        add_rec(rec11, "20261124 120000-BAD1.m4a")
        state_before = (state11 / "state.json").read_text()
        outs = [run(tk11, cfg11, rec11, state11, t11, "ok", "--dry-run", env_extra=env11) for _ in range(4)]
        case("TC30 and F-W1 dry run with only a failing recording: no failure count, no skip, no ledger, no notice, no agent",
             all(o.returncode == 0 for o in outs) and (state11 / "state.json").read_text() == state_before
             and not (tk11 / "bonus-watch-to-ai/memos/ledger.md").exists() and not (t11 / "sent.txt").exists()
             and not (t11 / "agent_prompt.txt").exists() and "giving up" not in "".join(o.stdout for o in outs)
             and not (state11 / "staging").exists(), outs[-1].stdout[-300:])
        add_rec(rec11, "20261124 121000-GOOD.m4a")
        r = run(tk11, cfg11, rec11, state11, t11, "ok", "--dry-run", env_extra=env11)
        case("F-W1 dry run with a good and a failing recording prints the prompt and still changes no state",
             r.returncode == 0 and "Stage 02" in r.stdout and (state11 / "state.json").read_text() == state_before
             and not (t11 / "agent_prompt.txt").exists() and not (t11 / "sent.txt").exists())

        # F-W12: state is saved before the ledger row, so a crash in between cannot hand a memo over twice
        t12 = base / "fw12"
        t12.mkdir()
        tk12 = build(t12)
        rec12, state12, cfg12 = env_files(t12)
        run(tk12, cfg12, rec12, state12, t12)
        add_rec(rec12, "20261124 170000-CRSH.m4a")
        calls = []
        real_agent, real_ledger, real_argv = vmi.run_agent, vmi.append_ledger, sys.argv

        def agent_ok(cfg, toolkit, prompt):
            calls.append(1)
            return "ok"

        def ledger_crash(memos_dir, rows):
            raise OSError("simulated crash before the ledger row")
        vmi.run_agent, vmi.append_ledger = agent_ok, ledger_crash
        sys.argv = ["x", "--config", str(cfg12), "--toolkit", str(tk12), "--recordings", str(rec12), "--state-dir", str(state12)]
        crashed = False
        try:
            vmi.main()
        except OSError:
            crashed = True
        finally:
            vmi.append_ledger = real_ledger
        saved = (state12 / "state.json").read_text()
        try:
            code = vmi.main()
        finally:
            vmi.run_agent, sys.argv = real_agent, real_argv
        case("TC31 crash after the agent run: state already has the recording, the next run hands over nothing again",
             crashed and "CRSH" in saved and "pending_ledger" in saved and code == 0 and len(calls) == 1, f"{crashed} {saved} {code} {calls}")
        led12 = (tk12 / "bonus-watch-to-ai/memos/ledger.md").read_text() if (tk12 / "bonus-watch-to-ai/memos/ledger.md").exists() else ""
        memo12 = [m.name for m in (tk12 / "bonus-watch-to-ai/memos").glob("2*.md")]
        case("L-W5 after that crash the next run writes the missing ledger row, exactly one, and no second hand-off",
             len(memo12) == 1 and led12.count(f"| {memo12[0]} |") == 1 and "pending_ledger" not in (state12 / "state.json").read_text()
             and len(calls) == 1, led12[-200:])
        vmi.run_agent = agent_ok
        sys.argv = ["x", "--config", str(cfg12), "--toolkit", str(tk12), "--recordings", str(rec12), "--state-dir", str(state12)]
        try:
            vmi.main()
        finally:
            vmi.run_agent, sys.argv = real_agent, real_argv
        case("L-W5 a third run adds no row and no hand-off",
             (tk12 / "bonus-watch-to-ai/memos/ledger.md").exists()
             and (tk12 / "bonus-watch-to-ai/memos/ledger.md").read_text().count(f"| {memo12[0]} |") == 1 and len(calls) == 1)
        md12 = t12 / "memos12"
        md12.mkdir()
        row = {"file": "2026-11-24-170000-abcd.md", "recorded": "2026-11-24 17:00", "summary": "ok"}
        vmi.append_ledger(md12, [row])
        vmi.append_ledger(md12, [row])
        case("TC31 the same memo handed over twice leaves one ledger row",
             len([l for l in (md12 / "ledger.md").read_text().splitlines() if l.startswith("| 2026-")]) == 1)
        md13 = t12 / "memos13"
        md13.mkdir()
        vmi.append_ledger(md13, [row, dict(row)])
        case("L-W13 two rows for one file in a single call write one row",
             len([l for l in (md13 / "ledger.md").read_text().splitlines() if l.startswith("| 2026-")]) == 1)
        # L-W2: the waits part of the reply is never cut
        done_part = "Filed the draft reply for the Thursday meeting at handoffs/drafts/tom-thursday.md and updated the board with the full list of details. " * 3
        line = f"2026-11-24-081502-ab12.md | {done_part}Waits on you: say yes to send it."
        out = vmi.summaries_by_memo(line, [{"memo": Path("2026-11-24-081502-ab12.md")}])["2026-11-24-081502-ab12.md"]
        out_whole = vmi.summaries_by_memo(f"{done_part}Waits on you: say yes to send it.", [{"memo": Path("none.md")}])["none.md"]
        case("L-W2 a long reply line keeps the waits part and stays on one line within 400 characters",
             out.endswith("Waits on you: say yes to send it.") and len(out) <= 400 and "|" not in out
             and out_whole.endswith("Waits on you: say yes to send it.") and len(out_whole) <= 400, out)
        # P2-W4: the reply line format and the parser agree
        stage02 = (SRC / "bonus-watch-to-ai/stages/02_hand-off/CONTEXT.md").read_text()
        ex = "2026-11-24-081502-ab12.md | Time Manager blocked Thursday 9:00 to 11:00 for proposals, result chief-of-staff/runs/2026-11-24-watch-memos/03_dispatch.md | nothing"
        fmt = "`<memo file name> | <what was done, by whom, result file path> | <what waits on the owner>`"
        case("P2-W4 stage 02 states the exact reply format, held memos and one example line, and the example parses",
             fmt in stage02 and ex in stage02 and "held memo" in stage02.lower() and "no folder before" in stage02
             and ex.count("|") == 2 and vmi.summaries_by_memo(ex, [{"memo": Path("2026-11-24-081502-ab12.md")}])["2026-11-24-081502-ab12.md"]
             == "Time Manager blocked Thursday 9:00 to 11:00 for proposals, result chief-of-staff/runs/2026-11-24-watch-memos/03_dispatch.md. Waits: nothing")
        reply = ("2026-11-24-081502-ab12.md | Email Manager drafted the reply, result handoffs/drafts/tom.md | the send, your list A1\n"
                 "chief/2026-11-24-090000-cd34.md | Held for protected time, result chief-of-staff/board/board.md | the hold until 10:00 | extra\n"
                 "2026-11-24-100000-ef56.md | no pipes here")
        items3 = [{"memo": Path(n)} for n in ("2026-11-24-081502-ab12.md", "2026-11-24-090000-cd34.md", "2026-11-24-100000-ef56.md")]
        got = vmi.summaries_by_memo(reply, items3)
        case("P2-W4 the parser keeps the done part and the waiting part, ignores a folder before the name, keeps one line with no extra pipe, falls back to the whole reply",
             got["2026-11-24-081502-ab12.md"] == "Email Manager drafted the reply, result handoffs/drafts/tom.md. Waits: the send, your list A1"
             and got["2026-11-24-090000-cd34.md"].startswith("Held for protected time, result chief-of-staff/board/board.md. Waits: the hold until 10:00")
             and all("|" not in v and "\n" not in v for v in got.values())
             and got["2026-11-24-100000-ef56.md"] == "no pipes here" or got["2026-11-24-100000-ef56.md"] == vmi.clip_summary(reply), str(got))
        # P2-W10: a made-up clock reaches the ledger and the agent prompt, a bad one is refused, the stage names the options
        t13 = base / "p2w10"
        t13.mkdir()
        tk13 = build(t13)
        rec13, state13, cfg13 = env_files(t13)
        run(tk13, cfg13, rec13, state13, t13)
        add_rec(rec13, "20261124 081502-CLK1.m4a")
        r = run(tk13, cfg13, rec13, state13, t13, "ok", "--now", "2026-11-24 08:20")
        led13 = (tk13 / "bonus-watch-to-ai/memos/ledger.md").read_text() if (tk13 / "bonus-watch-to-ai/memos/ledger.md").exists() else ""
        prompt13 = (t13 / "agent_prompt.txt").read_text() if (t13 / "agent_prompt.txt").exists() else ""
        case("P2-W10 --now sets the ledger Handed over column and a Clock line in the prompt",
             r.returncode == 0 and "| 2026-11-24 08:15 | 2026-11-24 08:20 |" in led13 and "\nClock: 2026-11-24 08:20" in prompt13, led13[-200:] + r.stdout[-200:])
        add_rec(rec13, "20261124 090000-CLK2.m4a")
        rbad = run(tk13, cfg13, rec13, state13, t13, "ok", "--now", "tomorrow")
        case("P2-W10 a bad --now is refused and changes nothing",
             rbad.returncode == 2 and "CLK2" not in (state13 / "state.json").read_text(), rbad.stderr[-200:])
        r = run(tk13, cfg13, rec13, state13, t13, "ok")
        led13b = (tk13 / "bonus-watch-to-ai/memos/ledger.md").read_text()
        row2 = [l for l in led13b.splitlines() if "-090000-" in l][0]
        case("P2-W10 without --now the ledger uses the real clock and the prompt has no Clock line",
             r.returncode == 0 and "\nClock: " not in (t13 / "agent_prompt.txt").read_text()
             and f"| {time.strftime('%Y-%m-%d')} " in row2, row2)
        case("P2-W10 stage 02 starts the run with --today and --now when the batch has a Clock line",
             '--today YYYY-MM-DD --now "YYYY-MM-DD HH:MM"' in stage02 and "`Clock:` line" in stage02)

        # P2-W8: a bare touch of the board is not a success, failures are limited and announced, a partial run is not replayed blind
        t14 = base / "p2w8"
        t14.mkdir()
        tk14 = build(t14)
        rec14, state14, cfg14 = env_files(t14)
        cfg14.write_text('{"transcribe_command": "%s %s/fake_transcribe.py {audio}", "claude_path": "%s", "claude_args": [],'
                         ' "notify_imessage": true, "notify_number": "+15550100"}' % (sys.executable, t14, t14 / "fake_agent.py"))
        fbin14 = t14 / "bin"
        fbin14.mkdir()
        (fbin14 / "osascript").write_text("#!%s\nimport sys\nopen(%r, 'a').write(' '.join(sys.argv[1:]) + '\\n')\n" % (sys.executable, str(t14 / "sent.txt")))
        (fbin14 / "osascript").chmod(0o755)
        env14 = {"PATH": str(fbin14) + os.pathsep + os.environ.get("PATH", "")}
        run(tk14, cfg14, rec14, state14, t14, env_extra=env14)
        add_rec(rec14, "20261124 100000-TCH1.m4a")
        r = run(tk14, cfg14, rec14, state14, t14, "touch", env_extra=env14)
        st14 = json.loads((state14 / "state.json").read_text())
        case("P2-W8 an agent that only touches the board fails the run, state not advanced, one notice",
             r.returncode == 1 and "TCH1" not in str(st14["processed"]) and "board did not change" in r.stdout
             and "agent run failed" in (t14 / "sent.txt").read_text() and st14["agent_failures"] == {"20261124 100000-TCH1.m4a": 1}
             and not (tk14 / "bonus-watch-to-ai/memos/ledger.md").exists(), r.stdout[-300:])
        r = run(tk14, cfg14, rec14, state14, t14, "writefail", env_extra=env14)
        st14 = json.loads((state14 / "state.json").read_text())
        case("P2-W8 an agent that writes the board and then exits non zero fails the run and is recorded as partial",
             r.returncode == 1 and st14["agent_partial"] == ["20261124 100000-TCH1.m4a"] and "board was written before the failure" in r.stdout
             and st14["agent_failures"] == {"20261124 100000-TCH1.m4a": 2}, r.stdout[-300:])
        r = run(tk14, cfg14, rec14, state14, t14, "fail", env_extra=env14)
        prompt14 = (t14 / "agent_prompt.txt").read_text()
        st14 = json.loads((state14 / "state.json").read_text())
        led14 = (tk14 / "bonus-watch-to-ai/memos/ledger.md").read_text() if (tk14 / "bonus-watch-to-ai/memos/ledger.md").exists() else ""
        sent14 = (t14 / "sent.txt").read_text()
        case("P2-W8 the retry prompt warns of the earlier partial run, the third failure gives up with one ledger row and a notice",
             "may already have written rows for this memo" in prompt14 and r.returncode == 0 and "20261124 100000-TCH1.m4a" in st14["processed"]
             and led14.count("skipped: the agent run failed 3 times") == 1 and "gave up on 1 memo" in sent14
             and not st14.get("agent_failures") and not st14.get("agent_partial"), led14[-300:] + sent14)
        case("F-W9 stage 02 names the log line for one memo in the singular",
             "Handed 1 Watch memo to the Chief of Staff" in stage02 and "Handed 1 Watch memos" not in stage02)
    finally:
        shutil.rmtree(base, ignore_errors=True)
    print(f"\n{len(passed)} passed, {len(failed)} failed.")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
