#!/usr/bin/env python3
"""Watch-to-AI Team Edition. Capture and hand-off.

Finds new Voice Memos recordings, transcribes them on your Mac, saves each
transcript as a memo file in bonus-watch-to-ai/memos/, then starts your agent as
the Chief of Staff with the stage 02 contract. The Chief of Staff takes it from
there: board, decision log, jobs for the managers.

It refuses to run until the Chief of Staff is set up. State only moves forward
when the agent run succeeds. The first run marks every existing recording as
seen and processes nothing.

Usage (from the ceo-ai-toolkit folder):
    python3 bonus-watch-to-ai/scripts/voice_memo_ingest.py
Test options:
    --dry-run            make the memo files and print the prompt, change no state
    --config PATH        use another config file
    --toolkit PATH       use another toolkit folder
    --recordings PATH    read recordings from another folder
    --state-dir PATH     keep state and logs in another folder
    --now "YYYY-MM-DD HH:MM"  use a made-up clock for the ledger "Handed over" column and tell the agent to use it (tests, replays)
Standard library only.
"""
import argparse
import hashlib
import json
import os
import re
import shlex
import shutil
import subprocess
import sys
from datetime import datetime
from pathlib import Path

HERE = Path(__file__).resolve().parent.parent  # the bonus-watch-to-ai folder
DEFAULT_RECORDINGS = Path.home() / "Library/Group Containers/group.com.apple.VoiceMemos.shared/Recordings"
DEFAULT_STATE_DIR = Path.home() / ".local/share/watch-to-ai-team"
QUARANTINE_AFTER = 3
CLOCK = None  # a datetime from --now, else the real clock
DEFAULT_CLAUDE_ARGS = [
    "--permission-mode", "acceptEdits", "--allowedTools",
    "Bash(python3 chief-of-staff/scripts/*)", "Bash(python3 time-manager/scripts/*)",
    "Bash(python3 email-manager/scripts/*)", "Bash(python3 focus-manager/scripts/*)",
    "Bash(python3 ceo-scoreboard/scripts/*)",
]


class StateDamaged(Exception):
    """state.json exists but cannot be read."""

STATE_DIR = DEFAULT_STATE_DIR
LOG_FILE = STATE_DIR / "run.log"


def log(msg):
    line = f"[{datetime.now():%Y-%m-%d %H:%M:%S}] {msg}"
    print(line, flush=True)
    try:
        if not STATE_DIR.is_dir():
            return
        with open(LOG_FILE, "a") as f:
            f.write(line + "\n")
    except OSError:
        pass


def toolkit_problems(toolkit):
    """Why the Chief of Staff cannot take memos yet. An empty list means ready."""
    problems = []
    profile = toolkit / "chief-of-staff/_shared/owner-profile.md"
    if not (toolkit / "chief-of-staff/CLAUDE.md").is_file():
        problems.append("chief-of-staff/CLAUDE.md is missing. Keep this folder inside your ceo-ai-toolkit folder")
    if not profile.is_file():
        problems.append("chief-of-staff/_shared/owner-profile.md is missing")
    else:
        text = profile.read_text(encoding="utf-8", errors="replace")
        if "{{" in text or not re.search(r"^setup_done:\s*yes\s*$", text, re.M):
            problems.append("your Chief of Staff setup is not finished. Say \"Start my Chief of Staff\" first")
    if not (toolkit / "handoffs/jobs.md").is_file():
        problems.append("handoffs/jobs.md is missing")
    if not (toolkit / "chief-of-staff/board/board.md").is_file():
        problems.append("chief-of-staff/board/board.md is missing")
    return problems


def load_config(path):
    try:
        cfg = json.loads(Path(path).read_text())
    except Exception as e:
        sys.exit(f"Cannot read config at {path}: {e}. Copy config.example.json to config.json first.")
    # An empty or missing claude_path means "not set": look for claude on the PATH.
    configured = str(cfg.get("claude_path") or "").strip()
    cfg["claude_path"] = shutil.which(configured) if configured else shutil.which("claude")
    cfg["claude_path_set"] = configured
    cfg.setdefault("claude_args", list(DEFAULT_CLAUDE_ARGS))
    cfg.setdefault("agent_timeout_seconds", 1800)
    cfg.setdefault("notify_imessage", False)
    cfg.setdefault("notify_number", "")
    if not cfg.get("transcribe_command"):
        sys.exit("config.json needs transcribe_command.")
    return cfg


def load_state():
    """None when there is no state file (a first run). StateDamaged when it exists but is unreadable."""
    state_file = STATE_DIR / "state.json"
    if not state_file.exists():
        return None
    try:
        state = json.loads(state_file.read_text())
        if not isinstance(state, dict):
            raise ValueError("not a JSON object")
        return state
    except Exception as e:
        try:
            shutil.copy2(state_file, STATE_DIR / "state.json.bad")
        except OSError:
            pass
        raise StateDamaged(str(e))


def save_state(state):
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    tmp = (STATE_DIR / "state.json").with_suffix(".tmp")
    tmp.write_text(json.dumps(state, indent=2))
    tmp.replace(STATE_DIR / "state.json")


def reconcile_ledger(state, memos_dir):
    """Write ledger rows a crashed run left pending in state, then clear them. Rows already written are skipped."""
    pending = state.get("pending_ledger") or []
    if not pending:
        return
    memos_dir.mkdir(parents=True, exist_ok=True)
    append_ledger(memos_dir, pending)
    state.pop("pending_ledger", None)
    save_state(state)
    log(f"Wrote {len(pending)} ledger row(s) left pending by an earlier run.")


def current_recordings(recordings):
    out = {}
    if not recordings.is_dir():
        sys.exit(f"Cannot see {recordings}. Grant Full Disk Access to your terminal or Python. See README.")
    try:
        files = list(recordings.glob("*.m4a"))
    except PermissionError:
        sys.exit("Permission denied on the Voice Memos folder. Grant Full Disk Access. See README.")
    for p in files:
        try:
            st = p.stat()
            out[p.name] = {"mtime": int(st.st_mtime), "size": st.st_size}
        except OSError:
            pass
    return out


def recorded_dt(name, mtime):
    m = re.match(r"(\d{8})\s+(\d{6})", name)
    if m:
        try:
            return datetime.strptime(m.group(1) + m.group(2), "%Y%m%d%H%M%S")
        except ValueError:
            pass
    return datetime.fromtimestamp(mtime)


def transcribe(cfg, audio):
    """Run the configured command. Accepts stdout text or a {stem}.txt file in the output dir."""
    outdir = audio.parent
    # An argument list, not a shell string, so a path with spaces or quotes stays one argument.
    cmd = [os.path.expanduser(t.replace("{audio}", str(audio)).replace("{outdir}", str(outdir)))
           for t in shlex.split(cfg["transcribe_command"])]
    r = subprocess.run(cmd, capture_output=True, text=True, timeout=3600)
    if r.returncode != 0:
        raise RuntimeError(f"transcribe command failed: {(r.stderr or r.stdout)[:300]}")
    txt_file = outdir / (audio.stem + ".txt")
    text = txt_file.read_text().strip() if txt_file.exists() else r.stdout.strip()
    if not text:
        raise RuntimeError("empty transcript")
    return text


def write_memo(memos_dir, name, rec, text):
    """Save the transcript as a memo file. The name is the same on every retry for the same recording."""
    tag = hashlib.sha1(name.encode("utf-8")).hexdigest()[:4]
    path = memos_dir / f"{rec:%Y-%m-%d-%H%M%S}-{tag}.md"
    path.write_text(
        "---\n"
        "from: bonus-watch-to-ai\n"
        f"recorded: {rec:%Y-%m-%d %H:%M}\n"
        f"source: {name}\n"
        "---\n\n"
        "## Transcript\n\n"
        f"{text}\n"
    )
    return path


def handed_time():
    return CLOCK or datetime.now()


def append_ledger(memos_dir, rows):
    ledger = memos_dir / "ledger.md"
    if not ledger.exists():
        ledger.write_text(
            "# Memo ledger\n\n"
            "One row for each memo handed to the Chief of Staff, and one for each recording skipped after 3 failed tries. Written by the script. In Basic mode (no script) the agent adds the row. Do not edit rows by hand.\n\n"
            "| Memo file | Recorded | Handed over | Run summary |\n|---|---|---|---|\n"
        )
    have = ledger.read_text()
    with open(ledger, "a") as f:
        for r in rows:
            fname = " ".join(str(r['file']).split()).replace("|", "/")
            if f"| {fname} |" in have:
                continue  # already written by an earlier run that crashed after this row
            f.write(f"| {fname} | {r['recorded']} | {handed_time():%Y-%m-%d %H:%M} | {r['summary']} |\n")
            have += f"| {fname} |"  # a second row for the same file in this call is skipped too


SUMMARY_CAP = 400


def clip_summary(text, cap=SUMMARY_CAP):
    """One line of at most cap characters. Too long: shorten the done part and keep the part that says what waits."""
    text = " ".join(text.split()).replace("|", "/")
    if len(text) <= cap:
        return text
    i = text.lower().rfind("wait")
    if i <= 0:
        return text[:cap]
    head, tail = text[:i].rstrip(), text[i:][:cap - 8]
    return head[:cap - len(tail) - 4].rstrip() + "... " + tail


def summaries_by_memo(summary, items):
    """Match the agent's reply lines to memo files. The line format is
    `<memo file name> | <what was done, by whom, result file path> | <what waits on the owner>`.
    The ledger summary is the done part, then `Waits:` and the waiting part. No line for a memo: the whole reply."""
    whole = clip_summary(summary)
    out = {}
    for it in items:
        name = it["memo"].name
        out[name] = whole
        for line in summary.splitlines():
            head, _, rest = line.partition("|")
            if os.path.basename(head.strip().strip("`")) != name:
                continue
            done, _, waits = (p.strip() for p in rest.partition("|"))
            text = f"{done.rstrip('. ')}. Waits: {waits}" if (done and waits) else (done or waits)
            out[name] = clip_summary(text) or whole
            break
    return out


def notify(cfg, text):
    if not cfg["notify_imessage"] or not cfg["notify_number"]:
        return
    script = (
        'on run argv\n'
        'tell application "Messages"\n'
        'set svc to 1st service whose service type = iMessage\n'
        'send (item 2 of argv) to buddy (item 1 of argv) of svc\n'
        'end tell\nend run'
    )
    try:
        subprocess.run(["osascript", "-e", script, cfg["notify_number"], text[:500]],
                       capture_output=True, text=True, timeout=60)
    except Exception as e:
        log(f"Notification failed: {e}")


def build_prompt(toolkit, items, partial=()):
    prompt = (HERE / "stages/02_hand-off/CONTEXT.md").read_text() + "\n\n" + (HERE / "_shared/filing-rules.md").read_text()
    lines = [prompt, "", "## This batch", ""]
    for it in items:
        rel = os.path.relpath(it["memo"], toolkit)
        note = (" An earlier run stopped part way and may already have written rows for this memo. "
                "Look for this memo file name on the board first and add no second Inbox row." if it["name"] in partial else "")
        lines.append(f"- Recorded {it['recorded']}. Memo file: {rel}.{note}" if note else f"- Recorded {it['recorded']}. Memo file: {rel}")
    if CLOCK:
        lines.append(f"Clock: {CLOCK:%Y-%m-%d %H:%M}")
    lines += ["", "Start with chief-of-staff/CLAUDE.md. Then read each memo file and follow the instructions above."]
    return "\n".join(lines)


class AgentFailed(Exception):
    """The agent run did not count. board_changed is True when the board was written before the failure."""
    def __init__(self, msg, board_changed=False):
        super().__init__(msg)
        self.board_changed = board_changed


def run_agent(cfg, toolkit, prompt):
    board = toolkit / "chief-of-staff/board/board.md"
    def board_stamp():
        try:
            return hashlib.sha1(board.read_bytes()).hexdigest()  # content, so a bare touch does not count
        except OSError:
            return None
    before = board_stamp()
    cmd = [cfg["claude_path"], "-p"] + cfg["claude_args"]
    r = subprocess.run(cmd, input=prompt, capture_output=True, text=True,
                       cwd=str(toolkit), timeout=cfg["agent_timeout_seconds"])
    after = board_stamp()
    if r.returncode != 0:
        raise AgentFailed(f"claude exited {r.returncode}: {(r.stderr or r.stdout)[:300]}", after not in (None, before))
    if after in (None, before):
        raise AgentFailed("claude finished but the board did not change, memos stay unprocessed for the next run")
    return r.stdout.strip()


def main():
    global STATE_DIR, LOG_FILE
    ap = argparse.ArgumentParser(description="Watch-to-AI Team Edition")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--config", default=os.environ.get("WATCH_TO_AI_CONFIG", str(HERE / "config.json")))
    ap.add_argument("--toolkit", default=str(HERE.parent))
    ap.add_argument("--recordings", default=str(DEFAULT_RECORDINGS))
    ap.add_argument("--state-dir", default=str(DEFAULT_STATE_DIR))
    ap.add_argument("--now", default="")
    args = ap.parse_args()
    global CLOCK
    CLOCK = None
    if args.now:
        try:
            CLOCK = datetime.strptime(args.now.strip(), "%Y-%m-%d %H:%M")
        except ValueError:
            ap.error('--now takes "YYYY-MM-DD HH:MM"')

    STATE_DIR = Path(args.state_dir)
    LOG_FILE = STATE_DIR / "run.log"
    toolkit = Path(args.toolkit).resolve()
    staging = STATE_DIR / "staging"
    memos_dir = toolkit / "bonus-watch-to-ai" / "memos"

    problems = toolkit_problems(toolkit)
    if problems:
        for p in problems:
            log(f"Cannot run: {p}.")
        log("Team Edition works only with the 5-Agent CEO System and a finished Chief of Staff. Nothing was processed.")
        return 2
    STATE_DIR.mkdir(parents=True, exist_ok=True)

    cfg = load_config(args.config)
    if not cfg["claude_path"] and not args.dry_run:
        where = f"claude_path '{cfg['claude_path_set']}' is not a program" if cfg["claude_path_set"] else "claude was not found on the PATH"
        log(f"Cannot run: {where}. Run `which claude` in Terminal and put that path in config.json as claude_path. Nothing was processed.")
        return 2
    now = current_recordings(Path(args.recordings))
    try:
        state = load_state()
    except StateDamaged as e:
        msg = (f"state.json is damaged ({e}). A copy is saved as state.json.bad. Nothing was processed and no recording was marked as seen. "
               "Restore state.json from that copy, or delete it to start over with a new first run.")
        log(f"Cannot run: {msg}")
        notify(cfg, "Watch-to-AI: state file damaged, memos paused. See run.log.")
        return 1
    if state is None:
        if args.dry_run:
            log(f"Dry run. First run would mark {len(now)} existing recordings as seen. Nothing processed.")
            return 0
        save_state({"processed": sorted(now), "failures": {}})
        log(f"First run. Marked {len(now)} existing recordings as seen. Nothing processed.")
        return 0
    if not args.dry_run:
        reconcile_ledger(state, memos_dir)
    processed = set(state.get("processed", []))
    failures = state.get("failures", {})
    new = sorted(n for n in now if n not in processed)
    if not new:
        log("No new recordings.")
        return 0
    log(f"{len(new)} new recording(s).")
    if staging.exists():
        shutil.rmtree(staging)
    staging.mkdir(parents=True)
    memos_dir.mkdir(exist_ok=True)
    items, quarantined = [], []
    for name in new:
        src = Path(args.recordings) / name
        dst = staging / name.replace(" ", "_")
        try:
            shutil.copy2(src, dst)
            text = transcribe(cfg, dst)
        except Exception as e:
            if args.dry_run:
                log(f"{name}: {e} (dry run, not counted)")
                continue
            failures[name] = failures.get(name, 0) + 1
            log(f"{name}: {e} (attempt {failures[name]})")
            if failures[name] >= QUARANTINE_AFTER:
                quarantined.append(name)
                log(f"{name}: giving up after {QUARANTINE_AFTER} tries.")
            continue
        rec = recorded_dt(name, now[name]["mtime"])
        memo = write_memo(memos_dir, name, rec, text)
        items.append({"name": name, "recorded": rec.strftime("%Y-%m-%d %H:%M"), "memo": memo})
    if args.dry_run:
        # A dry run stops here: no failure counts, no skips, no ledger rows, no notices, no state.
        if items:
            print(build_prompt(toolkit, items, ()))
        shutil.rmtree(staging, ignore_errors=True)
        log(f"Dry run. {len(items)} memo file(s) written. State not changed.")
        return 0
    handed, agent_skipped, agent_failed = [], [], False
    agent_failures = state.get("agent_failures", {})
    partial = set(state.get("agent_partial", []))
    if items:
        prompt = build_prompt(toolkit, items, partial)
        try:
            summary = run_agent(cfg, toolkit, prompt)
        except Exception as e:
            agent_failed = True
            changed = getattr(e, "board_changed", False)
            for i in items:
                agent_failures[i["name"]] = agent_failures.get(i["name"], 0) + 1
                if changed:
                    partial.add(i["name"])
                if agent_failures[i["name"]] >= QUARANTINE_AFTER:
                    agent_skipped.append(i)
            tries = max(agent_failures[i["name"]] for i in items)
            log(f"Agent run failed (try {tries} of {QUARANTINE_AFTER}), will retry at the next check: {e}")
            if changed:
                log("The board was written before the failure. The retry tells the agent to check the board first.")
            if agent_skipped:
                log(f"Giving up on {len(agent_skipped)} memo(s) after {QUARANTINE_AFTER} failed agent runs.")
                processed.update(i["name"] for i in agent_skipped)
        else:
            processed.update(i["name"] for i in items)
            handed = items
            log("Agent run succeeded.")
    processed.update(quarantined)
    # State first, with the ledger rows still to write saved beside it. A crash in between never hands the same
    # memo over twice, and the next run writes the pending rows (reconcile_ledger), so each memo gets one row.
    rows = []
    if handed:
        per_memo = summaries_by_memo(summary, handed)
        rows += [{"file": i["memo"].name, "recorded": i["recorded"], "summary": per_memo[i["memo"].name]} for i in handed]
    rows += [{"file": n, "recorded": recorded_dt(n, now[n]["mtime"]).strftime("%Y-%m-%d %H:%M"),
              "summary": f"skipped: transcription failed {QUARANTINE_AFTER} times, recording not handed over"} for n in quarantined]
    rows += [{"file": i["memo"].name, "recorded": i["recorded"],
              "summary": f"skipped: the agent run failed {QUARANTINE_AFTER} times, memo file kept in memos/, not handed over. Waits: say Watch memo with this file to hand it over"} for i in agent_skipped]
    new_state = {"processed": sorted(processed), "failures": {k: v for k, v in failures.items() if k not in processed}}
    if agent_failures or partial:
        new_state["agent_failures"] = {k: v for k, v in agent_failures.items() if k not in processed}
        new_state["agent_partial"] = sorted(n for n in partial if n not in processed)
    if rows:
        new_state["pending_ledger"] = rows
    save_state(new_state)
    shutil.rmtree(staging, ignore_errors=True)
    if rows:
        append_ledger(memos_dir, rows)
        new_state.pop("pending_ledger")
        save_state(new_state)
    if handed:
        notify(cfg, f"Watch memos handed to your Chief of Staff: {len(handed)}. Say morning, or check my memos.")
    if quarantined:
        notify(cfg, f"Watch-to-AI skipped {len(quarantined)} recording(s) after {QUARANTINE_AFTER} failed tries. See memos/ledger.md.")
    if agent_skipped:
        notify(cfg, f"Watch-to-AI gave up on {len(agent_skipped)} memo(s) after {QUARANTINE_AFTER} failed agent runs. See memos/ledger.md.")
    elif agent_failed:
        notify(cfg, "Watch-to-AI: the agent run failed, memos will retry at the next check. See run.log.")
    return 0 if not (set(new) - processed) else 1


if __name__ == "__main__":
    sys.exit(main())
