# Setup questionnaire

Used by onboarding step 7. Ask these one at a time and write each answer into `config.json` (copied from `config.example.json`).

1. Which transcription tool will you use? Set `transcribe_command`. `{audio}` is the recording and `{outdir}` is its folder. The command runs without a shell, so a path with a space in it needs quotes. The default uses openai-whisper.
2. Where is `claude`? Run `which claude`. Set `claude_path` only if launchd cannot find it.
3. What may the agent run while you are away? The default `claude_args` allow file edits and the toolkit's own scripts in `chief-of-staff/scripts/`, `time-manager/scripts/`, `email-manager/scripts/`, `focus-manager/scripts/` and `ceo-scoreboard/scripts/`. If you set `claude_args` before 0.1.5, add the manager folders yourself. To let it search the web, add `"WebSearch", "WebFetch"` after `--allowedTools`. Add only what you trust it to run while you are away. Sending, posting, paying, buying, deleting and booking with other people stay red whatever you allow.
4. Do you want a text when a run finishes? Set `notify_imessage` to true and `notify_number` to your own number. Messages must be signed in on this Mac.

Your notes folder is not asked here. Memos go to your Chief of Staff, so everything lands in the toolkit folder.

Done when `config.json` exists with every answer filled in, and `python3 bonus-watch-to-ai/scripts/voice_memo_ingest.py` has run once and logged "First run".
