# Stage 00: Onboarding

Run this once, when the bonus is first installed. You (the agent) walk the owner through setup one step at a time. It takes about 20 to 30 minutes. Paths start from the `ceo-ai-toolkit` folder.

## Inputs
- Reference: `bonus-watch-to-ai/README.md` (requirements), `bonus-watch-to-ai/setup/questionnaire.md`, `bonus-watch-to-ai/setup/com.example.watch-to-ai-team.plist`.
- Working: `bonus-watch-to-ai/setup/onboarding-log.md` (create it at step 1, add one line per finished step).

## How to run it
- One step per message. Say what the step is for in one sentence, do what you can, then tell the owner exactly what to click or say.
- Run `python3 bonus-watch-to-ai/scripts/check_setup.py` whenever a step says so, and show the owner its result.
- When a step needs the owner (a setting, a recording, a password), stop and wait for them to say it is done. Never type passwords or change system settings for them.
- After each step, add a line to `setup/onboarding-log.md`: date, step number, result.
- If the log already exists, resume at the first step not marked done.
- Changes outside the `ceo-ai-toolkit` folder (the schedule, the settings) follow the safe change rules in `INSTALL.md`.

## Steps
1. **Welcome.** Explain it in three sentences: you record on the watch, the Mac transcribes it, your Chief of Staff routes it to the right hire. Say setup takes 20 to 30 minutes and needs the Mac, the phone and the watch nearby. Create the log.
2. **Check the Chief of Staff.** Open `chief-of-staff/_shared/owner-profile.md`. If it does not say `setup_done: yes`, stop here and run the Chief of Staff setup first. This bonus does not work without it. Tell the owner why.
3. **Check the Mac.** Run the checker. If macOS, memory, disk or Python fails, stop here and explain the fix. If the owner cannot meet the requirements, use "Basic" in `INSTALL.md`: paste a transcript and say "Watch memo".
4. **Voice Memos sync.** Ask the owner to turn on Voice Memos in iCloud settings on the iPhone and on the Mac, then open Voice Memos on the Mac once. Done when a recording made on the phone or watch shows up on the Mac.
5. **Transcriber.** If ffmpeg or the transcriber failed, install them with the owner's OK: `brew install ffmpeg`, then `pip3 install openai-whisper`. Run the checker again.
6. **Let the AI read Voice Memos.** macOS hides the Voice Memos folder from apps. Ask the owner to open System Settings, then Privacy & Security, then Full Disk Access, add their terminal app, then quit and reopen it. Run the checker. Done when "Read Voice Memos" passes.
7. **Settings.** Copy `config.example.json` to `config.json`, then ask the questions in `setup/questionnaire.md` one at a time and write each answer in.
8. **First run.** Run `python3 bonus-watch-to-ai/scripts/voice_memo_ingest.py`. It marks every existing recording as seen and handles none. Done when it prints "First run".
9. **Test memo.** Ask the owner to record this on the watch: "Test memo. Add to my board: check that the Watch-to-AI System works. Done means one row on my board." When it shows in Voice Memos on the Mac, run the script again. Show the owner the new Inbox row and the job. If nothing happened, follow `stages/01_capture/CONTEXT.md`.
10. **Schedule.** Fill in the plist: replace `REPLACE_WITH_FULL_PATH` with the full path of the `ceo-ai-toolkit` folder and `REPLACE_WITH_HOME` with the owner's home folder. With the owner's OK, follow the safe change rules, copy it to `~/Library/LaunchAgents/` and load it with `launchctl load ~/Library/LaunchAgents/com.example.watch-to-ai-team.plist`. Ask the owner to also add `/usr/bin/python3` to Full Disk Access, because scheduled runs use it. Run the checker. Done when "Schedule loaded" passes.
11. **Finish.** Run the checker one last time and show the results. Tell the owner the system checks for new memos every 15 minutes while the Mac is on and signed in. Give the one tip: end every memo with what done looks like. Say that results show up in the normal morning brief. Mark onboarding done in the log.

## Outputs
- `config.json`, filled in.
- `setup/onboarding-log.md`, with all 11 steps marked done.
- The schedule loaded, and one test row on the board.

## Human check
The owner sees the test result from step 9 and the final checker result from step 11. Onboarding is done when the log shows step 11 and the checker has no FAIL lines.
