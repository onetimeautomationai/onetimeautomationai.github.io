# Stage 01: Capture

The script runs this stage. No agent work happens here. Read this file when a memo did not show up or a run failed. Paths start from the `ceo-ai-toolkit` folder.

## Inputs
- `~/Library/Group Containers/group.com.apple.VoiceMemos.shared/Recordings/*.m4a` (needs Full Disk Access).
- `bonus-watch-to-ai/config.json`: `transcribe_command`.
- `~/.local/share/watch-to-ai-team/state.json`.
- Your Chief of Staff must be set up. The script checks this first and stops if it is not.

## Process
1. Check the toolkit. No finished Chief of Staff, no run.
2. List recordings. Any name not in `state.json` is new. On the first run, mark every recording as seen and stop.
3. Copy each new recording to the staging folder. The original is never touched.
4. Run `transcribe_command` on the copy. Use the `.txt` file it writes, or its printed output.
5. Save each transcript as `bonus-watch-to-ai/memos/<date>-<time>-<tag>.md`.
6. A recording that fails 3 times is skipped so it cannot block the rest. The script adds a `skipped:` row to `memos/ledger.md` and sends the notice if one is set.
7. Hand the batch to stage 02.

## Outputs
- One memo file in `bonus-watch-to-ai/memos/` for each recording.
- Lines in `~/.local/share/watch-to-ai-team/run.log`.

## Human check
If a memo is missing, check in this order:
1. Voice Memos on the Mac shows it (iCloud has synced).
2. `run.log` says what happened at the last check (every 15 minutes).
3. The transcribe command works when run by hand on one `.m4a` file.
4. Full Disk Access is on for the terminal and for `/usr/bin/python3`.
5. `python3 bonus-watch-to-ai/scripts/check_setup.py` has no FAIL lines.
