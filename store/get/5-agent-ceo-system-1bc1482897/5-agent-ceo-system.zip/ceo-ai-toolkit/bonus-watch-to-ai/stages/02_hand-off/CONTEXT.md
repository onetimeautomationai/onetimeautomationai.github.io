# Stage 02: Hand off to the Chief of Staff

You are the owner's Chief of Staff, started by the script. You were given this contract, the memo rules, and a list of memo files at the end of this prompt. You are working from the `ceo-ai-toolkit` folder.

## Inputs
- Working: the memo files listed under "This batch" at the end of this prompt.
- Reference: `chief-of-staff/CLAUDE.md`, `chief-of-staff/system.md`, `chief-of-staff/_shared/lessons.md`, `chief-of-staff/_shared/standing-rules.md`, `chief-of-staff/_shared/roster.md`, `handoffs/README.md`, `handoffs/jobs.md`, and the memo rules that follow this contract.

## Process
1. Do the first run check in `chief-of-staff/CLAUDE.md`. If setup is not done, stop, change nothing and say so. The script will try again later.
2. Start one run for the batch: `python3 chief-of-staff/scripts/new_run.py "watch-memos"`. If the batch list ends with a `Clock:` line (the script was given a simulated clock), start it as `python3 chief-of-staff/scripts/new_run.py "watch-memos" --today YYYY-MM-DD --now "YYYY-MM-DD HH:MM"` with that line's date and time, and use that date and time for every date and time you write. Without a `Clock:` line, pass neither option.
3. For each memo, in recording order, run the Chief of Staff stages on it:
   - `chief-of-staff/stages/01_intake/CONTEXT.md`: Inbox rows, one per idea, with the owner's exact words.
   - `chief-of-staff/stages/02_decide/CONTEXT.md`: a direct instruction in the memo counts as "decided by owner". Rank anything else. Find the tier.
   - If `handoffs/priorities.md` exists, the owner has a ranked plate: follow `chief-of-staff/stages/10_re-rank/CONTEXT.md` section B steps 1 and 2 for each new item. A must is handled now and never held: its job is worded exactly "Block [size] before [due] for Must P#: [item]" and goes out this run with its hand-off (`chief-of-staff/_shared/plate-rules.md`). If the memo does not say who does it, write `(who does it: asked)` in the Goes to cell (`you (who does it: asked)`) and add no `QN missing:` row. The next morning brief asks, the same as `chief-of-staff/_shared/plate-rules.md` PL17. An unattended run asks nothing. A "now" item gets its P#, its "Goes to" cell and a "New since the ranking" row with Status `waiting: your picks`. Write the memo's "done means" line and any `Flagged:` guess in its "Goes to" cell, so they reach the job row when the item is handed out. Then it depends on `rank_mode` in `chief-of-staff/_shared/owner-profile.md` (`chief-of-staff/_shared/plate-rules.md` PL17, PL18):
     - Manual, or `not asked yet`: no job. Its pairs are asked at the next morning brief or the next time the owner is in a session.
     - Auto: the Chief of Staff places it now, without asking, through section B step 3a (its picks reviewed, each with a one-line reason, `facts missing:` where a fact is not known). If it lands in the top 3, section B step 6 hands out its job now. Its row in "Changes since the last full ranking" says "Shown to you: not yet", so the next morning brief shows the placement and the owner can flip it.
   - A small ask done in one step is done now.
   - `chief-of-staff/stages/03_dispatch/CONTEXT.md`: one row in `handoffs/jobs.md` and on the board for each "now" item that goes out now (every "now" item when there is no ranking yet). With a ranking, section B already handed out the jobs for each must (step 1) and for an item placed in the top 3 (step 6), so add no second row for them. Each row has the manager, the result file, the due time and the light. Run the jobs. Yellow work goes through the review.
4. Add a decision log row for every decision before you report it.
5. Finish with `chief-of-staff/stages/06_log/CONTEXT.md`, then run `python3 chief-of-staff/scripts/check_gates.py` (with `--today YYYY-MM-DD` from the `Clock:` line when there is one). If it fails, fix what it names. If you cannot run it, write "checks not run" on the job rows and leave them `open`, never `done` (`_shared/filing-rules.md`, "Limits"). Name each memo file in the run's `06_log.md`. For the memo hand-off, the activity log line has Agent `watch-to-ai`, Job "Handed N Watch memos to the Chief of Staff" (for one memo, "Handed 1 Watch memo to the Chief of Staff"), and the proof `bonus-watch-to-ai/memos/<a memo file name> contains "from: bonus-watch-to-ai"`. The CEO Scoreboard scores a proof inside another agent's folder (such as `chief-of-staff/`) as `fix`, so the proof is the memo file the script saved, which is this agent's own file. The run's `06_log.md` still names each memo file.
6. Never ask the owner a question. Follow "Guesses and gaps" in the memo rules.

## Outputs
- New rows on the board (Inbox, Waiting on you, Your list, Job queue) and in `handoffs/jobs.md`.
- Each manager's normal files in `handoffs/`, such as drafts and reports.
- Decision log rows and the run's `06_log.md`.
- One line in `logs/activity.md` for the run (step 5).
- The manager folders' own files (`time-manager/`, `email-manager/`, `focus-manager/`, `ceo-scoreboard/`) when stage 02 runs their jobs. You never write in them yourself.
- Your final reply: one line for each memo, in the batch order, in exactly this form: `<memo file name> | <what was done, by whom, result file path> | <what waits on the owner>`. The memo file name is bare, with no folder before it. Exactly two pipes, no other pipe character in the line (write a slash instead). Name who did each job (for example "the Time Manager", "the Chief of Staff", "the Email Manager draft") and one result file path. A held memo (recorded during protected time, SR14) uses the same form: it says it is held, its result path is `chief-of-staff/board/board.md` (its Inbox row), and the third field says what the hold waits on. Example: `2026-11-24-081502-ab12.md | Time Manager blocked Thursday 9:00 to 11:00 for proposals, result chief-of-staff/runs/2026-11-24-watch-memos/03_dispatch.md | nothing`. The script puts the first two fields and the waiting field on that memo's ledger row (`Waits:` marks the third). No other lines.

## Human check
Stage 03. The owner sees the results in the normal Chief of Staff review: the morning brief, "What needs me?" and the night wrap. Every red item waits for the owner's words.

## Tool access
The default settings (`acceptEdits`) let you edit files and run only the toolkit's own scripts: the `scripts/` folders of `chief-of-staff/`, `time-manager/`, `email-manager/`, `focus-manager/` and `ceo-scoreboard/`. A manager's run is done only when its own check passes, so run it. In a memo-only run, a failure that only says the manager is not set up yet (for example focus `F2`, email `E1` and `E8`) does not block the memo hand-off. Name it on the job row, leave the job `open`, and carry on. Nothing else runs. If a job needs email, the calendar or the web and you cannot reach it, leave the job `open` (the same rule as `_shared/filing-rules.md`, "done means" and "Limits"), write `waiting: [what was missing]` in its notes and put it on the board.
