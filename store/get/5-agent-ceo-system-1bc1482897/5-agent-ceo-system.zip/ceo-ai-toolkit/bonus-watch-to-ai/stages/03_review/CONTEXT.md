# Stage 03: Review

This is the normal Chief of Staff review. There is no separate Watch review. Paths start from the `ceo-ai-toolkit` folder.

## Inputs
- `chief-of-staff/board/board.md` (Inbox rows that name a Watch memo, Waiting on you, Your list, Job queue).
- `bonus-watch-to-ai/memos/ledger.md` (which memos were handed over, and when).
- `handoffs/` files the managers wrote, such as `drafts/`.

## Process
1. The owner says "Morning", "What needs me?", or "Check my memos".
2. For "Check my memos": first list any ledger row that says `skipped:` (a recording that could not be transcribed after 3 tries) and tell the owner to record it again. Then list the memos handed over since the owner last asked (ledger, newest first). For each, show the board rows it created. Red items first, then your list, then finished jobs. An item that waits for the owner's picks has no job yet: show it from the "New since the ranking" rows in `handoffs/priorities.md` as "waits for your picks". In auto mode (`rank_mode: auto`), an item the Chief of Staff placed during the memo run shows its place and its reasons from "Changes since the last full ranking" in `chief-of-staff/board/plate.md`, and the owner can flip a pick (`chief-of-staff/stages/10_re-rank/CONTEXT.md` section B step 4a).
3. For "Morning" and "What needs me?": the Chief of Staff runs its normal brief. Memo items are already on the board, so they appear in it with no special step.
4. The owner answers a decision ("yes to D3") the normal way. A yes to a decision is not a yes to send. The Chief of Staff shows the final draft and asks "Send it?" first.
5. If a memo was misread, the owner says "From now on, ..." and the Chief of Staff adds a line to `chief-of-staff/_shared/lessons.md`.

## Outputs
- The owner's decisions logged by the Chief of Staff, as always.
- A new lesson line when a guess was wrong.

## Human check
This stage is the human check. Drafts are sent by the owner, never by the agent.
