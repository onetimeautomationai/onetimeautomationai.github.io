# Acceptance criteria

Watch-to-AI is ready to ship when every row passes. It needs the Chief of Staff criteria (`chief-of-staff/tests/acceptance-criteria.md`) to pass first.

| AC# | Check | How to measure | Pass |
|---|---|---|---|
| AC-W1 | The script refuses an unfinished setup | TC1, TC2 | Exit 2, the missing piece is named, no state folder, no memo |
| AC-W2 | A memo is saved and handed over once | TC5 to TC7, TC31 | One memo file with the transcript, one ledger row, one hand-off. After a crash between state and ledger the next run writes the missing row, never a second hand-off |
| AC-W3 | Routing keeps the owner's words and lights | TC16 to TC26, TC28, TC29 and TC33, judged with `rubric.md` | 10 or more of 12 on 3 runs out of 3 |
| AC-W4 | Nothing is lost or blocked | TC11 to TC13, TC32, TC34 | An agent failure keeps state and leaves no staging copy, is announced, and is retried at most 3 times. One bad recording never blocks the others |
| AC-W5 | A dry run changes nothing | TC14, TC30 | State, ledger, notices and agent calls all unchanged, even when every transcript fails |
| AC-W6 | Gaps become questions, not guesses | TC23, TC33 | A `QN missing:` row, no job and no draft, 3 runs out of 3 |
| AC-W7 | No job is marked done without a run | TC16, TC23, TC26 | A job that exists stays `open` until the manager has run, or when it could not read its source |
| AC-W8 | The self-test passes | `python3 bonus-watch-to-ai/scripts/test_ingest.py` | Every case passes, exit 0 |
