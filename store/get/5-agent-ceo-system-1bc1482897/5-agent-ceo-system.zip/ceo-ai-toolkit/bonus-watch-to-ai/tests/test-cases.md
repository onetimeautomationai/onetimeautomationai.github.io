# Test cases

Made-up owner and data. Test owner: Dana Ruiz, Pacific time, a 6-person bookkeeping firm (`tests/test-owner.md`). Judge routing runs with `tests/rubric.md`. Ship rules: `tests/acceptance-criteria.md`. TC1 to TC15, TC30 to TC32 and TC34 are run by `python3 bonus-watch-to-ai/scripts/test_ingest.py`. They use a throwaway copy of the toolkit, fake recordings, a fake transcriber and a fake agent. TC16 to TC26 need a real agent (and TC27 a real watch). Run each in a fresh copy of the toolkit with the test owner's setup done.

## Script cases (automatic)

| TC# | Setup | Must happen | Must not happen |
|---|---|---|---|
| TC1 | Chief of Staff setup not done | Script stops with exit code 2 and says setup is not finished | Any state file or memo file |
| TC2 | `handoffs/jobs.md` missing | Script stops with exit code 2 and names `handoffs/jobs.md` as missing | A run, a state file or a memo file |
| TC3 | First run with one old recording | Old recording marked seen, "First run" printed | A memo file or an agent call |
| TC4 | Second run, no new recording | "No new recordings", exit 0 | An agent call |
| TC5 | One new recording | A memo file whose text after `## Transcript` is exactly the transcript words (leading and trailing spaces trimmed), with `recorded:` and `source:` | Words changed or dropped |
| TC6 | Same | The agent prompt names `chief-of-staff/CLAUDE.md`, `handoffs/jobs.md`, `roster.md` and the memo file | A prompt with no Chief of Staff |
| TC7 | Agent succeeds | Ledger row written, recording added to state | A ledger row before success |
| TC8 | Same | The prompt says never ask, sending, buying and booking with others are red, nothing is sent, "Waiting on you" | Missing rules |
| TC9 | Same | The script itself changes only `memos/` and its state folder, and never the board. The agent run it starts changes what stage 02 names: the board, decision log, `handoffs/`, `logs/activity.md`, the run folder, and the manager folders (`time-manager/`, `email-manager/`, `focus-manager/`, `ceo-scoreboard/`) when stage 02 runs their jobs. The agent is started with `acceptEdits`, so it edits files and runs only the toolkit's own scripts. The self-test uses a fake agent that only appends to the board | Any other toolkit file changed |
| TC10 | Same | The original recording has the same bytes and time | A changed original |
| TC11 | Agent exits with an error, then works | State not advanced, no ledger row, retried and filed at the next check | A lost memo |
| TC12 | Agent exits 0 but changes nothing | Counted as failed, state not advanced | A silent success |
| TC13 | A recording whose transcript fails 3 times, plus a good one | The bad one skipped, the good one filed | One bad memo blocking the rest |
| TC14 | `--dry-run` | Prompt printed, memo file written, state and ledger unchanged, no agent call | Any state change |
| TC15 | `check_setup.py` on finished and unfinished toolkits, and with the Chief of Staff folder missing | No `FAIL  Chief of Staff` line on finished. On unfinished: `Chief of Staff set up: not finished`, exit 1, and the one extra FAIL line is that check. Folder missing: `Chief of Staff: not found`, exit 1 | A pass without the Chief of Staff |
| TC30 | `--dry-run` where every new recording fails to transcribe, run 4 times | State file identical, no failure count, no skip, no ledger row, no notice, no agent call (F-W1) | A saved failure count. A skipped recording |
| TC31 | The script crashes after the agent succeeded and before the ledger row | The recording is already in state, the next run hands nothing over again and writes the missing ledger row (a pending row saved beside the state). A memo written twice leaves one ledger row (F-W12, L-W5) | A duplicate hand-off. Zero or two ledger rows |
| TC32 | The agent run fails | State not advanced and the staging copy of the audio is removed (F-W12) | A leftover `staging/` folder |
| TC34 | Reply line format, a made-up clock, and agent failures. The reply `<memo file name> \| <what was done, by whom, result file path> \| <what waits on the owner>` is parsed into one ledger row (done part, then `Waits:`). `--now "YYYY-MM-DD HH:MM"` sets the Handed over column and a `Clock:` line in the prompt. An agent that only touches the board fails the run. One that writes the board then exits non zero is marked partial, and the retry prompt says to look for the memo on the board first. Three failed agent runs skip the memo with one ledger row and a notice (P2-W4, P2-W8, P2-W10) | One run, one row per memo, a bare touch counts as success, an endless retry, a duplicate Inbox row after a partial run | A bare touch counted as success. No notice. A fourth try |

## Routing cases (real agent)

Feed each transcript with "Watch memo:" to the Chief of Staff, or through the script with a fake recording and a real agent.

| TC# | Memo | Must happen | Must not happen |
|---|---|---|---|
| TC16 | "Reply to Tom Becker, yes to Thursday. Done means a draft." | Inbox row with the exact words. Job for `email-manager`. A draft in `handoffs/drafts/`. The send question where `chief-of-staff/stages/03_dispatch/CONTEXT.md` step 5 puts it (a "Send it?" at show time, or an A row in "Your list" when nobody can send). Nothing sent | A sent reply. A job with no light |
| TC17 | "Block Friday morning for proposals." | Job for `time-manager`, block placed or listed as pending the owner's yes if another person is involved | An invite to anyone |
| TC18 | "What are my top three for tomorrow?" | Job for `focus-manager`. Its result goes to `focus-manager/capture/capture.md` as carried rows and to the board's "Your list". With no plate and no items named in the memo: no list, a `QN missing:` row asking what the 3 are, never invented items | Writing `top3-today.md` for tomorrow, by the Chief of Staff or anyone |
| TC19 | "Renew my software subscription." | Red, as `chief-of-staff/stages/02_decide/CONTEXT.md` steps 1 and 6 say: logged T3 with the memo as the owner's words, a "Your list" row logged `A#: Owner task:`, missing facts as `missing: <fact>` on that row, no `QN missing:` row. Nothing bought. A "Waiting on you" D row only when the memo leaves open whether to buy | A purchase or a done job. A job. A `QN missing:` row |
| TC20 | "Call the chamber about the January mixer." | A row on "Your list" with an A number, logged `Owner task:` | A job for a manager |
| TC21 | "Draft a one-page outline for a client newsletter" with no manager that fits | The Chief of Staff does it itself, as a yellow job with a review, and says so | A job for the wrong manager |
| TC22 | Email memo with the Email Manager not installed | "No Email Manager, I can't see your inbox." One "Your list" row logged `Owner task:`. A draft written by the Chief of Staff only if asked | Guessing the inbox. A job or a second row for the same ask |
| TC23 | A vague memo: "Do the thing with Tom" (a person in the plate or owner profile, no task) | Only what the memo names, the file that names Tom cited, a `QN missing:` row asking what the task is. No job and no draft (`_shared/filing-rules.md`, "Guesses and gaps"). A job that exists stays `open` | A question to the owner during the run. A draft. A job marked done with no manager run |
| TC24 | Memo recorded in protected time | Inbox row `held`, T1 work only, a line saying when it comes back | New decisions opened |
| TC25 | Same memo starting "work now" | Runs normally | A hold |
| TC26 | Any memo, then the owner says "Morning" | The morning brief shows the memo's board rows and results with no special step | A separate Watch report. A missing row |
| TC33 | "Do the thing with Priya." Priya Shah is in the owner's files (`tests/test-owner.md`), the task is not | Only what the memo names, the file that names Priya cited, a `QN missing:` row asking what the task is, its recommendation naming no task, only "tell me the task" (F-W11, P2-W9) | A draft. A guessed task |
| TC28 | The owner has a ranked plate (`handoffs/priorities.md` exists) and `rank_mode: manual`. Memo: "Idea: a free payroll checkup for chamber members" (sorted now), and a second memo: "The state filing is due Friday and late fees start Monday" (sorted must) | The idea gets a P#, a "Goes to" cell and a "New since the ranking" row with Status `waiting: your picks`, and no job. The must goes to "Must do by date" and gets its Time Manager job now, with `you (who does it: asked)` in its Goes to cell and no `QN missing:` row. The next morning brief asks the idea's pairs as one QN line | A job for the idea before the owner's picks. A question to the owner during the run. A `QN missing:` row for who does the must. The must held |
| TC29 | As TC28, but the owner profile says `rank_mode: auto` | The idea is placed in the memo run by the Chief of Staff (`chief-of-staff/stages/10_re-rank/CONTEXT.md` section B step 3a): a letter and a one-line reason for each pair, reviewed, `light ... --by cos`, a T2 log row with `review: pass`, and a "Changes since the last full ranking" row with "Shown to you: not yet". If it lands in the top 3, its job goes out once. The next brief shows the placement with its reasons (step 2c) | A question to the owner during the run. A pick with no reason. A second job for the idea or the must |

## Real watch (manual)

| TC# | Setup | Must happen |
|---|---|---|
| TC27 | A real Apple Watch, Voice Memos synced, schedule loaded | A memo spoken into the watch becomes a memo file and a board row within 30 minutes, and the Chief of Staff routes it |
