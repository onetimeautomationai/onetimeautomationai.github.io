# Test owner (made up)

The test owner is the same as the Chief of Staff's: Dana Ruiz, Pacific time, a 6-person bookkeeping firm. Use the setup answers and plate answers in `chief-of-staff/tests/test-owner.md` for every test case that needs setup done. Set `setup_done: yes` in the owner profile before any run.

## Extra facts for the Watch cases

| Fact | Where it lives | Used by |
|---|---|---|
| Tom Becker: Dana owes him a reply (plate P3) | `chief-of-staff/board/plate.md` | TC16, TC23 |
| Priya Shah is a new prospect, no task is known | Seed it as one line in the owner profile notes before the run | TC33 |
| Recordings are named like `20261124 081502-NEW1.m4a` | Fake Recordings folder | TC5 to TC14, TC30 to TC32, TC34 |
| Fake transcript: "Block Thursday morning for proposals. Done means it is on my calendar." | `scripts/test_ingest.py` | TC5 to TC13 |

The script cases build a throwaway copy of the toolkit, so they never touch your real files. Never point a test at the real Voice Memos folder.
