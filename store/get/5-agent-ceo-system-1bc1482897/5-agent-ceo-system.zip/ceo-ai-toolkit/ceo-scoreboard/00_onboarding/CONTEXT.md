# 00_onboarding: set up the scoreboard once

Runs the first time, or when the owner says "redo scoreboard setup" or asks to change a daily action or a target. Goal: fill `ceo-scoreboard/_shared/scoreboard-settings.md` so the scoreboard never asks these again. Paths start from the `ceo-ai-toolkit` folder.

## Inputs
- `ceo-scoreboard/setup/questionnaire.md` (the questions, in order)
- `ceo-scoreboard/_shared/scoreboard-settings.md` (the file you fill)
- `chief-of-staff/_shared/owner-profile.md` (read only, if it exists)

## Process
1. Find out how you were started. Open `chief-of-staff/_shared/owner-profile.md`. If it exists, has no `{{` and says `setup_done: yes`, you are **under the Chief of Staff**. Otherwise you are **standalone**.
2. Say one line. Standalone: "I'm your CEO Scoreboard. I'll ask you up to 5 short questions, one at a time, then score your first day. About 5 minutes. Say 'skip' to use the default." Under the Chief of Staff: "I'll set up your scoreboard from your profile. Two quick questions."
3. If some answers are already filled (the owner stopped halfway), start at the first question whose placeholder is still there. Never re-ask a filled one.
4. Ask the questions one per turn, offering the default in brackets. Standalone: Q1 to Q5. Under the Chief of Staff: read goal 1 and "Daily actions that move goal 1 most" from the profile and show them back in one line. Ask Q3 and Q4. Ask Q2 first only if the profile says `not given` for daily actions. The profile holds the daily actions as one free-text line. Split it at commas, "and" and semicolons into at most three actions, in the order written, as M1 to M3, keep the owner's words for each name, and show the split back in the same line ("M1 new conversations, M2 proposals, M3 follow-ups") so the owner can correct it. A skipped Q1 or Q2 gets one more ask in simpler words, then `not given`. With `not given` for Q2, set every daily action row to `not used` and score without daily actions (`scoring-guide.md` section 2). Remind the owner once, at the end of the first night score, that the score is more useful with daily actions.
5. Write each answer into the settings right away, replacing its `{{placeholder}}`. The action names come from Q2, or from the profile under the Chief of Staff, and fill the action cell of each row (code M1 to M3). The answer to Q3 fills the daily target and counts-when cells of those rows. Unused rows are written `not used`. Never leave a row blank.
6. Fill the standalone fields. Standalone: write the answers to Q1 and Q5, and the default report style. Under the Chief of Staff: write `see the owner profile` in each of the three standalone lines.
7. When no `{{` is left, set `setup_done: yes` in the settings front matter.
8. Add a row to `ceo-scoreboard/_shared/decision-log.md`: "Setup done", T1, Result done.
9. Tell the owner in one line what you filed. Under the Chief of Staff, stop here and do not score. The first night wrap runs you. Standalone: if a first night score is due, go straight to `ceo-scoreboard/stages/01_gather/CONTEXT.md`. It is due when the owner started in the evening, which means at or after their close time (Q5, for example 5 PM), or when there is a Top 3 for the clock date. Otherwise say the first score comes tonight or after the day's work.

## Changing a daily action or a target later

That is a red change (`ceo-scoreboard/system.md` section 5). If the owner asked for it in their own words, log those words as a T3 row with Result `done`, then change only the lines they named. If you are the one suggesting it, write the recommendation and wait. Never change a row the ledger already scored with the old target: the ledger keeps each day's own target in its Leading column.

## Output
- `ceo-scoreboard/_shared/scoreboard-settings.md` with no `{{` left and `setup_done: yes`.
- One decision log row.

## Human check
The owner reads the one-line summary and can correct any answer. A correction updates the settings and adds a lessons line.

## Redo setup
Copy the current settings to `ceo-scoreboard/archive/scoreboard-settings-YYYY-MM-DD.md`. Reset every answer to its `{{placeholder}}` and `setup_done: no`, then run this stage from step 1, offering the old answers as defaults. Never touch the ledger.
