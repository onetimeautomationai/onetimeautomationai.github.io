# Pipeline

Paths start from the `ceo-ai-toolkit` folder. The CEO Scoreboard runs two loops. Make each run folder by hand in `ceo-scoreboard/runs/`.

## Loop A: the night score (every work day)

Folder: `ceo-scoreboard/runs/YYYY-MM-DD-night/`. Copy `ceo-scoreboard/_templates/run/01_gather.md` into it to start.

| # | Stage | Output in the run folder | Human check |
|---|---|---|---|
| 01 | gather | `01_gather.md`: the Top 3, the owner's answer word for word, the proof for each item | The owner answers the one night question |
| 02 | score | `02_score.md`: statuses, counts, the arithmetic, why, fix | The owner confirms the counts |
| 03 | tomorrow | `03_tomorrow.md`: up to 3 items with their source | none |
| 04 | report | `04_report.md`, the ledger row, `handoffs/scoreboard-report.md`, the night score for the owner | The owner reads the night score |
| 06 | log | `06_log.md` | `check_scoreboard.py` passes |

## Loop B: the weekly view (Friday night, or when asked)

Folder: `ceo-scoreboard/runs/YYYY-MM-DD-week/`.

| # | Stage | Output | Human check |
|---|---|---|---|
| 05 | week | `05_week.md`: the table, totals, streaks, one change for next week | Reviewed (yellow), then the owner reads it |
| 06 | log | `06_log.md` | `check_scoreboard.py --skip-report` passes |

**Stable every run:** everything in `ceo-scoreboard/_shared/`.
**New every run:** `ceo-scoreboard/runs/`, a row in the ledger, rows in the decision log, `handoffs/scoreboard-report.md`.

Every stage reads `ceo-scoreboard/system.md` and the lessons first.
