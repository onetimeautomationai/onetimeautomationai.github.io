# Change how your CEO Scoreboard works

The easy way: tell it. "From now on, show my daily actions first." Standalone, it adds a line to `_shared/lessons.md`. Under your Chief of Staff, the Chief of Staff saves it in the toolkit's lessons file. Either way it follows the line from then on.

## Safe to change

| What | Where |
|---|---|
| Your daily actions, targets and what counts | Tell it, or edit the table in `_shared/scoreboard-settings.md`. Say "make my target 5 conversations". It logs your words, then changes it |
| Your work days (they decide what counts as a missed night) | `_shared/scoreboard-settings.md`, or tell it |
| The score that makes a good day (default 7) | `_shared/scoreboard-settings.md` |
| What the night score shows, and in what order | Tell it. It saves a lesson |
| Setup questions | `setup/questionnaire.md` |

## Change with care (it asks for your yes and keeps a snapshot first)

| What | Why |
|---|---|
| `_shared/scoring-guide.md` (the points: 6, 3 and 1) | The script `scripts/scoreboard_calc.py` uses the same numbers. Change both or the checks fail. Past scores keep the rules they were scored under, so changing the rules makes old and new weeks hard to compare |
| `_shared/decision-log.md` | Append only. To fix a row, ask for a "corrects L#" row |
| `ledger/scoreboard-log.md` | Append only. To fix a day, say "fix today's score" and it adds a "corrects" row |
| The report format in `chief-of-staff/_shared/handoffs.md` | The Chief of Staff reads it. Change the format and the Chief of Staff must change with it |

## Do not change

Sending, posting, publishing, paying, buying, deleting and booking with other people always need your yes. No setting or lesson changes that.
