# Install

Pick one path. Basic needs no terminal. Expert adds a nightly schedule and the safety checks. The scoreboard works with the rest of your toolkit or on its own.

## Basic (no terminal)

**If you have the whole toolkit:** the `ceo-scoreboard` folder is already inside `ceo-ai-toolkit`. Do the Chief of Staff's setup first. Then say **"Wrap up my day"** to your Chief of Staff, and it starts the scoreboard setup the first time (two quick questions, because it already knows your goal).

**If you use the scoreboard on its own:**
1. Download and unzip. Put the `ceo-scoreboard` folder anywhere you like, for example your Documents folder.
2. Load the `ceo-scoreboard` folder into your favorite AI agent platform (open the agent in that folder).
3. Say: **"Start my CEO Scoreboard."**
4. Answer the questions one at a time (5 at most). Say "skip" to use the default. It saves each answer as you go.
5. When it says setup is done, say **"Score my day"** at the end of your work day.

If your agent only has a box for a system prompt or custom instructions and cannot open folders, paste `INJECT-PROMPT.md` into that box instead. You get the scoring without the files, so it cannot keep a streak between chats.

## Expert (adds a nightly schedule)

Do Basic first, then:

1. **Run the score on a schedule**, if your agent supports scheduled tasks. Make one task that opens your folder at your day-close time with: "Score my day." Under the Chief of Staff, schedule "Wrap up my day" instead. Your agent follows the safe change rules below before it creates the task.
2. **Turn on the scripts**, if your agent can run commands. From the `ceo-ai-toolkit` folder, run `python3 ceo-scoreboard/scripts/check_scoreboard.py`. Before setup is done, it fails its first check (S1). That is expected. If you started standalone with no `handoffs/` folder, it also reports the missing report (S2) until your first night is scored.
3. **Optional:** ask for "Show my streak" once a week to see the numbers the script prints.

## Safe change rules

The AI follows these for any change outside the `ceo-scoreboard` folder (scheduled tasks, your agent's settings or rules file, files in `handoffs/`), and for any change to the scoreboard's rules files (`system.md`, `_shared/scoring-guide.md`).

1. If it cannot read and write files here, it says so and gives you manual steps instead.
2. Before changing anything, it tells you the time and lists every file and outside item it will create or change. It waits for your yes.
3. It copies each existing file it will change into `.ceo-toolkit/snapshots/ceo-scoreboard-<YYYYMMDD-HHMMSS>/`, keeping its path, and adds a row to `.ceo-toolkit/install-log.md`: time, action, snapshot, files changed, files created, notes. It creates the log with a header row if it is missing.
4. It never overwrites your agent's own rules file. It adds a block between `<!-- ceo-toolkit:ceo-scoreboard:start -->` and `<!-- ceo-toolkit:ceo-scoreboard:end -->` instead.
5. It never deletes your data, and never deletes anything in `.ceo-toolkit/`.

Changes it makes every night inside the toolkit (a new ledger row, `handoffs/scoreboard-report.md`, the status cell of its own row in `handoffs/jobs.md`) are its normal work and need no snapshot. Its first write to `handoffs/jobs.md` and `handoffs/scoreboard-report.md` is snapshotted once.

`.ceo-toolkit/` lives in the `ceo-ai-toolkit` folder. It is your record of every change.
