# CEO Scoreboard

Your CEO Scoreboard scores your day in five minutes each night and hands you tomorrow's list.

You set a Top 3 in the morning. At night the scoreboard checks it against what actually happened, counts the daily actions that move your number one goal, gives you a score out of 10 with one line why, names one fix, and lists what tomorrow starts with. Over days it shows your streak and your week.

## What it does for you

| When | What you get |
|---|---|
| Night | One question, then your score: Top 3 done, daily actions counted, one line why, one fix |
| Night | Tomorrow's list, up to 3 items, each with where it came from |
| Night | What your agents got done: each job they logged is checked against its proof file, only checked jobs are counted, and any job without proof is flagged with its fix |
| Every night | A running record, so your streak and your week are real numbers, not a feeling |
| Weekly | A one-page view of your seven days and one change for next week |

## How your score is worked out

| Part | Points | How |
|---|---|---|
| Top 3 | 6 | Each item done earns its share. Partly done earns half a share |
| Daily actions | 3 | Each action: what you did divided by your target, up to 1. The average, times 3 |
| Goal moved | 1 | Yes if something real happened today: a client signed, a contract signed, a payment in |

No daily actions set? Your Top 3 is worth 9 points instead of 6 and the daily actions part is dropped. The full rules are in `_shared/scoring-guide.md`.

It counts only what has proof: your words, or a file that is the result. A draft is never counted as sent.

## Works with your team, or on its own

- **With the Chief of Staff:** you do nothing extra. Say "Wrap up my day" to your Chief of Staff. It runs the scoreboard and shows you the result. The scoreboard reads your Top 3 from the Focus Manager (or from the Chief of Staff if you have no Focus Manager) and writes `handoffs/scoreboard-report.md` for the Chief of Staff.
- **On its own:** open your agent in the `ceo-scoreboard` folder and say "Start my CEO Scoreboard". It asks up to 5 questions, one at a time. After that, say "Score my day" each night.

## Install in 3 steps

1. Put the `ceo-scoreboard` folder inside your `ceo-ai-toolkit` folder (it comes there already), or anywhere you like for standalone use.
2. Load the folder into your favorite AI agent platform (open the agent in that folder).
3. Say: **"Start my CEO Scoreboard."** It asks its questions one at a time and saves your answers. It never asks them again unless you say "redo scoreboard setup".

Full steps: `INSTALL.md`. What you need first: `REQUIREMENTS.md`.

## What to say

See `wake-phrases.md`. The ones you will use most:
- "Score my day" (or "Wrap up my day" to your Chief of Staff).
- "Fix today's score, ..." when a count is wrong.
- "Weekly view" for your seven days.

## How it earns your trust

It never guesses a number. If it cannot prove a count, it says so and counts it as not done. Changes to your targets or scoring rules wait for your yes. Re-scores and weekly views are checked by an AI reviewer before you see them. Every night is saved as one new row, and old rows are never edited.

## What it will never do

It never sends, posts, publishes, pays, buys, deletes, or books time with another person without your yes. If you ask it to share your score with a coach or your team, it writes a draft and waits. It never edits another hire's files.

## More

- How it works inside: `docs/how-it-works.md`
- A sample night: `examples/sample-day.md`
- What you can change: `CUSTOMIZE.md`
- What it cannot do yet: `known-limitations.md`
- Help: `SUPPORT.md`
- Remove it: `UNINSTALL.md`

Version 0.2.9, 2026-11-21. Changes: `CHANGELOG.md`.
