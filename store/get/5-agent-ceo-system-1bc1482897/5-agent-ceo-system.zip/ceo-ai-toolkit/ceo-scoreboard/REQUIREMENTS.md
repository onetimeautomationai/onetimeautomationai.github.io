# What you need

## Required
- **An AI agent that can read and write files in a folder on your computer.** A chat window that cannot open files is not enough. The setup guide in the toolkit lists the agents we have tested.
- **This folder on your computer.** Your scores, streaks and decisions live here and nowhere else.

## Needed for the full team
- **The Chief of Staff and the Focus Manager** give the scoreboard your Top 3 and run it for you. Without them it asks you for your Top 3 each night.

## Optional
- **Python 3**, if your agent can run commands. Two small scripts use it (the score arithmetic and the safety checks). Without it, your agent does the same steps by hand.

## You do not need
- To write code.
- Email or calendar connected. The scoreboard never reads either.
- A subscription. You pay once and keep every file.
- Any other app.

## Tested with

| Agent | Model | Date | Result |
|---|---|---|---|
| Not yet tested | | | First draft. Walk tests are listed in `tests/acceptance-criteria.md` |

Model updates can change how an agent behaves. Before you switch to a new model, run the 17 test cases in `tests/test-cases.md` and compare.

## Before you buy, check
1. Can your AI agent open a folder and edit a file in it?
2. Are you willing to tell it, once a night, which of your Top 3 got done and how many of each daily action you did?
3. Are you OK with a score that is only as accurate as the answers you give it?
