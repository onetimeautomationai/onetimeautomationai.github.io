# Remove the CEO Scoreboard

## The simple way
Delete the `ceo-scoreboard` folder. Nothing else on your computer depends on it. Your Chief of Staff then scores your day itself in the night wrap, with a plainer score. If you did the Expert install or let it change anything outside the folder, use the next section instead.

Keep a copy of `ledger/` and `runs/` first if you want your history. The file `handoffs/scoreboard-report.md` stays where it is. After two days your Chief of Staff treats it as out of date.

## If your AI made changes outside the folder
Say: **"Uninstall the CEO Scoreboard."** Your AI then:

1. Copies your data (`ledger/`, `runs/`, `_shared/`) and anything it will remove into `.ceo-toolkit/removed/ceo-scoreboard-<YYYYMMDD-HHMMSS>/`. It includes `handoffs/scoreboard-report.md` in that copy.
2. Restores each file it changed from its snapshot in `.ceo-toolkit/snapshots/`. For `handoffs/jobs.md`, that means putting back the rows as they were before the scoreboard first set a status. Rows the Chief of Staff added after that are kept, not removed.
3. In shared files, removes only the block between `<!-- ceo-toolkit:ceo-scoreboard:start -->` and `<!-- ceo-toolkit:ceo-scoreboard:end -->`. Other hires' blocks stay.
4. Lists anything outside the folder it created (a scheduled task) and asks you before removing each one.
5. Adds a row to `.ceo-toolkit/install-log.md` and tells you what was restored, removed and kept.
6. Tells your Chief of Staff the scoreboard is gone, so it sets "CEO Scoreboard" to no in the owner profile and scores the night itself.

Say **"Show what uninstalling would change"** to see the list without changing anything.

## What stays on your computer
Everything in `.ceo-toolkit/` stays. It is your record. Your toolkit files are never sent to us, so there is nothing to delete anywhere else.
