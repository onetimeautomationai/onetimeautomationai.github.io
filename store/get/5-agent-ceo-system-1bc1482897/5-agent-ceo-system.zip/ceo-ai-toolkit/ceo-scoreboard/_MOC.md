# CEO Scoreboard: map

Paths start from the `ceo-ai-toolkit` folder.

| Path in `ceo-scoreboard/` | One line |
|---|---|
| `CLAUDE.md` | Start file for the AI: first-run check, routes, rules that never bend |
| `CONTEXT.md` | The two loops: the night score and the weekly view |
| `system.md` | The AI's full operating rules |
| `README.md` | The owner's one-page guide |
| `REQUIREMENTS.md` | What you need, tested-with record |
| `INSTALL.md` | Basic and Expert install, safe change rules |
| `UNINSTALL.md` | Safe removal and rollback |
| `CUSTOMIZE.md` | What you can change and where |
| `permissions.md` | What it can read and write |
| `known-limitations.md` | What it cannot do yet |
| `SUPPORT.md` | Help and the update promise |
| `LICENSE.md` | Use and resale terms |
| `CHANGELOG.md`, `manifest.json` | Version, file list, checksums |
| `wake-phrases.md` | What to say |
| `INJECT-PROMPT.md` | One-paste version for agents without folders |
| `00_onboarding/`, `setup/` | First-run setup |
| `_shared/` | Settings, scoring guide, review rubric, lessons, decision log |
| `stages/` | 01 gather, 02 score, 03 tomorrow, 04 report, 05 week, 06 log |
| `ledger/` | One row per scored day |
| `_templates/` | Run starter and output templates |
| `runs/` | Night and week history |
| `scripts/` | `scoreboard_calc.py`, `check_scoreboard.py` |
| `docs/` | How it works |
| `examples/` | A sample night with made-up data |
| `tests/` | Test cases, acceptance criteria, judge rubric, seed ledger |
