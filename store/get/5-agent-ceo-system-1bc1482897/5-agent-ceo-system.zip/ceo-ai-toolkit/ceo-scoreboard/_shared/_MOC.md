# _shared: map

| File | One line |
|---|---|
| `scoreboard-settings.md` | Daily actions with targets, work days, the standalone answers. Filled by setup |
| `scoring-guide.md` | What counts, the score formula, the one fix, tomorrow's list, streaks, the ledger |
| `review-rubric.md` | The five checks a reviewer runs on yellow work (own copy, so the scoreboard works alone) |
| `lessons.md` | Owner corrections about the scoreboard, read every run |
| `decision-log.md` | Append-only record of every scoreboard decision |

Shared with the rest of the toolkit (read, never written by this hire): `chief-of-staff/_shared/owner-profile.md`, `decision-tiers.md`, `handoffs.md`, `voice-profile.md`, `lessons.md`.
