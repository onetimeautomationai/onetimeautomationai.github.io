---
type: log
rule: append only. Never edit or delete a row.
---

# Decision log (CEO Scoreboard)

Every decision the scoreboard makes or records goes here before it is reported. Rows are numbered L1, L2, L3. This is the scoreboard's own log, in the same format as `chief-of-staff/_shared/decision-log.md`.

- **Tier:** T1, T2 or T3 (`chief-of-staff/_shared/decision-tiers.md`). Anything that sends, posts, publishes, pays, buys, deletes or books with another person is T3.
- **What gets a row:** each night's score (T1), each re-score after a correction (T2), each weekly view (T2), each change to a daily action, a target or a scoring rule (T3), and each request to share the score with anyone (T3).
- **Decision wording:** keep it neutral, for example "Scored 2026-11-19: 3 of 3 done, 8 of 10". Put proof in Evidence. The check treats words like send, post, book or share in the Decision column as a sign the row is T3.
- **Owner's words:** required for a T3 row whose Result is `done`, copied exactly. Leave it empty while you wait and set Result to `pending`.
- **Result:** one of `done`, `pending`, `parked`, `no`.
- **Evidence:** for a T2 row marked done, write `review: pass` (`ceo-scoreboard/_shared/review-rubric.md`), or `review: pass (self)` when the same agent reviewed because no helper could start. Put the run folder in Evidence too, for example `runs/YYYY-MM-DD-week, review: pass (self)`.
- **To fix a row:** add a new row whose Decision starts with `corrects L#`. The check reads the new row instead of the old one.

`ceo-scoreboard/scripts/check_scoreboard.py` enforces this (check S6).

| L# | Time | Decision | Tier | Why | Evidence | Owner's words | Result |
|---|---|---|---|---|---|---|---|
