---
type: factory
---

# Lessons (CEO Scoreboard only)

Corrections about the scoreboard: how it counts, what it asks, how it words the night score. Newest at the bottom.

Under the Chief of Staff, the Chief of Staff writes the owner's corrections in `chief-of-staff/_shared/lessons.md`, and the scoreboard reads that file too. The scoreboard writes here only when the owner talks to it directly. Read both files before every run. Follow every line.

| Date | The owner said (exact words) | What we do from now on |
|---|---|---|
