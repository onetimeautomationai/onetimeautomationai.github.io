---
type: factory
---

# Review rubric (yellow work)

This is the Scoreboard's own copy, so it works without the Chief of Staff folder. If `chief-of-staff/_shared/review-rubric.md` exists, that file is the master and wins on any difference in the checks RR1 to RR5. The record layout and the log wording below always come from this file and the scoreboard stages.

The reviewer sees: the job row or the owner's ask, the output, the source files the job used (the ledger rows for the date or week, the owner's words in `01_gather.md`, `ceo-scoreboard/_shared/scoreboard-settings.md`, `ceo-scoreboard/_shared/scoring-guide.md`), `ceo-scoreboard/_shared/lessons.md` and the Chief of Staff's lessons if they exist, and this rubric. It never sees the chat. It scores each line pass or fail.

| # | Check | Fail when |
|---|---|---|
| RR1 | Does it do the job as written? | Missing part of the job, or did more than asked |
| RR2 | Are the facts true? | A fact contradicts the source files, or is not in them. A fact found in a source passes |
| RR3 | Does it follow the lessons and the settings? | Breaks a lesson, the report style, or a scoring rule |
| RR4 | Is the light right for what happens next? | The output would share the score, send, post, pay, buy, delete or book without the owner's yes |
| RR5 | Is it ready for the owner to see? | Unclear, too long, the most important line not last |

**Review record layout** (one layout, the same in `stages/04_report` and `stages/05_week`). Write the five results into the review record file named by the stage: `runs/YYYY-MM-DD-night/04_review.md` for a re-score, `runs/YYYY-MM-DD-week/05_review.md` for a weekly view. Line 1 is `Reviewed by: helper, YYYY-MM-DD HH:MM` (the helper writes it, the time is the clock time). For a same-agent review, line 1 is `Reviewed by: self, YYYY-MM-DD HH:MM` and line 2 is `Helper failed: <the error>`. Then RR1 to RR5, one line each, for example `- RR2 pass: figures match the ledger rows`. A night re-score record ends with the drafted ledger row. There is no `Verdict:` line.

**Pass:** all five pass. Write `review: pass` in the decision log Evidence column, after the record exists.
**Fail:** list the failed lines and one fix each. The work goes back once. A second fail makes it red: the owner sees it with the reviewer's notes.

## Who reviews

1. **Best:** a separate helper agent with a fresh start, on a different AI model if the owner's agent allows. Its first line: "Read ceo-scoreboard/_shared/review-rubric.md before anything else. You are the reviewer." Under the Chief of Staff it also reads `chief-of-staff/worker.md`.
2. **Fallback:** only after a helper failed to start. Write `Reviewed by: self, YYYY-MM-DD HH:MM` and `Helper failed: <the error, or "no helper tool available">` as the first two lines of the review record, then the same agent does a separate review pass with this rubric, reading only the files listed above, and writes `review: pass (self)`. This is weaker, because it checks its own work. `known-limitations.md` says so.
