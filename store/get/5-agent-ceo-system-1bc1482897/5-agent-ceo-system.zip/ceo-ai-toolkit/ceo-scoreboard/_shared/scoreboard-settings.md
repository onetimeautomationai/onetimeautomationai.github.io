---
type: factory
setup_done: no
---

# Scoreboard settings

Filled by setup (`ceo-scoreboard/00_onboarding/CONTEXT.md`). These are the only settings the CEO Scoreboard owns. Everything else it needs about the owner (goal 1, time zone, report style) it reads from `chief-of-staff/_shared/owner-profile.md` when that file is set up. Change a line by telling the scoreboard, or say "redo scoreboard setup". A skipped answer uses its default. An unused row is written as `not used`, never left blank.

## Daily actions (up to 3 that move goal 1)

| Code | Daily action | Daily target | Counts when |
|---|---|---|---|
| M1 | {{action_1}} | {{target_1}} | {{counts_when_1}} |
| M2 | {{action_2}} | {{target_2}} | {{counts_when_2}} |
| M3 | {{action_3}} | {{target_3}} | {{counts_when_3}} |

## Your days
- Work days: {{work_days}}
- A good day is a score of: 7 or more

## Standalone answers (used only when the Chief of Staff's owner profile is not set up)
When the Chief of Staff's owner profile is set up, write `see the owner profile` in each line below.
- Goal 1, with a number and a date: {{goal_1}}
- Time zone and when your day closes: {{time_zone_and_close_time}}
- Report style: {{report_style}}
