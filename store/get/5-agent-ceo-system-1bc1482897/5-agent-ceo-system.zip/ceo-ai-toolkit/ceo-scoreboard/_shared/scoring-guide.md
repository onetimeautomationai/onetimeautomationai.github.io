---
type: factory
---

# Scoring guide

How the CEO Scoreboard counts, scores, writes the one fix, and runs streaks. The same rules sit in `ceo-scoreboard/scripts/scoreboard_calc.py`. If the two ever disagree, fix the script or this file the same turn, and tell the owner.

## 1. What counts, and the proof it needs

| Count | Counts when | Proof |
|---|---|---|
| A Top 3 item is done | The result written next to it in `handoffs/top3-today.md` happened | The owner's words, or a file that is the result (a draft that exists in `handoffs/drafts/`, a job marked done in `handoffs/jobs.md`) |
| A Top 3 item is partly done | A clear piece of the result happened (1 of 2 proposals, a call booked but not held). A booked call is always a piece of an item, never goal moved by itself | The owner's words naming the piece |
| A daily action | It meets the "Counts when" text for that action in `scoreboard-settings.md` | The owner's number. A conversation counts when the other person replied, not when the owner reached out |
| Goal moved | A result that counts toward goal 1 happened today (a client signed, a contract signed, a payment received) | The owner's words. Daily actions alone do not make it yes |

Rules:
- Something that happens outside your files (sent, held, signed, paid) needs the owner's words. A draft existing is never proof that it was sent.
- No proof means not counted. Mark it `unconfirmed`, count it as not done, and say so.
- A vague answer ("I think a few") gets one follow-up question. If it stays vague, count only the number the owner is sure of and write "owner estimate" in How I know.
- Never round an item up. If the result is not clearly met, it is partly or not done.
- The owner can correct any count. A correction is a re-score (see section 6).

## 2. The score, out of 10

| Part | Points when daily actions are set | Points when none are set | How it is worked out |
|---|---|---|---|
| Top 3 | 6 | 9 | Each item done is worth its share of the points. Partly is half a share |
| Daily actions | 3 | none | Each action: actual divided by target, capped at 1. Take the average of all actions, times 3 |
| Goal moved | 1 | 1 | 1 if yes, 0 if no |

Add the parts and round to the nearest whole number. A half rounds up. If fewer than 3 Top 3 items were set that day, the shares are of the number set.

Run it with `python3 ceo-scoreboard/scripts/scoreboard_calc.py score ...` (steps by hand in `ceo-scoreboard/scripts/README.md`).

Examples:
- 3 of 3 done, daily actions 0 of 2, 2 of 2, 0 of 3, goal moved yes: 6 + 1 + 1 = 8.
- 2 done and 1 partly, daily actions 2 of 3 and 1 of 3, goal moved no: 4.5 + 1.5 + 0 = 6.

## 3. The one line why

One sentence. Name what drove the score and the biggest gap. Facts only, no praise, no scolding.
Good: "All three Top 3 done and one client signed. Lost points on new conversations (0 of 2) and follow-ups (0 of 3)."

## 4. The one fix for tomorrow

One fix, one time, tied to the biggest gap: the Top 3 item left undone, or the daily action furthest below its target. Start it with a time the owner already has: the first work block on the next work day (when the owner profile or the settings give no block times, use `9:00 AM`, the default start of the work day, and say it is a default), or a block named in `handoffs/time-manager-report.md` if it is fresh.

**One naming rule for the fix, the first-thing line, the list heading and the list label.** Name the next work day by its day name, from the owner's Work days in the settings (a Friday or Saturday score names Monday, never a day off). Write "tomorrow" only when the day after the scored date is a work day and the clock date is still the scored date. After midnight, or when you score yesterday, always use the day name. The heading of `03_tomorrow.md` is `# Tomorrow's list, for <Day> YYYY-MM-DD` and the label in the night score is `<Day>'s list`. The report file keeps its keys `One fix for tomorrow:` and `## Tomorrow's list` (the check reads them) on every night, including a Friday or Saturday score, where the key is only a label and the text after it names the next work day (check S9 reads the text, never the key), and its Notes line `List is for: <Day> YYYY-MM-DD` says which day the list belongs to. After a re-score the fix is the one in the latest ledger row, and the report fix line must match it word for word. Never invent a new task the files and the owner's words do not support.

## 5. Tomorrow's list

Up to 3 items, in this order:
1. Each Top 3 item not done, with the remaining step as the result that counts as done. Source: carried.
2. Each daily action below its target, furthest below first (a tie goes to the larger shortfall in count), written as the shortfall against its target, as a count, one item each. Only a confirmed count builds an item. An unconfirmed count goes to `missing:`. Source: daily action.
3. Open rows from `chief-of-staff/board/board.md` ("Your list" and "now" jobs), if that file exists.
If fewer than 3 sources exist, list fewer. If none exist, item 1 is "Choose tomorrow's Top 3 first thing". Use the same form as `top3-today.md`: `1. <item> : result that counts as done (source)`. The scoreboard never writes `handoffs/top3-today.md`. It hands the list to the Chief of Staff, who hands it to the Focus Manager.

## 6. Corrections and days off

- **Correction:** the owner says a count was wrong. Do not edit the old ledger row. Add a new row for the same date with Note starting `corrects` and the owner's words. The latest row for a date is the one that counts. A re-score is yellow work (reviewed). The old `02_score.md` stays as history and gets one last line, `Re-scored: N out of 10 (was N)`. The latest ledger row is the one score everywhere else.
- **Answer arrives later:** a night written as partial (`status: partial`, items `unconfirmed`) is replaced when the owner's answer reaches you. Treat it as a correction: a new row for the same date, Note starting `corrects: owner's answer received`, reviewed first. The Chief of Staff writes `Owner's answer:` into the job row. The Scoreboard never writes it. A correction with no owner words (an arithmetic error found by the check) has the Note `corrects: arithmetic, no owner words` and the old and new numbers.
- **Day off:** the owner says they are off. Add a row with Score `off`, Done, Partly, Of as `0`, Leading `none`, Goal moved `no`. No score is given and the streak does not change. Tomorrow's list and the report are still written (stage 03 and 04). Work days listed in settings with no row and no `off` are missed nights.

## 7. Streaks

- **Good-day streak:** work days in a row with a score of 7 or more (the number in settings). A lower score ends it.
- **Nights scored in a row:** work days in a row with any score. A work day with no row and no `off` ends both streaks.
- Days that are not work days, and `off` days, change nothing. Say it in the night score by case: a scored work day (paste the script lines), a day off ("Day off, the streak does not change"), a scored day that is not a work day ("<Day> is not a work day, so the streak does not change"), a missed work day since the last night (paste the script's `Missed work day` line, the streak is back to 0).
- The best streak is the longest run found in the ledger.
Run `python3 ceo-scoreboard/scripts/scoreboard_calc.py streak --today YYYY-MM-DD` (the clock date). "Show my streak" is green work: show the script lines and write no file.

## 8. The ledger

`ceo-scoreboard/ledger/scoreboard-log.md`. Append only. One row per scored day, 11 columns:

`Date | Done | Partly | Of | Leading | Goal moved | Score | Why | Fix | How I know | Note`

- Leading is written `M1 2/3, M2 1/3` (code, actual, target). With no daily actions set, write `none`.
- How I know names the proof for each count: "owner's words in 01_gather.md", "draft file exists", "job J4 marked done".
- Replace any pipe character in the owner's words with a slash so the table stays readable.

## 9. The weekly view

Seven days ending on the day asked. Use `python3 ceo-scoreboard/scripts/scoreboard_calc.py week --end YYYY-MM-DD`. The table and totals come from the ledger and nowhere else. Add `--today YYYY-MM-DD` (the clock date): the streak line is worked out as of that date, so a missed work day after the week's last row shows. Then add one change for next week, tied to the daily action with the lowest share of its target. The weekly view is yellow work.

## 10. Agent work (the activity log)

Every agent adds one line to `logs/activity.md` when it finishes a job: When | Agent | Job | Result | Proof. The Proof cell names a file and words copied from it: `path contains "exact words"`. Each night the Scoreboard checks the lines for the day it scores. `python3 ceo-scoreboard/scripts/scoreboard_calc.py agents --date YYYY-MM-DD` does the check and gives each line a code (AL1, AL2, and on, in log order for that day).

| Mark | When | Counted |
|---|---|---|
| pass | The proof file exists inside the toolkit folder and holds the quoted words | Yes |
| fix | The claim cannot be checked: the Proof cell is empty or not in the `contains "..."` form, the quoted words are under 12 characters, the file does not exist, the proof is in another agent's folder, the proof is in a run folder dated another day, or the line is not in the log format. This is a claimed job with its proof missing | No. Flagged |
| replaced | A later line from the same agent starts `corrects AL3`, so AL3 is replaced | No. Not flagged, not counted. Only the correcting line is checked (shown in the script's table, never in the flags) |
| fail | The proof is there but does not show the claim: the quoted words are not in the file, the line says sent, posted, published, paid, booked, emailed, texted, messaged, replied, delivered, scheduled, submitted or forwarded and the proof is a draft (a file in `handoffs/drafts/` in any capital letters, or a path or quoted words that say "draft"), the proof is outside the toolkit folder (a link that leads out of it counts), or the proof is the activity log itself (in any capital letters) | No. Flagged |

Rules:
- Only pass counts. The report line is `- Agents: N jobs done, M flagged`, with N and M copied from the script.
- After the script, read each pass line's proof file. If the words are there but the file does not show the Job and the Result (for example the words are from an older run, or the file says "waiting" where the line says "done"), write a review line under `## Agent review` in `02_score.md`: `- review AL3 fail: <reason>` (or `fix`). Then run the script again. A review line can only move a job down (pass to fix or fail, fix to fail), never up.
- A line whose Job starts `corrects AL3` replaces AL3 for that day, but only when the correcting line is from the same agent. A `corrects` line from another agent is marked fix and the old line stays flagged. An exact duplicate line counts once. AL3 is then not counted and not flagged. A fix made on a later day is a new line for that later day.
- The Scoreboard never fixes another agent's work and never edits the log. Each flag names the fix for the Chief of Staff (standalone, with no Chief of Staff set up: for the owner, and the script writes "the owner").
- A line with no readable date (a bad format such as 2026/11/20, or an impossible date) is not counted. The script prints `- Unreadable log lines: N`. Copy that line into the report under the Agents line. Check S8 fails when it is missing.
- A line logged after the report's `updated` time is left out of that report. Pass `--until "YYYY-MM-DD HH:MM"` with the same time you write in `updated`. A line timed in the same minute as `updated` counts as before the report, so it stays in. The next report picks up only lines timed after that minute.
- Agent work never changes the score out of 10. It is a separate count.
