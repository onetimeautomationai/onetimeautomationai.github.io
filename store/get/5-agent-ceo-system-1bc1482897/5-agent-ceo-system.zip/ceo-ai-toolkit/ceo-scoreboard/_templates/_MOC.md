# _templates: map

| Path | One line |
|---|---|
| `run/01_gather.md` | Copied into each night run folder |
| `outputs/02_score.md` | Score stage output |
| `outputs/03_tomorrow.md` | Tomorrow stage output |
| `outputs/scoreboard-report.md` | The handoff file, exact format |
| `outputs/04_report.md` | Report stage output |
| `outputs/night-score.md` | What the owner reads each night |
| `outputs/05_week.md` | Weekly view |
| `outputs/06_log.md` | Log stage output |
