# Score, YYYY-MM-DD

## Top 3
| # | Item | Status: done / partly / not done / unconfirmed | Proof |
|---|---|---|---|

## Daily actions
Leading: M1 a/t, M2 a/t (or none)

## Goal moved
yes / no, and the owner's words

## Script output
<paste the output of scoreboard_calc.py score>

## Agent review
<one line per job whose proof does not show the claim, for example: - review AL3 fail: the file says waiting, the line says done. Or: none>

## Agent work
<paste the output of scoreboard_calc.py agents --date YYYY-MM-DD, run after the review lines are written>

## Score
N out of 10. Top 3 done: N of 3.

Why: <one sentence>

Fix: <one fix with a time>
