# Tomorrow's list, for <Day> YYYY-MM-DD

1. <item> : <result that counts as done> (<carried, a file path and item> or <daily action, a file path and M code> or <board, a file path and row>)
2. <item> : <result> (<kind, file path or ledger row>)
3. <item> : <result> (<kind, file path or ledger row>)

<Day>, first thing: <one thing>
