# Report, YYYY-MM-DD

- Ledger row added: yes / no
- handoffs/scoreboard-report.md written: yes / no (status: ok / partial / failed)
- Decision log rows: L# (and the re-score L# after a re-score, so both rows are listed)
- Job row status set: done / waiting: reason / no row
- check_scoreboard.py result:
- Ledger, report and run folder show the same score: yes / no

## Night score (the owner reads this)
<the night score from night-score.md>
