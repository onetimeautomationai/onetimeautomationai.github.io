# Week, ending YYYY-MM-DD

<paste the output of scoreboard_calc.py week>

Review: pending

**One change for next week:** <one sentence, tied to the lowest daily action or the Top 3 pattern>
