# Log

- Ledger row for the scored date: yes / no
- Report and ledger agree: yes / no
- Decision log rows added: L# to L#
- Lessons added:
- check_scoreboard.py result:
- Still open:
