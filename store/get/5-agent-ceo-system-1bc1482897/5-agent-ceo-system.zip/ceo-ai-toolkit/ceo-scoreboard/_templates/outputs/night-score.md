# Night score, YYYY-MM-DD

A re-score uses this whole template, not a shorter one.

**Agent flags:** <each flagged job in one line: code, agent, job, what is wrong, the fix and who does it. Or: none>

**Score:** <N> out of 10. Top 3 done: <N> of 3. <The ledger Why with its own closing period removed>. After a re-score, write `<N> out of 10 (re-score, was <N>).` so the line never ends in two periods. Add the reason as one sentence right after it: with owner words, `Re-scored because <the owner's words in short>.` Without owner words (the check found an arithmetic error), `Re-scored because the check found an arithmetic error, no owner words (old <N>, new <N>).`

**Top 3**
1. <item> : <done / partly / not done / unconfirmed>
2. <item> : <status>
3. <item> : <status>

**Daily actions:** <M1 action a of t, M2 action a of t>. Goal moved: <yes / no>.

**Agents:** <N> job or jobs (write "1 job", never "1 jobs") done, with proof. <M> flagged (listed at the top).

**Streak:** <paste the first line of `scoreboard_calc.py streak` exactly, for example `Good-day streak (score 7 or more): 1 good day in a row. Best: 3.`>. Then by case: a scored work day adds nothing. A day off adds "Day off, the streak does not change." A scored day that is not a work day adds "<Day> is not a work day, so the streak does not change." A missed work day adds the script's `Missed work day` line. Add the second line (Nights scored in a row) only when it is over 0.

**Counts I used are above. Say "fix" if any is wrong.**

**One fix for <Day>:** <one fix with a time>. Name the day (rule in `scoring-guide.md` section 4). Write `One fix for tomorrow:` only when tomorrow is a work day and the clock date is the scored day. The report file keeps the key `One fix for tomorrow:` either way.

**<Day>'s list, <YYYY-MM-DD>** (write `Tomorrow's list` only when tomorrow is a work day and the clock date is the scored day)
1. <item> : <result that counts as done> (<kind, file path or ledger row>)
2. <item> : <result> (<kind, file path or ledger row>)
3. <item> : <result> (<kind, file path or ledger row>)

<Day>, first thing: <one thing>. Write `Tomorrow, first thing:` only under the same condition.
