---
from: ceo-scoreboard
updated: YYYY-MM-DD HH:MM
status: ok
---

## Score for YYYY-MM-DD
- Top 3 done: N of 3
- Score: N out of 10, <one line why>
- One fix for tomorrow: <one fix with a time, naming the day, for example Monday 9 AM>
- Agents: <copy the rest of the script's own `- Agents:` line, which says "1 job" for one>

## Tomorrow's list
1. <item> : <result that counts as done>
2. <item> : <result>
3. <item> : <result>

## Agent flags
- <each flag line from scoreboard_calc.py agents, fail first, or: none>

## Notes
- Scored against: <top3-today.md / owner's words / board, confirmed by owner>
- Daily actions: M1 a of t, M2 a of t
- Streak: <the script's lines, for example `1 good day in a row` or `2 good days in a row`>. Nights scored in a row: <N>
- List is for: <Day> YYYY-MM-DD
- missing: <what, or delete this line>
- needs owner: <red item with recommendation and why it moves goal 1, or delete this line>
