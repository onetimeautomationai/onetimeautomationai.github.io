---
run: {{run_name}}
started: {{YYYY-MM-DD HH:MM}}
day scored: {{YYYY-MM-DD}}
---

# Gather

## Top 3 and where it came from
Source: top3-today.md (Focus Manager or Chief of Staff) / owner's words / board, confirmed by owner

| # | Item | Result that counts as done | Proof found in files |
|---|---|---|---|

## Owner's words (exact)


## Daily actions asked
| Code | Action | Target |
|---|---|---|

## Unconfirmed or missing

