# How your CEO Scoreboard works

## The idea
A CEO decides what matters in the morning and finds out at night whether it happened. Your CEO Scoreboard does the second part in five minutes. It compares your Top 3 with your day, counts the daily actions that move your number one goal, scores the day out of 10, and hands you tomorrow's list. The scores add up into streaks and a weekly view, so you see a trend and not just a feeling.

## The flow

```
Focus Manager ──> handoffs/top3-today.md ──┐
                                           v
You (one answer) ───────────────────> CEO Scoreboard
board, jobs, drafts (proof) ────────────────^   │
                                                 ├──> ledger row (one new row each night)
                                                 ├──> handoffs/scoreboard-report.md ──> Chief of Staff
                                                 └──> your night score and tomorrow's list
```

Each night has five steps: gather (the Top 3, the proof, your one answer), score (statuses, counts, arithmetic), tomorrow (the list), report (the ledger row, the handoff file, your night score), log (everything true, checks pass). The weekly view is a separate step that reads the ledger.

## How the score is worked out
Top 3 is worth 6 points, daily actions 3, goal moved 1. Without daily actions, the Top 3 is worth 9. The arithmetic is written in `_shared/scoring-guide.md` and done by `scripts/scoreboard_calc.py`, so the score is never picked first and explained after.

## What counts
Only what has proof. Your words count. A file counts when the result is a file (a draft written). A draft never counts as sent. If it cannot prove a count, it says "unconfirmed" and counts it as not done.

## With the Chief of Staff, or alone
- **With the Chief of Staff:** the Chief of Staff starts the scoreboard from a row in `handoffs/jobs.md`. The scoreboard reads your Top 3, writes `handoffs/scoreboard-report.md`, and the Chief of Staff shows you the result in your night wrap and uses yesterday's score in your next brief. The scoreboard does not talk to you unless the Chief of Staff tells it to.
- **Alone:** you talk to the scoreboard directly. It asks one question, and it has its own setup, lessons and decision log.

## Three trust lights
- **Green:** scoring the night, writing the files. It does it and logs it.
- **Yellow:** a re-score after you correct a count, and the weekly view. An AI reviewer checks it first. If it fails twice, it becomes red.
- **Red:** changing a daily action or target, sharing your score with anyone, and anything that sends, posts, pays, buys, deletes or books. It waits for your yes.

## What it keeps
Everything lives in the toolkit folder on your computer: the ledger (one row per day, never edited), the nightly run folders, the decision log, your settings. Nothing is sent to us.
