# A sample night (made-up owner, made-up data)

Owner: Dana Ruiz, runs a 6-person bookkeeping firm. Goal 1: "10 new monthly clients by March 31." Daily actions: M1 new conversations (target 2, counts when the person replies), M2 proposals sent (target 2), M3 follow-ups on open proposals (target 3). Work days Monday to Friday. A good day is 7 or more. Report style: short, lists.

This is the same day as `chief-of-staff/examples/sample-day.md`.

## 6:15 PM, Dana says "Wrap up my day"

Her Chief of Staff starts the scoreboard job. The scoreboard reads today's `handoffs/top3-today.md`, finds two drafts in `handoffs/drafts/`, and asks one question:

> Here is your day. Top 3:
> 1. Send proposals to the two warm leads : both proposals drafted for your review (found: draft file)
> 2. Call back Priya Shah about the payroll add-on : call held, next step agreed (found: nothing yet)
> 3. Year-end checklist offer post : post drafted for your review (found: draft file)
> Daily actions: M1 new conversations, target 2. M2 proposals sent, target 2. M3 follow-ups, target 3.
> One reply is enough: which of the three are done, partly or not, how many of each daily action, and anything that moved your goal. Example: "1 and 3 done, 2 partly, conversations 2, follow-ups 1, nothing signed."

Dana: "All three done. Priya signed for 12 months. Conversations 0, proposals 2, follow-ups 0."

## What the scoreboard writes

The score: Top 3 done 3 of 3 gives 6 points. Daily actions are (0 of 2, 2 of 2, 0 of 3), so (0 + 1 + 0) divided by 3, times 3, gives 1 point. Goal moved (Priya signed) gives 1 point. Total 8.

Ledger row in `ceo-scoreboard/ledger/scoreboard-log.md`:

```
| 2026-11-19 | 3 | 0 | 3 | M1 0/2, M2 2/2, M3 0/3 | yes | 8 | All three done and one client signed. Lost points on follow-ups (0 of 3) and new conversations (0 of 2) | First work block on the next work day, send 3 follow-ups before opening email | owner's words in run 2026-11-19-night, draft files for items 1 and 3 | |
```

`handoffs/scoreboard-report.md`:

```
---
from: ceo-scoreboard
updated: 2026-11-19 18:21
status: ok
---

## Score for 2026-11-19
- Top 3 done: 3 of 3
- Score: 8 out of 10, all three done and one client signed, lost points on follow-ups (0 of 3) and new conversations (0 of 2)
- One fix for tomorrow: first work block, send 3 follow-ups to people with open proposals before opening email
- Agents: 9 jobs done, 1 flagged

## Tomorrow's list
1. Follow-ups : 3 follow-ups sent to people with open proposals (daily action M3, 0 of 3 today)
2. New conversations : 2 new people reply to you (daily action M1, 0 of 2 today)
3. Approve and publish the offer post : post is live, needs your yes (board A1)

## Agent flags
- AL6 fix: time-manager, Blocked the Top 3. Claimed, proof missing: time-manager/runs/2026-11-19/06_log.md does not exist. Fix: the Chief of Staff asks the time-manager to add a new line that starts 'corrects AL6' and points to the file that shows the job. If no file shows it, the job is not done.

## Notes
- Scored against: top3-today.md (Focus Manager)
- Daily actions: M1 0 of 2, M2 2 of 2, M3 0 of 3
- Streak: 4 good days in a row. Nights scored in a row: 6
```

## What Dana reads in her wrap (night score)

> **Agent flags:** AL6, the Time Manager logged "Blocked the Top 3" but its proof file is missing. Your Chief of Staff will ask it to show the file. Until then it is not counted.
>
> **Score:** 8 out of 10. Top 3 done: 3 of 3. All three done and one client signed. Lost points on follow-ups (0 of 3) and new conversations (0 of 2).
>
> **Top 3**
> 1. Send proposals to the two warm leads : done
> 2. Call back Priya Shah : done
> 3. Year-end checklist offer post : done
>
> **Daily actions:** new conversations 0 of 2, proposals sent 2 of 2, follow-ups 0 of 3. Goal moved: yes.
>
> **Agents:** 9 jobs done, with proof. 1 flagged (listed at the top).
>
> **Streak:** 4 good days in a row (score 7 or more). Best: 4.
>
> **Counts I used are above. Say "fix" if any is wrong.**
>
> **One fix for tomorrow:** first work block, send 3 follow-ups before opening email.
>
> **Tomorrow's list**
> 1. Follow-ups : 3 sent to people with open proposals
> 2. New conversations : 2 new people reply to you
> 3. Approve and publish the offer post : post is live, needs your yes
>
> Tomorrow, first thing: send 3 follow-ups to people with open proposals.

The scoreboard never publishes the post. Item 3 waits for Dana's yes.

## 6:30 PM, Dana says "Fix today's score, I also had one new conversation, Ana Lima replied"

A correction is a re-score, so it is reviewed first. The ledger keeps the old row and gets a new row for 2026-11-19 with Note `corrects: "I also had one new conversation, Ana Lima replied"`. M1 becomes 1 of 2. Daily action points: (0.5 + 1 + 0) divided by 3, times 3, is 1.5. Total 6 + 1.5 + 1 = 8.5, which rounds up to 9. The report and the night score are rewritten with the new number.

## Another week: Dana says "Weekly view" on Wednesday 2026-11-18

The scoreboard runs the weekly script on the ledger. These are the five seeded rows in `ceo-scoreboard/tests/seed-ledger.md`.

> **Week from 2026-11-12 to 2026-11-18**
> Nights scored: 5 of 5 work days. Average score: 7.6 out of 10. Good days (7 or more): 4. Top 3 done: 12 of 15 items. New conversations: 6 of 10 (60 percent of target). Proposals sent: 7 of 10 (70 percent). Goal moved on 2 of 5 days. Best day: 2026-11-16 (10). Lowest day: 2026-11-17 (4).
>
> One change for next week: new conversations are the lowest daily action at 60 percent, so put your 2 new conversations in the first work block each day.

In your own week, every figure comes from your own ledger and nowhere else.
