# Known limitations

- **The score is only as true as the answers you give.** The scoreboard counts what you tell it and what files prove. It cannot see your email or calendar, so it cannot check a count you give it. A draft is never counted as sent.
- **A score is a tool, not a verdict.** A 10 means you hit your own Top 3, targets and goal check. It does not mean the Top 3 was the right one.
- **It works best with the Focus Manager.** Without one, it asks for your Top 3 each night, or uses your Chief of Staff's file. Scoring against a Top 3 you give at night is weaker than one set in the morning.
- **It does not run by itself unless your agent can schedule tasks.** Without that, open your agent and say "Score my day".
- **Under the Chief of Staff it cannot ask you questions.** If your answer is not in the job, it counts what files prove, marks the rest unconfirmed and gives a partial score. Your Chief of Staff can then ask you and re-run it.
- **Streaks follow your work days.** A work day with no night score ends the streak. A day off said out loud does not. If you forget to say so, say "I was off on [date]" and it adds the row.
- **The ledger lives in one folder on one computer.** It does not sync across devices unless you put the folder in a synced drive yourself.
- **The one-paste version has no memory.** `INJECT-PROMPT.md` scores a day, but it cannot keep a ledger, a streak or a weekly view between chats.
- **Rule following depends on your AI agent and model.** Stronger agents follow the rules more closely. The checks in `ceo-scoreboard/scripts/check_scoreboard.py` catch the most important misses (a score that does not match the arithmetic, a report that does not match the ledger, a share logged as green) when your agent can run Python.
- **The review is strongest with a second agent.** Re-scores and weekly views are checked by a separate reviewer. If your agent cannot start helper agents, the same agent reviews its own work in a separate pass, marked `review: pass (self)`. That is weaker, because it is checking itself.
- **One owner.** It is built for one CEO. A team can share the folder, but it treats every answer as coming from the owner.
- **No phone or text alerts built in.** It talks to you inside your AI agent.
- **Long histories slow it down.** After a few months, move old `runs/` folders into `runs/archive/`. Keep the ledger whole.
