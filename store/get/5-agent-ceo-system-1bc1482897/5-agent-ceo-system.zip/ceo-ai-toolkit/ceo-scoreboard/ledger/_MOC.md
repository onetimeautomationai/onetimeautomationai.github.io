# ledger: map

| File | One line |
|---|---|
| `scoreboard-log.md` | One row per scored day. Append only. Streaks and the weekly view read it |
