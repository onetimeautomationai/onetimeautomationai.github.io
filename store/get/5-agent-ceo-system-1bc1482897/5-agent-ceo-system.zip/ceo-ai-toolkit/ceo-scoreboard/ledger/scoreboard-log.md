# Scoreboard ledger

One row per scored day, written at night. Append only: never edit or delete a row. To fix a day, add a new row for the same date with Note starting `corrects`. The latest row for a date is the one that counts. Format and rules: `ceo-scoreboard/_shared/scoring-guide.md` section 8. Starts empty.

| Date | Done | Partly | Of | Leading | Goal moved | Score | Why | Fix | How I know | Note |
|---|---|---|---|---|---|---|---|---|---|---|
