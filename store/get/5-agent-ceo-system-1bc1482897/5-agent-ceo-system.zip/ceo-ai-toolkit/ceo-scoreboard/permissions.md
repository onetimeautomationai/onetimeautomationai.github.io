# What the CEO Scoreboard can touch

Paths start from the `ceo-ai-toolkit` folder.

| Area | Read | Write | Notes |
|---|---|---|---|
| `ceo-scoreboard/` | Yes | Yes | Its own working files. Rules files change only with your yes (`INSTALL.md`, safe change rules) |
| `handoffs/scoreboard-report.md` | Yes | Yes | The file it writes each night |
| `handoffs/jobs.md` | Yes | Only the Status cell of its own row | It never changes another row |
| `handoffs/top3-today.md` | Yes | No | The Focus Manager's file (or the Chief of Staff's). Never written by the scoreboard |
| `handoffs/drafts/` | Yes | No | It lists files there to prove a result that is a file |
| Other files in `handoffs/` | No need | No | |
| `chief-of-staff/_shared/owner-profile.md`, `lessons.md`, `decision-tiers.md`, `review-rubric.md` (master), `handoffs.md`, `voice-profile.md` | Yes | No | The Chief of Staff keeps them |
| `chief-of-staff/board/board.md` | Yes | No | For tomorrow's list and to find open items |
| `logs/activity.md` | Yes | No | The jobs the other agents logged. It checks them at night and never edits the log |
| Other hire folders | Only the proof files that `logs/activity.md` names | No | It reads a proof file to check a job. It never fixes another agent's work |
| `.ceo-toolkit/` | Yes | Adds snapshots and log rows only | Never deletes anything there |
| Your email and calendar | No | No | It never reads them. Your counts come from you and from files |
| Outside the toolkit folder (scheduled tasks, your agent's settings) | No | Only with your yes, following the safe change rules in `INSTALL.md` | |
| Passwords, keys, tokens | Never stored | Never stored | If a job needs one, it stops and tells you |

## Actions that always need your yes

Sending, posting, publishing, paying, buying, deleting, and booking with another person. These are always red (`chief-of-staff/_shared/decision-tiers.md`). Sharing your score with anyone is one of them. `ceo-scoreboard/scripts/check_scoreboard.py` fails if one is logged as green or yellow, or marked done without your words.
