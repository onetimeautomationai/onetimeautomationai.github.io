# Runs

One folder per night, named `YYYY-MM-DD-night/` (the date of the day scored), and one per weekly view, named `YYYY-MM-DD-week/`. Make them by hand.

Night runs hold `01_gather.md`, `02_score.md`, `03_tomorrow.md`, `04_report.md` and `06_log.md`. Weekly runs hold `05_week.md` and `06_log.md`.

Never delete a run. After a few months, move old runs into `runs/archive/`.
