# Scripts

Two small scripts. Standard Python 3, nothing to install. They work from any folder. The docs show them run from the `ceo-ai-toolkit` folder. Both are optional: if your AI agent cannot run Python, it does the same steps by hand, as listed here.

| Script | What it does | By hand |
|---|---|---|
| `scoreboard_calc.py score --done N --partly N --of N --leading "M1 2/3, M2 1/3" --goal-moved yes` | Works out the score from the counts | Section A below |
| `scoreboard_calc.py streak [--today YYYY-MM-DD]` | Current and best streaks, from the ledger | Section B below |
| `scoreboard_calc.py week --end YYYY-MM-DD [--today YYYY-MM-DD]` | The seven days ending that date, with totals. The streak line is as of today, not the week end | Section C below |
| `scoreboard_calc.py agents --date YYYY-MM-DD` | Checks each line of `logs/activity.md` for that day against its proof: pass, fix or fail. Counts jobs done (pass only) and lists the flags | Section E below |
| `check_scoreboard.py` | Runs checks S1 to S10. Exit code 0 means pass. Add `--skip-report` after a weekly view | Section D below |
| `../tests/test_agent_check.py` | Tests the agent work check on a made-up toolkit in a temporary folder (TC18 to TC24) | Not needed |

## A. The score by hand

1. Top 3 points. With daily actions set, the Top 3 is worth 6 points. With none set, 9. Points = that number times (items done + half of items partly done) divided by the number of Top 3 items that day.
2. Daily action points (only if set). For each action, divide the actual by the target. If it is more than 1, use 1. Add them up, divide by how many actions there are, multiply by 3.
3. Goal moved: 1 point for yes, 0 for no.
4. Add the three. Round to the nearest whole number. A half rounds up.

Example: 3 of 3 done, daily actions 0 of 2, 2 of 2, 0 of 3, goal moved yes. Top 3 points 6. Daily actions (0 + 1 + 0) / 3 times 3 = 1. Goal 1. Total 8.

## B. Streaks by hand

Open `ceo-scoreboard/ledger/scoreboard-log.md`. Use the latest row for each date. Go back one day at a time from the latest scored date:
- Row with a score of 7 or more (or the good-day number in the settings): add 1 to the good-day streak.
- Row with a lower score: the good-day streak stops.
- Row with Score `off`, or a day that is not a work day and has no row: skip it.
- A work day with no row: both streaks stop.
Nights scored in a row counts every scored row the same way, whatever the score. If a work day between the latest row and today has no row, both current streaks are 0.

## C. The weekly view by hand

List the seven days ending on the date asked, one line each, from the ledger rows: Top 3 done of items, the Leading column, goal moved, score. Then: nights scored out of work days, average score of the scored days (one decimal), good days, Top 3 done out of items, for each daily action the total actual out of the total target, days the goal moved, best and lowest day, and the streaks from section B, counted as of today (a work day after the week's last row with no row ends them). Never fill a day that has no row.

## D. The checks

| # | Check |
|---|---|
| S1 | `ceo-scoreboard/_shared/scoreboard-settings.md` has no `{{` and says `setup_done: yes` |
| S2 | `handoffs/scoreboard-report.md` exists, with a header (`from: ceo-scoreboard`, `updated`, `status`), a `## Score for YYYY-MM-DD` section with the three lines, and `## Tomorrow's list` with 1 to 3 numbered items |
| S3 | The report's scored day and its `updated` date are today or yesterday |
| S4 | The report's score and Top 3 count match the ledger row for that day, and so does the report's `One fix for tomorrow` text against the ledger Fix (ignoring spaces and capital letters) (skipped when the report says `status: failed`), and every ledger score matches the arithmetic in section A |
| S5 | Every ledger row has 11 columns, a valid date, whole-number counts, goal moved yes or no, and a filled "How I know". A repeated date needs a Note starting `corrects` |
| S6 | Every decision log row has 8 columns, a tier of T1, T2 or T3, a Result of done, pending, parked or no. A T3 marked done has the owner's words. Anything that sends, posts, publishes, pays, buys, deletes, books or shares is T3. A T2 marked done says `review: pass` |
| S7 | No password, key or token in `_shared/`, `ledger/` or `runs/` |
| S8 | The report's `- Agents: N jobs done, M flagged` line matches section E for the scored day, and every job marked fix or fail is listed by its code under `## Agent flags`. If the log has jobs for the day, the Agents line must be there. Lines logged after `updated` are ignored. If the log has lines with no readable date, the report needs `- Unreadable log lines: N` with the same N. Skipped when the report says `status: failed` |
| S9 | The report's `One fix for tomorrow` line, the closing line of `03_tomorrow.md` and the first-thing line of `04_report.md` name the next work day (from Work days in the settings). It says "tomorrow" only when tomorrow is a work day. A Friday or Saturday score must name Monday for a Monday to Friday owner |

| S10 | A weekly view whose `05_week.md` says `Review: pass` has `05_review.md` in the same run folder, and every ledger row whose Note starts `corrects` has `runs/<date>-night/04_review.md`. A record has a pass or fail result for each of RR1 to RR5 and a `Reviewed by: <helper or self>, <time>` line. A same-agent review (self) also needs a `Helper failed: <the error>` line. `Review: pending` needs no record |

A decision log row whose Decision starts with `corrects L4` replaces row L4 for check S6.

**Today and the time zone.** The checks use today's date in the owner's time zone, read from the profile or settings file. Add `--today YYYY-MM-DD` to test as if it were another day. A row marked `Owner task:` fails if its Evidence says the AI sent it. The action words that must be T3 include forward, accept, renew, subscribe, ordered, charge, share, invite and cancel.

## E. The agent work check by hand

Open `logs/activity.md`. Take the lines whose When starts with the day you score, in order, and number them AL1, AL2, and on. For each line:
0. Leave out any line logged after the report's `updated` time, and count an exact duplicate line once. A line whose date is unreadable or impossible is not counted. Write `- Unreadable log lines: N`.
1. It needs 5 cells, a When of YYYY-MM-DD HH:MM, an Agent from the list at the top of the log, and a Job and a Result. If not: fix.
2. The Proof cell must read `path contains "words"`. Empty, or in another form: fix (claimed, proof missing).
3. The path starts with `/`, `~` or has `..`, or it leads outside the toolkit folder, or it is `logs/activity.md` itself (any capital letters): fail. The Job or Result says sent, posted, published, paid, booked, emailed, texted, messaged, replied, delivered, scheduled, submitted or forwarded (not "not sent") and the proof path is in `handoffs/drafts/` (any capital letters) or the path or words say "draft": fail.
4. The file does not exist: fix (claimed, proof missing). A proof in another agent's folder is fix (claimed, proof in another agent's folder). A proof in a run folder dated another day is fix (claimed, proof from a run dated another day).
4a. The path starts with another agent's folder name (not the Agent in the line), or it is under a `runs/YYYY-MM-DD...` folder dated a different day than the line: fix (not a pass). Other paths are not checked this way.
4b. The quoted words are under 12 characters: fix.
5. The words are not in the file (ignore extra spaces and capital letters): fail. Otherwise: pass.
6. Apply your review lines from `02_score.md` (`- review AL3 fail: reason`). They only move a job down.
7. A line whose Job starts `corrects AL3` replaces AL3 only when both lines have the same Agent: AL3 is then marked `replaced`, neither counted nor flagged. From another agent it is marked fix and AL3 stays flagged.
8. Under each flag, the fix names the Chief of Staff when it is set up and the owner when it is not.

Jobs done = the pass lines. Flagged = the fix and fail lines. Write `- Agents: N jobs done, M flagged`, and `- Unreadable log lines: N` when there are any.
