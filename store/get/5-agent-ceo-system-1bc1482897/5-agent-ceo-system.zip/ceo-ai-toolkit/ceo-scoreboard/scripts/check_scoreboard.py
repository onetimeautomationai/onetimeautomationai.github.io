#!/usr/bin/env python3
"""Hard checks the CEO Scoreboard runs before it calls a night or a week done.

Usage (from the ceo-ai-toolkit folder, works from any folder):
    python3 ceo-scoreboard/scripts/check_scoreboard.py
    python3 ceo-scoreboard/scripts/check_scoreboard.py --skip-report      (after a weekly view, when no new report was written)
    python3 ceo-scoreboard/scripts/check_scoreboard.py --today 2026-11-19  (test with a made-up date)

Exit code 0 = all checks pass. 1 = at least one check failed (each failure is printed).
Standard library only. Reads files, never changes them.

Checks:
  S1  Setup is done: settings file has no {{ placeholders and says setup_done: yes.
  S2  handoffs/scoreboard-report.md exists and is well formed (header, score section, tomorrow's list).
  S3  The report is fresh: scored day and updated date are today or yesterday.
  S4  The report matches the ledger, and the ledger score matches the arithmetic.
  S5  Every ledger row is complete and says how the counts are known.
  S6  Decision log rows are valid. T3 done has the owner's words, sends and the like are T3, yellow done has review: pass.
  S7  No secrets in this hire's working files.
  S8  The report's agent count and flags match the check of logs/activity.md for the scored day
      (the same check as scoreboard_calc.py agents). Only jobs that pass are counted. Every job
      marked fix or fail is listed under ## Agent flags.
  S9  The report's fix line, the closing line of the night score and 03_tomorrow.md name the next
      work day (from Work days in the settings), or say "tomorrow" only when tomorrow is a work day.
  S10 A weekly view that says `Review: pass` has a review record, runs/<date>-week/05_review.md, and every
      ledger row whose Note starts `corrects` has runs/<date>-night/04_review.md. A record has a result for
      RR1 to RR5 and a `Reviewed by: <helper or self>, <time>` line. A same-agent review also needs a
      `Helper failed:` line. When the record says `Reviewed by: self`, both `05_week.md` and the
      decision log row for that run folder must say `review: pass (self)`, never a bare pass.
"""
import argparse
import datetime
import re
import sys
from pathlib import Path

try:
    from zoneinfo import ZoneInfo
except ImportError:  # very old Python
    ZoneInfo = None


COMMON_ZONES = [("pacific", "America/Los_Angeles"), ("pst", "America/Los_Angeles"), ("pdt", "America/Los_Angeles"),
                ("mountain", "America/Denver"), ("mst", "America/Denver"), ("mdt", "America/Denver"),
                ("central", "America/Chicago"), ("cst", "America/Chicago"), ("cdt", "America/Chicago"),
                ("eastern", "America/New_York"), ("est", "America/New_York"), ("edt", "America/New_York")]


def owner_today(override, profile_files):
    """Today's date in the owner's time zone. override is YYYY-MM-DD (tests).
    The zone is read from the first profile file that names one (a line like 'Time zone: America/Chicago').
    With no zone found, the computer's date is used."""
    if override:
        try:
            return datetime.date.fromisoformat(override)
        except ValueError:
            raise SystemExit(f"--today {override} is not a real date. Use YYYY-MM-DD.")
    if ZoneInfo:
        for p in profile_files:
            try:
                text = Path(p).read_text(encoding="utf-8")
            except OSError:
                continue
            m = re.search(r"^-?\s*Time zone[^:\n]*:[^\n]*?([A-Za-z]+/[A-Za-z_]+(?:/[A-Za-z_]+)?)", text, re.M | re.I)
            if m:
                try:
                    return datetime.datetime.now(ZoneInfo(m.group(1))).date()
                except Exception:
                    pass
            line = re.search(r"^-?\s*Time zone[^:\n]*:([^\n]*)", text, re.M | re.I)
            if line:  # a plain name such as "Pacific, 5 PM" (LR-D11)
                low = line.group(1).lower()
                for word, zone in COMMON_ZONES:
                    if re.search(rf"\b{word}\b", low):
                        try:
                            return datetime.datetime.now(ZoneInfo(zone)).date()
                        except Exception:
                            pass
    return datetime.date.today()


def arg_today():
    """The value after --today on the command line, or empty."""
    if "--today" in sys.argv:
        i = sys.argv.index("--today")
        if i + 1 < len(sys.argv):
            return sys.argv[i + 1]
    return ""

HERE = Path(__file__).resolve().parent.parent  # the ceo-scoreboard folder
sys.path.insert(0, str(Path(__file__).resolve().parent))
import scoreboard_calc as calc  # noqa: E402

TOOLKIT = HERE.parent
REPORT = TOOLKIT / "handoffs" / "scoreboard-report.md"
FAILS = []

RESULTS = {"done", "pending", "parked", "no"}
EMPTY_WORDS = {"", "-", "--", "n/a", "na", "none", "tbd", "?"}
ACTION = re.compile(
    r"\b(send|sends|sent|email to|reply to|post|posts|posted|publish|published|"
    r"pay|pays|paid|buy|buys|bought|purchase|purchased|invoice|refund|"
    r"delete|deletes|deleted|book|books|booked|schedule a call with|"
    r"sign a contract|sign the contract|signed|contract|hire|hiring|"
    r"website|wire|transfer|share|shared|invite|invites|invited|cancel|cancels|cancelled|forward|forwards|forwarded|accept|accepts|accepted|renew|renews|renewed|subscribe|subscribes|subscribed|ordered|place an order|charge|charges|charged|share|shares|shared|confirm with|confirmed with|confirms with)\b",
    re.I,
)
OWNER_TASK = re.compile(r"^\s*owner task\s*:", re.I)
# An "Owner task:" row says the owner did it. If its Evidence says the AI sent it, the row is mislabeled.
AI_SENT = re.compile(r"\b(ai sent|i sent|sent by (the )?(ai|agent|assistant|manager|email manager|me)|(the )?(ai|agent|assistant|email manager) (has )?sent)\b", re.I)
REVIEW_PASS = re.compile(r"review:\s*pass", re.I)
CORRECTS = re.compile(r"^\s*corrects\s+(L\d+)", re.I)
SECRET = re.compile(r"(api[_-]?key|secret|password|passwd|token)\s*[:=]\s*\S{8,}", re.I)


def plural(n, word):
    return f"{n} {word}" if n == 1 else f"{n} {word}s"


def fail(code, msg):
    FAILS.append(f"{code} FAIL: {msg}")


def table_rows(path):
    rows = []
    for line in path.read_text(encoding="utf-8").splitlines():
        s = line.strip()
        if not s.startswith("|") or set(s) <= set("|-: "):
            continue
        rows.append([c.strip() for c in s.strip("|").split("|")])
    return rows


def check_setup():
    p = HERE / "_shared" / "scoreboard-settings.md"
    if not p.exists():
        fail("S1", "ceo-scoreboard/_shared/scoreboard-settings.md is missing. Run setup.")
        return
    text = p.read_text(encoding="utf-8")
    left = len(re.findall(r"\{\{", text))
    if left:
        fail("S1", f"settings still have {plural(left, 'unanswered setup item')}. Finish setup.")
    if not re.search(r"^setup_done:\s*yes\s*$", text, re.M):
        fail("S1", "settings do not say setup_done: yes.")


def parse_report(today):
    """Returns (score_date, done, of, score_text, status) or None after recording failures."""
    if not REPORT.exists():
        fail("S2", "handoffs/scoreboard-report.md is missing. Run the night job (stage 04).")
        return None
    text = REPORT.read_text(encoding="utf-8")
    m = re.match(r"\A---\n(.*?)\n---\n", text, re.S)
    if not m:
        fail("S2", "report has no header block (from, updated, status) between --- lines.")
        return None
    head = m.group(1)
    frm = re.search(r"^from:\s*(\S+)", head, re.M)
    upd = re.search(r"^updated:\s*(\d{4}-\d{2}-\d{2}) \d{2}:\d{2}", head, re.M)
    sta = re.search(r"^status:\s*(ok|partial|failed)\s*$", head, re.M)
    if not frm or frm.group(1) != "ceo-scoreboard":
        fail("S2", "report header must say from: ceo-scoreboard.")
    if not upd:
        fail("S2", "report header needs updated: YYYY-MM-DD HH:MM.")
    if not sta:
        fail("S2", "report header needs status: ok, partial or failed.")
    sec = re.search(r"^## Score for (\d{4}-\d{2}-\d{2})\s*$", text, re.M)
    if not sec:
        fail("S2", "report needs a section '## Score for YYYY-MM-DD'.")
        return None
    top = re.search(r"^- Top 3 done:\s*(\d+) of (\d+)", text, re.M)
    sco = re.search(r"^- Score:\s*(\d+) out of 10|^- Score:\s*(not scored)", text, re.M)
    fix = re.search(r"^- One fix for tomorrow:\s*\S", text, re.M)
    if not top:
        fail("S2", "report needs the line '- Top 3 done: N of 3'.")
    if not sco:
        fail("S2", "report needs the line '- Score: N out of 10, and one line why'.")
    if not fix:
        fail("S2", "report needs the line '- One fix for tomorrow: ...'.")
    tom = re.search(r"^## Tomorrow's list\s*\n((?:\s*\d+\..*\n?)+)", text, re.M)
    if not tom:
        fail("S2", "report needs '## Tomorrow's list' with 1 to 3 numbered items.")
    elif not 1 <= len(re.findall(r"^\s*\d+\.", tom.group(1), re.M)) <= 3:
        fail("S2", "tomorrow's list must have 1 to 3 numbered items.")
    # S3 freshness
    if upd:
        d = datetime.date.fromisoformat(upd.group(1))
        if (today - d).days not in (0, 1):
            fail("S3", f"report was updated {d}, so it is not fresh (today or yesterday).")
    sd = datetime.date.fromisoformat(sec.group(1))
    if (today - sd).days not in (0, 1):
        fail("S3", f"report scores {sd}, which is not today or yesterday.")
    if not (top and sco):
        return None
    return sec.group(1), int(top.group(1)), int(top.group(2)), (sco.group(1) or sco.group(2)), (sta.group(1) if sta else "")


def check_ledger_and_report(parsed):
    rows = calc.read_ledger()
    latest = calc.latest_by_date(rows)
    for cells in rows:
        if len(cells) != 11:
            fail("S5", f"ledger row has {len(cells)} columns, needs 11: {' | '.join(cells)[:80]}")
            continue
        date, done, partly, of_, leading, goal, score, _why, _fix, known, _note = cells
        if not calc.ISO_DATE.match(date):
            fail("S5", f"ledger date '{date}' is not YYYY-MM-DD.")
            continue
        if known.strip().lower() in EMPTY_WORDS:
            fail("S5", f"{date}: 'How I know' is empty. Every count needs its evidence.")
        if goal.strip().lower() not in ("yes", "no", "-"):
            fail("S5", f"{date}: Goal moved must be yes or no.")
        if score.strip().lower() == "off":
            continue
        try:
            d, p, o, sc = int(done), int(partly), int(of_), int(score)
            r = calc.compute(d, p, o, calc.parse_leading(leading), goal.strip().lower() == "yes")
        except ValueError as e:
            fail("S5", f"{date}: cannot read the row ({e}).")
            continue
        if r["score"] != sc and latest.get(date) is cells:
            fail("S4", f"{date}: ledger score is {sc} but the counts work out to {r['score']}. Add a 'corrects' row.")
    # duplicate dates need a corrects note
    seen = set()
    for cells in rows:
        if len(cells) == 11:
            if cells[0] in seen and not cells[10].lower().startswith("corrects"):
                fail("S5", f"{cells[0]} appears twice without a 'corrects' note. The ledger is append only.")
            seen.add(cells[0])
    if parsed and parsed[4] != "failed":
        sdate, done, of_, score_text, _status = parsed
        row = calc.latest_by_date(rows).get(sdate)
        if not row:
            fail("S4", f"the report scores {sdate} but the ledger has no row for that day.")
            return
        if row[6].strip().lower() == "off":
            if score_text != "not scored":
                fail("S4", f"{sdate} is a day off in the ledger, but the report gives a score.")
            return
        if score_text == "not scored":
            fail("S4", f"the report says not scored for {sdate}, but the ledger has a score.")
            return
        if int(score_text) != int(row[6]):
            fail("S4", f"report score {score_text} does not match ledger score {row[6]} for {sdate}.")
        if done != int(row[1]) or of_ != int(row[3]):
            fail("S4", f"report says {done} of {of_} done, ledger says {row[1]} of {row[3]} for {sdate}.")
        fm = re.search(r"^- One fix for tomorrow:[ \t]*(.*)$", REPORT.read_text(encoding="utf-8"), re.M)
        norm = lambda t: " ".join(t.split()).lower().rstrip(". ")
        if fm and norm(fm.group(1)) != norm(row[8]):
            fail("S4", f"the report's fix line does not match the ledger Fix for {sdate}. After a re-score, update the fix line in the report to the latest ledger row.")


def check_decision_log():
    p = HERE / "_shared" / "decision-log.md"
    if not p.exists():
        fail("S6", "ceo-scoreboard/_shared/decision-log.md is missing.")
        return
    good = []
    for cells in table_rows(p)[1:]:
        if len(cells) != 8:
            fail("S6", f"log row has {len(cells)} columns, needs 8. A pipe character splits it: {' | '.join(cells)[:80]}")
            continue
        good.append(cells)
    corrected = set()
    for cells in good:
        m = CORRECTS.match(cells[2])
        if m:
            corrected.add(m.group(1).upper())
    seen = set()
    for num, _t, decision, tier, _w, evidence, words, result in good:
        key = num.upper()
        dup = key in seen
        seen.add(key)
        if key in corrected:
            continue
        if dup:
            fail("S6", f"{num} appears twice. Use the next number, or add a 'corrects {num}' row.")
        if tier not in ("T1", "T2", "T3"):
            fail("S6", f"{num}: tier '{tier}' is not T1, T2 or T3.")
        if result.lower() not in RESULTS:
            fail("S6", f"{num}: Result '{result}' is not done, pending, parked or no.")
        text = CORRECTS.sub("", decision)
        if ACTION.search(text) and tier != "T3" and not OWNER_TASK.match(text):
            fail("S6", f"{num}: '{text[:60]}' reaches another person, the public or money, so it must be T3, not {tier}.")
        if OWNER_TASK.match(text) and AI_SENT.search(evidence):
            fail("S6", f"{num}: marked 'Owner task:' but Evidence says the AI sent it. Remove 'Owner task:' and set the tier to T3. Add a 'corrects {num}' row.")
        if tier == "T3" and result.lower() == "done" and words.strip().lower() in EMPTY_WORDS:
            fail("S6", f"{num}: T3 marked done without the owner's words.")
        if tier == "T2" and result.lower() == "done" and not REVIEW_PASS.search(evidence):
            fail("S6", f"{num}: yellow (T2) work marked done without 'review: pass' in Evidence.")


AGENTS_LINE = re.compile(r"^- Agents:\s*(\d+) jobs? done(?:,\s*(\d+) flagged)?", re.M)


def check_agents(parsed):
    """S8. The report's agent count and flags match the activity log check for the scored day."""
    if not parsed or parsed[4] == "failed":
        return
    sdate = parsed[0]
    text = REPORT.read_text(encoding="utf-8")
    um = re.search(r"^updated:\s*(\d{4}-\d{2}-\d{2} \d{2}:\d{2})", text, re.M)
    jobs, unreadable = calc.agent_check(sdate, until=um.group(1) if um else None)
    done, flagged = calc.agent_counts(jobs)
    if unreadable:
        ur = re.search(r"^- Unreadable log lines:\s*(\d+)", text, re.M)
        if not ur or int(ur.group(1)) != unreadable:
            fail("S8", f"logs/activity.md has {plural(unreadable, 'line')} with no readable date, but the report has no '- Unreadable log lines: {unreadable}' line.")
    m = AGENTS_LINE.search(text)
    if not m:
        if jobs:
            fail("S8", f"logs/activity.md has {plural(len(jobs), 'job')} for {sdate}, but the report has no '- Agents: N jobs done, N flagged' line.")
        return
    if int(m.group(1)) != done:
        fail("S8", f"the report says {m.group(1)} agent jobs done, but {done} pass the check for {sdate}. Run scoreboard_calc.py agents --date {sdate}.")
    if m.group(2) is not None and int(m.group(2)) != len(flagged):
        fail("S8", f"the report says {m.group(2)} flagged, but the check flags {len(flagged)} for {sdate}.")
    sec = re.search(r"^## Agent flags\s*\n(.*?)(?=^## |\Z)", text, re.M | re.S)
    listed = set(re.findall(r"^\s*-\s*(AL\d+)\b", sec.group(1), re.M)) if sec else set()
    for j in flagged:
        if j["code"] not in listed:
            fail("S8", f"{j['code']} ({j['agent']}, {j['job'][:40]}) is marked {j['verdict']} but is not listed under '## Agent flags'.")


WEEKDAYS = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"]


def check_next_day(parsed):
    """S9. The fix line, the closing line of the night score and 03_tomorrow.md name the next work day, never a day off."""
    if not parsed or parsed[4] == "failed":
        return
    sdate = datetime.date.fromisoformat(parsed[0])
    days = calc.work_days()
    nxt = sdate + datetime.timedelta(days=1)
    tomorrow_ok = nxt.weekday() in days
    while nxt.weekday() not in days:
        nxt += datetime.timedelta(days=1)
    name = WEEKDAYS[nxt.weekday()]
    run_dir = HERE / "runs" / f"{parsed[0]}-night"
    targets = []
    fm = re.search(r"^- One fix for tomorrow:[ \t]*(.*)$", REPORT.read_text(encoding="utf-8"), re.M)
    if fm:
        targets.append(("the fix line", fm.group(1)))
    tp = run_dir / "03_tomorrow.md"
    if tp.is_file():
        lines = [l for l in tp.read_text(encoding="utf-8").splitlines() if l.strip()]
        if lines:
            targets.append(("the closing line of 03_tomorrow.md", lines[-1]))
    rp = run_dir / "04_report.md"
    if rp.is_file():
        firsts = [l for l in rp.read_text(encoding="utf-8").splitlines() if "first thing" in l.lower()]
        if firsts:
            targets.append(("the closing line of the night score", firsts[-1]))
    for label, text in targets:
        low = text.lower()
        if tomorrow_ok:
            if name in low or "tomorrow" in low:
                continue
            fail("S9", f"{label} must start with a time on tomorrow ({name.capitalize()}). Name the day.")
        elif "tomorrow" in low or name not in low:
            fail("S9", f"{label} must name the next work day, {name.capitalize()}, because the day after {parsed[0]} is a day off. Do not write tomorrow.")


REVIEW_LINE_PASS = re.compile(r"^[\s*_>-]*review[\s*_]*:[\s*_]*pass\b(.*)$", re.I | re.M)
REVIEWED_BY = re.compile(r"^[\s*_-]*reviewed by[\s*_]*:\s*\S.*\d{1,2}:\d{2}", re.I | re.M)


def check_record(rec, rel, label, self_review):
    """The review record holds a result line for RR1 to RR5 and a `Reviewed by: <helper or self>, <time>` line.
    A same-agent review (self) also needs a `Helper failed:` line that quotes why the helper did not start."""
    body = rec.read_text(encoding="utf-8")
    missing = [f"RR{i}" for i in range(1, 6) if not re.search(rf"\bRR{i}\b\s*(pass|fail)", body, re.I)]
    if missing:
        fail("S10", f"{rel} has no pass or fail result for {', '.join(missing)}.")
    if not REVIEWED_BY.search(body):
        fail("S10", f"{rel} has no 'Reviewed by: <helper or self>, <time>' line. Name who reviewed and when.")
    if self_review or re.search(r"^[\s*_-]*reviewed by[\s*_]*:\s*self", body, re.I | re.M):
        if not re.search(r"^[\s*_-]*helper failed[\s*_]*:\s*\S", body, re.I | re.M):
            fail("S10", f"{label} is a same-agent review but {rel} has no 'Helper failed: <the error>' line. Try a helper agent first.")


def check_log_self_mark(folder):
    """S10. A decision log row whose Evidence names this run folder and says `review: pass` must say
    `review: pass (self)` when the review record says the same agent reviewed."""
    p = HERE / "_shared" / "decision-log.md"
    if not p.exists():
        return
    for cells in table_rows(p)[1:]:
        if len(cells) != 8 or folder not in cells[5]:
            continue
        m = REVIEW_PASS.search(cells[5])
        if m and not re.search(r"review[\s*_]*:[\s*_]*pass\s*\(self\)", cells[5], re.I):
            fail("S10", f"decision log row {cells[0]} says a bare 'review: pass' but runs/{folder}/ has a same-agent review. Write 'review: pass (self)'.")


def check_week_reviews():
    """S10. A weekly view that says `Review: pass`, and every `corrects` ledger row, needs a review record in
    its run folder (05_review.md for a week, 04_review.md for a re-score), see check_record."""
    for wk in sorted((HERE / "runs").glob("*-week/05_week.md")):
        m = REVIEW_LINE_PASS.search(wk.read_text(encoding="utf-8"))
        if not m:
            continue
        rel = wk.parent.relative_to(HERE).as_posix()
        rec = wk.parent / "05_review.md"
        if not rec.is_file():
            fail("S10", f"{rel}/05_week.md says 'Review: pass' but {rel}/05_review.md does not exist. Run the review first, write its RR1 to RR5 results there, then write the pass line.")
            continue
        marked_self = bool(re.search(r"\(self\)", m.group(1), re.I))
        check_record(rec, f"{rel}/05_review.md", f"{rel}/05_week.md", marked_self)
        if re.search(r"^[\s*_-]*reviewed by[\s*_]*:\s*self", rec.read_text(encoding="utf-8"), re.I | re.M):
            if not marked_self:
                fail("S10", f"{rel}/05_review.md says 'Reviewed by: self' but {rel}/05_week.md says a bare 'Review: pass'. Write 'Review: pass (self)'.")
            check_log_self_mark(wk.parent.name)
    for cells in calc.read_ledger():
        if len(cells) != 11 or not calc.ISO_DATE.match(cells[0]) or not cells[10].strip().lower().startswith("corrects"):
            continue
        rel = f"runs/{cells[0]}-night"
        rec = HERE / rel / "04_review.md"
        if not rec.is_file():
            fail("S10", f"the ledger has a 'corrects' row for {cells[0]} but {rel}/04_review.md does not exist. A re-score is reviewed first: write the RR1 to RR5 results there.")
            continue
        check_record(rec, f"{rel}/04_review.md", f"the {cells[0]} re-score", False)
        if re.search(r"^[\s*_-]*reviewed by[\s*_]*:\s*self", rec.read_text(encoding="utf-8"), re.I | re.M):
            check_log_self_mark(f"{cells[0]}-night")


def check_secrets():
    paths = list((HERE / "_shared").glob("*.md")) + list((HERE / "ledger").glob("*.md")) + list((HERE / "runs").rglob("*.md"))
    for p in paths:
        for i, line in enumerate(p.read_text(encoding="utf-8").splitlines(), 1):
            if SECRET.search(line):
                fail("S7", f"{p.relative_to(HERE)} line {i} looks like a secret. Remove it.")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--skip-report", action="store_true")
    ap.add_argument("--today", default="")
    args = ap.parse_args()
    today = owner_today(args.today, [TOOLKIT / "chief-of-staff" / "_shared" / "owner-profile.md", HERE / "_shared" / "scoreboard-settings.md"])
    check_setup()
    parsed = None if args.skip_report else parse_report(today)
    check_ledger_and_report(parsed)
    check_agents(parsed)
    check_next_day(parsed)
    check_week_reviews()
    check_decision_log()
    check_secrets()
    if FAILS:
        print("\n".join(FAILS))
        print(f"\n{plural(len(FAILS), 'check')} failed.")
        return 1
    print("All checks passed (S1 to S10).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
