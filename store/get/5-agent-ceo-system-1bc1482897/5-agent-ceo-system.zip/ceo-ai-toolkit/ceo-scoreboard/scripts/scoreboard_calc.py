#!/usr/bin/env python3
"""The CEO Scoreboard's arithmetic: the day's score, streaks, and the weekly view.

Usage (from the ceo-ai-toolkit folder, works from any folder):
    python3 ceo-scoreboard/scripts/scoreboard_calc.py score --done 2 --partly 1 --of 3 --leading "M1 2/3, M2 1/3" --goal-moved no
    python3 ceo-scoreboard/scripts/scoreboard_calc.py streak [--today YYYY-MM-DD]
    python3 ceo-scoreboard/scripts/scoreboard_calc.py week --end YYYY-MM-DD [--today YYYY-MM-DD]
    python3 ceo-scoreboard/scripts/scoreboard_calc.py agents --date YYYY-MM-DD [--until "YYYY-MM-DD HH:MM"]

score   Works out the score from the counts. No daily actions set: leave out --leading.
streak  Reads ceo-scoreboard/ledger/scoreboard-log.md and prints the current and best streaks.
week    Prints the seven days ending on --end as a table, with totals.
agents  Checks every line of logs/activity.md for that date against its proof file and marks
        each job pass, fix or fail. Counts jobs done (pass only) and lists the flags.
        Reads Scoreboard review lines ("- review AL3 fail: reason") from
        ceo-scoreboard/runs/YYYY-MM-DD-night/02_score.md if that file exists.

Standard library only. Reads files, never changes them. The rules are in ceo-scoreboard/_shared/scoring-guide.md.
"""
import argparse
import datetime
import math
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent.parent  # the ceo-scoreboard folder
LEDGER = HERE / "ledger" / "scoreboard-log.md"
SETTINGS = HERE / "_shared" / "scoreboard-settings.md"
DAY_NAMES = ["mon", "tue", "wed", "thu", "fri", "sat", "sun"]
CODED = re.compile(r"(m\d)\s+(\d+(?:\.\d+)?)\s*/\s*(\d+(?:\.\d+)?)", re.I)
ISO_DATE = re.compile(r"^\d{4}-\d{2}-\d{2}$")

# Agent work check (the activity log). Rules: ceo-scoreboard/_shared/scoring-guide.md section 10.
TOOLKIT = HERE.parent
ACTIVITY_LOG = TOOLKIT / "logs" / "activity.md"
AGENT_NAMES = ("chief-of-staff", "email-manager", "time-manager", "focus-manager", "watch-to-ai")
EMPTY = {"", "-", "--", "n/a", "na", "none", "tbd", "?"}
WHEN = re.compile(r"^(\d{4}-\d{2}-\d{2}) ([01]\d|2[0-3]):[0-5]\d$")
PROOF = re.compile(r'^`?([^`"]+?)`?\s+contains\s+"(.+)"\s*$', re.I)
# A claim that something reached another person. A file can never prove that.
SEND_CLAIM = re.compile(
    r"(?<!not )(?<!never )\b(sent|posted|published|paid|booked|emailed|texted|messaged|replied|"
    r"delivered|scheduled|submitted|forwarded)\b", re.I)
MIN_PROOF_WORDS = 12  # characters of quoted words a proof must hold (LR-D6)
CORRECTS_AL = re.compile(r"^\s*corrects\s+(AL\d+)\b", re.I)
REVIEW_LINE = re.compile(r"^\s*-\s*review\s+(AL\d+)\s+(fix|fail)\s*:\s*(\S.*)$", re.I)
VERDICT_RANK = {"pass": 0, "fix": 1, "fail": 2}


def half_up(x):
    return int(math.floor(round(x, 6) + 0.5))


def parse_leading(text):
    """'M1 2/3, M2 1/3' becomes [('M1', 2.0, 3.0), ('M2', 1.0, 3.0)]. 'none' or empty becomes []."""
    text = (text or "").strip()
    if text.lower() in ("", "-", "none", "n/a"):
        return []
    found = [(m.group(1).upper(), float(m.group(2)), float(m.group(3))) for m in CODED.finditer(text)]
    if not found:
        raise ValueError(f"cannot read daily actions '{text}'. Use the form: M1 2/3, M2 1/3")
    for code, _a, target in found:
        if target <= 0:
            raise ValueError(f"{code}: the target must be above 0")
    return found


def compute(done, partly, of_, leading, goal_moved):
    """Returns the points and the whole-number score. Rules: ceo-scoreboard/_shared/scoring-guide.md."""
    if of_ < 1 or of_ > 3:
        raise ValueError("Of must be 1, 2 or 3")
    if done < 0 or partly < 0 or done + partly > of_:
        raise ValueError("Done plus Partly cannot be more than Of, and neither can be below 0")
    top_max = 6.0 if leading else 9.0
    top = top_max * (done + 0.5 * partly) / of_
    lead = 0.0
    if leading:
        lead = 3.0 * sum(min(a / t, 1.0) for _c, a, t in leading) / len(leading)
    goal = 1.0 if goal_moved else 0.0
    exact = top + lead + goal
    return {"top": top, "top_max": top_max, "lead": lead, "has_lead": bool(leading),
            "goal": goal, "exact": exact, "score": half_up(exact)}


def read_ledger(path=None):
    path = path or LEDGER
    rows = []
    if not path.exists():
        return rows
    for line in path.read_text(encoding="utf-8").splitlines():
        s = line.strip()
        if not s.startswith("|") or set(s) <= set("|-: "):
            continue
        cells = [c.strip() for c in s.strip("|").split("|")]
        if cells and cells[0].lower() == "date":
            continue
        rows.append(cells)
    return rows


def latest_by_date(rows):
    """The last row for each date wins, so a later 'corrects' row replaces the earlier one."""
    out = {}
    for cells in rows:
        if len(cells) == 11 and ISO_DATE.match(cells[0]):
            out[cells[0]] = cells
    return out


def setting_text(label):
    if not SETTINGS.exists():
        return ""
    for line in SETTINGS.read_text(encoding="utf-8").splitlines():
        if line.lower().lstrip("- ").startswith(label.lower()):
            return line.split(":", 1)[1].strip() if ":" in line else ""
    return ""


def work_days():
    text = setting_text("Work days").lower()
    if not text or "{{" in text:
        return {0, 1, 2, 3, 4}
    names = [w[:3] for w in re.findall(r"[a-z]+", text) if w[:3] in DAY_NAMES]
    if " to " in text and len(names) >= 2:
        a, b = DAY_NAMES.index(names[0]), DAY_NAMES.index(names[1])
        days, i = {a}, a
        while i != b:
            i = (i + 1) % 7
            days.add(i)
        return days
    return {DAY_NAMES.index(n) for n in names} or {0, 1, 2, 3, 4}


def active_actions():
    """Codes of the daily actions in the settings table that are in use (a name, no placeholder, not `not used`)."""
    if not SETTINGS.exists():
        return []
    out = []
    for line in SETTINGS.read_text(encoding="utf-8").splitlines():
        cells = [c.strip() for c in line.strip().strip("|").split("|")]
        if len(cells) >= 2 and re.fullmatch(r"M\d", cells[0]) and cells[1] and "{{" not in cells[1] and cells[1].lower() != "not used":
            out.append(cells[0])
    return out


def good_day_score():
    m = re.search(r"(\d+)", setting_text("A good day is a score of"))
    return int(m.group(1)) if m else 7


def score_cell(cells):
    """An int, or None for a day off."""
    s = cells[6].strip().lower()
    if s == "off":
        return None
    return int(s)


def streaks(by_date, today):
    """Returns (good-day streak now, nights-scored streak now, best good-day streak, best nights-scored streak, missed)."""
    if not by_date:
        return 0, 0, 0, 0, []
    days = work_days()
    good = good_day_score()
    dates = sorted(datetime.date.fromisoformat(d) for d in by_date)
    first, last = dates[0], dates[-1]

    def walk_back(end, need_good):
        n, d = 0, end
        while d >= first:
            row = by_date.get(d.isoformat())
            if row is None:
                if d.weekday() in days:
                    break
            elif d.weekday() in days:
                sc = score_cell(row)
                if sc is not None:
                    if need_good and sc < good:
                        break
                    n += 1
            d -= datetime.timedelta(days=1)
        return n

    def best_run(need_good):
        best = cur = 0
        d = first
        while d <= last:
            row = by_date.get(d.isoformat())
            if row is None:
                if d.weekday() in days:
                    cur = 0
            elif d.weekday() in days:
                sc = score_cell(row)
                if sc is not None:
                    if need_good and sc < good:
                        cur = 0
                    else:
                        cur += 1
                        best = max(best, cur)
            d += datetime.timedelta(days=1)
        return best

    missed = []
    d = last + datetime.timedelta(days=1)
    while d < today:
        if d.weekday() in days:
            missed.append(d.isoformat())
        d += datetime.timedelta(days=1)
    if missed:
        return 0, 0, best_run(True), best_run(False), missed
    return walk_back(last, True), walk_back(last, False), best_run(True), best_run(False), missed


def read_activity(path=None):
    """Lines of the activity log as lists of cells. The header and divider rows are left out."""
    path = path or ACTIVITY_LOG
    rows = []
    if not path.exists():
        return rows
    for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
        s = line.strip()
        if not s.startswith("|") or set(s) <= set("|-: "):
            continue
        cells = [c.strip() for c in s.strip("|").split("|")]
        if cells and cells[0].lower() == "when":
            continue
        rows.append(cells)
    return rows


def flat(text):
    return " ".join(text.split()).lower()


def judge_line(cells, toolkit):
    """Returns (verdict, why) for one log line. verdict is pass, fix or fail.
    fix: the claim cannot be checked yet (proof missing or the line is not in the format).
    fail: the proof is there but does not show the claim."""
    if len(cells) != 5:
        return "fix", f"the line has {len(cells)} cells, it needs 5 (When, Agent, Job, Result, Proof)"
    when, agent, job, result, proof = cells
    if not WHEN.match(when):
        return "fix", "When must be YYYY-MM-DD HH:MM"
    if agent not in AGENT_NAMES:
        return "fix", f"Agent '{agent}' is not one of {', '.join(AGENT_NAMES)}"
    if job.lower() in EMPTY or result.lower() in EMPTY:
        return "fix", "Job or Result is empty"
    if proof.strip().lower() in EMPTY:
        return "fix", "claimed, proof missing: the Proof cell is empty"
    m = PROOF.match(proof.strip())
    if not m:
        return "fix", 'claimed, proof missing: the Proof cell must be: path contains "exact words from that file"'
    rel, words = m.group(1).strip(), m.group(2).strip()
    p = Path(rel)
    if p.is_absolute() or ".." in p.parts or rel.startswith("~"):
        return "fail", f"the proof {rel} is outside the toolkit folder"
    full = (toolkit / p).resolve()
    root = Path(toolkit).resolve()
    try:
        full.relative_to(root)
    except ValueError:
        return "fail", f"the proof {rel} points outside the toolkit folder (a link leads out of it)"
    if p.parts and p.parts[0] in AGENT_NAMES and p.parts[0] != agent:
        return "fix", f"claimed, proof in another agent's folder: {rel} ({p.parts[0]}). Point to this agent's own file"
    for i, part in enumerate(p.parts[:-1]):
        rd = re.match(r"^(\d{4}-\d{2}-\d{2})", p.parts[i + 1]) if part == "runs" else None
        if rd and rd.group(1) != when[:10]:
            return "fix", f"claimed, proof from a run dated another day: {rel} is in a run folder dated {rd.group(1)}, not {when[:10]}. Point to today's run"
    if p.as_posix().lower() == "logs/activity.md" or full == (root / "logs" / "activity.md").resolve():
        return "fail", "the activity log cannot prove its own line"
    if SEND_CLAIM.search(f"{job} {result}"):
        if p.as_posix().lower().startswith("handoffs/drafts/") or "draft" in rel.lower() or "draft" in words.lower():
            return "fail", f"the line claims something reached another person, but the proof {rel} is a draft or says draft. A draft never proves a send"
    if not full.is_file():
        return "fix", f"claimed, proof missing: {rel} does not exist"
    if len(flat(words)) < MIN_PROOF_WORDS:
        return "fix", f"claimed, proof missing: the quoted words are too short to prove anything (at least {MIN_PROOF_WORDS} characters)"
    if flat(words) not in flat(full.read_text(encoding="utf-8", errors="replace")):
        return "fail", f'the proof does not match: "{words}" is not in {rel}'
    return "pass", f'"{words}" is in {rel}'


def review_lines(path):
    """The Scoreboard's own review of a job, '- review AL3 fail: reason', from the night's 02_score.md."""
    out = {}
    if path and path.exists():
        for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
            m = REVIEW_LINE.match(line)
            if m:
                out[m.group(1).upper()] = (m.group(2).lower(), m.group(3).strip())
    return out


def is_standalone(toolkit):
    """True unless the Chief of Staff is set up (its owner profile exists, has no {{ and says setup_done: yes).
    Standalone, the owner is the one who acts on a flag."""
    prof = Path(toolkit) / "chief-of-staff" / "_shared" / "owner-profile.md"
    try:
        text = prof.read_text(encoding="utf-8")
    except OSError:
        return True
    return "{{" in text or not re.search(r"^setup_done:\s*yes\s*$", text, re.M)


def fix_for(verdict, agent, code, why="", toolkit=None):
    who = agent if agent in AGENT_NAMES else "agent that wrote it"
    boss = "the owner" if is_standalone(toolkit or TOOLKIT) else "the Chief of Staff"
    if "never proves a send" in why:
        return (f"{boss} checks whether it went out and never sends it again to check. If it did, "
                f"the {who} adds a new line that starts 'corrects {code}' with the owner's words as proof.")
    if verdict == "fix":
        return (f"{boss} asks the {who} to add a new line that starts 'corrects {code}' and points to the file "
                f"that shows the job. If no file shows it, the job is not done.")
    return (f"{boss} runs the job again with the {who} (never a job that reaches another person), "
            f"or confirms it in their own words. "
            f"Then the {who} adds a new line that starts 'corrects {code}'.")


def real_date(text):
    """True when the first 10 characters of text are a real calendar date."""
    try:
        datetime.date.fromisoformat(text[:10])
        return bool(ISO_DATE.match(text[:10]))
    except ValueError:
        return False


def agent_check(day, log_path=None, review_path=None, toolkit=None, until=None, notes=None):
    """Checks every activity log line dated `day`. Returns (jobs, unreadable).
    until: 'YYYY-MM-DD HH:MM'. A line logged after it is left out (it belongs to the next report).
    notes: an optional dict that gets 'late' and 'duplicates' counts.
    An exact duplicate line counts once. A line that corrects another agent's line does not replace it.
    jobs: dicts with code, when, agent, job, result, proof, verdict, why, fix (fix is '' for pass and replaced).
    A line whose Job starts 'corrects AL3' replaces AL3: AL3 then has verdict 'replaced' and is not counted."""
    toolkit = toolkit or TOOLKIT
    if review_path is None:
        review_path = HERE / "runs" / f"{day}-night" / "02_score.md"
    reviews = review_lines(review_path)
    jobs, unreadable, late, dupes = [], 0, 0, 0
    seen = set()
    for cells in read_activity(log_path):
        first = cells[0] if cells else ""
        if not real_date(first) or (len(first) > 10 and first[10] != " "):
            unreadable += 1
            continue
        if not first.startswith(day):
            continue
        if until and WHEN.match(first) and first > until:
            late += 1
            continue
        key = tuple(flat(c) for c in cells)
        if key in seen:
            dupes += 1
            continue
        seen.add(key)
        code = f"AL{len(jobs) + 1}"
        padded = (cells + [""] * 5)[:5]
        verdict, why = judge_line(cells, toolkit)
        if code in reviews:
            rv, reason = reviews[code]
            if VERDICT_RANK[rv] > VERDICT_RANK[verdict]:
                verdict, why = rv, f"Scoreboard review: {reason}"
        jobs.append({"code": code, "when": padded[0], "agent": padded[1], "job": padded[2],
                     "result": padded[3], "proof": padded[4], "verdict": verdict, "why": why, "fix": ""})
    by_code = {j["code"]: j for j in jobs}
    for j in jobs:
        m = CORRECTS_AL.match(j["job"])
        if m and m.group(1).upper() in by_code and m.group(1).upper() != j["code"]:
            old = by_code[m.group(1).upper()]
            if old["agent"] != j["agent"]:
                if j["verdict"] == "pass":
                    j["verdict"] = "fix"
                    j["why"] = f"{j['agent']} cannot correct a line written by {old['agent']} ({old['code']}). That agent adds its own corrects line"
                continue
            old["verdict"], old["why"] = "replaced", f"replaced by {j['code']}"
    for j in jobs:
        if j["verdict"] in ("fix", "fail"):
            j["fix"] = fix_for(j["verdict"], j["agent"], j["code"], j["why"], toolkit)
    if notes is not None:
        notes["late"], notes["duplicates"] = late, dupes
    return jobs, unreadable


def agent_counts(jobs):
    done = sum(1 for j in jobs if j["verdict"] == "pass")
    flagged = [j for j in jobs if j["verdict"] in ("fix", "fail")]
    return done, flagged


def cmd_agents(args):
    day = args.date
    if not real_date(day) or len(day) != 10:
        raise ValueError("--date must be a real date, YYYY-MM-DD")
    until = args.until or None
    if until and not WHEN.match(until):
        raise ValueError("--until must be YYYY-MM-DD HH:MM")
    log_path = Path(args.log) if args.log else None
    review_path = Path(args.review) if args.review else None
    notes = {}
    jobs, unreadable = agent_check(day, log_path, review_path, until=until, notes=notes)
    done, flagged = agent_counts(jobs)
    print(f"## Agent work for {day}")
    print()
    if not jobs:
        print(f"No agent jobs logged for {day}.")
    else:
        print("| Code | When | Agent | Job | Result | Check | Why |")
        print("|---|---|---|---|---|---|---|")
        for j in jobs:
            print(f"| {j['code']} | {j['when']} | {j['agent']} | {j['job']} | {j['result']} | {j['verdict']} | {j['why']} |")
    print()
    if notes.get("late"):
        n = notes["late"]
        print(f"Note: {n} {'line was' if n == 1 else 'lines were'} logged after {until} and {'is' if n == 1 else 'are'} left out. {'It belongs' if n == 1 else 'They belong'} to the next report.")
    if notes.get("duplicates"):
        n = notes["duplicates"]
        print(f"Note: {n} identical duplicate {'line was' if n == 1 else 'lines were'} counted once.")
    if unreadable:
        print(f"- Unreadable log lines: {unreadable}. They have no readable date and are not counted.")
    print(f"- Agents: {done} {'job' if done == 1 else 'jobs'} done, {len(flagged)} flagged")
    print()
    print("## Agent flags")
    if not flagged:
        print("- none")
    for j in sorted(flagged, key=lambda x: -VERDICT_RANK[x["verdict"]]):
        why = j["why"].rstrip(". ")
        why = why[:1].upper() + why[1:]
        print(f"- {j['code']} {j['verdict']}: {j['agent']}, {j['job']}. {why}. Fix: {j['fix']}")
    return 0


def cmd_score(args):
    leading = parse_leading(args.leading)
    r = compute(args.done, args.partly, args.of, leading, args.goal_moved == "yes")
    print(f"Top 3 points: {r['top']:.2f} of {r['top_max']:.0f}")
    if r["has_lead"]:
        print(f"Daily action points: {r['lead']:.2f} of 3")
    else:
        print("Daily action points: not used (no daily actions set)")
    print(f"Goal moved point: {r['goal']:.0f} of 1")
    print(f"Exact: {r['exact']:.2f}. Score: {r['score']} out of 10")
    return 0


def cmd_streak(args):
    today = datetime.date.fromisoformat(args.today) if args.today else datetime.date.today()
    by_date = latest_by_date(read_ledger())
    if not by_date:
        print("No nights scored yet. Streak: 0.")
        return 0
    good = good_day_score()
    g, n, bg, bn, missed = streaks(by_date, today)
    print(f"Good-day streak (score {good} or more): {g} good {'day' if g == 1 else 'days'} in a row. Best: {bg}.")
    print(f"Nights scored in a row: {n}. Best: {bn}.")
    if missed:
        label = "Missed work day" if len(missed) == 1 else "Missed work days"
        print(f"{label} with no night score: " + ", ".join(missed) + ". The streak is back to 0.")
    return 0


def cmd_week(args):
    end = datetime.date.fromisoformat(args.end)
    start = end - datetime.timedelta(days=6)
    by_date = latest_by_date(read_ledger())
    days = work_days()
    good = good_day_score()
    print(f"## Week from {start.isoformat()} to {end.isoformat()}")
    print()
    print("| Date | Day | Top 3 | Daily actions | Goal moved | Score |")
    print("|---|---|---|---|---|---|")
    scored, work_total, top_done, top_of, goal_days = [], 0, 0.0, 0, 0
    totals = {}
    d = start
    while d <= end:
        iso, name = d.isoformat(), d.strftime("%a")
        is_work = d.weekday() in days
        row = by_date.get(iso)
        if row is None:
            if is_work:
                work_total += 1
            print(f"| {iso} | {name} | no night score | | | |" if is_work else f"| {iso} | {name} | rest day | | | |")
        else:
            sc = score_cell(row)
            if sc is None:
                print(f"| {iso} | {name} | day off | | | off |")
            else:
                if is_work:
                    work_total += 1
                scored.append((iso, sc))
                done, partly, of_ = int(row[1]), int(row[2]), int(row[3])
                top_done += done
                top_of += of_
                if row[5].strip().lower() == "yes":
                    goal_days += 1
                for code, a, t in parse_leading(row[4]):
                    x = totals.setdefault(code, [0.0, 0.0])
                    x[0] += a
                    x[1] += t
                print(f"| {iso} | {name} | {done} of {of_} done, {partly} partly | {row[4]} | {row[5]} | {sc} |")
        d += datetime.timedelta(days=1)
    print()
    if not scored:
        print("No nights scored this week.")
        return 0
    avg = sum(s for _d, s in scored) / len(scored)
    best = max(scored, key=lambda x: x[1])
    low = min(scored, key=lambda x: x[1])
    print(f"- Nights scored: {len(scored)} of {work_total} work {'day' if work_total == 1 else 'days'}.")
    print(f"- Average score: {avg:.1f} out of 10.")
    print(f"- Good days (score {good} or more): {sum(1 for _d, s in scored if s >= good)}.")
    print(f"- Top 3 done: {top_done:g} of {top_of} {'item' if top_of == 1 else 'items'}.")
    for code in sorted(totals):
        a, t = totals[code]
        print(f"- {code}: {a:g} of {t:g} ({100 * a / t:.0f} percent of target).")
    for code in active_actions():
        if code not in totals:
            print(f"- {code}: no counts this week (none in the ledger).")
    print(f"- Goal moved on {goal_days} of {len(scored)} {'day' if len(scored) == 1 else 'days'}.")
    print(f"- Best day: {best[0]} ({best[1]}). Lowest day: {low[0]} ({low[1]}).")
    today = datetime.date.fromisoformat(args.today) if args.today else datetime.date.today()
    g, n, bg, bn, missed = streaks(by_date, today)
    print(f"- Streaks as of {today.isoformat()}. Good-day streak: {g}. Best: {bg}. Nights scored in a row: {n}. Best: {bn}.")
    if missed:
        label = "Missed work day" if len(missed) == 1 else "Missed work days"
        print(f"- {label} with no night score: " + ", ".join(missed) + ". The streak is back to 0.")
    return 0


def main():
    p = argparse.ArgumentParser(description="CEO Scoreboard math")
    sub = p.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("score")
    s.add_argument("--done", type=int, required=True)
    s.add_argument("--partly", type=int, default=0)
    s.add_argument("--of", type=int, default=3)
    s.add_argument("--leading", default="")
    s.add_argument("--goal-moved", choices=["yes", "no"], default="no")
    k = sub.add_parser("streak")
    k.add_argument("--today", default="")
    w = sub.add_parser("week")
    w.add_argument("--end", required=True)
    w.add_argument("--today", default="", help="streaks are worked out as of this date, YYYY-MM-DD (default: today)")
    g = sub.add_parser("agents")
    g.add_argument("--date", required=True)
    g.add_argument("--log", default="", help="another activity log file (tests)")
    g.add_argument("--until", default="", help="leave out lines logged after this time, YYYY-MM-DD HH:MM (the report's updated time)")
    g.add_argument("--review", default="", help="another file with review lines (tests)")
    args = p.parse_args()
    try:
        return {"score": cmd_score, "streak": cmd_streak, "week": cmd_week, "agents": cmd_agents}[args.cmd](args)
    except (ValueError, KeyError) as e:
        print(f"Cannot work this out: {e}")
        return 2


if __name__ == "__main__":
    sys.exit(main())
