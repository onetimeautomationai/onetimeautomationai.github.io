# Setup questions

Ask one per turn, in this order. The default is in brackets. Write each answer into `ceo-scoreboard/_shared/scoreboard-settings.md` the moment you get it. "Required" means there is no default (see onboarding step 4).

Which questions you ask depends on how you started (details in `ceo-scoreboard/00_onboarding/CONTEXT.md`):
- **Standalone:** ask Q1 to Q5. That is the most you ever ask.
- **Under the Chief of Staff** with the owner profile set up: ask Q3 and Q4 only. Ask Q2 too if the owner profile says `not given` for daily actions.

## About your goal
1. What is your number one goal right now, with a number and a date? For example: "$10,000 in new sales by December 31." [required] (Standalone only. Under the Chief of Staff this is already in the owner profile.)
2. Which daily actions move that goal the most? Name up to three. For example: new conversations, follow-ups, proposals sent. [required. If skipped, ask once more in simpler words: "What would you do more of if you wanted this goal sooner?"]

## How to count them
3. For each action: how many make a good day, and what counts as one? For example: "2 new conversations, counted when the person replies", "3 follow-ups, counted when sent". [target 2 a day, counts when you can point to it (a reply, a sent message, a file that exists)]

## Your days
4. Which days do you work? [Monday to Friday]
5. What time zone are you in, and when does your work day close? Name it like "America/Los_Angeles" or say Pacific, Mountain, Central or Eastern. [the time zone your computer shows, 5 PM] (Standalone only. Under the Chief of Staff these are in the owner profile.)

Report style is not asked. Standalone default: short, lists, most important line last. The owner can change it any time by saying "From now on, ...".
