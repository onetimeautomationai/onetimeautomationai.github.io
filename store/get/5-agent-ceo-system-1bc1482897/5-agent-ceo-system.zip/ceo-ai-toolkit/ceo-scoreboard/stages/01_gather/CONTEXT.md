# 01_gather: collect the Top 3, the proof, and the owner's answers

One job: know exactly what the day was supposed to be and what happened, with proof for each item, using one question at most. Paths start from the `ceo-ai-toolkit` folder.

## Inputs
- Reference: `ceo-scoreboard/system.md`, `ceo-scoreboard/_shared/scoring-guide.md` (section 1), `ceo-scoreboard/_shared/scoreboard-settings.md`, both lessons files, `chief-of-staff/_shared/owner-profile.md` (if it exists)
- Handoffs: `handoffs/top3-today.md`, `handoffs/jobs.md`, `handoffs/drafts/`
- Optional: `chief-of-staff/board/board.md` (Wins, Your list, Job queue)
- Template: `ceo-scoreboard/_templates/run/01_gather.md`

## Process
1. **Check the real clock** in the owner's time zone. The day being scored is the clock date. Exception: if it is before 4 AM and the job row or the owner names yesterday, or the Top 3 file is for yesterday and there is none for the clock date, score yesterday and say so in one line with the date ("Scoring 2026-11-24"). Everywhere below, "the day being scored" means that date, never the word "today" after midnight.
2. **Already scored?** If the ledger has a row for this date and the owner did not ask to fix it, run `python3 ceo-scoreboard/scripts/check_scoreboard.py` first (a repeat close still proves the night). Then say "Already scored: N out of 10. Check: <passed, or what failed>. Say 'fix' if a count was wrong." If the check fails, fix what it names and run it again. Then stop, before any folder or file is made, so a repeat close never recopies the template. A fix goes to `scoring-guide.md` section 6.
3. Make `ceo-scoreboard/runs/YYYY-MM-DD-night/` (the date of the day being scored) and copy the template into it as `01_gather.md`. If the folder exists, reuse it.
4. **Day off?** If the owner says they are off, go to `scoring-guide.md` section 6, then `03_tomorrow`, then `04_report`. No question needed.
5. **Read the Top 3.** Open `handoffs/top3-today.md`. It counts only if its heading `## Top 3 for YYYY-MM-DD` is the day being scored. Copy the items and their results into `01_gather.md`.
   - Installed but not for this day: write "Focus Manager not run today" in `01_gather.md` and use the fallback below. (Installed means a `focus-manager/` folder sits next to `ceo-scoreboard/`.)
   - Not installed and no file: write "no Focus Manager" and use the fallback below.
   - A file written by the Chief of Staff (`from: chief-of-staff`) counts the same as the Focus Manager's.
6. **Fallback when there is no Top 3 for the day.** Never score against an old Top 3. Offer the board first, only when it has open rows (the empty shipped board does not count): up to 3 open rows from its Job queue and "Your list", shown as "From your board I'd score against: 1, 2, 3. Right?". Otherwise ask: "I have no Top 3 for <the day being scored>. What were the three things you meant to finish, and what counts as done for each?" The owner's words become the Top 3 for scoring, and you write the source ("owner's words" or "board, confirmed by owner") in `01_gather.md`. Under the Chief of Staff with no way to ask: write `missing: Top 3 for YYYY-MM-DD`, set `status: failed` and your job `waiting: no Top 3`, and stop. Do not write `handoffs/top3-today.md`. It is not your file.
7. **Collect proof the files already hold.** For each Top 3 item, look for a job in `handoffs/jobs.md` marked done, a file in `handoffs/drafts/` dated that day, or a board row marked done. Write what you found next to the item, with the file name. A file proves a result only when the result is a file (a draft written, a report made). It never proves something sent, held, signed or paid.
8. **Read the daily actions** from the settings (the active rows, with targets and "Counts when").
9. **Ask the night question** when you may talk to the owner. That means: standalone, or the job row says to ask, or the Chief of Staff switched you in and told you to. It is one message. If step 6 had to ask for the Top 3 because there is none, put the step 6 question and this night question in that same single message and send no second one. Pre-fill what you found, and ask for everything else in one reply:

   > Here is your day. Top 3:
   > 1. <item> : <result> (found: <proof or nothing yet>)
   > 2. ...
   > 3. ...
   > Daily actions: M1 <action>, target <N>. M2 ...
   > One reply is enough: which of the three are done, partly or not, how many of each daily action, and anything that moved your goal (a client signed, a contract signed, a payment in). Example: "1 and 3 done, 2 partly, conversations 2, follow-ups 1, nothing signed."

   Protected hours do not stop this question when the owner asked for the score. If the answer is vague, ask one follow-up and no more.
10. **Under the Chief of Staff and you may not ask:** use the owner's answer if the job row carries it (look for "Owner answers:", and still accept the older "Owner's answer:", which the Chief of Staff writes, never the Scoreboard). Otherwise count only what the files prove, mark the rest `unconfirmed`, and write `missing: [which Top 3 items and which counts]`. The report will be `status: partial`.
11. Copy the owner's answer into `01_gather.md` under "Owner's words (exact)". Replace any pipe character with a slash. The reviewer and later nights read this file, not the chat.

## Output
- `01_gather.md` in the run folder: the Top 3 and its source, the proof found, the owner's exact answer, anything marked unconfirmed.

## Human check
The owner answers the night question. Nothing else is asked at this stage.
