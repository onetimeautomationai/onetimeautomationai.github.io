# 02_score: score the day, with proof

One job: turn what the owner said and what the files prove into a score out of 10, one line why, and one fix. Paths start from the `ceo-ai-toolkit` folder.

## Inputs
- Working: `01_gather.md` in the run folder
- Reference: `ceo-scoreboard/_shared/scoring-guide.md`, `ceo-scoreboard/_shared/scoreboard-settings.md`, both lessons files
- Agent work: `logs/activity.md` and the proof files its lines name (read only)
- Template: `ceo-scoreboard/_templates/outputs/02_score.md`

## Process
1. **Status for each Top 3 item:** done, partly, not done, or unconfirmed. Apply the proof rules in `scoring-guide.md` section 1. Write the proof next to each status. Unconfirmed counts as not done.
2. **Daily action counts:** the owner's number for each active action, as actual and target (for example `M1 2/3`). A count the owner did not give is 0 and is marked unconfirmed. No daily actions set: write `none`.
3. **Goal moved:** yes only when the owner names a result that counts toward goal 1 (a client signed, a contract signed, a payment in). Otherwise no.
4. **Work out the score.** Run `python3 ceo-scoreboard/scripts/scoreboard_calc.py score --done N --partly N --of N --leading "M1 a/t, M2 a/t" --goal-moved yes|no`, or do the arithmetic by hand from `scoring-guide.md` section 2. Copy the output into `02_score.md`. Never pick a score first and work back.
5. **Agent work** (`scoring-guide.md` section 10). Run `python3 ceo-scoreboard/scripts/scoreboard_calc.py agents --date YYYY-MM-DD --until "YYYY-MM-DD HH:MM"` (the day being scored, and the time you will write as `updated` in the report, from the clock) and paste the output into `02_score.md` under `## Agent work`. Then open the proof file of each line marked pass and read the lines around the quoted words. If the file does not show the Job and the Result, add a review line under `## Agent review`, for example `- review AL3 fail: the file says waiting, the line says done`, and run the script again. Paste the new output over the old output under `## Agent work`. Keep the review lines. A review line only moves a job down. Never fix the job and never edit `logs/activity.md`. No Python: do it by hand from `ceo-scoreboard/scripts/README.md` section E.
6. **One line why** (`scoring-guide.md` section 3) and **one fix** (section 4). Check the fix against the files: no new task the files and the owner's words do not support. Agent work does not change the score.
7. Apply every line in the lessons (for example "always show the daily actions first").
8. Write `02_score.md` from the template.

## Output
- `02_score.md` in the run folder: statuses with proof, counts, the script output, the score, why, fix, and the agent work check with any review lines.

## Human check
The owner confirms the counts. The night score (stage 04) shows the counts used, and the owner can say "fix" at any point. A fix is a re-score and goes through `scoring-guide.md` section 6.
