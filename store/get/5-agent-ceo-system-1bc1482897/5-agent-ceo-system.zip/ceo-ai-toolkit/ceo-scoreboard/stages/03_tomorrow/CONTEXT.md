# 03_tomorrow: hand over tomorrow's list

One job: give the owner and the Chief of Staff a list of up to 3 items for tomorrow, built only from what the files and the owner's words support. Paths start from the `ceo-ai-toolkit` folder.

## Inputs
- Working: `02_score.md` in the run folder
- Reference: `ceo-scoreboard/_shared/scoring-guide.md` (section 5), both lessons files, `chief-of-staff/board/board.md` (if it exists), `handoffs/time-manager-report.md` (only to name a block for the fix, and only if it is fresh)
- Template: `ceo-scoreboard/_templates/outputs/03_tomorrow.md`

## Process
1. Item 1 and on: each Top 3 item that is not done, written as the remaining step with its result that counts as done. Source: carried.
2. Next: each daily action below its target, furthest below first (a tie goes to the larger shortfall in count), written as the shortfall against its target, as a count ("2 new conversations"), one item each. Only a confirmed count builds a shortfall item. An action whose count is unconfirmed (a 0 the owner never gave) is skipped here and goes to the `missing:` line instead. Source: daily action.
3. Next: open rows on the board ("Your list", then "now" jobs in the Job queue), if the board exists. Source: board row number.
4. Stop at 3. If you have fewer than 3, list fewer. If you have none, item 1 is "Choose tomorrow's Top 3 first thing".
5. Write each item in the form `<item> : result that counts as done (source)`, the same form as `handoffs/top3-today.md`, so the Focus Manager can copy it. The source is always a kind plus a file path or ledger row, never none, and it stays on each line of the night score. Use exactly these forms: `(carried, handoffs/top3-today.md item 2)` (or `runs/YYYY-MM-DD-night/01_gather.md item 2` when the Top 3 came from the owner's words), `(daily action, ceo-scoreboard/_shared/scoreboard-settings.md M1)`, `(board, chief-of-staff/board/board.md row 4)`. The heading is `# Tomorrow's list, for <Day> YYYY-MM-DD` with the next work day's name and date, not the scored day, and nothing else on that line.
6. Add the first thing: one line, the item to start with. Follow the one naming rule in `scoring-guide.md` section 4: name the next work day by its day name (for example Monday after a Friday or Saturday score), and write "Tomorrow" only when tomorrow is a work day and the clock date is still the scored day. It is the same as the fix when the fix is about an item on the list.
7. Never write `handoffs/top3-today.md`. The list is a draft. The Focus Manager (or the Chief of Staff, or the owner) sets the real Top 3.

## Output
- `03_tomorrow.md` in the run folder: the list with sources, and the first thing tomorrow.

## Human check
None. If the owner changes the list, update it, and log their words in the decision log as a T1 row.
