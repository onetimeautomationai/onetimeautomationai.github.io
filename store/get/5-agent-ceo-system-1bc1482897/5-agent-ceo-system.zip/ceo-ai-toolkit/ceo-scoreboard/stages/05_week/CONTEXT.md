# 05_week: the weekly view and streaks

One job: show the owner seven days at a glance, from the ledger and nowhere else, with one change for next week. Paths start from the `ceo-ai-toolkit` folder.

## Inputs
- Reference: `ceo-scoreboard/ledger/scoreboard-log.md`, `ceo-scoreboard/_shared/scoring-guide.md` (sections 7 and 9), `ceo-scoreboard/_shared/scoreboard-settings.md`, both lessons files
- Template: `ceo-scoreboard/_templates/outputs/05_week.md`

## Process
1. **Check the clock.** Make `ceo-scoreboard/runs/YYYY-MM-DD-week/` (today's date, or the date the job row names).
2. Run `python3 ceo-scoreboard/scripts/scoreboard_calc.py week --end YYYY-MM-DD --today YYYY-MM-DD` (the clock date) only. Its streak line is worked out as of that date and already holds the streaks and any missed work day, so do not run `streak` as well. Paste the output into `05_week.md`. No Python: build the table and totals by hand from the ledger rows (steps in `ceo-scoreboard/scripts/README.md`).
3. Missing nights stay missing. Never fill a day that has no row.
4. **One change for next week:** tied to the daily action with the lowest share of its target, or to the Top 3 pattern (for example, item 3 is left undone on most days). One sentence. Facts from the table only.
5. **Review (yellow).** The `Review:` line in `05_week.md` is the line the template puts after the pasted output and before the one change, and it starts as `Review: pending`. Never write `pass` before a review has run. Start a helper agent first. `05_review.md` uses the record layout in `ceo-scoreboard/_shared/review-rubric.md` (`Reviewed by:` line, `Helper failed:` line on a same-agent review, RR1 to RR5, no `Verdict:` line). It reads the ledger rows for the week, the output, the scoring guide and the settings, checks `ceo-scoreboard/_shared/review-rubric.md` (or `chief-of-staff/_shared/review-rubric.md` if it exists, the master) RR1 to RR5, and writes each result into `runs/YYYY-MM-DD-week/05_review.md`. Pass: change the line in `05_week.md` to `Review: pass`, add a T2 row to `ceo-scoreboard/_shared/decision-log.md` with Evidence `runs/YYYY-MM-DD-week, review: pass` (`review: pass (self)` for a same-agent review), then show it. Only when no helper could start for any reason (an error, no helper tool in this agent, or not allowed to start one), the same agent reviews with the same rubric, writes `Reviewed by: self, YYYY-MM-DD HH:MM` and `Helper failed: <the error, or "no helper tool available">` as the first two lines of `05_review.md`, and the line reads `Review: pass (self)`, in `05_week.md` and in the decision log row. `check_scoreboard.py` fails S10 on a bare pass in either place when the record says self. `check_scoreboard.py` fails S10 on a pass line with no record. Fail: fix exactly what the reviewer listed, once. A second fail makes it red: show the owner the work with the reviewer's notes.
6. Show the owner the week. Under the Chief of Staff, write it where the job row says, and tell the Chief of Staff in one line. Last line: the one change for next week.

## Output
- `05_week.md` in the run folder: the table, the totals, the streaks, the one change. `05_review.md` next to it: the RR1 to RR5 results.
- A T2 row in the decision log.

## Human check
The owner reads the week. If they dispute a day, that day goes through `scoring-guide.md` section 6.
