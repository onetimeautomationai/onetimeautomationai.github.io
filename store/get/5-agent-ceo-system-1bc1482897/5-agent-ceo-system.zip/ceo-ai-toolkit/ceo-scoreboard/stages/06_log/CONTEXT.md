# 06_log: close the loop

One job: every file shows the true state before the session ends. Paths start from the `ceo-ai-toolkit` folder.

## Inputs
- Working: the run folder
- Reference: `ceo-scoreboard/ledger/scoreboard-log.md`, `ceo-scoreboard/_shared/decision-log.md`, both lessons files, `handoffs/scoreboard-report.md`
- Template: `ceo-scoreboard/_templates/outputs/06_log.md`

## Process
1. Night run: the ledger has the row for the scored date, and the report scores the same date and the same number.
2. Decision log: every decision made this session has a row. After a re-score, `06_log.md` lists both rows, the original and the re-score, by L#. Any T3 marked done has the owner's words. Any T2 marked done says `review: pass`.
3. Lessons: every correction the owner gave this session is a line (standalone: in `ceo-scoreboard/_shared/lessons.md`. Under the Chief of Staff: handed to the Chief of Staff).
4. Your job row in `handoffs/jobs.md` has its final status.
5. Run `python3 ceo-scoreboard/scripts/check_scoreboard.py` (after a weekly view, add `--skip-report`). If it fails, fix what it names and run it again. To fix a log row, add a `corrects L#` row. No Python: do the checks in `ceo-scoreboard/scripts/README.md` by hand.
6. Write `06_log.md` in the run folder: files updated, check result, anything still open.

## Output
- `06_log.md` in the run folder.

## Human check
The check passes. A run is done only when this file exists.
