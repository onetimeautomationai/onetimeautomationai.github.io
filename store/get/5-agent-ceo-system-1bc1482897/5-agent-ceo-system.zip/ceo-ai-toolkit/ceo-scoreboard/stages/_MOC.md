# stages: map

| Folder | One line |
|---|---|
| `01_gather/` | The day's Top 3, the proof, the owner's one answer |
| `02_score/` | Statuses, counts, the score out of 10, why, fix |
| `03_tomorrow/` | Up to 3 items for tomorrow, each with its source |
| `04_report/` | Ledger row, handoff file, night score, proof |
| `05_week/` | Weekly view, streaks, one change for next week |
| `06_log/` | Logs true, checks pass |
