# tests: map

| File | One line |
|---|---|
| `test-cases.md` | TC1 to TC31, what the owner says and what must happen |
| `test_agent_check.py` | Runs TC18 to TC24 and the re-run checks on a made-up toolkit in a temporary folder |
| `acceptance-criteria.md` | AC1 to AC13, the bar to ship |
| `rubric.md` | How a judge on a different model scores a night score |
| `test-owner.md` | Reuses the Chief of Staff's made-up owner, adds standalone answers and a made-up day |
| `seed-ledger.md` | Five seeded ledger rows and the expected streak and weekly numbers |
