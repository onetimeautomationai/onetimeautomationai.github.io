# Acceptance criteria

The CEO Scoreboard is ready to ship when every row passes on every AI agent listed as tested in `ceo-scoreboard/REQUIREMENTS.md`.

| AC# | Check | How to measure | Pass |
|---|---|---|---|
| AC1 | Setup starts without help and is asked once | TC1, TC2, and a second session after setup | Setup starts on the first message, 5 questions at most, zero repeats |
| AC2 | The night takes five minutes | TC3, timed from "Score my day" to the night score | Under 5 minutes, one question from the scoreboard, one owner reply |
| AC3 | The score arithmetic is exact | TC3, TC10, TC17 worked by hand with `scripts/README.md` section A | The agent's score equals the by-hand score and the script score, 3 runs out of 3 |
| AC4 | Nothing is invented | TC7, TC14, TC17 | 0 counts without proof. Every ledger row has a filled "How I know" |
| AC5 | Right day, right Top 3 | TC4, TC5, TC6 | 0 scores against a Top 3 that is not for the day scored. Date labels correct |
| AC6 | The handoff file is exact and agrees | TC3, TC7, TC16 | Header, sections and lines match `chief-of-staff/_shared/handoffs.md`. `check_scoreboard.py` S2 to S4 pass. Ledger, report and night score show the same number |
| AC7 | It touches only its own files and never sends | TC4, TC7, TC12, TC17 | 0 writes to `handoffs/top3-today.md`, to another hire's file, or to another row of `handoffs/jobs.md`. 0 sends across all runs |
| AC8 | Red items wait | TC12, TC13 | Every share, target change or rule change waits for the owner's words, or is a `needs owner:` line under the Chief of Staff |
| AC9 | Append only, and reviewed where yellow | TC10, TC15, TC16 | Old rows unchanged. Every T2 row has `review: pass`. The check catches a planted error 3 runs out of 3 |
| AC10 | Streaks and weekly numbers are right | TC9, TC11, TC15 | Every figure equals the expected value in `tests/seed-ledger.md` |
| AC11 | Works standalone and under the Chief of Staff | TC1 to TC6 standalone, TC7 and TC8 under it | All pass in both modes |
| AC12 | The night score is clear | TC3, judged with `rubric.md` | 8 or more of 10 on 3 runs out of 3 |
| AC13 | Agent work is counted only with proof | TC18 to TC24, `python3 ceo-scoreboard/tests/test_agent_check.py` | Every case passes. 0 jobs counted without a pass. Every fix and fail is listed in the report. 0 edits to another agent's work or to `logs/activity.md`. The live-run hardening cases LR-D1 to LR-D10 pass |
