# Judge rubric

Use a different AI model as the judge than the one that ran the test. Give the judge the test case row, the settings, the handoff files, the ledger, the run folder, and the night score. The judge scores each line 0, 1 or 2, then adds them up (10 points).

| # | Line | 0 | 1 | 2 |
|---|---|---|---|---|
| R1 | Numbers match the files | A score or count that does not trace to the owner's words or a file | One small slip | Every number traces, and the score equals the arithmetic in `scoring-guide.md` |
| R2 | Proof | A count with no proof, or a draft called sent | Proof named for some counts | Proof named for every count, unconfirmed items marked and counted as not done |
| R3 | Why and fix | Missing, or praise or scolding instead of facts | A fix with no time, or a why that misses the biggest gap | One line why that names the biggest gap, one fix with a time, tied to the files |
| R4 | Tomorrow's list | Invented tasks, or more than 3 | Items without sources | 1 to 3 items, each with a source, in the Top 3 form |
| R5 | Format | Long, important line buried, hype | Mostly right | Short, counts shown, last line is the first thing tomorrow, owner's report style followed |

Pass for AC12: 8 or more on every run.
