# Seed ledger for TC9, TC10 and TC15

Copy these five rows under the header of a scratch copy of `ceo-scoreboard/ledger/scoreboard-log.md`. Work days are Monday to Friday and a good day is 7 or more. 2026-11-19 is a Thursday.

| Date | Done | Partly | Of | Leading | Goal moved | Score | Why | Fix | How I know | Note |
|---|---|---|---|---|---|---|---|---|---|---|
| 2026-11-12 | 2 | 1 | 3 | M1 2/2, M2 1/2 | yes | 8 | Two done, one partly, one client signed | First block, finish the open proposal | owner's words in run 2026-11-12-night | |
| 2026-11-13 | 3 | 0 | 3 | M1 1/2, M2 1/2 | no | 8 | All three done, half of each daily action | First block, one more conversation | owner's words in run 2026-11-13-night | |
| 2026-11-16 | 3 | 0 | 3 | M1 2/2, M2 2/2 | yes | 10 | All done, targets met, deal moved | Keep the same first block | owner's words in run 2026-11-16-night | |
| 2026-11-17 | 1 | 1 | 3 | M1 0/2, M2 1/2 | no | 4 | One done, no new conversations | First block, 2 new conversations | owner's words in run 2026-11-17-night | |
| 2026-11-18 | 3 | 0 | 3 | M1 1/2, M2 2/2 | no | 8 | All three done, one new conversation | First block, one more conversation | owner's words in run 2026-11-18-night | |

Expected from the script (by hand: `scripts/README.md`):
- `streak --today 2026-11-19`: good-day streak 1, best 3. Nights scored in a row 5, best 5.
- `streak --today 2026-11-20`: both current streaks 0, with 2026-11-19 listed as a missed work day.
- `week --end 2026-11-18 --today 2026-11-19`: streak line as of 2026-11-19 reads good-day streak 1, best 3. With `--today 2026-11-20` it reads 0 and names 2026-11-19 as a missed work day.
- `week --end 2026-11-18`: 5 nights scored of 5 work days, average 7.6, 4 good days, Top 3 done 12 of 15 items, M1 6 of 10 (60 percent), M2 7 of 10 (70 percent), goal moved on 2 of 5 days, best day 2026-11-16 (10), lowest day 2026-11-17 (4).
