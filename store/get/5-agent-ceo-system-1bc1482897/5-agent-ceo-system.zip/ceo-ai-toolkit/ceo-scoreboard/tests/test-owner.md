# Test owner (made up)

Use the same made-up owner as the Chief of Staff, Dana Ruiz: `chief-of-staff/tests/test-owner.md` (Q1 to Q18). For tests under the Chief of Staff, finish the Chief of Staff's setup with those answers first.

## Standalone setup answers (for a fresh `ceo-scoreboard/` with no Chief of Staff setup)

| Q | Answer |
|---|---|
| 1 | 10 new monthly clients by March 31 |
| 2 | new sales conversations, proposals sent, follow-ups on open proposals |
| 3 | M1 new conversations, target 2, counts when the person replies. M2 proposals sent, target 2, counts when sent. M3 follow-ups, target 3, counts when sent to someone with an open proposal |
| 4 | Monday to Friday |
| 5 | Pacific, 5 PM |

## Under the Chief of Staff (TC8)

The Chief of Staff's profile already holds goal 1 and the daily actions ("new sales conversations, proposals sent, follow-ups on open proposals"). The Scoreboard asks only Q3 and Q4.

| Q | Answer |
|---|---|
| 3 | M1 target 2 (counts when the person replies), M2 target 2 (counts when sent), M3 target 3 (counts when sent to someone with an open proposal) |
| 4 | Monday to Friday |

## The made-up day (used by TC3)

Today's `handoffs/top3-today.md`:

```
---
from: focus-manager
updated: 2026-11-19 08:05
status: ok
---

## Top 3 for 2026-11-19
1. Send proposals to the two warm leads : both proposals drafted for your review
2. Call back Priya Shah about the payroll add-on : call held, next step agreed
3. Year-end checklist offer post : post drafted for your review

## One result per block
| Block | Result that counts as done |
|---|---|
| 9:00 to 11:00 | Proposals drafted |
```

Files that exist: two drafts in `handoffs/drafts/` dated today (the proposals and the offer post).

Dana's reply to the night question: "1 and 3 done, 2 partly because the call is booked for tomorrow, conversations 1, proposals 2, follow-ups 1, nothing signed."
