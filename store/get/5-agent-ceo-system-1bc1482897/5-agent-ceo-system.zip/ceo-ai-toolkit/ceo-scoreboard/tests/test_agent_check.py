#!/usr/bin/env python3
"""Tests for the agent work check (TC18 to TC24 in test-cases.md).

Usage (from the ceo-ai-toolkit folder, works from any folder):
    python3 ceo-scoreboard/tests/test_agent_check.py

Builds a made-up toolkit in a temporary folder (made-up owner, made-up jobs), runs
scoreboard_calc.py agents and check_scoreboard.py on it, and prints PASS or FAIL per case.
Standard library only. Never touches the real toolkit files.
"""
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent.parent  # the ceo-scoreboard folder
DAY = "2026-11-20"
RESULTS = []


def case(name, ok, detail=""):
    RESULTS.append(ok)
    print(f"{'PASS' if ok else 'FAIL'}  {name}" + ("" if ok else f"  ({detail})"))


def write(root, rel, text):
    p = root / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(text, encoding="utf-8")


LOG_HEAD = "# Activity log\n\n| When | Agent | Job | Result | Proof |\n|---|---|---|---|---|\n"

LINES = [
    # AL1 pass: the file exists and holds the words
    f'| {DAY} 08:15 | email-manager | Sorted the inbox | 14 threads sorted, 2 drafts | email-manager/runs/{DAY}-0815/06_log.md contains "Check result: all checks passed" |',
    # AL2 fix: the file does not exist
    f'| {DAY} 09:02 | time-manager | Blocked the Top 3 | 3 blocks placed | time-manager/runs/{DAY}/06_log.md contains "3 blocks placed" |',
    # AL3 fail: the words are not in the file
    f'| {DAY} 10:30 | focus-manager | Set the Top 3 | Top 3 written | handoffs/top3-today.md contains "Top 3 for 2026-11-19" |',
    # AL4 fail: says sent, proof is a draft
    f'| {DAY} 11:00 | email-manager | Reply to Priya Shah | sent | handoffs/drafts/{DAY}-priya.md contains "Hi Priya" |',
    # AL5 fix: empty proof
    f'| {DAY} 12:00 | chief-of-staff | Morning brief | brief given | - |',
    # AL6 pass, later downgraded by a review line
    f'| {DAY} 13:00 | chief-of-staff | Intake of 2 ideas | 2 board rows | chief-of-staff/board/board.md contains "# Board ## Inbox" |',
    # AL7 replaces AL2 and passes
    f'| {DAY} 14:00 | time-manager | corrects AL2 Blocked the Top 3 | 3 blocks placed | time-manager/runs/{DAY}-0900/06_log.md contains "3 blocks placed" |',
    # another day: ignored for {DAY}
    '| 2026-11-19 18:00 | focus-manager | Closed the day | 2 of 3 done | handoffs/top3-today.md contains "Top 3" |',
    # no readable date
    '| yesterday | email-manager | Sorted the inbox | done | handoffs/email-manager-report.md contains "x" |',
]

FILES = {
    f"email-manager/runs/{DAY}-0815/06_log.md": "# Log\n\nCheck result: all   checks passed\n",
    "handoffs/top3-today.md": f"---\nfrom: focus-manager\n---\n\n## Top 3 for {DAY}\n1. Proposals : both drafted\n",
    f"handoffs/drafts/{DAY}-priya.md": "status: draft\n\nHi Priya, here is the payroll add-on.\n",
    "chief-of-staff/board/board.md": "# Board\n\n## Inbox\n| # | Idea |\n",
    f"time-manager/runs/{DAY}-0900/06_log.md": "# Log\n\n3 blocks placed. Check passed.\n",
}

SETTINGS = """---
type: settings
---
setup_done: yes
- Time zone: America/Chicago
- Work days: Monday to Friday
- A good day is a score of: 7
"""

LEDGER = f"""# Ledger

| Date | Done | Partly | Of | Leading | Goal moved | Score | Why | Fix | How I know | Note |
|---|---|---|---|---|---|---|---|---|---|---|
| {DAY} | 2 | 1 | 3 | M1 2/2, M2 1/2, M3 1/3 | no | 7 | Two of three done | Monday 9 AM, send 2 follow-ups | owner's words in 01_gather.md | |
"""

DECISIONS = """# Decision log

| L# | Time | Decision | Tier | Why | Evidence | Owner's words | Result |
|---|---|---|---|---|---|---|---|
| L1 | 2026-11-20 18:20 | Scored 2026-11-20: 2 of 3 done, 7 of 10 | T1 | night run | runs/2026-11-20-night | - | done |
"""


def report(agents_line, flags, extra=""):
    return f"""---
from: ceo-scoreboard
updated: {DAY} 18:20
status: ok
---

## Score for {DAY}
- Top 3 done: 2 of 3
- Score: 7 out of 10, two of three done
- One fix for tomorrow: Monday 9 AM, send 2 follow-ups
{agents_line}
{extra}
## Tomorrow's list
1. Follow-ups : 2 sent

## Agent flags
{flags}
"""


def build(root, lines, with_log=True):
    shutil.copytree(HERE, root / "ceo-scoreboard", ignore=shutil.ignore_patterns("__pycache__", "runs", "ledger"))
    (root / "ceo-scoreboard" / "runs").mkdir()
    write(root, "ceo-scoreboard/_shared/scoreboard-settings.md", SETTINGS)
    write(root, "ceo-scoreboard/ledger/scoreboard-log.md", LEDGER)
    write(root, "ceo-scoreboard/_shared/decision-log.md", DECISIONS)
    for rel, text in FILES.items():
        write(root, rel, text)
    if with_log:
        write(root, "logs/activity.md", LOG_HEAD + "\n".join(lines) + "\n")


def run(root, *args):
    r = subprocess.run([sys.executable, *args], cwd=root, capture_output=True, text=True)
    return r.returncode, r.stdout + r.stderr


def load_calc(root):
    sys.path.insert(0, str(root / "ceo-scoreboard" / "scripts"))
    import importlib
    import scoreboard_calc
    importlib.reload(scoreboard_calc)
    sys.path.pop(0)
    return scoreboard_calc


def cells_of(line):
    return [c.strip() for c in line.strip().strip("|").split("|")]


def hardening_cases(tmp):
    """Live-run hardening (LR-D1 to LR-D6, LR-D10 in the 2026-11-20 report)."""
    outside = tmp / "outside.md"
    outside.write_text("secret outside words that prove nothing\n", encoding="utf-8")
    ok1 = f'| {DAY} 08:15 | email-manager | Sorted the inbox | 14 threads sorted | email-manager/runs/{DAY}-0815/06_log.md contains "Check result: all checks passed" |'
    lines = [
        ok1,
        # LR-D1 late line (after the report time 18:20)
        f'| {DAY} 23:59 | time-manager | Blocked tomorrow | 3 blocks placed | time-manager/runs/{DAY}-0900/06_log.md contains "3 blocks placed" |',
        # LR-D2 symlink out of the toolkit
        f'| {DAY} 09:00 | focus-manager | Linked proof | done | link.md contains "secret outside words" |',
        # LR-D4 case variant of the log
        f'| {DAY} 09:10 | focus-manager | Self proof | done | logs/Activity.md contains "Self proof" |',
        # LR-D3 send verbs and path case
        f'| {DAY} 09:20 | email-manager | Mail to Priya | emailed | notes/outbox.md contains "Drafted 2 replies to clients" |',
        f'| {DAY} 09:30 | email-manager | Mail to Sam | sent | Handoffs/Drafts/{DAY}-sam.md contains "Hi Sam, here is the plan" |',
        f'| {DAY} 09:40 | email-manager | Text to Lee | texted | notes/outbox.md contains "Drafted 2 replies to clients" |',
        f'| {DAY} 09:50 | email-manager | Note to Kim | messaged | handoffs/{DAY}-kim.md contains "Hi Kim, see you at ten" |',
        # LR-D6 short proof words
        f'| {DAY} 10:00 | email-manager | Short proof | done | email-manager/runs/{DAY}-0815/06_log.md contains "a" |',
        # LR-D5 exact duplicate
        ok1,
        # LR-D10 unreadable dates
        '| 2026/11/20 10:00 | email-manager | Bad slash date | done | x contains "yyyyyyyyyyyyyyy" |',
        '| 2026-13-45 10:00 | email-manager | Impossible date | done | x contains "yyyyyyyyyyyyyyy" |',
    ]
    root = tmp / "hard"
    build(root, lines)
    write(root, "notes/outbox.md", "Log: Drafted 2 replies to clients today.\n")
    write(root, f"handoffs/drafts/{DAY}-sam.md", "Hi Sam, here is the plan.\n")
    write(root, f"handoffs/{DAY}-kim.md", "Hi Kim, see you at ten.\n")
    try:
        (root / "link.md").symlink_to(outside)
    except OSError:
        pass
    calc = load_calc(root)
    until = f"{DAY} 18:20"
    notes = {}
    jobs, unreadable = calc.agent_check(DAY, until=until, notes=notes)
    v = {j["agent"] + ":" + j["job"]: j["verdict"] for j in jobs}
    case("LR-D1 a line logged after the report time is left out", "time-manager:Blocked tomorrow" not in v and notes["late"] == 1, (v, notes))
    jobs_all, _u = calc.agent_check(DAY)
    case("LR-D1b with no cutoff the late line is still read", any(j["job"] == "Blocked tomorrow" for j in jobs_all))
    if (root / "link.md").is_symlink():
        case("LR-D2 a symlink that leads outside the toolkit is fail", v.get("focus-manager:Linked proof") == "fail", v)
    case("LR-D4 a case variant of the log cannot prove its own line", v.get("focus-manager:Self proof") == "fail", v)
    case("LR-D3a 'emailed' with 'Drafted' in the proof words is fail", v.get("email-manager:Mail to Priya") == "fail", v)
    case("LR-D3b 'sent' with Handoffs/Drafts/ (case variant) is fail", v.get("email-manager:Mail to Sam") == "fail", v)
    case("LR-D3c 'texted' with 'Drafted' in the proof words is fail", v.get("email-manager:Text to Lee") == "fail", v)
    case("LR-D3d 'messaged' with a real non-draft file passes", v.get("email-manager:Note to Kim") == "pass", v)
    case("LR-D6 proof words under 12 characters are fix", v.get("email-manager:Short proof") == "fix", v)
    case("LR-D5b an exact duplicate line counts once", notes["duplicates"] == 1 and sum(1 for j in jobs if j["job"] == "Sorted the inbox") == 1, notes)
    case("LR-D10 unreadable and impossible dates are counted as unreadable", unreadable == 2, unreadable)
    done, flagged = calc.agent_counts(jobs)
    flags = "\n".join(f"- {j['code']} flagged" for j in flagged)
    ag = f"- Agents: {done} jobs done, {len(flagged)} flagged"
    write(root, "handoffs/scoreboard-report.md", report(ag, flags))
    code, out = run(root, "ceo-scoreboard/scripts/check_scoreboard.py", "--today", DAY)
    case("LR-D10b report without the unreadable line fails S8", code == 1 and "no '- Unreadable log lines: 2' line" in out, out)
    write(root, "handoffs/scoreboard-report.md", report(ag, flags, "- Unreadable log lines: 2"))
    code, out = run(root, "ceo-scoreboard/scripts/check_scoreboard.py", "--today", DAY)
    case("LR-D1c a late log line does not break S8 on a finished night", code == 0, out)
    code, out = run(root, "ceo-scoreboard/scripts/scoreboard_calc.py", "agents", "--date", "2026-13-45")
    case("LR-D10c --date 2026-13-45 is refused", code == 2, out)

    # LR-D5 one agent cannot correct another agent's line
    lines2 = [
        f'| {DAY} 09:00 | time-manager | Blocked the Top 3 | 3 blocks placed | time-manager/runs/{DAY}/06_log.md contains "3 blocks placed" |',
        f'| {DAY} 10:00 | email-manager | corrects AL1 Blocked the Top 3 | 14 threads sorted | email-manager/runs/{DAY}-0815/06_log.md contains "Check result: all checks passed" |',
    ]
    root2 = tmp / "cover"
    build(root2, lines2)
    calc2 = load_calc(root2)
    jobs2, _u = calc2.agent_check(DAY)
    v2 = {j["code"]: j["verdict"] for j in jobs2}
    done2, flagged2 = calc2.agent_counts(jobs2)
    case("LR-D5 email-manager cannot cover time-manager's flag: AL1 stays fix, AL2 is fix", v2 == {"AL1": "fix", "AL2": "fix"} and done2 == 0 and len(flagged2) == 2, v2)
    case("LR-D7 the fix text has no doubled 'the the'", all("the the" not in j["fix"] for j in jobs2), [j["fix"] for j in jobs2])


def rerun_cases(tmp):
    """Re-run fixes (R2-D1, R2-D4 in the 2026-11-21 report)."""
    lines = [
        # R2-D4a proof in another agent's folder
        f'| {DAY} 08:15 | time-manager | Blocked the Top 3 | 3 blocks placed | email-manager/runs/{DAY}-0815/06_log.md contains "Check result: all checks passed" |',
        # R2-D4b proof in an older run folder of the same agent
        f'| {DAY} 08:30 | email-manager | Sorted the inbox | 14 threads sorted | email-manager/runs/2026-11-18-0815/06_log.md contains "Check result: all checks passed" |',
        # control: own folder, today's run
        f'| {DAY} 08:45 | email-manager | Sorted again | 14 threads sorted | email-manager/runs/{DAY}-0815/06_log.md contains "Check result: all checks passed" |',
    ]
    root = tmp / "rerun"
    build(root, lines)
    write(root, "email-manager/runs/2026-11-18-0815/06_log.md", "# Log\n\nCheck result: all checks passed\n")
    calc = load_calc(root)
    jobs, _u = calc.agent_check(DAY)
    v = {j["code"]: j["verdict"] for j in jobs}
    case("R2-D4a a proof in another agent's folder is not a pass", v.get("AL1") == "fix", v)
    case("R2-D4b a proof in an older run folder is not a pass", v.get("AL2") == "fix", v)
    case("R2-D4c a proof in its own folder, today's run, still passes", v.get("AL3") == "pass", v)
    # R2-D1 the report fix line must equal the latest ledger Fix
    root2 = tmp / "fixline"
    build(root2, [])
    write(root2, "handoffs/scoreboard-report.md", report("- Agents: 0 jobs done, 0 flagged", "- none").replace(
        "Monday 9 AM, send 2 follow-ups", "hold the Priya Shah call"))
    code, out = run(root2, "ceo-scoreboard/scripts/check_scoreboard.py", "--today", DAY)
    case("R2-D1a a report fix line that differs from the ledger Fix fails S4", code == 1 and "S4 FAIL" in out and "fix line" in out, out)
    write(root2, "handoffs/scoreboard-report.md", report("- Agents: 0 jobs done, 0 flagged", "- none").replace(
        "Monday 9 AM, send 2 follow-ups", "MONDAY 9 AM, send 2   follow-ups"))
    code, out = run(root2, "ceo-scoreboard/scripts/check_scoreboard.py", "--today", DAY)
    case("R2-D1b the same fix with other case and spacing passes", code == 0, out)


def r3_cases(tmp):
    """Re-run fixes R3-S2 (S9 next work day) and R3-S3 (streak ignores non-work days)."""
    # DAY 2026-11-20 is a Friday, so the fix must name Monday
    root = tmp / "nextday"
    build(root, [])
    base = report("- Agents: 0 jobs done, 0 flagged", "- none")
    bad = base.replace("Monday 9 AM, send 2 follow-ups", "Tomorrow 9 AM, send 2 follow-ups")
    write(root, "ceo-scoreboard/ledger/scoreboard-log.md", LEDGER.replace("Monday 9 AM, send 2 follow-ups", "Tomorrow 9 AM, send 2 follow-ups"))
    write(root, "handoffs/scoreboard-report.md", bad)
    code, out = run(root, "ceo-scoreboard/scripts/check_scoreboard.py", "--today", DAY)
    case("R3-S2a a Friday fix line that says tomorrow fails S9", code == 1 and "S9 FAIL" in out and "Monday" in out, out)
    write(root, "ceo-scoreboard/ledger/scoreboard-log.md", LEDGER)
    write(root, "handoffs/scoreboard-report.md", base)
    code, out = run(root, "ceo-scoreboard/scripts/check_scoreboard.py", "--today", DAY)
    case("R3-S2b a Friday fix line that names Monday passes", code == 0 and "S9" not in out.replace("S1 to S9", ""), out)
    # Thursday score: tomorrow is a work day, so "tomorrow" is allowed
    thu = "2026-11-19"
    write(root, "ceo-scoreboard/ledger/scoreboard-log.md", LEDGER.replace(DAY, thu).replace("Monday 9 AM, send", "Tomorrow 9 AM, send"))
    write(root, "handoffs/scoreboard-report.md", base.replace(DAY, thu).replace("Monday 9 AM, send", "Tomorrow 9 AM, send"))
    code, out = run(root, "ceo-scoreboard/scripts/check_scoreboard.py", "--today", thu)
    case("R3-S2c a Thursday fix line that says tomorrow passes", code == 0, out)
    # Saturday score with Work days Monday to Friday: Monday is the next work day
    sat = "2026-11-21"
    write(root, "ceo-scoreboard/ledger/scoreboard-log.md", LEDGER.replace(DAY, sat).replace("Monday 9 AM, send", "Tomorrow 9 AM, send"))
    write(root, "handoffs/scoreboard-report.md", base.replace(DAY, sat).replace("Monday 9 AM, send", "Tomorrow 9 AM, send"))
    code, out = run(root, "ceo-scoreboard/scripts/check_scoreboard.py", "--today", sat)
    case("R3-S2d a Saturday fix line that says tomorrow (Sunday) fails S9", code == 1 and "S9 FAIL" in out, out)
    # streak: a scored Saturday is not a work day and changes nothing
    import datetime
    calc = load_calc(root)
    mk = lambda d, sc: [d, "2", "0", "3", "none", "no", str(sc), "w", "f", "k", ""]
    bd = {"2026-11-19": mk("2026-11-19", 8), "2026-11-20": mk("2026-11-20", 8), "2026-11-21": mk("2026-11-21", 3)}
    r = calc.streaks(bd, datetime.date(2026, 11, 22))
    case("R3-S3a a low score on a Saturday does not break the good-day streak", r[0] == 2 and r[1] == 2, r)
    bd["2026-11-21"] = mk("2026-11-21", 9)
    r = calc.streaks(bd, datetime.date(2026, 11, 22))
    case("R3-S3b a high score on a Saturday does not add to the streak or the best run", r[0] == 2 and r[2] == 2, r)


def r4_cases(tmp):
    """Re-run fixes R4-S1 (S9 also checks 03_tomorrow.md and the closing line), R4-S6 (proof reasons), R4-S7 (plurals)."""
    root = tmp / "r4"
    build(root, [])
    base = report("- Agents: 0 jobs done, 0 flagged", "- none")
    write(root, "handoffs/scoreboard-report.md", base)
    rd = f"ceo-scoreboard/runs/{DAY}-night"
    write(root, f"{rd}/03_tomorrow.md", "# Tomorrow's list, for Monday 2026-11-23\n\n1. A : b (carried)\n\nMonday, first thing: send 2 follow-ups (carried)\n")
    code, out = run(root, "ceo-scoreboard/scripts/check_scoreboard.py", "--today", DAY)
    case("R4-S1a Friday 03_tomorrow.md closing line names Monday: passes", code == 0, out)
    write(root, f"{rd}/03_tomorrow.md", "# Tomorrow's list\n\n1. A : b (carried)\n\nTomorrow, first thing: send 2 follow-ups (carried)\n")
    code, out = run(root, "ceo-scoreboard/scripts/check_scoreboard.py", "--today", DAY)
    case("R4-S1b Friday 03_tomorrow.md closing line says tomorrow: S9 fails", code == 1 and "S9 FAIL" in out and "03_tomorrow.md" in out, out)
    write(root, f"{rd}/03_tomorrow.md", "x\n\nTomorrow at 9, then Monday, first thing: send follow-ups\n")
    code, out = run(root, "ceo-scoreboard/scripts/check_scoreboard.py", "--today", DAY)
    case("R4-S1c 'tomorrow, then Monday' on a Friday still fails S9", code == 1 and "S9 FAIL" in out, out)
    write(root, f"{rd}/03_tomorrow.md", "x\n\nMonday, first thing: send follow-ups\n")
    write(root, f"{rd}/04_report.md", "# Report\n\nTomorrow, first thing: send follow-ups\n")
    code, out = run(root, "ceo-scoreboard/scripts/check_scoreboard.py", "--today", DAY)
    case("R4-S1d Friday night score closing line says tomorrow: S9 fails", code == 1 and "night score" in out, out)
    write(root, f"{rd}/04_report.md", "# Report\n\nMonday, first thing: send follow-ups\n")
    code, out = run(root, "ceo-scoreboard/scripts/check_scoreboard.py", "--today", DAY)
    case("R4-S1e Friday night score closing line names Monday: passes", code == 0, out)
    # R4-S6 reasons
    calc = load_calc(root)
    write(root, "time-manager/runs/2026-11-19/06_log.md", "Blocked the Top 3 for the day, check passed.\n")
    write(root, "chief-of-staff/runs/x.md", "Blocked the Top 3 for the day, check passed.\n")
    mk = lambda proof: [f"{DAY} 10:00", "time-manager", "Blocked the Top 3", "3 blocks placed", proof]
    r = calc.judge_line(mk('time-manager/runs/2026-11-19/06_log.md contains "Blocked the Top 3 for the day"'), root)
    case("R4-S6a proof from a run dated another day (file exists) does not say 'proof missing'",
         r[0] == "fix" and "another day" in r[1] and "proof missing" not in r[1], r)
    r = calc.judge_line(mk('chief-of-staff/runs/x.md contains "Blocked the Top 3 for the day"'), root)
    case("R4-S6b proof in another agent's folder (file exists) does not say 'proof missing'",
         r[0] == "fix" and "another agent" in r[1] and "proof missing" not in r[1], r)
    # R4-S7 plurals
    one = LINES[0].replace("AL1", "AL1")
    root2 = tmp / "r4plural"
    build(root2, [LINES[0]])
    code, out = run(root2, "ceo-scoreboard/scripts/scoreboard_calc.py", "agents", "--date", DAY)
    case("R4-S7a one job done reads '1 job done'", "- Agents: 1 job done," in out, out)
    code, out = run(root2, "ceo-scoreboard/scripts/scoreboard_calc.py", "streak", "--today", "2026-11-21")
    case("R4-S7b one good day reads '1 good day in a row'", "1 good day in a row" in out, out)


def r5_cases(tmp):
    """Final-round fixes: F-S4 (review record, S10), F-S3 (weekly streak as of today), F-S8 (flag text), F-S5 (plurals)."""
    # F-S4 / TC15: `Review: pass` needs the review record file
    root = tmp / "r5review"
    build(root, [])
    wk = "ceo-scoreboard/runs/2026-11-18-week"
    rr = "# Review, week ending 2026-11-18\n\nReviewed by: helper, 2026-11-19 18:30\n- RR1 pass: ok\n- RR2 pass: ok\n- RR3 pass: ok\n- RR4 pass: ok\n- RR5 pass: ok\n"
    write(root, f"{wk}/05_week.md", "# Week, ending 2026-11-18\n\nReview: pending\n")
    code, out = run(root, "ceo-scoreboard/scripts/check_scoreboard.py", "--skip-report", "--today", DAY)
    case("F-S4a `Review: pending` needs no record", code == 0, out)
    write(root, f"{wk}/05_week.md", "# Week, ending 2026-11-18\n\nReview: pass\n")
    code, out = run(root, "ceo-scoreboard/scripts/check_scoreboard.py", "--skip-report", "--today", DAY)
    case("F-S4b `Review: pass` with no 05_review.md fails S10", code == 1 and "S10 FAIL" in out and "05_review.md" in out, out)
    write(root, f"{wk}/05_review.md", rr)
    code, out = run(root, "ceo-scoreboard/scripts/check_scoreboard.py", "--skip-report", "--today", DAY)
    case("F-S4c `Review: pass` with a record for RR1 to RR5 passes", code == 0, out)
    write(root, f"{wk}/05_review.md", rr.replace("- RR4 pass: ok\n", ""))
    code, out = run(root, "ceo-scoreboard/scripts/check_scoreboard.py", "--skip-report", "--today", DAY)
    case("F-S4d a record with no RR4 result fails S10", code == 1 and "RR4" in out, out)
    write(root, f"{wk}/05_week.md", "# Week, ending 2026-11-18\n\nreview: pass (self)\n")
    write(root, f"{wk}/05_review.md", rr)
    code, out = run(root, "ceo-scoreboard/scripts/check_scoreboard.py", "--skip-report", "--today", DAY)
    case("F-S4e `pass (self)` without a 'Helper failed:' line fails S10", code == 1 and "Helper failed" in out, out)
    write(root, f"{wk}/05_review.md", rr + "Helper failed: could not start a helper agent, tool not available\n")
    code, out = run(root, "ceo-scoreboard/scripts/check_scoreboard.py", "--skip-report", "--today", DAY)
    case("F-S4f `pass (self)` with the helper error quoted passes", code == 0, out)

    # F-S3: the weekly streak is as of today, not the week end
    root = tmp / "r5week"
    build(root, [])
    code, out = run(root, "ceo-scoreboard/scripts/scoreboard_calc.py", "week", "--end", DAY, "--today", "2026-11-24")
    case("F-S3a weekly streak as of Tuesday 11-24 is 0 and names the missed Monday",
         code == 0 and "Good-day streak: 0." in out and "Missed work day with no night score: 2026-11-23" in out, out)
    code, out = run(root, "ceo-scoreboard/scripts/scoreboard_calc.py", "week", "--end", DAY, "--today", "2026-11-21")
    case("F-S3b weekly streak as of Saturday 11-21 is still 1", code == 0 and "Good-day streak: 1." in out, out)
    code, out = run(root, "ceo-scoreboard/scripts/scoreboard_calc.py", "streak", "--today", "2026-11-24")
    case("F-S5a one missed work day reads 'Missed work day' (singular)", "Missed work day with no night score: 2026-11-23" in out, out)
    # F-S5: singular in the week table
    write(root, "ceo-scoreboard/_shared/scoreboard-settings.md", SETTINGS.replace("Monday to Friday", "Friday"))
    code, out = run(root, "ceo-scoreboard/scripts/scoreboard_calc.py", "week", "--end", DAY, "--today", DAY)
    case("F-S5b one work day reads '1 of 1 work day.' and one scored day reads '1 of 1 day.'",
         "Nights scored: 1 of 1 work day." in out and "Goal moved on 0 of 1 day." in out, out)

    # F-S8: flag text names the owner when standalone, the Chief of Staff when it exists, and never ends in ".."
    line = f'| {DAY} 09:00 | time-manager | Blocked the Top 3 | 3 blocks placed | time-manager/runs/{DAY}/06_log.md contains "3 blocks placed" |'
    root = tmp / "r5flag"
    build(root, [line, f'| {DAY} 10:00 | email-manager | Sorted the inbox | 14 threads sorted | email-manager/runs/{DAY}-0815/06_log.md contains "Check result: all checks passed" |'])
    write(root, f"email-manager/runs/{DAY}-0815/06_log.md", "# Log\n\nCheck result: all checks passed\n")
    write(root, f"ceo-scoreboard/runs/{DAY}-night/02_score.md", "## Agent review\n- review AL2 fail: the file shows no job from today.\n")
    code, out = run(root, "ceo-scoreboard/scripts/scoreboard_calc.py", "agents", "--date", DAY)
    case("F-S8a standalone: the flag fix names the owner, not the Chief of Staff", "the owner asks" in out and "Chief of Staff" not in out, out)
    case("F-S8b a review reason that ends in a period does not print '..'", ".." not in out, out)
    write(root, "chief-of-staff/_shared/owner-profile.md", "setup_done: yes\n- Goal 1: x\n")
    code, out = run(root, "ceo-scoreboard/scripts/scoreboard_calc.py", "agents", "--date", DAY)
    case("F-S8c under the Chief of Staff the flag fix names the Chief of Staff", "the Chief of Staff asks" in out, out)


def r6_cases(tmp):
    """0.2.6: F2-S4 (S10 guards corrects rows), F2-S3 (reviewer and time), F2-S44 (action with no counts)."""
    root = tmp / "r6corrects"
    build(root, [])
    rr = "Reviewed by: helper, 2026-11-20 18:30\n- RR1 pass: ok\n- RR2 pass: ok\n- RR3 pass: ok\n- RR4 pass: ok\n- RR5 pass: ok\n"
    row = f"| {DAY} | 2 | 1 | 3 | M1 2/2, M2 1/2, M3 1/3 | no | 7 | Two of three done | Monday 9 AM, send 2 follow-ups | owner's words in 01_gather.md | corrects: arithmetic, no owner words, was 8 now 7 |\n"
    write(root, "ceo-scoreboard/ledger/scoreboard-log.md", LEDGER + row)
    code, out = run(root, "ceo-scoreboard/scripts/check_scoreboard.py", "--skip-report", "--today", DAY)
    case("F2-S4a a corrects row with no 04_review.md fails S10", code == 1 and "S10 FAIL" in out and "04_review.md" in out, out)
    rv = f"ceo-scoreboard/runs/{DAY}-night/04_review.md"
    write(root, rv, rr)
    code, out = run(root, "ceo-scoreboard/scripts/check_scoreboard.py", "--skip-report", "--today", DAY)
    case("F2-S4b a corrects row with a full review record passes", code == 0, out)
    write(root, rv, rr.replace("- RR2 pass: ok\n", ""))
    code, out = run(root, "ceo-scoreboard/scripts/check_scoreboard.py", "--skip-report", "--today", DAY)
    case("F2-S4c a corrects record with no RR2 result fails S10", code == 1 and "RR2" in out, out)
    write(root, rv, rr.replace("Reviewed by: helper, 2026-11-20 18:30\n", ""))
    code, out = run(root, "ceo-scoreboard/scripts/check_scoreboard.py", "--skip-report", "--today", DAY)
    case("F2-S3a a record with no 'Reviewed by' line fails S10", code == 1 and "Reviewed by" in out, out)
    write(root, rv, rr.replace("helper", "self"))
    code, out = run(root, "ceo-scoreboard/scripts/check_scoreboard.py", "--skip-report", "--today", DAY)
    case("F2-S3b a self review with no 'Helper failed:' line fails S10", code == 1 and "Helper failed" in out, out)

    # F2-S44: an active action with no ledger counts is shown, not dropped
    root = tmp / "r6action"
    build(root, [])
    settings = SETTINGS + "\n| Code | Daily action | Daily target | Counts when |\n|---|---|---|---|\n| M1 | conversations | 2 | reply |\n| M2 | follow-ups | 2 | sent |\n| M3 | proposals | 1 | sent |\n"
    write(root, "ceo-scoreboard/_shared/scoreboard-settings.md", settings)
    write(root, "ceo-scoreboard/ledger/scoreboard-log.md", LEDGER.replace("M1 2/2, M2 1/2, M3 1/3", "M1 2/2, M2 1/2"))
    code, out = run(root, "ceo-scoreboard/scripts/scoreboard_calc.py", "week", "--end", DAY, "--today", DAY)
    case("F2-S44 an active action with no counts says no counts this week and never 0 of 0", code == 0 and "- M3: no counts this week" in out and "0 of 0" not in out and "- M1: 2 of 2" in out, out)


def r7_cases(tmp):
    """0.2.7: F3-S62 (S10 needs the (self) mark in 05_week.md and the decision log), F3-S1 (M3 wording)."""
    root = tmp / "r7self"
    build(root, [])
    wk = f"ceo-scoreboard/runs/{DAY}-week"
    rr = "- RR1 pass: ok\n- RR2 pass: ok\n- RR3 pass: ok\n- RR4 pass: ok\n- RR5 pass: ok\n"
    write(root, f"{wk}/05_review.md", "Reviewed by: self, 2026-11-20 18:30\nHelper failed: no helper tool available\n" + rr)
    log = DECISIONS + f"| L2 | 2026-11-20 18:40 | Weekly view ending {DAY} | T2 | the week | runs/{DAY}-week, EVIDENCE | | done |\n"
    write(root, f"{wk}/05_week.md", "# Week\n\nReview: pass (self)\n")
    write(root, "ceo-scoreboard/_shared/decision-log.md", log.replace("EVIDENCE", "review: pass (self)"))
    code, out = run(root, "ceo-scoreboard/scripts/check_scoreboard.py", "--skip-report", "--today", DAY)
    case("F3-S62a self review marked (self) in both places passes", code == 0, out)
    write(root, f"{wk}/05_week.md", "# Week\n\nReview: pass\n")
    code, out = run(root, "ceo-scoreboard/scripts/check_scoreboard.py", "--skip-report", "--today", DAY)
    case("F3-S62b a bare 'Review: pass' in 05_week.md over a self review fails S10", code == 1 and "S10 FAIL" in out and "(self)" in out, out)
    write(root, f"{wk}/05_week.md", "# Week\n\nReview: pass (self)\n")
    write(root, "ceo-scoreboard/_shared/decision-log.md", log.replace("EVIDENCE", "review: pass"))
    code, out = run(root, "ceo-scoreboard/scripts/check_scoreboard.py", "--skip-report", "--today", DAY)
    case("F3-S62c a bare 'review: pass' in the decision log over a self review fails S10", code == 1 and "S10 FAIL" in out and "L2" in out, out)


def r8_cases(tmp):
    """0.2.8: a line timed in the same minute as the report counts as before the report."""
    root = tmp / "r8same"
    build(root, [f'| {DAY} 18:20 | email-manager | Same minute job | done | email-manager/runs/{DAY}-0815/06_log.md contains "a" |',
                 f'| {DAY} 18:21 | email-manager | Next minute job | done | email-manager/runs/{DAY}-0815/06_log.md contains "a" |'])
    calc = load_calc(root)
    notes = {}
    jobs, _u = calc.agent_check(DAY, until=f"{DAY} 18:20", notes=notes)
    names = [j["job"] for j in jobs]
    case("F-C7 a line timed in the report's minute counts, the next minute is left out",
         "Same minute job" in names and "Next minute job" not in names and notes["late"] == 1, (names, notes))
    guide = (HERE / "_shared" / "scoring-guide.md").read_text(encoding="utf-8")
    case("F-C7 the scoring guide writes the same-minute rule", "same minute as `updated` counts as before the report" in guide)


def main():
    tmp = Path(tempfile.mkdtemp(prefix="scoreboard-agents-"))
    try:
        # TC18 empty log: no file, then a header only
        root = tmp / "empty"
        build(root, [], with_log=False)
        code, out = run(root, "ceo-scoreboard/scripts/scoreboard_calc.py", "agents", "--date", DAY)
        case("TC18a no log file gives 0 and no crash", code == 0 and "- Agents: 0 jobs done, 0 flagged" in out, out)
        write(root, "logs/activity.md", LOG_HEAD)
        code, out = run(root, "ceo-scoreboard/scripts/scoreboard_calc.py", "agents", "--date", DAY)
        case("TC18b header-only log gives 0 and no crash", code == 0 and "- Agents: 0 jobs done, 0 flagged" in out, out)
        write(root, "handoffs/scoreboard-report.md", report("- Agents: 0 jobs done, 0 flagged", "- none"))
        code, out = run(root, "ceo-scoreboard/scripts/check_scoreboard.py", "--today", DAY)
        case("TC18c empty log, report says 0: check passes", code == 0, out)

        # TC19 to TC23 on the full made-up day
        root = tmp / "day"
        build(root, LINES)
        calc = load_calc(root)
        jobs, unreadable = calc.agent_check(DAY)
        v = {j["code"]: j["verdict"] for j in jobs}
        case("TC19 a job with proof passes (AL1, words found with extra spaces)", v.get("AL1") == "pass", v)
        al2 = calc.judge_line([c.strip() for c in LINES[1].strip().strip("|").split("|")], root)
        case("TC20 a claimed job with a missing proof file is fix (AL2 on its own, before its correction)",
             al2[0] == "fix" and "proof missing" in al2[1], al2)
        case("TC20b an empty Proof cell is fix (AL5)", v.get("AL5") == "fix", v)
        case("TC21 a mismatched proof is fail (AL3, words not in the file)", v.get("AL3") == "fail", v)
        case("TC21b 'sent' with a draft as proof is fail (AL4)", v.get("AL4") == "fail", v)
        case("TC22 'corrects AL2' replaces AL2, and the new line passes (AL7)", v.get("AL2") == "replaced" and v.get("AL7") == "pass", v)
        case("TC22b other days are left out, an unreadable date is counted as unreadable", len(jobs) == 7 and unreadable == 1, (len(jobs), unreadable))
        done, flagged = calc.agent_counts(jobs)
        case("TC22c counts: 3 done (AL1, AL6, AL7), 3 flagged (AL3, AL4, AL5)",
             done == 3 and sorted(j["code"] for j in flagged) == ["AL3", "AL4", "AL5"], (done, [j["code"] for j in flagged]))

        # TC23 a review line moves a pass down, never a fix up
        write(root, f"ceo-scoreboard/runs/{DAY}-night/02_score.md",
              "## Agent review\n- review AL6 fail: the board shows the Inbox heading but no new rows from today\n"
              "- review AL5 pass: trying to move it up\n\n## Agent work\n- AL3 fail: pasted script output is not a review line\n")
        jobs, _u = calc.agent_check(DAY)
        v = {j["code"]: j["verdict"] for j in jobs}
        case("TC23 review line moves AL6 pass to fail, and cannot move AL5 up", v.get("AL6") == "fail" and v.get("AL5") == "fix", v)
        done, flagged = calc.agent_counts(jobs)

        # TC24 check_scoreboard S8 against the report
        flags = "\n".join(f"- {c} flagged" for c in ("AL3", "AL4", "AL5", "AL6"))
        write(root, "handoffs/scoreboard-report.md", report(f"- Agents: {done} jobs done, {len(flagged)} flagged", flags, "- Unreadable log lines: 1"))
        code, out = run(root, "ceo-scoreboard/scripts/check_scoreboard.py", "--today", DAY)
        case("TC24a report matches the script (2 done, 4 flagged): check passes", code == 0 and done == 2, out)
        write(root, "handoffs/scoreboard-report.md", report("- Agents: 7 jobs done, 0 flagged", "- none", "- Unreadable log lines: 1"))
        code, out = run(root, "ceo-scoreboard/scripts/check_scoreboard.py", "--today", DAY)
        case("TC24b report counts every claimed job (7): S8 fails on the count and on each unlisted flag",
             code == 1 and "S8 FAIL: the report says 7 agent jobs done" in out and out.count("is not listed under") == 4, out)
        write(root, "handoffs/scoreboard-report.md", report("", "- none", "- Unreadable log lines: 1"))
        code, out = run(root, "ceo-scoreboard/scripts/check_scoreboard.py", "--today", DAY)
        case("TC24c report with no Agents line while the log has jobs: S8 fails", code == 1 and "has no '- Agents:" in out, out)
        hardening_cases(tmp)
        rerun_cases(tmp)
        r3_cases(tmp)
        r4_cases(tmp)
        r5_cases(tmp)
        r6_cases(tmp)
        r7_cases(tmp)
        r8_cases(tmp)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    passed = sum(RESULTS)
    print(f"\n{passed} passed, {len(RESULTS) - passed} failed.")
    return 0 if all(RESULTS) else 1


if __name__ == "__main__":
    sys.exit(main())
