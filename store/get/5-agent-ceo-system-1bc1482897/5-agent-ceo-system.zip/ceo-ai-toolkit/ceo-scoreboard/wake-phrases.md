# What to say to your CEO Scoreboard

## Under your Chief of Staff
You talk only to your Chief of Staff. It runs the scoreboard for you.

| Say to the Chief of Staff | It does |
|---|---|
| "Wrap up my day" or "Night" | Runs the scoreboard, asks you the one night question, shows your score, what got done and tomorrow's list |
| "Weekly view" or "How was my week" | Your seven days from the scoreboard's ledger |
| "Show my streak" | Your current and best streaks |
| "Fix today's score, ..." | Re-scores with your correction |
| "I'm off today" | Records a day off. No score, streak unchanged |

## On its own
Open your agent in the `ceo-scoreboard` folder.

| Say | It does |
|---|---|
| "Start my CEO Scoreboard" | First-time setup (5 questions at most) |
| "Score my day", "Wrap up my day", "Shutdown" or "How did I do" | The one night question, then your score and tomorrow's list. Said again after the day is scored, it shows the score and runs the check again |
| "Weekly view" or "How was my week" | Your seven days and one change for next week |
| "Show my streak" | Current and best streaks |
| "Fix today's score, ..." | Re-scores with your correction. Old rows stay |
| "I'm off today" | Records a day off |
| "Make my target 5 conversations" | Logs your words, then changes the target |
| "Send my score to [person]" | Writes a draft (saved in that night's run folder as `share-draft.md`) and waits for your yes. Never sends |
| "From now on, ..." | Saves a new rule in the lessons file |
| "Redo scoreboard setup" | Asks the setup questions again |
| "Stop" | Stops and says what was in progress |
| "Uninstall the CEO Scoreboard" | Safe removal, see `UNINSTALL.md` |
