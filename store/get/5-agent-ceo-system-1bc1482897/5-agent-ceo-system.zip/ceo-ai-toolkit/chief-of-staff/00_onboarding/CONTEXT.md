# 00_onboarding: learn the owner once

Runs the first time, or when the owner says "redo setup". Goal: fill `chief-of-staff/_shared/owner-profile.md` and `chief-of-staff/_shared/adapters.md` so no hire asks these again. Paths start from the `ceo-ai-toolkit` folder.

## Inputs
- `chief-of-staff/setup/questionnaire.md` (the questions, in order)
- `chief-of-staff/_shared/owner-profile.md` (the file you fill)

## Process
1. Say one line: "I'm your Chief of Staff. I'll ask you 18 short questions, one at a time, so your team knows you and how you work, then a few more to set up each of your hires. About 20 minutes. Say 'skip' to use the default."
2. If some answers are already filled (the owner stopped halfway last time), start at the first question whose placeholder is still there. Never re-ask a filled one. A resumed setup skips the step 1 line and says instead: "Picking up where we stopped: question N of 18."
3. Ask the questions one per turn. Offer the default in brackets.
4. Write each answer into the profile right away, replacing its `{{placeholder}}`. If the owner stops halfway, the answers so far are saved.
5. "Skip" means use the default. For a required question (no default), ask once more in simpler words. If they skip again, write "not given" and move on. Remind them once, in the first brief, that the brief works better with that answer.
6. Fill the matching fields in `chief-of-staff/_shared/adapters.md` from the tools answer.
6a. After question 14, build `chief-of-staff/_shared/voice-profile.md` from the writing source the owner named (rules at the top of that file). If you cannot reach the source, ask them to paste 3 to 5 messages instead. Tell them in one line what you learned.
6b. Question 18 (the brain dump) is not saved in the profile. Run it straight through `chief-of-staff/stages/01_intake/CONTEXT.md` and `02_decide`, so every item is on the board before the first brief.
7. Fill "Installed hires" yourself: `yes` if the folder exists next to `chief-of-staff/`, `no` if not. Do not ask.
8. When no `{{` is left, set `setup_done: yes` in the profile front matter. Do this before step 8a: each hire's setup checks this line to know it runs under the Chief of Staff and copies from this profile.
8a. **Set up every installed hire now, so all five are ready before the first brief.** Run each installed hire's `00_onboarding/CONTEXT.md` in its "under the Chief of Staff" mode, in this order, with the same rules as above (one question per turn, a default in brackets, "skip" uses it). Each one reads this profile and asks only what it still needs. Stop each one where its own file says to stop under the Chief of Staff (it never runs its first job here: the first brief and the first night wrap run them). Each setup is a job like any other: before it starts, add a row to `handoffs/jobs.md` and the board Job queue (For the hire's folder name, Job "Set up under the Chief of Staff", Write result to its settings file, light green), and mark it `done` when its "Done when" below holds, or leave it `open` with the reason (`chief-of-staff/stages/03_dispatch/CONTEXT.md` step 8). A hire that stopped with `waiting: setup` gets the owner's answers in that row as `Owner answers: <exact words>`, then runs again.
   - **Email Manager** (`email-manager/00_onboarding/CONTEXT.md`): asks only what this profile does not hold (your email addresses, the check time, email access if the tools answer did not say). Done when `email-manager/_shared/email-settings.md` has no `{{` and says `setup_done: yes`.
   - **Time Manager** (`time-manager/00_onboarding/CONTEXT.md`): copies name, time zone, work days and hours, protected time and calendar from this profile into `time-manager/config.json` (time zone as a name like `America/Los_Angeles`, not "Pacific", `protected` with one row per block: name, days, start, end), then asks only its two remaining questions (focus time and breaks). Done when `time-manager/config.json` says `"setup_done": true`.
   - **CEO Scoreboard** (`ceo-scoreboard/00_onboarding/CONTEXT.md`): reads goal 1 and the daily actions from this profile, shows them back in one line, and asks Q3 (how many make a good day) and Q4 (work days). Done when `ceo-scoreboard/_shared/scoreboard-settings.md` has no `{{` and says `setup_done: yes`.
   - **Focus Manager**: nothing to ask. It uses this profile under the Chief of Staff (its own setup runs only standalone).
   Then check all three files. Say in one line what each hire has ("Email, calendar, focus and scoreboard are set up"). A hire the owner stopped partway is named in that line ("Scoreboard not finished: 1 question left"), and each morning brief offers to finish it once (`chief-of-staff/stages/04_morning-brief/CONTEXT.md` step 5). A hire that is not installed is skipped: the roster fallback covers it.
9. Add a decision log row: "Onboarding done", T1, Result done.
9a. Close the brain dump run from step 6b with `chief-of-staff/stages/06_log/CONTEXT.md`. Its check can pass now that setup is done. Without its `06_log.md`, check C5 fails from the next day.
10. Tell the owner in one line what you filed. Then offer the plate ranking in one question, with the number from the profile's use answer (11 for business or personal use, 12 for both): "Want to rank everything on your plate now? The brain dump you just gave me is the starting list. [11] short questions. Then you pick between two items at a time, or I rank them for you to review. About 15 minutes. Say 'later' to skip for now. [yes, now]" The default is yes, now: a plain "ok", "sure", "go", "yes" or any reply that does not say later counts as yes, when it is the owner's next message in this session, right after the offer. Only "later" (or "not now") skips it. **No answer:** the owner moves on to something else or the session ends with no reply to the offer: treat it as "later" (the bullet below), so the offer is never lost. A message in a later session ("Morning" the next day) is a new request, never a yes to this offer: route it as usual, and the brief offers the ranking from the Job queue row.
   - Yes: run `chief-of-staff/stages/07_plate/CONTEXT.md` now, then 08, 09 and 06. The first brief then takes its Top 3 from the ranking. If the yes already names a way to rank ("yes, rank it for me" is auto, "yes, I'll pick" is manual), write `rank_mode` in the owner profile now, with a T1 log row "Owner chose ranking mode: auto" (or manual) and their words, so `08_rank` step 0 does not ask again. Otherwise `08_rank` step 0 asks once.
   - Later: add a row "Rank your plate" for the Chief of Staff to the board's Job queue only (it is the Chief of Staff's own reminder, not a manager job, so it never goes in `handoffs/jobs.md`). Its cells: Job# the next J number on the board (the same numbers as every job, never a new letter such as R1), Job "Rank your plate", Manager "Chief of Staff", Result goes to "handoffs/priorities.md", Due "next brief", Light green, Status `open`. The same holds for every "Re-rank your plate" row. The brief given right after setup (step 11) does not offer it again, because the owner just said later. The next morning's brief offers it once more (`chief-of-staff/stages/04_morning-brief/CONTEXT.md` step 5).
11. Then, if it is before the owner's work hours end, give their first morning brief (stage 04, saved as today's `brief.md`). After work hours, say the first brief comes tomorrow morning and log the first-week job on the board.

## Output
- `chief-of-staff/_shared/owner-profile.md` with no `{{` left and `setup_done: yes`.
- `chief-of-staff/_shared/adapters.md` filled.
- Each installed hire set up (step 8a): `email-manager/_shared/email-settings.md` and `ceo-scoreboard/_shared/scoreboard-settings.md` say `setup_done: yes`, `time-manager/config.json` says `"setup_done": true`.
- One decision log row.

## Human check
The owner reads the one-line summary and can correct any answer. A correction updates the profile and adds a `lessons.md` line.

## Redo setup
Copy the current profile to `chief-of-staff/archive/owner-profile-YYYY-MM-DD.md`. Reset every answer line to its `{{placeholder}}` and `setup_done: no`, then run this stage from step 1, offering the old answers as defaults.
