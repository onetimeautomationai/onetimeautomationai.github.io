# Pipeline

Paths start from the `ceo-ai-toolkit` folder. The Chief of Staff runs three loops.

## Loop A: one owner request (an idea, an ask, a brain dump)

Start it with `python3 chief-of-staff/scripts/new_run.py "short-name"`, or copy `chief-of-staff/_templates/run/` to `chief-of-staff/runs/YYYY-MM-DD-short-name/`.

| # | Stage | Output in the run folder | Human check |
|---|---|---|---|
| 01 | intake | `01_intake.md` + board Inbox rows | none, logged the same turn |
| 02 | decide | `02_decide.md` | Owner decides every T3 item |
| 03 | dispatch | `03_dispatch.md` + jobs | Owner approves anything that leaves their hands |
| 06 | log | `06_log.md` | `check_gates.py` passes |

Small asks (a lookup, a status check) go 01, then a one-line answer, then 06. Write "lookup only" in `02_decide.md`.

## Loop B: the daily rhythm

| # | Stage | When | Output |
|---|---|---|---|
| 04 | morning brief | First session of the day | `chief-of-staff/runs/YYYY-MM-DD-morning/brief.md` |
| 05 | night wrap | Last session of the day | `chief-of-staff/runs/YYYY-MM-DD-night/wrap.md` |

Start them with `new_run.py morning` or `new_run.py night`. These folders get no intake file and need no `06_log.md`.

## Loop C: rank the owner's plate

Runs right after setup (if the owner says yes), on "Prioritize my plate", "What should I work on?" or "I'm overwhelmed", and once a week. Start it with `python3 chief-of-staff/scripts/new_run.py plate`, or copy `chief-of-staff/_templates/plate/` to `chief-of-staff/runs/YYYY-MM-DD-plate/`. Rules: `chief-of-staff/_shared/plate-rules.md`.

| # | Stage | Output in the run folder | Human check |
|---|---|---|---|
| 07 | plate | `07_plate.md` + `chief-of-staff/board/plate.md` | Owner approves the sort and the ranking question |
| 08 | rank | `08_rank.md` with every pair, who picked it, and the Result | Manual: owner picks every pair. Auto: reviewed, then the owner may flip any pair and says it looks right (PL18) |
| 09 | organize | `09_priorities.md` + `handoffs/priorities.md` + jobs | Reviewer passes it. Owner decides every red item |
| 06 | log | `06_log.md` | `check_gates.py` passes |

Between weekly rankings, `chief-of-staff/stages/10_re-rank/CONTEXT.md` places each new item with at most 3 pairs and needs no run folder. A new "now" item goes to a manager only once it is in the top 3, and a must right away (`chief-of-staff/_shared/plate-rules.md` PL17).

**Stable every run:** everything in `chief-of-staff/_shared/`.
**New every run:** `chief-of-staff/runs/`, rows on the board and in the decision log, files in `handoffs/`.

Every stage reads `chief-of-staff/_shared/standing-rules.md` and `chief-of-staff/_shared/lessons.md` first.
