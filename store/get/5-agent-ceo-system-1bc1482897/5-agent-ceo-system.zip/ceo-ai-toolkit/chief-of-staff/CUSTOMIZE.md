# Change how your Chief of Staff works

The easy way: tell it. "From now on, put decisions first in my brief." It adds a line to `_shared/lessons.md` and follows it from then on.

## Safe to change

| What | File |
|---|---|
| Your goals, hours, tools, report style | `_shared/owner-profile.md` (or say "redo setup") |
| What goes in the brief and wrap, and in what order | Tell it. It saves a lesson |
| Which manager gets which job | `_shared/roster.md` |
| Setup questions | `setup/questionnaire.md` |
| The questions it asks about your plate | `setup/plate-questions.md` |
| The question every pair is judged on, and your weekly re-rank day | Tell it ("from now on, re-rank on Sunday"). Both are kept in `board/plate.md` |
| How many pairs it shows per message (9 by default) | Tell it. It saves a lesson |
| Who picks each pair: you, or your Chief of Staff for your review | Say "I'll pick" or "Rank it for me". It is kept as `rank_mode` in `_shared/owner-profile.md` |

## Change with care (your Chief of Staff asks for your yes and keeps a snapshot first)

| What | Why |
|---|---|
| `_shared/decision-tiers.md` | You can add things to T3 any time. Moving anything down needs your direct yes. Sending, posting, publishing, paying, buying, deleting and booking with other people always stay T3 |
| `_shared/standing-rules.md`, `system.md` | These keep your accounts safe. Add to them. Think twice before removing a line |
| `_shared/handoffs.md` | The other hires read these formats. Change one and the hire that reads it must change too |
| `chief-of-staff/scripts/check_gates.py` | The checks catch missing approvals and skipped reviews. Keep C3, C7 and C8 |
| `_shared/plate-rules.md`, `scripts/rank_plate.py` | How your plate is sorted and counted. Keep "you pick every pair, or review every automatic pick before it is used" and "most wins ranks first", or the ranking stops being yours |
| `_shared/review-rubric.md` | What the reviewer checks. Add lines freely. Removing one lets more mistakes reach you |

## Do not edit by hand

`_shared/decision-log.md` is append only. To fix a row, ask your Chief of Staff to add a "corrects L#" row.
