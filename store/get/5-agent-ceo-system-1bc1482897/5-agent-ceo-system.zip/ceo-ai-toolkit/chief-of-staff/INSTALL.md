# Install

Pick one path. Basic needs no terminal. Expert adds a daily rhythm.

## Basic (no terminal)

1. Download and unzip the toolkit. Put the `ceo-ai-toolkit` folder anywhere you like, for example your Documents folder.
2. Load the `ceo-ai-toolkit` folder into your favorite AI agent platform (open the agent in that folder).
3. Say: **"Start my Chief of Staff."**
4. Answer the questions one at a time. Say "skip" to use the default. It saves each answer as you go.
5. When it says setup is done, say **"Morning"** for your first brief.

If your agent only has a box for a system prompt or custom instructions and cannot open folders, paste `chief-of-staff/INJECT-PROMPT.md` into that box instead. You get the Chief of Staff without the files, so it cannot keep a board between chats.

## Expert (adds a daily rhythm)

Do Basic first, then:

1. **Connect email and calendar** in your AI agent's settings (its connectors or plugins). The Email Manager and Time Manager use them. The Chief of Staff never touches them itself.
2. **Run the brief and wrap on a schedule**, if your agent supports scheduled tasks. Make two tasks that open the `ceo-ai-toolkit` folder:
   - At your morning brief time: "Morning."
   - At your night wrap time: "Wrap up my day."
   Your agent follows the safe change rules below before it creates them.
3. **Turn on the scripts**, if your agent can run commands. From the `ceo-ai-toolkit` folder, run `python3 chief-of-staff/scripts/check_gates.py`. Before setup is done, it fails its first check (C1). That is expected.

## Safe change rules

The AI follows these for any change outside the `ceo-ai-toolkit` folder (scheduled tasks, your agent's settings or rules file, connecting a calendar), and for any change to the Chief of Staff's rules files (`system.md`, `decision-tiers.md`, `standing-rules.md`).

1. If it cannot read and write files here, it says so and gives you manual steps instead.
2. Before changing anything, it tells you the time and lists every file and outside item it will create or change. It waits for your yes.
3. It copies each existing file it will change into `.ceo-toolkit/snapshots/chief-of-staff-<YYYYMMDD-HHMMSS>/`, keeping its path, and adds a row to `.ceo-toolkit/install-log.md`: time, action, snapshot, files changed, files created, notes. It creates the log with a header row if it is missing.
4. It never overwrites your agent's own rules file. It adds a block between `<!-- ceo-toolkit:chief-of-staff:start -->` and `<!-- ceo-toolkit:chief-of-staff:end -->` instead.
5. It never deletes your data, and never deletes anything in `.ceo-toolkit/`.

`.ceo-toolkit/` lives in the `ceo-ai-toolkit` folder. It is your record of every change.
