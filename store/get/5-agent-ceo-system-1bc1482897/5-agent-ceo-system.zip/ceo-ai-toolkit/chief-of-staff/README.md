# Chief of Staff

Your AI Chief of Staff runs your other four hires and brings you only the decisions that need you.

You are the CEO. Your Chief of Staff keeps one board of every idea you drop, decides the small things, asks you about the big ones, and hands the work to the right manager. You start each morning with one brief and end each night with one wrap.

## What it does for you

| When | What you get |
|---|---|
| Morning | One brief: your Top 3, today's calendar, who is waiting on you, and only the decisions that need you |
| During the day | Drop any idea or ask. It lands on your board with a yes, later or no, and goes to the right manager. Once you have ranked your plate, a new idea first gets up to 3 quick picks against your top 3, and goes out when it is in your top 3 |
| Night | One wrap: your score from the CEO Scoreboard, what got done, and tomorrow's list |
| When your plate is full | Say "Prioritize my plate". It asks what is on your plate. Then you pick between two items at a time, or your Chief of Staff ranks them for you to review, with a reason for each pick. You get one page with your Top 3 this week, what has a date, what to hand off and what to drop. Once a week it offers a quick re-rank |

## Who it works with

| Hire | What the Chief of Staff gets from it |
|---|---|
| Email Manager | Who is waiting on you and the one important email |
| Time Manager | Today's calendar and open time |
| Focus Manager | Your Top 3 and one result for each work block |
| CEO Scoreboard | Your score and tomorrow's list |

Each hire is optional. If one is not installed, your Chief of Staff tells you what it could not see and keeps going.

## Install in 3 steps

1. Put the `ceo-ai-toolkit` folder anywhere on your computer.
2. Load the `ceo-ai-toolkit` folder into your favorite AI agent platform (open the agent in that folder).
3. Say: **"Start my Chief of Staff."** It asks you 18 short questions, one at a time, and saves your answers. It never asks them again unless you say "redo setup".

Full steps: `INSTALL.md`. What you need first: `REQUIREMENTS.md`.

## What to say

See `wake-phrases.md`. The three you will use most:
- "Morning" for your brief.
- "Idea: ..." to drop anything on your board.
- "Wrap up my day" for your night wrap.

## How it earns your trust

Every piece of work gets a light. Green: small and reversible, it does it. Yellow: an AI reviewer checks it before it reaches you. Red: anything with money, other people, or no undo waits for your yes. You get fewer outputs, and each one is checked before you see it.

## What it will never do

It never sends, posts, publishes, pays, buys, deletes, or books time with another person without your yes. Your plans and decisions stay in this folder on your computer.

## More

- How it works inside: `docs/how-it-works.md`
- What you can change: `CUSTOMIZE.md`
- What it cannot do yet: `known-limitations.md`
- Help: `SUPPORT.md`
- Remove it: `UNINSTALL.md`

Version 0.6.16, 2026-11-21. Changes: `CHANGELOG.md`.
