# What you need

## Required
- **An AI agent that can read and write files in a folder on your computer.** A chat window that cannot open files is not enough. The setup guide in the toolkit lists the agents we have tested.
- **This folder on your computer.** Your plans, decisions and scores live here and nowhere else.

## Needed for the full team
- **Email your AI agent can reach** (through a connector or plugin), for the Email Manager.
- **A calendar is optional.** Without one, the Time Manager keeps your two-week plan in a file and you copy the blocks into your calendar yourself.

## Optional
- **Python 3**, if your agent can run commands. Two small scripts use it. Without it, your agent does the same steps by hand.

## You do not need
- To write code.
- A subscription. You pay once and keep every file.
- Any other app.

## Tested with

| Agent | Model | Date | Result |
|---|---|---|---|
| Not yet tested | | | First draft. Walk tests are listed in `tests/acceptance-criteria.md` |

Model updates can change how an agent behaves. Before you switch to a new model, run the test cases in `tests/test-cases.md` and compare.

## Before you buy, check
1. Can your AI agent open a folder and edit a file in it?
2. Can it read your email (for the Email Manager)?
3. Are you OK with your AI drafting replies that you approve before anything is sent?
