# Help and updates

## Get help
1. Check `known-limitations.md` and `TROUBLESHOOTING.md` in the toolkit folder first.
2. Ask your Chief of Staff: "Something is wrong with [what]. Check your files." It reads its own rules and logs and tells you what it finds.
3. Still stuck? Use the contact form at https://gh.onetimeautomation.ai/support/. Give your name, your email, what you said, what it did, and which AI agent you use. We reply by email.

## What updates you get
- **Fixes to this version are free.** If the Chief of Staff does not do what this folder says it does, we fix it and you get the new files.
- **New features are not promised.** If we add new hires or bigger features, they may be a separate product.
- **We do not control your AI agent or your email or calendar provider.** If one of them changes how it works, we will try to adapt, but we cannot promise a fix by a date.

## How to update
Download the new version. Copy `handoffs/` and, in every hire folder, its `_shared/`, `runs/`, `board/`, `calendar/`, `capture/`, `ledger/`, `config.json` and `paste-here/` into it (copy only the ones that exist). Your setup and history carry over. Check `CHANGELOG.md` for what changed.
