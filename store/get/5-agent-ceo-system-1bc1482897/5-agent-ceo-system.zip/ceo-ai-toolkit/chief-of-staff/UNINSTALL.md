# Remove the Chief of Staff

## The simple way
Delete the `chief-of-staff` folder. Nothing else on your computer depends on it. Your other hires keep working, but nobody writes the morning brief or keeps the board. If you did the Expert install or let it change anything outside the folder, use the next section instead.

Keep a copy of `board/`, `runs/` and `_shared/decision-log.md` first if you want your history.

## If your AI made changes outside the folder
Say: **"Uninstall the Chief of Staff."** Your AI then:

1. Copies your data (`board/`, `runs/`, `_shared/`) and anything it will remove into `.ceo-toolkit/removed/chief-of-staff-<YYYYMMDD-HHMMSS>/`.
2. Restores each file it changed from its snapshot in `.ceo-toolkit/snapshots/`.
3. In shared files, removes only the block between `<!-- ceo-toolkit:chief-of-staff:start -->` and `<!-- ceo-toolkit:chief-of-staff:end -->`. Other hires' blocks stay.
4. Lists anything outside the folder it created (scheduled tasks, calendar events) and asks you before removing each one.
5. Adds a row to `.ceo-toolkit/install-log.md` and tells you what was restored, removed and kept.

Say **"Show what uninstalling would change"** to see the list without changing anything.

## What stays on your computer
Everything in `.ceo-toolkit/` stays. It is your record. Your toolkit files are never sent to us, so there is nothing to delete anywhere else.
