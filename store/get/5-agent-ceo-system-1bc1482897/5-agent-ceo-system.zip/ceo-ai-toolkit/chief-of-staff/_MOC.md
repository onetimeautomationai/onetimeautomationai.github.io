# Chief of Staff: map

Paths start from the `ceo-ai-toolkit` folder.

| Path in `chief-of-staff/` | One line |
|---|---|
| `CLAUDE.md` | Start file for the AI: first-run check, routes, rules that never bend |
| `CONTEXT.md` | The three loops: owner requests, the daily rhythm, ranking the plate |
| `system.md` | The AI's full operating rules |
| `worker.md` | Rules every manager or helper reads first |
| `README.md` | The owner's one-page guide |
| `REQUIREMENTS.md` | What you need, tested-with record |
| `INSTALL.md` | Basic and Expert install, safe change rules |
| `UNINSTALL.md` | Safe removal and rollback |
| `CUSTOMIZE.md` | What you can change and where |
| `permissions.md` | What it can read and write |
| `known-limitations.md` | What it cannot do yet |
| `SUPPORT.md` | Help and the update promise |
| `LICENSE.md` | Use and resale terms |
| `CHANGELOG.md`, `manifest.json` | Version, file list, checksums |
| `wake-phrases.md` | What to say |
| `INJECT-PROMPT.md` | One-paste version for agents without folders |
| `00_onboarding/`, `setup/` | First-run setup, and the plate questions |
| `_shared/` | Stable files every stage reads |
| `stages/` | 01 intake, 02 decide, 03 dispatch, 04 morning brief, 05 night wrap, 06 log, 07 plate, 08 rank, 09 organize, 10 re-rank |
| `board/` | Live state: the board and the plate |
| `_templates/` | Run starters and output templates |
| `runs/` | Run history |
| `scripts/` | `new_run.py`, `check_gates.py`, `rank_plate.py` |
| `docs/` | How it works |
| `examples/` | A sample day and a sample plate ranking, with made-up data |
| `tests/` | Test cases, acceptance criteria, judge rubric |
