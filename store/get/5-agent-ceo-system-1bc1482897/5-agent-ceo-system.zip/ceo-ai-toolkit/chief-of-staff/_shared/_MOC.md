# _shared: map

| File | One line |
|---|---|
| `owner-profile.md` | Who the owner is, goals, tools, hours, limits. Filled by setup |
| `decision-tiers.md` | The trust lights (green, yellow, red), the safety floor, how green is earned |
| `review-rubric.md` | How yellow work is checked before it lands, and who reviews |
| `voice-profile.md` | How the owner writes, learned at setup from real samples |
| `standing-rules.md` | SR1 to SR14, read by every stage |
| `plate-rules.md` | PL1 to PL16, how the plate is sorted and ranked, and where each item goes |
| `roster.md` | Who does what, and fallbacks when a hire is missing |
| `handoffs.md` | File formats the hires pass to each other |
| `adapters.md` | Which tool does which job |
| `lessons.md` | Owner corrections, read every run |
| `decision-log.md` | Append-only record of every decision |
