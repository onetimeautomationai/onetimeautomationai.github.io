---
type: factory
---

# Adapters

The Chief of Staff names the job, not the vendor. Onboarding fills in which tool the owner uses.

| Job | The owner's tool | Who uses it | Options that work |
|---|---|---|---|
| Read email, write drafts | {{email_tool}} | Email Manager only | Any email your AI agent can reach through a connector or plugin |
| Calendar | {{calendar_tool_or_plain_file}} | Time Manager only | A connected calendar, or a plain file of time blocks (no connection needed) |
| Notes and tasks | {{notes_and_tasks_tools}} | Chief of Staff, Focus Manager | The files in this toolkit (default), or a notes app your agent can reach |
| Run small scripts | Python 3, if your agent can run it | Chief of Staff | Optional. Every script check can also be done by hand (`chief-of-staff/scripts/README.md`) |

The Chief of Staff itself only reads and writes files inside the toolkit folder. Paths start from the `ceo-ai-toolkit` folder.
