---
type: log
rule: append only. Never edit or delete a row.
---

# Decision log

Every decision the Chief of Staff makes or records goes here before it is reported. Rows are numbered L1, L2, L3. (Board numbers like D1 are the decisions waiting on the owner. L numbers are log rows. They are different.)

- **Time:** `YYYY-MM-DD HH:MM` in the owner's time zone, from the real clock (SR2). Rows are in time order. Check C4 fails a Time with no date and clock time.
- **Tier:** T1, T2 or T3 (`decision-tiers.md`). Anything that sends, posts, publishes, pays, buys, deletes or books with another person is T3.
- **Owner's words:** required for a T3 row whose Result is `done`, copied exactly. Leave it empty while you wait, and set Result to `pending`.
- **Result:** one of `done`, `pending`, `parked`, `no`. `pending` is only for a T3 row waiting for the owner's words. A job handed out and not yet run is logged T1 when handed out, and its T2 row comes when the work passes review (`chief-of-staff/stages/03_dispatch/CONTEXT.md` step 8). A row held for protected time is `done` ("IN4: held for protected time, back Wednesday 8:00 AM"), never `parked`.
- **Decision:** start with `A#: Owner task:` when the owner will do it themselves (the A list), for example "A2: Owner task: call the accountant". Every row added to the board's "Your list" gets this row the same turn, with its A number (check C12 fails an open "Your list" row with none). Other item codes may come first too ("IN3, A2: Owner task: ..."), nothing else. The check C7 then knows the team is not sending or booking anything. The Evidence of an `Owner task:` row never says the AI or a manager did it ("the Time Manager sent it" fails C7). Naming a reply is not sending it: "put the reply to Tom first" is not a send, "Send the reply to Tom" is. Check C7 flags only a Decision that says the team did or does the outward action ("Sent the email to Tom", "Send Priya the offer", "the Email Manager posted it", "website footer updated"). Naming, planning, drafting, asking, reordering, quoting or negating it is not flagged ("P12: draft held, nothing recorded or published", "P8 website pricing page: parked"), so write what really happened.
- **Evidence:** for a T2 (yellow) row marked done, write exactly `review: pass (separate)` when a separate reviewer passed it, or `review: pass (self)` when you reviewed it yourself (`review-rubric.md`, "Who reviews"), then a comma and the path of the saved review file from the `chief-of-staff` folder, for example `review: pass (separate), runs/2026-11-24-plate/09_review.md`. Check C8 fails a bare `review: pass`, a review file that does not exist, and one whose last line is not `Verdict: pass`. The same two words as the Time Manager and the Email Manager use.
- **To fix a row:** add a new row whose Decision starts with `corrects L#` (for example "corrects L4: owner said yes"), where L# is a row above it, never the new row's own number. The check script then reads the new row instead of the old one. A `corrects` row fixes the record, never the world: when the row it corrects says the team already sent, paid or posted something without the owner's yes, the correcting row says so in its Decision ("corrects L4: the email went to Tom without your yes"), and the owner is told in the same turn.

`chief-of-staff/scripts/check_gates.py` enforces all of this.

| L# | Time | Decision | Tier | Why | Evidence | Owner's words | Result |
|---|---|---|---|---|---|---|---|
