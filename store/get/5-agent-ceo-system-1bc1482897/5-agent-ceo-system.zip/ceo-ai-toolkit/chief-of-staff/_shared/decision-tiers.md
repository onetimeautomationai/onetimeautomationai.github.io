---
type: factory
---

# Decision tiers (the trust lights)

Every piece of work gets a light by how far a mistake could reach. Like a top kitchen: nothing important leaves without being checked at the pass.

| Light | Tier | What it covers | What happens |
|---|---|---|---|
| Green | T1 | Internal, reversible, small. Filing a note, ranking a list, re-running a check, handing out a job. Also the owner's own tasks ("call my accountant", "reply to Tom myself"), which go on the board's "Your list" with an A number. Log them with a Decision that starts `A#: Owner task:` (its A number first), so the checks know the owner does it, not the team. Every red item below (a payment, a purchase, a hire, a send, a post, publishing, a website change, a booking with another person, a deletion) stays red even when the owner decides it or says they will do it themselves: the decision is a T3 row, with the owner's words when they already said yes (Result `done`), or a "Waiting on you" D row and a `pending` T3 row when they have not. "Fix the website footer" in a brain dump is a T3 D row, never a T1 task. Two rows, never one: once the owner does the red step themselves ("renew it from your own account", "I'll update the footer"), that doing is a Your list row logged T1 as `A#: Owner task:`, next to the T3 decision row | Done and logged. Must pass the hard checks |
| Yellow | T2 | Reversible, internal, but it changes the owner's day or is shown to the owner as finished. Moving a calendar block that holds no other person, reordering the Top 3, a finished draft, a plan | **AI review first.** A reviewer checks it against the job and `review-rubric.md` before it lands. Pass: done, logged, owner told. Fail: sent back once. Fails twice: becomes red |
| Red | T3 | Anything that reaches another person or the public (send, post, publish, change a website, book a meeting with someone), money of any size (pay, buy, invoice, refund, hire, sign a contract), deleting, anything you cannot undo, a new recurring commitment, a change to the goals or to these rules | **The owner steps in.** Recommend with the reason, then wait for the owner's words |

When unsure, use the next light up.

## The floor (cannot be changed by setup or lessons)

Sending, posting, publishing, paying, buying, deleting, and booking with other people are always red. The owner can add more items to red. Moving anything down from red needs the owner's direct yes, logged as a red decision, and never applies to the items in this paragraph.

## Green grows only when it is earned

Work starts at the light above. A kind of yellow work can move to green only after 10 reviews in a row pass with no fix needed, and only with the owner's yes, logged as red. Any later miss moves it back to yellow.

## How an idea gets ranked

Ask one question: does it move goal 1 this month? The sort test in `chief-of-staff/_shared/plate-rules.md` PL3 says what counts, line by line.
- **Yes:** now. It goes to the job queue. When the owner has a ranked plate, it first takes the light path, and its job goes out once it is in the top 3 (`chief-of-staff/_shared/plate-rules.md` PL17).
- **It helps goal 1 later, or needs something done first:** later. Name what it waits on.
- **Neither:** no. Log the reason so the idea is never lost.

The owner can overrule any ranking. Their words go in the decision log.

When the owner ranks their whole plate (`chief-of-staff/stages/07_plate/CONTEXT.md`), the same question sorts every item, with one more answer: **must**, for an item with a hard date in the next 14 days and a real cost if it slips, even if it does not move goal 1. Then the "now" items are put in order two at a time: the owner picks each pair, or the Chief of Staff picks them for the owner to review, as the owner chose (`chief-of-staff/_shared/plate-rules.md` PL18). The owner's own picks are green. The Chief of Staff's picks are yellow: reviewed before the owner sees them.
