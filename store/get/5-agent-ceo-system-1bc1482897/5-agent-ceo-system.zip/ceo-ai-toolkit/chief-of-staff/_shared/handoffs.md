---
type: factory
---

# Handoff formats

The hires pass work through plain files in `handoffs/` (in the toolkit folder). Each hire overwrites only its own files. Nobody edits another hire's file.

Every report starts with this header:

```
---
from: <hire folder name>
updated: YYYY-MM-DD HH:MM (owner's time zone)
status: ok | partial | failed
---
```

**Extra sections.** After the sections shown below, a report may add its own sections (for example `## Notes`, `## Warnings`, `## Waiting on your yes`, `## Schedule items handled`, `## Missing`). Readers use the sections they know and may ignore the rest. A line starting `missing:` means the hire needed an answer it could not get. The Chief of Staff asks the owner once, then re-runs the job with one line `Owner answers: <the owner's exact words>` in the job row (the one format for owner answers, the same line the Email Manager reads). A line starting `needs owner:` means the hire found something only the owner can settle. The Chief of Staff puts it on the board's "Waiting on you" with the next D number and the hire's recommendation. Exception: `top3-today.md` has no extra sections.

**Fresh** means `updated` is today. Two exceptions: `scoreboard-report.md` is written at night, so it is fresh if dated today or yesterday. `priorities.md` is the owner's own ranking, so readers use it whenever it exists. Its age is its `ranked_on` date, and the Chief of Staff offers a re-rank once that is 7 or more days old. A file that is not fresh is treated as missing, and the reader says so.

## email-manager-report.md (Email Manager writes. Chief of Staff reads. Focus Manager reads "The important one" only)

```
## The important one
- From, subject, why it matters, draft: <file in handoffs/drafts/ or "none">

## Waiting on you
| Person | Subject | Waiting since | Draft |

## Counts
- New today: N. Sorted: N. Needs you: N.
```

"Waiting since" is `YYYY-MM-DD HH:MM` (owner's time zone, 24 hour clock). The Email Manager's copy (`email-manager/_shared/handoffs.md`) has the rest of its rules for this report.

## drafts/ (Email Manager writes, or the Chief of Staff if no Email Manager)

One file per draft. Format in `handoffs/drafts/README.md`. Nothing is sent without the owner's yes.

## schedule-items.md (Email Manager writes, Time Manager reads)

The Email Manager owns the Status column. At its next run it sets `placed` or `skipped` from the Time Manager's `## Schedule items handled` section, when the report is dated today or yesterday. It matches a line there to a row by Found in email plus What, because the Time Manager may write the date its own way. The Time Manager never edits this file.

```
---
from: email-manager
updated: YYYY-MM-DD HH:MM (owner's time zone)
status: ok
---

| Found in email | What | Date and time | Who | Status: new / placed / skipped |
```

Date and time is always `Day YYYY-MM-DD, time zone`, resolved against the email's date, for example `Friday 2026-11-20, 10 AM Pacific`, or `Wednesday 2026-11-18 or Thursday 2026-11-19, afternoon` for a range. A missing part is written "time not given" or "not given".

## time-manager-report.md (Time Manager writes, or the Chief of Staff if no Time Manager. Chief of Staff, Focus Manager and Email Manager read)

```
## Today
| Start | End | Block | Fixed or movable |

## Open time today
- Total hours open, and when
```

The Time Manager also adds `## Schedule items handled` on every run. It lists every schedule item handled today, from every run today, not only the latest run. Open time never includes time before the real clock.

## top3-today.md (Focus Manager writes, or the Chief of Staff if no Focus Manager. Chief of Staff, Time Manager and CEO Scoreboard read)

```
## Top 3 for YYYY-MM-DD
1. <item> : result that counts as done
2. <item> : result
3. <item> : result

## One result per block
| Block | Result that counts as done |
```

## priorities.md (Chief of Staff writes. Focus Manager reads it to set the daily Top 3. Time Manager reads it through its jobs)

The owner's ranked plate for the week (`chief-of-staff/stages/09_organize/CONTEXT.md`): their own picks, or the Chief of Staff's picks after the owner reviewed them and said the ranking looks right (`chief-of-staff/_shared/plate-rules.md` PL18). Between full rankings, in auto mode, the Chief of Staff also places new items itself (light path, reviewed by the AI reviewer), and the owner sees each placement and can flip it, at once or at the next brief. Readers treat all of these the same way. Two extra header lines: `ranked_on: YYYY-MM-DD` (the day of the last full ranking. A light-path change updates `updated` and never `ranked_on`) and `criterion: "<the question every pair was judged on>"`. Ranks run 1, 2, 3 with no gaps and never repeat. Status is the last column of every table. Readers skip rows whose Status is `done` or starts with `waiting`. Readers take open "Ranked" rows by rank, then open "New since the ranking" rows as listed. A "New since the ranking" row is `open` once the light path placed it below the top 3, or `waiting: your picks` while it waits for the owner's pairs (`chief-of-staff/_shared/plate-rules.md` PL17). In auto mode the Chief of Staff places a new item itself, so a row waits only while the owner answers a pair with facts missing, or after the reviewer failed its picks twice. No other sections.

```
## Ranked
| Rank | P# | Item | Who does it | Due | Size | Result this week | Status: open / done / waiting: reason |

## Must do by date
| P# | Item | Who does it | Due | Status |

## New since the ranking
| P# | Item | Placed | Status |
```

## scoreboard-report.md (CEO Scoreboard writes, Chief of Staff and Focus Manager read. Tomorrow's list is the Focus Manager's draft Top 3)

```
## Score for YYYY-MM-DD
- Top 3 done: N of 3
- Score: N out of 10, and one line why
- One fix for tomorrow
- Agents: N jobs done, M flagged
- Unreadable log lines: N   (only when the Scoreboard counted any, right under the Agents line)

## Tomorrow's list
1. ...

## Agent flags
- <code> <fail or fix>: <agent>, <job>. <what is wrong>. Fix: <the fix and who does it>
- none   (when nothing is flagged)
```

The Agents line and `## Agent flags` come from the Scoreboard's agent work check (`python3 ceo-scoreboard/scripts/scoreboard_calc.py agents --date YYYY-MM-DD --until "YYYY-MM-DD HH:MM"`, `ceo-scoreboard/_shared/scoring-guide.md` section 10). The Scoreboard writes the line every night, `0 jobs done, 0 flagged` when nothing was logged. The Chief of Staff copies both into the night wrap and puts each flag on the Job queue once (`chief-of-staff/stages/05_night-wrap/CONTEXT.md` step 3, `chief-of-staff/stages/06_log/CONTEXT.md` step 6).

## logs/activity.md (every hire adds a line when it finishes a job. The CEO Scoreboard checks it at night and never edits it)

```
| When | Agent | Job | Result | Proof |
| YYYY-MM-DD HH:MM | chief-of-staff | <what the job was> | <what came out> | <path from the toolkit folder> contains "<exact words from that file>" |
```

Five cells, When in the owner's time zone, Agent one of `chief-of-staff`, `email-manager`, `time-manager`, `focus-manager`, `watch-to-ai`. Add lines at the bottom and never edit one. To fix a line, add a line whose Job starts `corrects AL#`. The proof file is never the log itself and never a draft for a send. The night wrap writes its own line before the Scoreboard job runs (`chief-of-staff/stages/05_night-wrap/CONTEXT.md` step 2a), so it counts that night.

## jobs.md (Chief of Staff writes the rows, each manager sets the status of its own rows)

```
| Job# | For | Job | Write result to | Due | Light: green / yellow / red | Status: open / done / waiting: reason |
```

The For cell is the hire's folder name, for example `time-manager`. A hire's routine run (sort email, block the Top 3, score the day) is never a Top 3 candidate. Owner answers go in the Job cell after the job, on one line `Owner answers: <the owner's exact words>`. A job that could not run stays `open` (`chief-of-staff/stages/03_dispatch/CONTEXT.md` step 8). Every row has 7 cells, as the header (check C12).
