---
type: factory
---

# Lessons

Every correction the owner gives becomes one line here, the same turn. Every hire reads this file before it starts. Newest at the bottom.

| Date | The owner said (exact words) | What we do from now on |
|---|---|---|
