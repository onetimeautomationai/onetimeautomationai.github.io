---
type: factory
setup_done: no
---

# Owner profile

Filled in by setup (`chief-of-staff/00_onboarding/CONTEXT.md`). Every hire in the toolkit reads this file. Change a line by telling your Chief of Staff, or say "redo setup" to start over. A skipped answer uses its default. A skipped required answer (no default) is written as "not given".

## Who you are
- Name the team should use: {{owner_name}}
- Use: {{business_personal_or_both}}
- Your business (or what to run, for personal use): {{business_detail}}
- Your role, and the work you still do yourself: {{owner_role}}
- Time zone: {{time_zone}}

## Your goals (in order)
- Goal 1, with a number and a date: {{goal_1}}
- Goal 2: {{goal_2}}
- Daily actions that move goal 1 most: {{leading_actions}}

## Your tools
- Email: {{email_tool}}
- Calendar: {{calendar_tool_or_plain_file}}
- Notes and tasks: {{notes_and_tasks_tools}}

## Your day
- Work days and hours: {{work_hours}}
- Protected time (no new questions): {{protected_hours}}
- Morning brief time: {{morning_brief_time}}
- Night wrap time: {{night_wrap_time}}

## How to write for you
- Report style (short or detailed, lists or sentences): {{report_style}}
- Tone, words to avoid, sign-off: {{writing_style}}
- Where your real writing lives (voice samples): {{writing_sources}}. Learned voice: `voice-profile.md`

## Limits
- Extra things that need your yes (sending, posting, publishing, paying, buying, deleting and booking with other people always do): {{extra_approval_list}}
- People, brands or topics to never mention or contact: {{never_list}}

## First-week job
- The one job you want from your team this week: {{first_week_job}}

## How your plate is ranked (asked once, at your first ranking)
- rank_mode: not asked yet
  (auto: your Chief of Staff picks each pair and you review the result. manual: you pick each pair yourself. Say "I'll pick" or "Rank it for me" to switch any time. `chief-of-staff/_shared/plate-rules.md` PL18)

## Installed hires (filled by the Chief of Staff, not asked)
- Email Manager: {{email_manager_installed}}
- Time Manager: {{time_manager_installed}}
- Focus Manager: {{focus_manager_installed}}
- CEO Scoreboard: {{ceo_scoreboard_installed}}
