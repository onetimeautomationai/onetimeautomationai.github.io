---
type: factory
---

# Review rubric (yellow work)

The reviewer sees: the job row, the output, the source files the job used (listed in the job row or the output, for example a handoff, the board, the decision log), `chief-of-staff/_shared/owner-profile.md`, `chief-of-staff/_shared/voice-profile.md`, `chief-of-staff/_shared/lessons.md`, and this rubric. It never sees the chat. It scores each line pass or fail.

**Priorities page** (`09_priorities.md`, stage 09 step 10). The sources also include `08_rank.md` with its tally, `chief-of-staff/_shared/roster.md`, `chief-of-staff/_shared/plate-rules.md`, `chief-of-staff/board/plate.md` and the date from the clock. For RR2 a win count from the tally, a hand-off target from the roster or the plate rules, and a re-rank day from `board/plate.md` or the plate rules count as found in a source. The table headed "What happens next, and who does it" has one row for every now item in the ranking and every must, and none for an item listed under "Not ranked yet" (PL4).

| # | Check | Fail when |
|---|---|---|
| RR1 | Does it do the job as written? | Missing part of the job, or did more than asked |
| RR2 | Are the facts true? | A fact contradicts the source files, or is not in them. A fact found in a source passes |
| RR3 | Does it follow the lessons, the owner profile and the voice profile? | Breaks a lesson, the report style, or the voice profile |
| RR4 | Is the light right for what happens next? | The output would send, post, pay, buy, delete or book without the owner's yes. A draft waiting for the owner's review is fine, unless it commits the owner to money terms (a price, a discount, a fee, a cut) that no source and no owner's words set: that fails RR4 as well as RR2, because sending it would be a money decision nobody made |
| RR5 | Is it ready for the owner to see? | Unclear, too long, the most important line not last, or a draft that needs more than a light touch |

**Automatic ranking** (`chief-of-staff/_shared/plate-rules.md` PL18 and PL22). For a ranking the Chief of Staff picked (`08_rank.md`, the light-path picks with their reasons, or a weekly kept order), the reviewer also gets PL22 and judges every pick against it, so two reviewers reach the same verdict. RR2 and RR4 also mean:
- Every Chief of Staff pick has a one-line reason, and every fact in it is in one of the two items' PL22 sources (the Items table, the item rows in `07_plate.md`, the item rows in `chief-of-staff/board/plate.md`, or, for a new item on the light path, the owner's words in its board Inbox row or memo). The reviewer gets those files. A fact found nowhere fails RR2. A fact from the owner profile, an email or a lesson fails RR2, even when true.
- The winner is the one the PL22 reading order gives: the first fact that differs, in the order Due, Who waits, If it slips, Why now, Size. A pick that skips an earlier fact that differs fails RR2. A reason that favors the loser fails RR2.
- A reason that names no deciding fact fails RR2. An open pair (PL22) picked with nobody here starts "facts equal:" (all five known and equal) or "facts missing:" (a fact missing), names the facts both share, and follows the tie rule: the item already ranked kept its place (light path, kept order) or the lower P# won (full ranking). A reason that leans on list position ("listed first", "listed after") fails RR2. With the owner here, an open pair was asked the manual way.
- A pair with a fact missing starts "facts missing:" and names which fact of which item. "facts missing:" with nothing named fails RR2, and so does "facts equal:" on a pair with a fact missing (missing is never equal). With the owner here, a pair the script marked `[facts missing: ..., no known fact decides]` was asked the manual way. A pair marked `[facts missing: ..., <fact> decides]` is the Chief of Staff's pick, decided by that fact (PL22), and is never a fail for not being asked. Every reason names both items by P#.
- In a light-path placement the owner reads, "Over" stands for a pair the new item won (N) and "Below" for one it lost (O), and the flip example names a pair up to the first O. Words that do not match the letters fail RR2.
- On the light path every pair has a letter and a reason, also the pairs after the first O (PL13). Those pairs are judged the same way. The place comes from the letters up to the first O.
- Every pick is judged on the ranking's question. Nothing in it sends, books with another person, pays or deletes (RR4).

**Pass:** all five pass. Write `review: pass (separate)` (a separate reviewer, "Who reviews" 1) or `review: pass (self)` (the fallback, "Who reviews" 2) in the decision log Evidence column, then a comma and the path of the saved review file, for example `review: pass (self), runs/2026-11-24-pricing/03_review.md` (check C8 reads both). **Keep the reviewer's list.** Save every reviewer verdict in the run folder as `NN_review.md`, named for the stage that asked for it (`08_review.md` for an automatic ranking, `09_review.md` for the priorities page, `10_review.md` for a light-path placement or a weekly kept order, `03_review.md` for a job): the failed lines and fixes from a first fail, and the final verdict. A pass on the first try is saved as "no failed items". The last line of the file is always `Verdict: pass` or `Verdict: fail` (check C8 reads it for every T2 row, check C9 for an automatic ranking and a kept order). Another stage's review uses the same pattern (`04_review.md` for a change to the brief's Top 3). The listed failed items stay with the pass, so the review can be audited later. **A review after the fact** (yellow work that landed unreviewed and a check caught it, for example C8 at the night wrap) is saved the same way, in the run folder of the work (work that had no run folder of its own, for example a Top 3 reorder in a morning run with no folder or a change made in chat, uses the run folder of the check that caught it, usually tonight's `runs/YYYY-MM-DD-night/`), with a first line "Reviewed after the fact on YYYY-MM-DD HH:MM", and the `corrects L#` row names it in Evidence.
**Fail:** list the failed lines and one fix each. The work goes back once. A second fail makes it red: the owner sees it with the reviewer's notes.

## Who reviews

1. **Best:** a separate helper agent with a fresh start, on a different AI model if the owner's agent allows. Its first line: "Read chief-of-staff/worker.md and chief-of-staff/_shared/review-rubric.md before anything else. You are the reviewer."
2. **Fallback:** if the agent cannot start helpers, the same agent does a separate review pass with this rubric, reading only the files listed at the top. This is weaker, because it checks its own work. `known-limitations.md` says so.
