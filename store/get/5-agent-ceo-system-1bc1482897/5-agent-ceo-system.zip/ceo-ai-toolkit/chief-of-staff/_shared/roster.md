---
type: factory
---

# Roster

Paths start from the `ceo-ai-toolkit` folder.

| Hire | Folder | Owns | Writes |
|---|---|---|---|
| Chief of Staff | `chief-of-staff/` | The board, decisions inside T1 and T2, the morning brief, the night wrap, the owner's ranked plate | `handoffs/jobs.md`, `handoffs/priorities.md` |
| Email Manager | `email-manager/` | Sorting the inbox, the one important email, who is waiting on a reply, reply drafts, dates found in email | `handoffs/email-manager-report.md`, `handoffs/schedule-items.md`, `handoffs/drafts/` |
| Time Manager | `time-manager/` | The two-week calendar, blocking time for what the owner decided | `handoffs/time-manager-report.md` |
| Focus Manager | `focus-manager/` | The Top 3 each morning, one result for each block, quick capture | `handoffs/top3-today.md` |
| CEO Scoreboard | `ceo-scoreboard/` | The nightly score and tomorrow's list | `handoffs/scoreboard-report.md` |
| Watch-to-AI Team Edition (bonus) | `bonus-watch-to-ai/` | Turns a memo spoken into the owner's Apple Watch into a job for the Chief of Staff, who routes it with the table below | `bonus-watch-to-ai/memos/` |

## Which manager gets which job

| Job | Manager |
|---|---|
| Anything about email: sort, find, draft a reply or a new email (owner sends it) | Email Manager |
| Anything that needs time on the calendar | Time Manager |
| Ranking the whole plate with the owner, two items at a time | The Chief of Staff itself (stages 07 to 10) |
| Today's Top 3 (from the ranked plate when there is one), capturing a stray thought | Focus Manager |
| Scoring the day, tomorrow's list | CEO Scoreboard |
| A job no manager owns | The Chief of Staff does it itself, under the same lights and review |

## When a manager is not installed

Check "Installed hires" in the owner profile.

| Missing | The Chief of Staff does instead |
|---|---|
| Email Manager | Says "no Email Manager, I can't see your inbox". A read-only ask ("what did Tom write?") gets one "Your list" row "Check your inbox for [what]", logged `A#: Owner task:`, and nothing else: no job, no D row, no second row (the one home for it, `chief-of-staff/stages/02_decide/CONTEXT.md` step 4). If the owner asks for a reply, it writes the draft itself in `handoffs/drafts/` and shows it. It never sends |
| Time Manager | Asks the owner for today's fixed times once and writes `handoffs/time-manager-report.md` itself with `from: chief-of-staff`. Puts "block time for X" on the owner's action list ("Your list", logged `A#: Owner task:`) |
| Focus Manager | Asks the owner for their Top 3, offering the top open items in `handoffs/priorities.md` as the default when it exists, otherwise the "now" jobs. Writes `handoffs/top3-today.md` itself with `from: chief-of-staff` |
| CEO Scoreboard | Scores the day itself in the night wrap (stage 05 step 3) |
