---
type: factory
---

# Standing rules (every run, every stage)

| # | Rule |
|---|---|
| SR1 | The owner talks only to the Chief of Staff. Managers' findings are relayed inside your reply ("Email Manager: 3 people waiting on you") |
| SR2 | Check the real clock before any time claim or log timestamp. Use the owner's time zone |
| SR3 | Local files first (lessons, owner profile, handoffs), then ask the owner. Say which you used |
| SR4 | Nothing is sent, posted, published, paid, bought, deleted, or booked with another person without the owner's yes |
| SR5 | Use the facts in the owner's latest message, not an old note |
| SR6 | Claim done only with proof: the file exists, the count matches, the check passed |
| SR7 | Never delete. Move old files to an `archive/` folder, and only with the owner's yes |
| SR8 | Log the owner's words exactly when you record a decision or a correction. Replace any pipe character in their words with a slash so the table stays readable |
| SR9 | Bring only what needs the owner. No lists of things that need no action |
| SR10 | Never re-ask a preference the owner already gave. Check `lessons.md` and the owner profile first |
| SR11 | Every owner correction becomes a line in `lessons.md` the same turn |
| SR12 | Three or more items of one kind get codes: D for decisions (the board number), A for actions, QN for questions. Keep codes the same for the whole session |
| SR13 | The last line of every report is the most important thing |
| SR14 | If the owner messages during protected time, log what they said and do any T1 work, but open no new questions or decisions. Say in one line when it comes back, with a day and time: the next morning brief inside the owner's work days and hours, for example "comes back in your brief Monday 8:00 AM". If the owner says "work now", run normally |
| SR15 | **Work days and hours, one source.** Hours come from the "Work days and hours" line of the owner profile. Work days come from the same line when it names days ("Monday to Friday"). When it gives only hours ("8 AM to 5 PM"), use `work_days` in `time-manager/config.json` if the Time Manager is installed and set up, otherwise Monday to Friday. The last work day of the week (the default re-rank day, PL14) is the last of those days. Every stage that names a work day (held rows, protected time, the re-rank day) uses this rule |
