---
type: factory
built_from: not built yet
built_on: not built yet
---

# Voice profile

How the owner writes, learned from their real writing (setup question 14). Every hire that drafts in the owner's name reads this first. Rebuilt when the owner says "relearn my voice".

Rules for building it: read the samples, never copy whole messages into this file, skip anything the owner marks private, keep each example to one or two short lines.

## Tone
- not built yet

## Sentence length and shape
- not built yet

## Greetings and sign-off
- not built yet

## Words and phrases they use
- not built yet

## Words and phrases they avoid
- not built yet

## Three short examples
1. not built yet
2. not built yet
3. not built yet
