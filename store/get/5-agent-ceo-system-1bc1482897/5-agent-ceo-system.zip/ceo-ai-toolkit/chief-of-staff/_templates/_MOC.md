# _templates: map

| Path | One line |
|---|---|
| `run/01_intake.md` | Copied into each new request run by `new_run.py` |
| `outputs/02_decide.md` | Decide stage output |
| `outputs/03_dispatch.md` | Dispatch stage output |
| `outputs/06_log.md` | Log stage output |
| `outputs/brief.md` | Morning brief |
| `outputs/wrap.md` | Night wrap |
| `plate/07_plate.md`, `plate/08_rank.md` | Copied into each plate run by `new_run.py plate` |
| `outputs/09_priorities.md` | The owner's priorities page (stage 09) |
