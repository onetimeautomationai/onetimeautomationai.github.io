# Decide

| IN# | Item | Ranking: now / later / no | Tier | Reason or what it waits on | Board D# (T3 only) | Log L# |
|---|---|---|---|---|---|---|

## Owner's words (exact, if they answered)

