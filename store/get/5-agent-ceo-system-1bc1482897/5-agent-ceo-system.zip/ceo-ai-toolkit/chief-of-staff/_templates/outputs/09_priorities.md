# Your priorities, week of YYYY-MM-DD

Goal 1: <goal 1, in your words>. Every pair was judged on this question: "<the question>"

## Top 3 this week
1. P#: <item>. Done when: <result that counts as done this week>. Who: <you, or the manager>.
2. P#: <item>. Done when: <result>. Who: <...>.
3. P#: <item>. Done when: <result>. Who: <...>.

## The full order
Picked by: <one of the three forms in stage 09 step 3: you, two at a time / your Chief of Staff, reviewed by you on YYYY-MM-DD, K pairs flipped by you / you and your Chief of Staff (N pairs by you, M by your Chief of Staff), reviewed by you on YYYY-MM-DD, K pairs flipped by you. Write "1 pair", "2 pairs", "0 pairs">.

| Rank | P# | Item | Wins | Who does it | Due |
|---|---|---|---|---|---|

<If any: Not ranked yet (over the cap of 10): P#, item. It is considered again at the next full re-rank (PL4).>

## Personal (only when you use your team for business and personal life)
| Rank | P# | Item | Due |
|---|---|---|---|

## Must do by date (the date sets the order)
| P# | Item | Due | If it slips | Who does it |
|---|---|---|---|---|

## What happens next, and who does it
| P# | Item | To | Light | What happens next |
|---|---|---|---|---|

## Later (with what each waits on)
| P# | Item | Waits on |
|---|---|---|

## Drop or park (with the reason)
| P# | Item | Reason | Someone to tell? |
|---|---|---|---|

## What waits on what
- P# waits on <P#, a person, or an answer>.

## Decisions only you can make
- D#: <question>. I recommend <answer>, because <your own words from the plate or profile: what happens if it slips, or who waits>. <With no reason in your words, end the line "I recommend <answer> (no reason given)." and leave out "because".>

## Ties and loops in the picks
- <none, or the tie and how it was settled>

Next re-rank: <weekday, Mon DD, for example Friday, Dec 4, the first re-rank day at least 5 days after the ranking>, at your night wrap. A new item in between is compared only with your top 3 (by you, or by your Chief of Staff for your review, as you chose).

<The #1 item to start first, with its due date. Name only what the page already gives.>
