# Morning brief, YYYY-MM-DD

**Top 3 today**
1. <item>. Done when: <result that counts as done>
2. <item>. Done when: <result>
3. <item>. Done when: <result>

**Calendar:** <fixed times>. Open: <hours>. <Blocked for Must P#: item, day and time, one line per must block placed since the last brief.>

**Managers:** <only when a manager failed or did not run: "[manager] ran at HH:MM and failed: <reason>. Its job stays open." or "[manager] not run today">. Leave out when every manager ran.

**Waiting on you:** <the important one>. Also <people waiting on a reply>.

**Decisions only you can make**
- D#: <question>. I recommend <answer>, because <how it moves goal 1>.

**Done since your last brief:** <finished memo jobs and jobs you asked for, one line each: what, and where the result is>. Leave out when there is none.

**Held until <day> <time>:** <rows, questions and offers held for protected time or a day off, and when they come back (stage 04 steps 1a and 1c)>. Leave out when there is none.

**Your list:** A#: <task only you can do>.

**Yesterday:** <score> out of 10. Fix: <one fix>.

<The one thing to do first: Top 3 item 1, or "Answer D#, then [Top 3 item 1]".>
