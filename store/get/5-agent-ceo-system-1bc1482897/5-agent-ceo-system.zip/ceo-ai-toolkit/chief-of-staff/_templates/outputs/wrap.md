# Night wrap, YYYY-MM-DD

**Score:** <N> out of 10. Top 3 done: <N> of 3. <One line why.>

**Done today:** <short list>

**Carried to tomorrow:** <short list, each item with its reason in a few words>

**Blocked for musts:** <P#, item, due date. Leave this line out when none>

**Gate caught:** <C# on L#, fixed with L#. Leave this line out when the checks passed the first time>

**Agents:** <N jobs done, M flagged. Then each flag with its fix, or none. When the Scoreboard could not run: "Scoreboard: could not run, <reason>. Scored by your Chief of Staff">
**Focus Manager day close:** <ran, with the path of its 05_close.md, or could not run and why. Leave this line out when no Focus Manager is installed>

**Decisions still waiting on you:** <D numbers, or none>

**Question for you:** <the Focus Manager's QN line from its close, or another QN line the wrap must bring. In protected time: "I'll ask this in your brief <day> <time>: <the question>". Leave this line out when none>

Tomorrow, first thing: <one thing>. <How it moves goal 1, in your own words from the plate or profile. Leave this out when your words give none.>
