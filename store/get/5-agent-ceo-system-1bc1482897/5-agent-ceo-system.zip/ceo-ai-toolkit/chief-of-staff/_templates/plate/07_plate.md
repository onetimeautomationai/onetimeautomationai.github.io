---
run: {{run_name}}
started: {{YYYY-MM-DD HH:MM}}
kind: full ranking / weekly re-rank
---

# Plate inventory

Questions: `chief-of-staff/setup/plate-questions.md`. P numbers are permanent: take the next free one from `chief-of-staff/board/plate.md`.

## Seed (what was already known before the first question)
- Board Inbox rows still "needs decision" or "held":
- Board Inbox rows marked "decided" whose work is not done, with no Decided row, no job and no A number (a green item never handed out):
- Board "Waiting on you" rows (keep their D numbers):
- Board Decided rows ranked now or later, work not done (the setup brain dump lands here):
- Board "Your list" rows still open:
- Board Job queue rows still open that carry owner work (never routine runs, "Rank your plate" rows, or jobs that name a P#):
- Email Manager "Waiting on you" (only if the report is dated today):
- Open items from the last ranking (re-rank only):

## Owner's answers (exact)
| PQ# | Owner's words |
|---|---|

## Items
| P# | Item | Kind: project / promise / waiting / recurring / idea / personal / task | Source | Due | If it slips | Who waits | Only you? | Size | Waits on | Sort: now / must / later / no / standing | Why, or what it waits on |
|---|---|---|---|---|---|---|---|---|---|---|---|
