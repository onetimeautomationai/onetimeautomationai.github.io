---
type: plate-ranking
run: {{run_name}}
status: battling
mode: "{{manual or auto, from rank_mode in the owner profile}}"
owner_review: not yet
criterion: "{{the question every pair is judged on}}"
---

# Plate ranking

Question for every pair: **{{the question every pair is judged on}}** One letter per pair. No ties.

Script: `python3 chief-of-staff/scripts/rank_plate.py start|next|answer|set|tally|check chief-of-staff/runs/<this run>/08_rank.md`. Automatic ranking: `auto|picks|flip|clear`. By hand: `chief-of-staff/scripts/README.md`, "Ranking by hand".

## Items

The "now" items, at most 10 (`chief-of-staff/_shared/plate-rules.md` PL4). Fill one row per item from A down, with the facts from `07_plate.md`. Write `none`, `nobody` or `no date` when the owner's answers say so, and `?` when a fact is not known. Leave unused rows as they are. `start` removes them and the pairs that name them.

| Key | Item | P# | Due | If it slips | Who waits | Only you? | Size | Why now |
|---|---|---|---|---|---|---|---|---|
| A | {{item}} | | | | | | | |
| B | {{item}} | | | | | | | |
| C | {{item}} | | | | | | | |
| D | {{item}} | | | | | | | |
| E | {{item}} | | | | | | | |
| F | {{item}} | | | | | | | |
| G | {{item}} | | | | | | | |
| H | {{item}} | | | | | | | |
| I | {{item}} | | | | | | | |
| J | {{item}} | | | | | | | |

## Head-to-head

Keep this order. Answers fill the next empty rows in order, 9 per batch. By: `owner` or `chief of staff`. Reason: one line, only for a pick the Chief of Staff made, from the facts above (`chief-of-staff/_shared/plate-rules.md` PL18).

| Pair | Winner | By | Reason |
|---|---|---|---|
| A-B |  |  |  |
| A-C |  |  |  |
| A-D |  |  |  |
| A-E |  |  |  |
| A-F |  |  |  |
| A-G |  |  |  |
| A-H |  |  |  |
| A-I |  |  |  |
| A-J |  |  |  |
| B-C |  |  |  |
| B-D |  |  |  |
| B-E |  |  |  |
| B-F |  |  |  |
| B-G |  |  |  |
| B-H |  |  |  |
| B-I |  |  |  |
| B-J |  |  |  |
| C-D |  |  |  |
| C-E |  |  |  |
| C-F |  |  |  |
| C-G |  |  |  |
| C-H |  |  |  |
| C-I |  |  |  |
| C-J |  |  |  |
| D-E |  |  |  |
| D-F |  |  |  |
| D-G |  |  |  |
| D-H |  |  |  |
| D-I |  |  |  |
| D-J |  |  |  |
| E-F |  |  |  |
| E-G |  |  |  |
| E-H |  |  |  |
| E-I |  |  |  |
| E-J |  |  |  |
| F-G |  |  |  |
| F-H |  |  |  |
| F-I |  |  |  |
| F-J |  |  |  |
| G-H |  |  |  |
| G-I |  |  |  |
| G-J |  |  |  |
| H-I |  |  |  |
| H-J |  |  |  |
| I-J |  |  |  |
