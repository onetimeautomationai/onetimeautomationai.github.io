---
type: board
---

# Board

Live state. The Chief of Staff reads it at the start of every session. Everything on the owner's plate, ranked, lives next to it in `plate.md`.

## Inbox (every idea and ask lands here first)
| IN# | Date | Owner's words | Status: needs decision / held / decided / note / parked |
|---|---|---|---|

## Waiting on you (decisions only the owner can make)
| D# | Date | Question | Recommendation and why it moves goal 1 | Log L# |
|---|---|---|---|---|

## Decided
| D# or IN# | Date | Decision | Owner's words | Tier | Log L# |
|---|---|---|---|---|---|

## Your list (tasks only the owner does)
| A# | Date | Task | Why it matters | Status: open / done |
|---|---|---|---|---|

## Job queue
| Job# | Job | Manager | Result goes to | Due | Light | Status |
|---|---|---|---|---|---|---|

## Wins
| Date | Win | Moved which goal |
|---|---|---|
