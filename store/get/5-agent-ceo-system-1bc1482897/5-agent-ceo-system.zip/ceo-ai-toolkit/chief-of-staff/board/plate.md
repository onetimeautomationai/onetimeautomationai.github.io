---
type: board
criterion: "not set yet"
criterion_approved: not yet
goal_1_when_approved: not yet
last_full_ranking: not yet
rerank_day: last work day of the week
---

# Your plate

Live state: everything on the owner's plate, its sort, its rank and who does it. Part of the board. Rules: `chief-of-staff/_shared/plate-rules.md`. Each full ranking keeps its own record in `chief-of-staff/runs/YYYY-MM-DD-plate/`. P numbers are permanent and never reused.

## Plate
| P# | Added | Item | Kind | Due | Who waits | Only you? | Size | Waits on | Sort: now / must / later / no / standing | Rank | Goes to | Status: open / done / waiting: reason / parked |
|---|---|---|---|---|---|---|---|---|---|---|---|---|

## Changes since the last full ranking
| Date | P# | What changed | Pairs answered | Letters and who picked | Reasons (Chief of Staff's picks) | Lands at | Shown to you |
|---|---|---|---|---|---|---|---|
