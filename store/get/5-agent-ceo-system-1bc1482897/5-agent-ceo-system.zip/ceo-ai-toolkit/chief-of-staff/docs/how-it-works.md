# How your Chief of Staff works

## The idea
You are the CEO. A CEO does not sort email or build the calendar. They set direction and make the calls only they can make. Your Chief of Staff runs everything else and brings you only those calls.

## The flow

```
You ──> Chief of Staff ──> board (yes / later / no)
              │
              ├──> Email Manager ──> who is waiting, the important one, drafts
              ├──> Time Manager  ──> time blocked on your calendar
              ├──> Focus Manager ──> your Top 3, one result per block
              └──> CEO Scoreboard ──> your score, tomorrow's list
              │
              └──> back to you: one morning brief, one night wrap,
                   and only the decisions that need you
```

The managers never talk to you directly. They write short reports into the `handoffs/` folder, and your Chief of Staff reads them and tells you what matters.

## Three trust lights
- **Green:** small and reversible. It does it and logs it.
- **Yellow:** reversible, but it changes your day or is shown to you as finished. An AI reviewer checks it first. If it fails review twice, it becomes red.
- **Red:** money, other people, deleting, anything you cannot undo. It recommends, then waits for you.

A kind of work moves from yellow to green only after 10 clean reviews in a row and your yes.

Every decision is written to a log that is never edited, only added to. A small check script fails if anything that sends, posts, pays, buys, deletes or books is logged as less than red, or marked done without your words.

## How it ranks your plate

Say "Prioritize my plate", or say yes when it offers right after setup.

1. **Everything out of your head.** It starts from what it already knows (your setup brain dump and your board), then asks up to 12 short questions, one at a time: your projects, your promises and dates, what you wait on, your weekly duties, your ideas, and personal items if you use it for both. Then a few questions the ranking needs: what happens if a date slips, who else waits, what only you can do, and how big each item is. Every question has a default, so "skip" always works.
2. **A first sort.** Each item gets one of five: standing (it repeats every day or week, so it gets its own calendar block and is never ranked), now (it moves your number one goal this month), must (a hard date with a real cost, even if it does not move the goal), later (with what it waits on), or no (with the reason). You approve the sort.
3. **Two at a time, by you or for you.** You never order a whole list. Your "now" items are compared two at a time, up to 10 items, so at most 45 pairs. The first time, it asks once: "Do you want to pick each pair yourself, or should I rank it for you to review?"
   - **You pick:** it shows you nine pairs at a time, and you reply with nine letters. At most 5 replies.
   - **It ranks for you:** your Chief of Staff picks every pair on the same question, using only what you told it and what is on your board: the due date, what happens if it slips, who waits, whether only you can do it, the size, and why it matters now. Each pick gets a one-line reason. A second AI check reads the picks and reasons first. Then you see your Top 3 and the full order. Say "show the picks" to read every pick and its reason, "flip 7" to change one, or "looks right". Nothing goes to your managers until you say it looks right. If a fact is missing for a pair, it asks you that pair instead.
   - Switch any time: "I'll pick" or "Rank it for me".
4. **Counted the same way every time.** The item with the most wins ranks first. A tie goes to the item that won their own pair. If the picks go in a circle, it tells you and lets you choose.
5. **One page.** Your Top 3 this week, the full order, what has a date, what to hand to which manager, what waits on what, and what to drop with the reason. Your Focus Manager sets each day's Top 3 from it, and your Time Manager blocks time for the top items.
6. **Kept current.** Once a week at your night wrap it offers a quick re-rank. A new idea in between is compared only with your top 3, so it takes three picks at most. If you chose "rank it for me", your Chief of Staff makes those picks and tells you where the idea landed and why, and you can flip any of them.
7. **New items wait their turn.** A new idea goes to a manager only when the picks put it in your top 3. Placed lower, it waits on your list, and your morning brief hands it out when it reaches the top 3. Anything with a hard date and a real cost is handled right away. An idea that arrives while you are away, for example from a Watch memo, waits for your picks at your next morning brief. If you chose "rank it for me", your Chief of Staff places it while you are away and shows you where it went, with the reasons, at your next brief. With no ranking yet, ideas go to a manager right away, as before.

Ranking only puts your work in order. Nothing on the page is sent, booked with another person, paid or deleted without your yes, whoever made the picks.

## How it learns
When you correct it ("from now on, decisions go first"), it writes one line in a lessons file. Every hire reads that file before it starts, so you never have to say it twice.

## Your files
Everything lives in the toolkit folder on your computer: your profile, your board, your decisions, your history. Nothing is sent to us.
