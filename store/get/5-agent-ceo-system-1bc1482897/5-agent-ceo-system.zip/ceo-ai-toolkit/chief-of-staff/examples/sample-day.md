# A sample day (made-up owner, made-up data)

Owner: Dana Ruiz, runs a 6-person bookkeeping firm. Goal 1: "10 new monthly clients by March 31." Report style: short, lists.

## 8:02 AM, Dana says "Morning"

> **Top 3 today**
> 1. Send proposals to the two warm leads from last week. Result: both proposals drafted for your review
> 2. Call back Priya Shah about the payroll add-on. Result: call held, next step agreed
> 3. Post the year-end checklist offer. Result: post drafted for your review
>
> **Calendar:** team meeting 10:00 to 10:30, client review 2:00 to 3:00. Open: 3 hours.
>
> **Waiting on you:** Priya Shah, "Payroll add-on pricing", 2 days. Draft ready. Also Tom Becker and Ana Lima.
>
> **Decisions only you can make**
> - D1: Priya asked for 10% off the add-on. I recommend yes for a 12-month term, because it adds a monthly client toward goal 1.
> - D2: A software vendor wants a 30-minute demo Thursday. I recommend no, it does not move goal 1 this quarter.
>
> **Yesterday:** 7 out of 10. Two of three done. Fix: start proposals before email.
>
> Start with the two proposals.

Dana: "D1 yes, D2 no."

The decision log gets two red-light rows with Dana's own words. The Email Manager updates the Priya draft with the 12-month term and hands it back for Dana to send.

## 11:40 AM, Dana says "Idea: a webinar for restaurant owners in January"

> Logged. Later: it helps goal 1, but it needs the year-end offer to run first so we know which message works. I put it on the board for the first week of January.

## 6:15 PM, Dana says "Wrap up my day"

> **Score:** 8 out of 10. Top 3 done: 3 of 3. One proposal was sent late.
>
> **Done today:** you sent both proposals, Priya call held (she signed for 12 months), offer post drafted.
>
> **Carried to tomorrow:** publish the offer post (waiting on your yes).
>
> **Decisions still waiting on you:** none.
>
> Tomorrow, first thing: approve and publish the offer post.
