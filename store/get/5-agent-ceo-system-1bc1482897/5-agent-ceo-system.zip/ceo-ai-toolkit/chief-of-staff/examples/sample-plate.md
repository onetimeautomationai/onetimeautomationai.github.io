# Sample plate ranking (made-up data)

The owner is the made-up test owner in `chief-of-staff/tests/test-owner.md`: Dana Ruiz, a 6-person bookkeeping firm, goal 1 "10 new monthly clients by March 31". She answered 11 plate questions (business use, so no PQ6), and 18 items landed on her plate. 10 were "now" and all 10 went into the pairs (45 pairs, 5 replies). One was standing (P11, Tuesday sales calls, work that repeats on a named day, plate rule PL19. "LinkedIn posts twice a week" names no day, so it stays a now item), so it is not ranked and gets a standing block instead. This is the page she got from `chief-of-staff/stages/09_organize/CONTEXT.md`.

Sources behind every line (the same ones the reviewer gets, stage 09 step 10):
- The test owner file for her words, dates, sizes and who does what.
- The tally of `08_rank.md` for the wins, "Picked by: you, two at a time", the two ties and the loop count. Ties: P3 and P15 both 4 wins (P3 won their pair), P13 and P5 both 3 wins (P13 won their pair). Wins by P#: P4 9, P18 8, P1 7, P17 6, P3 4, P15 4, P13 3, P5 3, P8 1, P16 0. Loops in the picks: 2, and none touches the top 3. Owner to order: none.
- `_shared/roster.md` and `_shared/plate-rules.md` for who does what, when a hand-off goes out (PL17), the must rule (PL10), the over-the-cap rule (PL4) and the re-rank day (PL14). `board/plate.md` for the re-rank day, which is the last work day of the week (Friday: her profile gives only hours, 8 AM to 5 PM, so her work days come from the Time Manager's `work_days`, Monday to Friday, standing rule SR15).
- The run date from the clock: Monday 2026-11-23.

---

# Your priorities, week of 2026-11-23

Goal 1: 10 new monthly clients by March 31. Every pair was judged on this question: "Which one moves 10 new monthly clients by March 31 forward most this month?"

## Top 3 this week
1. P4: Harbor Grill proposal. Done when: proposal sent to Harbor Grill by Fri Nov 27. Who: you.
2. P18: Call 5 past leads from the fall. Done when: five calls made. Who: you.
3. P1: Follow up with the chamber about the January mixer. Done when: follow-up drafted by the Email Manager and waiting for your yes. Due Dec 5. Who: Email Manager drafts, you send.

## The full order
Picked by: you, two at a time.

| Rank | P# | Item | Wins | Who does it | Due |
|---|---|---|---|---|---|
| 1 | P4 | Harbor Grill proposal | 9 | you | Fri Nov 27 |
| 2 | P18 | Call 5 past leads from the fall | 8 | you | |
| 3 | P1 | Follow up with the chamber about the January mixer | 7 | Email Manager drafts, you send | Dec 5 |
| 4 | P17 | Email newsletter to past prospects | 6 | Email Manager drafts, you send | |
| 5 | P3 | Reply to Tom Becker | 4 | Email Manager drafts, you send | |
| 6 | P15 | Case study from Bella's Bakery | 4 | Chief of Staff drafts | |
| 7 | P13 | Lunch talk for the chamber | 3 | you | |
| 8 | P5 | Referral offer for current clients | 3 | Chief of Staff drafts | |
| 9 | P8 | Website pricing page | 1 | Chief of Staff drafts | |
| 10 | P16 | LinkedIn posts twice a week | 0 | Chief of Staff drafts | |

Standing, not ranked (PL19): P11, Tuesday sales calls. It gets a block every Tuesday instead of a place in the order.

## Must do by date (the date sets the order)
| P# | Item | Due | If it slips | Who does it |
|---|---|---|---|---|
| P9 | Payroll run | Fri Nov 27 | Clients' staff get paid late | your team |
| P2 | Renew my software subscription | Dec 1 | The team loses access to client files | you decide (D1) |

## What happens next, and who does it
| P# | Item | To | Light | What happens next |
|---|---|---|---|---|
| P9 | Payroll run | Your team | green | Your team runs it, due Fri Nov 27. No block on your calendar |
| P2 | Renew my software subscription | You, on D1 | red | Waits for your yes on D1, due Dec 1 |
| P4 | Harbor Grill proposal | You | green | Yours to do, due Fri Nov 27. On your list with an A number |
| P18 | Call 5 past leads from the fall | You | green | Yours to do. On your list with an A number |
| P1 | Chamber follow-up | Email Manager | red at the send | A draft waits for your yes |
| P17 | Email newsletter to past prospects | Email Manager | red at the send | Drafted when it reaches the top 3. You send it |
| P3 | Reply to Tom Becker | Email Manager | red at the send | Drafted when it reaches the top 3 |
| P15 | Bella's Bakery case study | Chief of Staff | yellow | Drafted when it reaches the top 3 |
| P13 | Lunch talk for the chamber | You | green | Yours to do. Gets an A number on your list when it is in the top 3 |
| P5 | Referral offer for current clients | Chief of Staff | yellow, red at the send | Drafted when it reaches the top 3 |
| P8 | Website pricing page | Chief of Staff | yellow, red at publish | Drafted when it reaches the top 3 |
| P16 | LinkedIn posts twice a week | Chief of Staff | yellow, red at the post | Drafted when it reaches the top 3 |
| P11 | Tuesday sales calls | Time Manager | yellow | Standing block: every Tuesday, about half a day. The Time Manager adds it as a fixed weekly time. It waits for a start time from you. Not in the Top 3 |

## Later (with what each waits on)
| P# | Item | Waits on |
|---|---|---|
| P6 | Hire a part-time payroll clerk | Two new clients signed |
| P7 | Year-end tax packets for 12 clients | Due Jan 15 |
| P10 | Card payments for clients | The bank approving the merchant account |

## Drop or park (with the reason)
| P# | Item | Reason | Someone to tell? |
|---|---|---|---|
| P12 | Start a podcast | No date, and it does not move goal 1 this month | no |
| P14 | Clean up the shared drive | You moved it to no, no reason given | no |

## What waits on what
- P6 waits on two new clients signed.
- P10 waits on the bank.

## Decisions only you can make
- D1 (P2): Renew before Dec 1? I recommend yes, because you said without it the team loses access to client files.

## Ties and loops in the picks
- P3 and P15 both had 4 wins. P3 won their pair.
- P13 and P5 both had 3 wins. P13 won their pair.
- 2 loops in the picks (three items that each beat one and lost to one). None touches your top 3, so your order stays as it is.

Next re-rank: Friday, Dec 4, at your night wrap. A new item in between is compared only with your top 3.

Start with the Harbor Grill proposal. It is due Friday, Nov 27.
