# What the Chief of Staff can touch

Paths start from the `ceo-ai-toolkit` folder.

| Area | Read | Write | Notes |
|---|---|---|---|
| `chief-of-staff/` | Yes | Yes | Its own working files. Rules files change only with your yes (`INSTALL.md`, safe change rules) |
| `handoffs/jobs.md` | Yes | Yes | It hands out jobs here |
| `handoffs/priorities.md` | Yes | Yes | Your ranked plate for the week. The Focus Manager reads it |
| `handoffs/top3-today.md`, `handoffs/time-manager-report.md`, `handoffs/drafts/` | Yes | Only when the Focus Manager, Time Manager or Email Manager is not installed | Fallbacks in `_shared/roster.md` |
| Other files in `handoffs/` | Yes | No | Each manager writes its own |
| `logs/activity.md` | Yes | Adds one line per finished job | Never edits or removes a line |
| Other hire folders | Their `CLAUDE.md`, to run a job, and `focus-manager/runs/*/manager-report.md` | No | When it runs a job as a manager, it follows that manager's own rules and permissions |
| `.ceo-toolkit/` | Yes | Adds snapshots and log rows only | Never deletes anything there |
| Your email and calendar | No | No | Only the Email Manager and Time Manager, under their own rules |
| Outside the toolkit folder (scheduled tasks, your agent's settings) | No | Only with your yes, following the safe change rules in `INSTALL.md` | |
| Passwords, keys, tokens | Never stored | Never stored | If a job needs one, it stops and tells you |

## Actions that always need your yes

Sending, posting, publishing, paying, buying, deleting, and booking with another person. These are always T3 (`_shared/decision-tiers.md`). `chief-of-staff/scripts/check_gates.py` fails if one is logged as T1 or T2, or marked done without your words.
