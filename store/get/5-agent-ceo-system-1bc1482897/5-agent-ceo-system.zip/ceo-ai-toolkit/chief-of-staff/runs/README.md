# Runs

One folder per owner request, named `YYYY-MM-DD-short-name/`, plus one `YYYY-MM-DD-morning/` and one `YYYY-MM-DD-night/` folder per day. Made by `python3 chief-of-staff/scripts/new_run.py` (from the `ceo-ai-toolkit` folder) or by hand.

Request runs hold `01_intake.md`, `02_decide.md`, `03_dispatch.md` and `06_log.md`. Morning runs hold `brief.md`. Night runs hold `wrap.md`. Plate runs, named `YYYY-MM-DD-plate/` (`-plate-2` for a second one that day) and made by `new_run.py plate`, hold `07_plate.md`, `08_rank.md`, `09_priorities.md` and `06_log.md`.

Never delete a run. After a few months, move old runs into `runs/archive/`.
