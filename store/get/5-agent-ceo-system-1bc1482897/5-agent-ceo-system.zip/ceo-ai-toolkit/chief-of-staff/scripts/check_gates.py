#!/usr/bin/env python3
"""Hard checks the Chief of Staff runs before it calls a run done.

Usage (from the ceo-ai-toolkit folder, works from any folder):
    python3 chief-of-staff/scripts/check_gates.py
    python3 chief-of-staff/scripts/check_gates.py --today 2026-11-20   (test with a made-up date. --date works too, and so does "2026-11-20 08:00")

Exit code 0 = all checks pass. 1 = at least one check failed (each failure is printed).
Standard library only. Reads files, never changes them. "Today" is the date in the owner's time zone (from the owner profile).

Checks:
  C1  Setup is done: owner profile has no {{ placeholders and says setup_done: yes.
  C2  Decision log rows have 8 columns, a tier of T1/T2/T3, and a Result of done/pending/parked/no.
  C3  Every T3 row marked done has real owner's words (not empty, "-", "n/a" or "none").
  C4  Row numbers (L#) are unique. The log is append only. Every Time is YYYY-MM-DD HH:MM and no row is
      timed earlier than the row above (the log is in time order). A "corrects L<n>" row names an earlier row.
  C5  Every request run and plate run dated before today has 06_log.md (morning and night runs are exempt,
      and so are runs dated today or later).
  C6  No secrets in shared files (lines that look like passwords, API keys or tokens).
  C7  A decision that says the team sent, posted, published, paid, bought, deleted, booked with another person or
      changed a website (as the thing done or decided) is T3. A row that only names, plans, drafts, asks, reorders,
      quotes or negates the action is not flagged ("nothing recorded or published", "P8 website pricing page: parked",
      "reorder the Top 3, reply to Tom first"). An "Owner task:" row whose Evidence says the AI or a manager did it is mislabeled.
  C8  Every T2 (yellow) row marked done says "review: pass (separate)" or "review: pass (self)" in Evidence,
      and names its saved review file (runs/<run>/NN_review.md), which exists and ends "Verdict: pass".
  C9  Every plate ranking file (runs/*/08_rank*.md) is sound: each winner is in its pair, no pair is
      missing or listed twice, and a written Result table follows from the picks. Every pick says who
      made it (owner or chief of staff), every Chief of Staff pick has a reason, and an automatic
      ranking reaches 09_priorities.md only after owner_review says "looks right YYYY-MM-DD HH:MM"
      (plate rule PL18). No pair is left open once the file says status ranked or waiting for your
      review, and a file with every pair answered says status ranked once 09_priorities.md exists.
      The same review rule holds for a "## Kept order" in 07_plate.md with picks by the Chief of Staff
      (weekly "keep") once 09_priorities.md exists or handoffs/priorities.md was ranked on the run's date,
      and that kept order also needs its saved review (10_review.md ending "Verdict: pass").
      An automatic ranking at "waiting for your review" or "ranked" has 08_review.md ending "Verdict: pass"
      (or "Verdict: fail" with the logged red path), and a 09_priorities.md shows the order of the Result.
      A pass needs its T2 decision log row naming runs/<run>/08_review.md. A fail needs a T3 row "failed review
      twice" that names the same run. After a weekly "keep", 09_priorities.md shows the order of the Kept order table.
  C10 handoffs/priorities.md (if it exists) has the header (with ranked_on), comes from the Chief of Staff, has ranks
      1, 2, 3 with no gaps, no P# twice, and a known status on every row. A new item still
      waiting for the owner's picks has no job in handoffs/jobs.md yet. P numbers in
      board/plate.md are never used twice, and each "Changes since the last full ranking" row's
      Pairs answered equals the number of letters in its next cell.
  C11 Every must on board/plate.md that is not done, parked or waiting, due within 14 days (or overdue), that the owner
      or the Chief of Staff does, or whose doer is not known yet, has a "Must P#" job in handoffs/jobs.md (or, with no
      Time Manager, a "block time ... for P#" line on the board) (PL21). Who does it is read from the Goes to cell,
      before its first colon. A blank Goes to is skipped only while a plate ranking is still in progress.
      A must still "waiting: D# answer" whose D# is in the board's Decided table fails (the answer reopens it).
  C12 Every row of the tables in board/board.md, board/plate.md and handoffs/jobs.md has as many cells as its
      header, and every open "Your list" row has a decision log row "A#: Owner task: ..." naming its A number.
      A Watch memo file named in a logs/activity.md line dated today has a board row "(Watch memo <file name>)".

A row whose Decision starts with "corrects L<n>" replaces every earlier row numbered L<n> for checks C2, C3, C4, C7 and C8.
"""
import datetime
import re
import sys
from pathlib import Path

try:
    from zoneinfo import ZoneInfo
except ImportError:  # very old Python
    ZoneInfo = None


ZONE_NAMES = {"pacific": "America/Los_Angeles", "pst": "America/Los_Angeles", "pdt": "America/Los_Angeles", "mountain": "America/Denver", "mst": "America/Denver", "mdt": "America/Denver", "central": "America/Chicago", "cst": "America/Chicago", "cdt": "America/Chicago", "eastern": "America/New_York", "est": "America/New_York", "edt": "America/New_York", "utc": "UTC", "gmt": "UTC"}


def zone_name(text):
    """The zone on the 'Time zone:' line: an IANA name (America/Chicago) or a common name (Pacific, PST). Empty if none."""
    m = re.search(r"^-?\s*Time zone[^:\n]*:([^\n]*)", text, re.M | re.I)
    if not m:
        return ""
    i = re.search(r"([A-Za-z]+/[A-Za-z_]+(?:/[A-Za-z_]+)?)", m.group(1))
    if i:
        return i.group(1)
    for w in re.findall(r"[A-Za-z]+", m.group(1)):
        if w.lower() in ZONE_NAMES:
            return ZONE_NAMES[w.lower()]
    return ""


def owner_today(override, profile_files):
    """Today's date in the owner's time zone. override is YYYY-MM-DD (tests).
    The zone is read from the first profile file that names one (a line like 'Time zone: America/Chicago').
    With no zone found, the computer's date is used."""
    if override:
        # YYYY-MM-DD, or "YYYY-MM-DD HH:MM" (the same form rank_plate.py and new_run.py take): the date is the first 10 characters.
        try:
            return datetime.date.fromisoformat(override.strip()[:10])
        except ValueError:
            print(f'STOP: --today takes YYYY-MM-DD or "YYYY-MM-DD HH:MM", not {override}.')
            sys.exit(2)
    if ZoneInfo:
        for p in profile_files:
            try:
                text = Path(p).read_text(encoding="utf-8")
            except OSError:
                continue
            name = zone_name(text)
            if name:
                try:
                    return datetime.datetime.now(ZoneInfo(name)).date()
                except Exception:
                    pass
    return datetime.date.today()


def arg_today():
    """The value after --today (or --date) on the command line, or empty."""
    for flag in ("--today", "--date"):
        if flag in sys.argv:
            i = sys.argv.index(flag)
            if i + 1 < len(sys.argv):
                return sys.argv[i + 1]
    return ""

HERE = Path(__file__).resolve().parent.parent  # the chief-of-staff folder
FAILS = []

RESULTS = {"done", "pending", "parked", "no"}
EMPTY_WORDS = {"", "-", "--", "n/a", "na", "none", "tbd", "?"}
# ---- C7: does a Decision say the team did (or does) an outward action? ----
# Since 0.6.15 the test reads the Decision clause by clause, so it flags only a row that states an outward action
# (send, post, publish, pay, buy, book or schedule with another person, delete, forward, hire, sign, change a website ...)
# as the thing done or decided:
#   - the clause starts with the verb: "Send the offer to Priya", "Sent the email to Tom", "Paid the invoice",
#     "then sent the offer to Tom", "but posted to the group"
#   - the team is its subject: "the Email Manager sent it", "I booked the call with Priya"
#   - it is the result: "email sent to Tom", "invoice paid", "website footer updated"
# Never flagged: a negated part, the whole list after the negating word ("nothing sent or posted", "nothing recorded or
# published", "not sent, posted or paid"), a planned, drafted, asked, sorted or reordered mention ("Email Manager drafts it,
# red at the send", "reorder the Top 3, reply to Tom Becker first"), quoted words, a question, an item's name before its
# sort ("P8 website pricing page: parked", "P6 Hire a part-time payroll clerk: later"), a word used in passing
# ("before they buy", "Sent not checked", "Roll the calendar forward"), and anything aimed at the owner or the team
# ("sent to you", "posted on the board", "forwarded to the Email Manager").
_SITE = r"(?:web\s*site|site|homepage|home\s+page|web\s+page|landing\s+page)"
# "Email Priya the offer" is a send, "email tool" and "Email Manager" are not: e-mail as a verb needs a name or a pronoun after it.
_IMPERATIVE = (r"(?:send|e-?mail(?=\s+(?:(?-i:[A-Z])(?!anager\b)|(?:him|her|them|the|a|an|this|that|it|back|everyone|all)\b))|reply\s+to|post|publish|pay|buy|purchase|place\s+an\s+order|book|delete|forward|cancel|invite|sign|"
               r"wire|transfer|renew|subscribe|charge|share|refund|invoice|hire|accept|confirm\s+with|schedule)")
_PAST = (r"(?:sent|e-?mailed|replied\s+to|posted|published|paid|bought|purchased|ordered|placed\s+an\s+order|booked|deleted|forwarded|"
         r"cancell?ed|invited|signed|wired|transferred|renewed|subscribed|charged|shared|refunded|invoiced|hired|accepted|confirmed\s+with|scheduled)")
_PRESENT = (r"(?:sends|e-?mails|replies\s+to|posts|publishes|pays|buys|purchases|books|deletes|forwards|cancels|invites|signs|"
            r"wires|transfers|renews|subscribes|charges|shares|refunds|invoices|hires|accepts|confirms\s+with|schedules)")
_PASSIVE = (r"(?:sent|e-?mailed|posted|published|paid|bought|purchased|booked|deleted|forwarded|cancell?ed|invited|signed|wired|"
            r"transferred|renewed|charged|shared|refunded|invoiced|hired|scheduled)")
_CHANGE = r"(?:change|changes|changed|update|updates|updated|edit|edits|edited|push|pushes|pushed|launch|launches|launched|fix|fixes|fixed)"
_DOERS = (r"(?:ai|agent|assistant|i|we|(?:the\s+)?(?:email|time|focus)[- ]manager|(?:the\s+)?(?:ceo\s+)?scoreboard|"
          r"(?:the\s+)?chief[- ]of[- ]staff|(?:the\s+)?manager|(?:the\s+)?team)")
_NEG = re.compile(r"\b(?:nothing|not|never|no|none|without|nor|neither|wasn't|weren't|isn't|aren't|hasn't|haven't|hadn't|didn't|"
                  r"don't|doesn't|won't|can't|cannot|instead\s+of|rather\s+than)\b", re.I)
_NEG_END = re.compile(r"[;:.!?)]|\s(?:but|then|so|however|except|although|though|while|whereas)\b|,", re.I)
_PART = r"(?:[a-z]+(?:ed|en)|sent|paid|bought|built|made|done|told|sold|spent|shown|run|kept|held)"
_LIST_TAIL = re.compile(r"\s*(?:(?:or|and|nor)\s+)?" + _PART + r"(?:\s*(?:,|\bor\b|\band\b|\bnor\b)\s*" + _PART + r")*"
                        r"(?:\s+(?:by|to|on|in|from|for|with|yet|anywhere|externally)\b[^,;:.!?)]*)?\s*$", re.I)
_QUOTED = re.compile(r"\"[^\"]*\"|“[^”]*”|(?<![A-Za-z])'[^']*'(?![A-Za-z])")
_SENT_NOUN = re.compile(r"\bsent\s+(?:not\s+checked|checked|unchecked|folder|box|items|tab|mail)\b|"
                        r"\b(?:her|his|their|your|my|the|owner's|dana's)\s+sent\b", re.I)
_CLAUSE_END = re.compile(r"\s*[;:.()\[\]!]\s*|\s*,\s*|\s+-\s+|\s+(?:but|then|so|while|because|since|although|though|whereas)\s+|"
                         r"\s+(?:and|&)\s+(?=(?:then\s+|also\s+)?(?:" + _PAST + r"|" + _IMPERATIVE + r")\b)", re.I)
_LEAD = re.compile(r"^(?:(?:(?:IN|D|A|P|J|L|E|R|W|QN)\d+|must|job|item)\b[\s,/&:-]*(?:(?:to|and|or)\s+)?|"
                   r"(?:then|and|but|so|also|plus|after\s+that)\s+|~neg~\s*)+", re.I)
_SORTISH = re.compile(r"^(?:~neg~|sorted|sort\b|now\b|must\b|later\b|no\b|standing\b|parked|ranked|placed|added|moved|kept|held|"
                      r"waiting|open\b|on\s+(?:the|your)\s+plate|over\s+the\s+cap|idea\b|new\s+item|#\d|rank\s*\d|P\d+\b)", re.I)
_REORDER = re.compile(r"\b(?:re-?order\w*|top\s*3|top\s+three|rank(?:ed|s|ing)?|priorit\w*|order\s+of)\b", re.I)
_ORDER_END = re.compile(r"\b(?:first|next|last|second|third|on\s+top|at\s+the\s+top|ahead\s+of\s+\S+(?:\s+\S+)?)\s*$", re.I)
_PLAN = re.compile(r"\b(?:drafted|drafting|drafts\s+(?:it|the|a|an)|draft\s+(?:only|ready|saved|written|held|prepared|kept)|written|prepared|"
                   r"for\s+(?:your|the\s+owner's|her|his)\s+review|planned|plans?\s+to|queued|proposed|suggested|asked|asks|ask|question|"
                   r"waits?\s+(?:for|on)|waiting|pending|after\s+(?:the\s+owner|you|your|her|his)|once\s+(?:the\s+owner|you|she|he)|"
                   r"when\s+(?:the\s+owner|you)|needs?\s+(?:the\s+owner|your|her|his)|owner'?s?\s+(?:yes|ok|approval|go)|your\s+yes|"
                   r"red\s+at|is\s+red|stays\s+red|stays\s+with|sorted|parked|ranked|placed|later|kept|held)\b", re.I)
_INTERNAL = re.compile(r"\b(?:to|on|in|into|onto|with)\s+(?:the\s+|your\s+|her\s+|his\s+)?(?:owner|you|yourself|me|board|plate|"
                       r"job\s*queue|jobs(?:\.md)?|your\s+list|(?:decision\s+)?log|(?:morning\s+)?brief|inbox|handoffs\S*|drafts\S*|"
                       r"email[- ]manager|time[- ]manager|focus[- ]manager|(?:ceo\s+)?scoreboard|chief[- ]of[- ]staff|manager|"
                       r"team'?s?\s+(?:list|board))\b", re.I)
_OWN_TIME = re.compile(r"\b(?:block|blocks|focus|deep\s+work|time\s+for|time\s+block|calendar\s+block)\b", re.I)
_INTERNAL_OBJECT = re.compile(r"^(?:delete|deleted|cancel|cancell?ed)\s+(?:(?:the|a|an|old|duplicate|stale|empty)\s+)*"
                              r"(?:rows?|drafts?|duplicates?|blocks?|jobs?|J\d+|lines?|tests?|copy|notes?|reminders?|runs?)\b", re.I)
# A word after an imperative that shows the verb is a noun ("Send question asked", "Email Manager drafts it").
_NOUN_NEXT = {"of", "is", "was", "are", "were", "stays", "stay", "waits", "wait", "question", "questions", "row", "rows", "step", "steps",
              "line", "lines", "gate", "light", "date", "dates", "time", "times", "button", "decision", "approval", "stopped", "held",
              "blocked", "kept", "changed", "manager", "report", "list", "folder", "box", "page", "plan", "plans", "idea", "ideas", "item",
              "items", "task", "tasks", "job", "jobs", "template", "outline", "checklist", "notes", "copy", "guide", "criteria", "summary",
              "reminder", "due", "from", "drive", "calendar", "settings", "setup", "access", "status", "history", "count", "limit", "~neg~",
              "off", "thread", "threads", "triage", "run", "inbox", "newsletter", "address", "account", "sort", "connector", "by", "draft:",
              "drafts", "pipeline", "rules", "rule", "flow"}
_PAST_NOUN_NEXT = {"not", "folder", "box", "items", "tab", "mail", "back", "drive", "~neg~", "by", "off", "list"}
_PASSIVE_PRE = {"to", "be", "being", "will", "would", "could", "should", "can", "may", "might", "must", "once", "after", "before", "when",
                "if", "until", "unless", "whether", "get", "gets", "got", "getting", "ready", "she", "he", "they", "you", "owner", "client",
                "clients", "customer", "customers", "~neg~", "and", "or", "not"}
_PASSIVE_NEXT = {"", "to", "on", "via", "out", "through", "with", "for", "online", "live", "today", "yesterday", "at", "this", "last",
                 "from", "in", "by"}


def strip_negated(text):
    """Replace every negated part with ' ~neg~ ': from the negating word to the end of its clause, and on through a
    list that goes on after a comma ("nothing sent, posted or paid"). "not sent, but posted" keeps "posted"."""
    out, pos = [], 0
    while True:
        m = _NEG.search(text, pos)
        if not m:
            out.append(text[pos:])
            return "".join(out)
        out.append(text[pos:m.start()])
        end = m.end()
        while True:
            e = _NEG_END.search(text, end)
            if not e:
                end = len(text)
                break
            if e.group(0) != ",":
                end = e.start()
                break
            nxt = _NEG_END.search(text, e.end())
            seg_end = nxt.start() if nxt else len(text)
            if _LIST_TAIL.match(text[e.end():seg_end]):
                end = seg_end  # the list goes on: still negated
                continue
            end = e.start()
            break
        out.append(" ~neg~ ")
        pos = end


def _clauses(text):
    """(clause, the delimiter after it) pairs."""
    out, pos = [], 0
    for m in _CLAUSE_END.finditer(text):
        out.append((text[pos:m.start()], m.group(0).strip().lower()))
        pos = m.end()
    out.append((text[pos:], ""))
    return out


def _next_word(rest):
    w = rest.split()
    return w[0].lower().strip(",.;:!?\"'") if w else ""


def _clause_claim(c, had_code, delim, nxt, reorder):
    """The outward action a clause states as done or decided, or ''."""
    s = c.strip()
    if not s or s.endswith("?"):
        return ""
    if _INTERNAL.search(s):
        return ""  # aimed at the owner, the board or a manager
    m = re.match(r"(" + _PAST + r")\b(.*)$", s, re.I)
    if m:
        verb, rest = m.group(1).lower(), m.group(2)
        nw = _next_word(rest)
        if nw in _PAST_NOUN_NEXT or (verb == "scheduled" and not re.search(r"\bwith\b", rest, re.I)) \
                or (verb in ("booked", "scheduled", "cancelled", "canceled") and _OWN_TIME.search(rest)) \
                or (verb == "ordered" and nw in ("by", "of")) or (verb == "forwarded" and nw in ("draft", "drafts")) \
                or _INTERNAL_OBJECT.match(s):
            return ""
        return s
    m = re.match(r"(" + _IMPERATIVE + r")\b(.*)$", s, re.I)
    if m:
        verb, rest = m.group(1).lower(), m.group(2)
        nw = _next_word(rest)
        item_name = (had_code == "item" and delim == ":") or \
            ((delim in (":", "(") or (delim == "," and had_code)) and bool(_SORTISH.match(nxt.strip())))
        noun = nw in _NOUN_NEXT or bool(re.fullmatch(_PASSIVE + r"|[a-z]+ed", nw, re.I))  # "Invoice paid by Dana": a noun, then its verb
        if not (noun or item_name or _PLAN.search(s) or (reorder and _ORDER_END.search(s))
                or (verb == "schedule" and not re.search(r"\bwith\b", rest, re.I))
                or (verb in ("book", "schedule", "cancel") and _OWN_TIME.search(rest))
                or (verb == "forward" and nw in ("draft", "drafts")) or _INTERNAL_OBJECT.match(s)
                or (verb == "send" and nw == "back")):
            return s
    m = re.match(_CHANGE + r"\s+(?:\S+\s+){0,4}?" + _SITE + r"\b", s, re.I)
    if m and not _PLAN.search(s):
        return s
    m = re.search(r"\b" + _DOERS + r"\s+(?:(?:has|have|had|already|just|then|also|now)\s+)*(" + _PAST + r"|" + _PRESENT + r"|"
                  + _CHANGE + r"(?=.*\b" + _SITE + r"\b))\b(.*)$", s, re.I)
    if m:
        verb, rest = m.group(1).lower(), m.group(2)
        present = not re.fullmatch(_PAST + r"|" + _CHANGE, verb, re.I)
        if not (_next_word(rest) in _PAST_NOUN_NEXT or (present and _PLAN.search(s))
                or (verb.startswith(("book", "schedul", "cancel")) and _OWN_TIME.search(rest))
                or (verb.startswith("schedul") and not re.search(r"\bwith\b", rest, re.I))):
            return s
    for m in re.finditer(r"(\S+)\s+(" + _PASSIVE + r")\b(.*)$", s, re.I):
        pre, verb, rest = m.group(1).lower().strip(",.;:\"'"), m.group(2).lower(), m.group(3)
        nw = _next_word(rest)
        if pre in _PASSIVE_PRE or nw not in _PASSIVE_NEXT or re.match(_DOERS + r"$", pre, re.I):
            continue
        if nw == "by" and not re.match(r"\s*by\s+" + _DOERS + r"\b", rest, re.I):
            continue  # done by the owner or another person, not by the team
        if verb in ("booked", "scheduled", "cancelled", "canceled") and _OWN_TIME.search(s):
            continue
        if verb == "scheduled" and not re.search(r"\bwith\b", rest, re.I):
            continue
        return s
    m = re.search(r"\b" + _SITE + r"\b(?:\s+\S+){0,3}?\s+(?:changed|updated|edited|pushed|launched|fixed|live|published)\b", s, re.I)
    if m and not _PLAN.search(s):
        return s
    return ""


def outward_claim(decision):
    """The clause of a Decision that says the team did (or does) an outward action, or '' when none does (check C7)."""
    t = _QUOTED.sub(" ", decision)
    t = _SENT_NOUN.sub(" ", t)
    t = strip_negated(t)
    reorder = bool(_REORDER.search(t))
    parts = _clauses(t)
    for i, (c, delim) in enumerate(parts):
        lead = _LEAD.match(c.strip())
        # "P7 Buy a new laptop: ..." names a plate, inbox, decision or list item before what happened to it.
        had_code = "" if not (lead and re.search(r"\d", lead.group(0))) else \
            ("item" if re.search(r"\b(?:P|IN|D|A)\d+", lead.group(0), re.I) else "code")
        body = c.strip()[lead.end():] if lead else c.strip()
        nxt = parts[i + 1][0] if i + 1 < len(parts) else ""
        hit = _clause_claim(body, had_code, delim, nxt, reorder)
        if hit:
            return hit
    return ""
# "Owner task:" starts the Decision. An item code before it ("IN3: Owner task: ...") is allowed.
OWNER_TASK = re.compile(r"^\s*(?:(?:IN|D|A|P|J)\d+(?:\s*(?:,|/|\bto\b|\band\b)\s*(?:IN|D|A|P|J)\d+)*\s*:\s*)?owner task\s*:", re.I)
# An "Owner task:" row says the owner did it. If its Evidence says the AI or a manager did it, the row is mislabeled.
DONE_VERBS = r"(?:sent|emailed|posted|published|paid|bought|booked|deleted|forwarded|replied|scheduled|invited|cancelled|purchased)"
DOERS = r"(?:ai|agent|assistant|i|me|we|us|(?:the\s+)?(?:email|time|focus)[- ]manager|(?:the\s+)?(?:ceo\s+)?scoreboard|(?:the\s+)?chief[- ]of[- ]staff|(?:the\s+)?manager)"
AI_SENT = re.compile(r"\b" + DOERS + r"\s+(?:has\s+|have\s+|had\s+|already\s+|just\s+)*" + DONE_VERBS + r"\b|\b" + DONE_VERBS + r"\s+by\s+(?:the\s+)?" + DOERS + r"\b", re.I)
REVIEW_PASS = re.compile(r"review:\s*pass", re.I)
# Who reviewed, in the same two words as the Time Manager and the Email Manager: (separate) or (self).
REVIEW_TAG = re.compile(r"review:\s*pass\s*\((?:separate|self)\)", re.I)
REVIEW_PATH = re.compile(r"(?:chief-of-staff/)?runs/([^\s,;/]+)/(\d\d_review[\w-]*\.md)", re.I)
REVIEW_NAME = re.compile(r"\b(\d\d_review[\w-]*\.md)\b", re.I)
RUN_NAME = re.compile(r"\b(\d{4}-\d{2}-\d{2}-[A-Za-z0-9][\w-]*)\b")
LOG_ROWS = []  # the parsed decision log rows, for C12
CORRECTS = re.compile(r"^\s*corrects\s+(L\d+)", re.I)
LOG_TIME = re.compile(r"^\d{4}-\d{2}-\d{2}[ T]\d{1,2}:\d{2}\b")
SECRET = re.compile(r"(api[_-]?key|secret|password|passwd|token)\s*[:=]\s*\S{8,}", re.I)
DAILY_RUN = re.compile(r"-(morning|night)(-\d+)?$")


def fail(code, msg):
    FAILS.append(f"{code} FAIL: {msg}")


def table_rows(path):
    rows = []
    for line in path.read_text(encoding="utf-8").splitlines():
        s = line.strip()
        if not s.startswith("|") or set(s) <= set("|-: "):
            continue
        rows.append([c.strip() for c in s.strip("|").split("|")])
    return rows


def check_setup():
    p = HERE / "_shared" / "owner-profile.md"
    if not p.exists():
        fail("C1", "chief-of-staff/_shared/owner-profile.md is missing. Run setup.")
        return
    text = p.read_text(encoding="utf-8")
    holders = re.findall(r"\{\{([^}]*)\}\}", text)
    hires = [h for h in holders if h.strip().endswith("_installed")]
    left = len(holders) - len(hires)
    if left:
        fail("C1", f"owner profile still has {left} unanswered setup answer(s) (lines from the 18 setup questions, some questions fill two lines). Finish setup.")
    if hires:
        fail("C1", f"owner profile has {len(hires)} 'Installed hires' line(s) not filled yet (setup step 7 fills them, no question needed).")
    if "{{" in text and not holders:
        fail("C1", "owner profile still has a {{ placeholder. Finish setup.")
    if not re.search(r"^setup_done:\s*yes\s*$", text, re.M):
        fail("C1", "owner profile does not say setup_done: yes.")


def review_file_problem(evidence):
    """A T2 row names its saved review file (review rubric): runs/<run>/NN_review.md, which exists and ends 'Verdict: pass'.
    Empty string when fine."""
    m = REVIEW_PATH.search(evidence)
    if m:
        run, name = m.group(1), m.group(2)
    else:
        n, r = REVIEW_NAME.search(evidence), RUN_NAME.search(evidence)
        if not (n and r):
            return ("Evidence names no saved review file. Write its path after the review words, for example "
                    "'review: pass (separate), runs/2026-11-24-plate/09_review.md'.")
        run, name = r.group(1), n.group(1)
    p = HERE / "runs" / run / name
    if not p.exists():
        return f"the review file runs/{run}/{name} named in Evidence does not exist. Save the reviewer's verdict there (review-rubric.md)."
    lines = [ln.strip() for ln in p.read_text(encoding="utf-8").splitlines() if ln.strip()]
    if not lines or not re.match(r"^\W*verdict\s*:\s*pass\b", lines[-1], re.I):
        return f"runs/{run}/{name} does not end 'Verdict: pass', so the row cannot say review: pass."
    return ""


def check_decision_log():
    p = HERE / "_shared" / "decision-log.md"
    if not p.exists():
        fail("C2", "chief-of-staff/_shared/decision-log.md is missing.")
        return
    rows = table_rows(p)[1:]  # skip header
    good = []
    for cells in rows:
        if len(cells) != 8:
            fail("C2", f"row has {len(cells)} columns, needs 8. A pipe character in the text splits it: {' | '.join(cells)[:80]}")
            continue
        good.append(cells)

    # A row "corrects L<n>" clears every check on the earlier row(s) numbered L<n>.
    # It must name a row above it, never itself, or it would hide its own problems.
    corrected = set()
    above = set()
    for cells in good:
        own = cells[0].upper()
        m = CORRECTS.match(cells[2])
        if m:
            target = m.group(1).upper()
            if target in above and target != own:
                corrected.add(target)
            else:
                fail("C4", f"{cells[0]} says 'corrects {target}', but {target} is not a row above it. A 'corrects' row names an earlier row, never itself.")
        above.add(own)

    # The log is in time order. A row earlier than the row above it is flagged (a 'corrects' row for it clears the flag).
    last = None
    for cells in good:
        if not LOG_TIME.match(cells[1]) and cells[0].upper() not in corrected:
            fail("C4", f"{cells[0]}: Time '{cells[1]}' is not YYYY-MM-DD HH:MM. Check the clock (SR2) and add a 'corrects {cells[0]}' row with the full date and time.")
        m = re.search(r"(\d{4}-\d{2}-\d{2})?\D*?(\d{1,2}):(\d{2})", cells[1])
        if not m:
            continue
        key = (m.group(1) or "", int(m.group(2)) * 60 + int(m.group(3)))
        if last and key < last[0] and cells[0].upper() not in corrected:
            fail("C4", f"{cells[0]} is timed {cells[1]}, earlier than {last[1]} on {last[2]}, the row above it. The log is in time order. Add a 'corrects {cells[0]}' row with the right time.")
        last = (key, cells[1], cells[0])

    seen = set()
    for cells in good:
        num, _t, decision, tier, _w, evidence, words, result = cells
        key = num.upper()
        is_dup = key in seen
        seen.add(key)
        if key in corrected:
            continue  # a later "corrects" row replaces every row with this number
        if is_dup:
            fail("C4", f"{num} appears twice. Use the next number for a new row, or add a 'corrects {num}' row.")
        if tier not in ("T1", "T2", "T3"):
            fail("C2", f"{num}: tier '{tier}' is not T1, T2 or T3. Add a 'corrects {num}' row.")
        if result.lower() not in RESULTS:
            fail("C2", f"{num}: Result '{result}' is not done, pending, parked or no. Add a 'corrects {num}' row.")
        decision_text = CORRECTS.sub("", decision).lstrip(" :")
        claim = outward_claim(decision_text) if tier != "T3" and not OWNER_TASK.match(decision_text) else ""
        if claim:
            fail("C7", f"{num}: '{decision_text[:60]}' says the team did or does an outward action ('{claim.strip()[:50]}'), which reaches "
                       f"another person, the public or money, so it must be T3, not {tier}. Add a 'corrects {num}' row. "
                       "A row that only names, plans, drafts or negates the action is not flagged: write it that way if nothing went out.")
        if OWNER_TASK.match(decision_text) and AI_SENT.search(evidence):
            fail("C7", f"{num}: marked 'Owner task:' but Evidence says the AI sent it. Remove 'Owner task:' and set the tier to T3. Add a 'corrects {num}' row.")
        if tier == "T3" and result.lower() == "done" and words.strip().lower() in EMPTY_WORDS:
            fail("C3", f"{num}: T3 marked done without the owner's words. Ask the owner, or add a 'corrects {num}' row with Result pending.")
        if tier == "T2" and result.lower() == "done":
            if not REVIEW_PASS.search(evidence):
                fail("C8", f"{num}: yellow (T2) work marked done without 'review: pass' in Evidence. Run the review (review-rubric.md), then add a 'corrects {num}' row.")
            elif not REVIEW_TAG.search(evidence):
                fail("C8", f"{num}: Evidence says 'review: pass' without who reviewed. Write 'review: pass (separate)' or 'review: pass (self)', then the review file (decision-log.md). Add a 'corrects {num}' row.")
            else:
                problem = review_file_problem(evidence)
                if problem:
                    fail("C8", f"{num}: {problem} Add a 'corrects {num}' row once the review is saved.")
    LOG_ROWS[:] = good


def check_runs():
    runs = HERE / "runs"
    if not runs.exists():
        return
    today = owner_today(arg_today(), [HERE / "_shared" / "owner-profile.md"]).isoformat()
    for d in sorted(runs.iterdir()):
        if not d.is_dir() or d.name == "archive" or DAILY_RUN.search(d.name):
            continue
        if re.match(r"\d{4}-\d{2}-\d{2}", d.name) and d.name[:10] >= today:
            continue  # a run dated today (or later, in a replay) may still be open
        if ((d / "01_intake.md").exists() or (d / "07_plate.md").exists()) and not (d / "06_log.md").exists():
            fail("C5", f"runs/{d.name} has no 06_log.md. Close it with stages/06_log.")


def order_column(lines):
    """The P# of each numbered row of the first table in these lines, in order (a Rank, P#, ... table)."""
    head, out = None, []
    for line in lines:
        s = line.strip()
        if not s.startswith("|"):
            if head is not None:
                break
            continue
        if set(s) <= set("|-: "):
            continue
        cells = split_cells(s)
        if head is None:
            head = [c.lower() for c in cells]
            continue
        if "p#" in head and cells[0].isdigit() and head.index("p#") < len(cells):
            out.append(cells[head.index("p#")].upper())
    return out


def check_plate_runs():
    runs = HERE / "runs"
    if not runs.exists():
        return
    sys.path.insert(0, str(HERE / "scripts"))
    sys.dont_write_bytecode = True  # read only: leave no cache files behind
    try:
        import rank_plate
    except ImportError:
        fail("C9", "chief-of-staff/scripts/rank_plate.py is missing, so plate rankings cannot be checked.")
        return
    for f in sorted(runs.glob("*/08_rank*.md")):
        if f.parent.name == "archive":
            continue
        for problem in rank_plate.check_file(str(f)):
            fail("C9", f"runs/{f.parent.name}/{f.name}: {problem}.")
    # A weekly "keep" records its order and owner_review under "## Kept order" in 07_plate.md (stage 10).
    ranked_on = ""
    prio = HERE.parent / "handoffs" / "priorities.md"
    if prio.exists():
        m = re.search(r"^ranked_on:\s*(\d{4}-\d{2}-\d{2})", prio.read_text(encoding="utf-8"), re.M)
        ranked_on = m.group(1) if m else ""
    for f in sorted(runs.glob("*/07_plate.md")):
        if f.parent.name == "archive":
            continue
        used = (f.parent / "09_priorities.md").exists() or (ranked_on and f.parent.name.startswith(ranked_on))
        if not used:
            continue
        text = f.read_text(encoding="utf-8")
        m = re.search(r"^## Kept order\s*$(.*?)(?=^## |\Z)", text, re.M | re.S)
        if m and (f.parent / "09_priorities.md").exists():
            # The page shows the kept order (stage 09 step 2): a page written before the order changed is stale (C:P2-C9).
            kept = order_column(m.group(1).splitlines())
            page_text = (f.parent / "09_priorities.md").read_text(encoding="utf-8")
            full = re.search(r"^## The full order\s*$(.*?)(?=^## |\Z)", page_text, re.M | re.S)
            shown = order_column(full.group(1).splitlines()) if full else []
            if kept and shown and kept != shown:
                fail("C9", f"runs/{f.parent.name}/09_priorities.md shows the order {', '.join(shown)}, but the Kept order in 07_plate.md "
                           f"gives {', '.join(kept)}. Write the page again from the Kept order (stage 09 steps 1 to 3).")
        if not m or not re.search(r"Chief of Staff\s*:", m.group(1), re.I):
            continue
        why = "09_priorities.md exists" if (f.parent / "09_priorities.md").exists() else f"handoffs/priorities.md was ranked on {ranked_on}"
        review = re.search(r"^\W*owner_review\s*:\s*\W*(.*)$", m.group(1), re.M | re.I)
        if not review or not rank_plate.approved(review.group(1)):
            fail("C9", f"runs/{f.parent.name}/07_plate.md: the Kept order has picks by the Chief of Staff and {why}, "
                       "but owner_review does not say 'looks right YYYY-MM-DD HH:MM' with no change asked. An automatic kept order goes to the managers only after the owner reviews it (plate rule PL18).")
        verdict = f.parent / "10_review.md"
        last = [ln.strip() for ln in verdict.read_text(encoding="utf-8").splitlines() if ln.strip()][-1:] if verdict.exists() else []
        if not (last and re.match(r"^\W*verdict\s*:\s*pass\b", last[0], re.I)):
            fail("C9", f"runs/{f.parent.name}/07_plate.md: the Kept order has picks by the Chief of Staff and {why}, but runs/{f.parent.name}/10_review.md "
                       "is missing or does not end 'Verdict: pass'. The reviewer passes the reasons before the owner sees them (stage 10 section A step 6).")


PRIO_STATUS = re.compile(r"^(open|done|waiting\b.*)$", re.I)


def check_priorities():
    plate = HERE / "board" / "plate.md"
    if plate.exists():
        seen = set()
        for cells in table_rows(plate):
            p = cells[0].upper()  # only the Plate table starts its rows with a P number
            if re.fullmatch(r"P\d+", p):
                if p in seen:
                    fail("C10", f"board/plate.md: {p} is used twice. P numbers are never reused.")
                seen.add(p)
        # Changes since the last full ranking: Pairs answered is the number of letters written in the next cell (stage 10 section B step 5).
        section, head = "", None
        for line in plate.read_text(encoding="utf-8").splitlines():
            if line.startswith("## "):
                section, head = line[3:].strip().lower(), None
                continue
            s = line.strip()
            if not section.startswith("changes since") or not s.startswith("|") or set(s) <= set("|-: "):
                continue
            cells = [c.strip() for c in s.strip("|").split("|")]
            if head is None:
                head = [c.lower() for c in cells]
                continue
            ia = next((i for i, h in enumerate(head) if h.startswith("pairs answered")), None)
            il = next((i for i, h in enumerate(head) if h.startswith("letters")), None)
            if ia is None or il is None or max(ia, il) >= len(cells):
                continue
            letters = re.match(r"^\s*([NOno]+)\b", cells[il])
            if not letters or not cells[ia].isdigit():
                continue
            if int(cells[ia]) != len(letters.group(1)):
                fail("C10", f"board/plate.md: the Changes row for {cells[1] if len(cells) > 1 else '?'} says Pairs answered {cells[ia]}, "
                            f"but its letters '{letters.group(1)}' answer {len(letters.group(1))} pair(s). Write the number of letters (rank_plate.py light prints it).")
    p = HERE.parent / "handoffs" / "priorities.md"
    if not p.exists():
        return
    text = p.read_text(encoding="utf-8")
    head = re.match(r"^---\n(.*?)\n---", text, re.S)
    if not head:
        fail("C10", "handoffs/priorities.md has no header (from, updated, status).")
        return
    meta = dict(re.findall(r"^(\w+):\s*(.*)$", head.group(1), re.M))
    if meta.get("from", "").strip() != "chief-of-staff":
        fail("C10", "handoffs/priorities.md must say from: chief-of-staff.")
    if not re.match(r"\d{4}-\d{2}-\d{2}", meta.get("updated", "")):
        fail("C10", "handoffs/priorities.md: updated must start with a date, YYYY-MM-DD.")
    if not re.match(r"\d{4}-\d{2}-\d{2}", meta.get("ranked_on", "")):
        fail("C10", "handoffs/priorities.md: ranked_on must be the date of the last full ranking, YYYY-MM-DD.")
    if meta.get("status", "").strip() not in ("ok", "partial", "failed"):
        fail("C10", "handoffs/priorities.md: status must be ok, partial or failed.")
    if "{{" in text:
        fail("C10", "handoffs/priorities.md still has template text ({{).")
    section, ranks, pnums, held, rank_of = "", [], [], [], {}
    for line in text.splitlines():
        if line.startswith("## "):
            section = line[3:].strip().lower()
            continue
        s = line.strip()
        if not s.startswith("|") or set(s) <= set("|-: "):
            continue
        cells = [c.strip() for c in s.strip("|").split("|")]
        if section == "ranked" and cells[0].isdigit():
            ranks.append(int(cells[0]))
            pnums.append(cells[1].upper())
            rank_of[cells[1].upper()] = int(cells[0])
            status = cells[-1]
        elif section in ("must do by date", "new since the ranking") and re.fullmatch(r"P\d+", cells[0], re.I):
            pnums.append(cells[0].upper())
            status = cells[-1]
            if section == "new since the ranking" and status.lower().startswith("waiting: your picks"):
                held.append(cells[0].upper())
        else:
            continue
        if not PRIO_STATUS.match(status):
            fail("C10", f"handoffs/priorities.md: row {cells[0]} status '{status}' is not open, done or waiting: reason.")
    if ranks != list(range(1, len(ranks) + 1)):
        fail("C10", f"handoffs/priorities.md: ranks must run 1, 2, 3 with no gaps. Found {ranks}.")
    dups = sorted({x for x in pnums if pnums.count(x) > 1})
    if dups:
        fail("C10", f"handoffs/priorities.md: {', '.join(dups)} listed more than once.")
    # Rank cells of board/plate.md must match the ranking: a number equal to the Ranked rank, or "-" (or empty) for an unranked item.
    if plate.exists():
        phead = None
        for line in plate.read_text(encoding="utf-8").splitlines():
            s = line.strip()
            if not s.startswith("|") or set(s) <= set("|-: "):
                continue
            cells = [c.strip() for c in s.strip("|").split("|")]
            low = [c.lower() for c in cells]
            if "p#" in low and "rank" in low:
                phead = low.index("rank") if low[0] == "p#" else None
                continue
            if phead is None or phead >= len(cells) or not re.fullmatch(r"P\d+", cells[0], re.I):
                continue
            pn, rk = cells[0].upper(), cells[phead]
            want = rank_of.get(pn)
            if rk in ("", "-") and want is None:
                continue
            if rk.isdigit() and want is not None and int(rk) == want:
                continue
            fail("C10", f"board/plate.md: {pn} has Rank cell '{rk}' but handoffs/priorities.md ranks it "
                        f"{want if want is not None else 'nowhere (use - for an item that is not ranked)'}. The Rank cell holds only the number.")
    jobs = HERE.parent / "handoffs" / "jobs.md"
    if held and jobs.exists():
        rows = [ln for ln in jobs.read_text(encoding="utf-8").splitlines() if ln.strip().startswith("|")]
        for pn in held:
            if any(re.search(rf"\b{pn}\b", ln, re.I) for ln in rows):
                fail("C10", f"{pn} waits for the owner's picks, but handoffs/jobs.md already has a job for it. A new item is handed out only after the light path puts it in the top 3 (plate rule PL17).")


MONTHS = {m: i for i, m in enumerate(["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"], 1)}


def parse_due(text, today):
    """A date from a Due cell: YYYY-MM-DD, or 'Nov 27' / 'Fri Nov 27' / 'Dec 1, 2026' (the next one on or after today when no year). None if none."""
    m = re.search(r"(\d{4})-(\d{2})-(\d{2})", text)
    if m:
        try:
            return datetime.date(int(m.group(1)), int(m.group(2)), int(m.group(3)))
        except ValueError:
            return None
    m = re.search(r"\b(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\.?\s+(\d{1,2})(?:,?\s+(\d{4}))?", text, re.I)
    if not m:
        return None
    mon, day = MONTHS[m.group(1).lower()], int(m.group(2))
    try:
        if m.group(3):
            return datetime.date(int(m.group(3)), mon, day)
        d = datetime.date(today.year, mon, day)
        return d if d >= today - datetime.timedelta(days=30) else datetime.date(today.year + 1, mon, day)
    except ValueError:
        return None


DOER_OWNER = re.compile(r"\b(you|owner(?!'s|s\b)|chief[- ]of[- ]staff|time[- ]manager|not known|unknown)\b|\?", re.I)


def plate_run_in_progress():
    """True when the newest plate run has no 09_priorities.md yet (stage 09 step 12 gives the must jobs)."""
    runs = HERE / "runs"
    plates = sorted(d for d in runs.glob("*-plate*") if d.is_dir()) if runs.exists() else []
    return bool(plates) and not (plates[-1] / "09_priorities.md").exists()


def decided_d_numbers(board_text):
    """D numbers in the first cell of the board's Decided table (a D row moves there when the owner answers it)."""
    out, section, head = set(), "", None
    for line in board_text.splitlines():
        if line.startswith("## "):
            section, head = line[3:].strip().lower(), None
            continue
        s = line.strip()
        if not section.startswith("decided") or not s.startswith("|") or set(s) <= set("|-: "):
            continue
        cells = split_cells(s)
        if head is None:
            head = cells
            continue
        out.update(d.upper() for d in re.findall(r"\bD\d+\b", cells[0], re.I))
    return out


def check_musts():
    """C11 (PL21): an open must due within 14 days (or overdue), done by the owner or the Chief of Staff
    or by someone not known yet, has a 'Must P#' job."""
    plate = HERE / "board" / "plate.md"
    if not plate.exists():
        return
    today = owner_today(arg_today(), [HERE / "_shared" / "owner-profile.md"])
    jobs_p = HERE.parent / "handoffs" / "jobs.md"
    board_p = HERE / "board" / "board.md"
    jobs = jobs_p.read_text(encoding="utf-8") if jobs_p.exists() else ""
    board = board_p.read_text(encoding="utf-8") if board_p.exists() else ""
    in_progress = None
    answered = decided_d_numbers(board)
    for cells in table_rows(plate):
        if len(cells) < 13 or not re.fullmatch(r"P\d+", cells[0], re.I):
            continue
        pn = cells[0].upper()
        sort, goes, status, due = cells[9].lower(), cells[11].strip(), cells[12].strip().lower(), cells[4]
        wait_d = re.match(r"waiting\s*:\s*(d\d+)\b", status)
        if sort == "must" and wait_d and wait_d.group(1).upper() in answered:
            # The owner answered the D row (it moved to Decided), so the must no longer waits on it (stage 02 step 6).
            fail("C11", f"{pn} still says '{cells[12].strip()}', but {wait_d.group(1).upper()} is in the board's Decided table. "
                        f"On a yes set {pn} to open and, when it is due within 14 days, hand out 'Block [size] before [due] for Must {pn}: [item]' the same turn, "
                        f"on a no set it parked (stage 02 step 6, plate rule PL21).")
            continue
        if sort != "must" or status.startswith(("done", "parked", "waiting")):
            continue  # waiting (for example on a D answer), done and parked musts get no job yet. Any other status counts as open.
        d = parse_due(due, today)
        if d is None or d > today + datetime.timedelta(days=14):
            continue
        who = goes.split(":", 1)[0]  # "Email Manager: draft the note" names the doer before the colon
        if not who or who in ("-", "--"):
            if in_progress is None:
                in_progress = plate_run_in_progress()
            if in_progress:
                continue  # a plate ranking is still running: stage 09 fills Goes to and gives the job
        elif not DOER_OWNER.search(who):
            continue  # another person or the owner's team does it: no block (PL10)
        has_job = re.search(rf"Must {pn}\b", jobs, re.I)
        has_line = re.search(rf"block time before[^\n]*\b{pn}\b", board, re.I)
        if not (has_job or has_line):
            when = f"overdue since {d.isoformat()}" if d < today else f"due {d.isoformat()} (within 14 days)"
            fail("C11", f"{pn} is an open must {when} and has no 'Must {pn}' job in handoffs/jobs.md. Hand the Time Manager 'Block [size] before [due] for Must {pn}: [item]' (plate rule PL21).")


def split_cells(s):
    """Cells of one table line. A pipe written as \\| inside a cell does not split it."""
    return [c.strip() for c in re.split(r"(?<!\\)\|", s.strip().strip("|"))]


def check_board_tables():
    """C12: every board table row has as many cells as its header (board.md, plate.md, handoffs/jobs.md),
    and every open 'Your list' row has an 'Owner task:' log row naming its A# (decision-log.md)."""
    for p, label in ((HERE / "board" / "board.md", "board/board.md"), (HERE / "board" / "plate.md", "board/plate.md"),
                     (HERE.parent / "handoffs" / "jobs.md", "handoffs/jobs.md")):
        if not p.exists():
            continue
        head, section = None, ""
        for n, line in enumerate(p.read_text(encoding="utf-8").splitlines(), 1):
            s = line.strip()
            if line.startswith("## "):
                section = line[3:].strip()
            if not s.startswith("|"):
                head = None  # a table ends at the first line that is not a table line
                continue
            if set(s) <= set("|-: "):
                continue
            cells = split_cells(s)
            if head is None:
                head = cells
                continue
            if len(cells) != len(head):
                fail("C12", f"{label} line {n} ({section or 'table'}) has {len(cells)} cells, its header has {len(head)}. "
                            "Fill every cell (write - for an empty one) and replace a pipe in the text with a slash.")
    board = HERE / "board" / "board.md"
    if not board.exists():
        return
    section, head = "", None
    for line in board.read_text(encoding="utf-8").splitlines():
        if line.startswith("## "):
            section, head = line[3:].strip().lower(), None
            continue
        s = line.strip()
        if not section.startswith("your list") or not s.startswith("|") or set(s) <= set("|-: "):
            continue
        cells = split_cells(s)
        if head is None:
            head = cells
            continue
        a = cells[0].upper()
        if not re.fullmatch(r"A\d+", a) or not cells[-1].lower().startswith("open"):
            continue
        logged = any(OWNER_TASK.match(CORRECTS.sub("", r[2]).lstrip(" :")) and re.search(rf"\b{a}\b", r[2], re.I) for r in LOG_ROWS)
        if not logged:
            fail("C12", f"board Your list row {a} is open but no decision log row says '{a}: Owner task: ...'. "
                        "Every Your list row gets that log row the same turn (stage 02 step 4).")
    check_memo_rows(board.read_text(encoding="utf-8"))


MEMO_FILE = re.compile(r"bonus-watch-to-ai/memos/(\d{4}-\d{2}-\d{2}-\d{6}[\w-]*\.md)")


def check_memo_rows(board_text):
    """C12: a Watch memo handed over today (its file named in a logs/activity.md line dated today) has a board row
    that ends '(Watch memo <file name>)', so a memo run that wrote nothing on the board cannot pass."""
    act = HERE.parent / "logs" / "activity.md"
    if not act.exists():
        return
    today = owner_today(arg_today(), [HERE / "_shared" / "owner-profile.md"]).isoformat()
    named = []
    for line in act.read_text(encoding="utf-8").splitlines():
        cells = split_cells(line) if line.strip().startswith("|") else []
        if len(cells) < 5 or not cells[0].startswith(today):
            continue
        for name in MEMO_FILE.findall(line):
            if name not in named:
                named.append(name)
    for name in named:
        stem = name[:-3]
        if not re.search(r"Watch memo\s+" + re.escape(stem) + r"(?:\.md)?\b", board_text, re.I):
            fail("C12", f"logs/activity.md names the Watch memo {name} today, but no board row ends '(Watch memo {name})'. "
                        "Every memo gets its Inbox row on chief-of-staff/board/board.md (stage 01 step 3) before the run ends.")


def check_secrets():
    for p in (HERE / "_shared").glob("*.md"):
        for i, line in enumerate(p.read_text(encoding="utf-8").splitlines(), 1):
            if SECRET.search(line):
                fail("C6", f"_shared/{p.name} line {i} looks like a secret. Remove it. Secrets never go in these files.")


def main():
    check_setup()
    check_decision_log()
    check_runs()
    check_secrets()
    check_plate_runs()
    check_priorities()
    check_musts()
    check_board_tables()
    if FAILS:
        print("\n".join(FAILS))
        print(f"\n{len(FAILS)} check(s) failed.")
        return 1
    print("All checks passed (C1 to C12).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
