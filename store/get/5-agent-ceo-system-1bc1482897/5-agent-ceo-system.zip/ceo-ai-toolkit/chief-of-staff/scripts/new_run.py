#!/usr/bin/env python3
"""Start a run folder in chief-of-staff/runs/.

Usage (from the ceo-ai-toolkit folder):
    python3 chief-of-staff/scripts/new_run.py "short-name"   request run, gets the intake template
    python3 chief-of-staff/scripts/new_run.py morning        today's morning folder (reused if it exists)
    python3 chief-of-staff/scripts/new_run.py night          today's night folder (reused if it exists)
    python3 chief-of-staff/scripts/new_run.py plate          plate ranking run, gets 07_plate.md and 08_rank.md
    add --today YYYY-MM-DD (or --date, optionally "YYYY-MM-DD HH:MM") to date the run on a made-up day (tests, replays)
    add --now "YYYY-MM-DD HH:MM" to set both the date and the started: time (the same as --today with a time)

Works from any folder. Standard library only. Never overwrites an existing run.
The date and time come from the owner's time zone (the "Time zone:" line of the owner profile), else this computer's clock.
"""
import datetime
import re
import shutil
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent.parent  # the chief-of-staff folder
ZONE_NAMES = {"pacific": "America/Los_Angeles", "pst": "America/Los_Angeles", "pdt": "America/Los_Angeles", "mountain": "America/Denver", "mst": "America/Denver", "mdt": "America/Denver", "central": "America/Chicago", "cst": "America/Chicago", "cdt": "America/Chicago", "eastern": "America/New_York", "est": "America/New_York", "edt": "America/New_York", "utc": "UTC", "gmt": "UTC"}


def slug(text: str) -> str:
    text = re.sub(r"[^a-z0-9]+", "-", text.lower()).strip("-")
    return text[:40] or "run"


def owner_now(override=""):
    """Now in the owner's time zone. override is YYYY-MM-DD or "YYYY-MM-DD HH:MM" (tests, replays)."""
    now = datetime.datetime.now()
    try:
        from zoneinfo import ZoneInfo
        text = (HERE / "_shared" / "owner-profile.md").read_text(encoding="utf-8")
        m = re.search(r"^-?\s*Time zone[^:\n]*:([^\n]*)", text, re.M | re.I)
        name = ""
        if m:
            i = re.search(r"([A-Za-z]+/[A-Za-z_]+(?:/[A-Za-z_]+)?)", m.group(1))
            name = i.group(1) if i else next((ZONE_NAMES[w.lower()] for w in re.findall(r"[A-Za-z]+", m.group(1)) if w.lower() in ZONE_NAMES), "")
        if name:
            now = datetime.datetime.now(ZoneInfo(name))
    except Exception:
        pass
    if override:
        m = re.match(r"^(\d{4})-(\d{2})-(\d{2})(?:[ T](\d{1,2}):(\d{2}))?$", override.strip())
        if not m:
            raise SystemExit(f'STOP: --today takes YYYY-MM-DD or "YYYY-MM-DD HH:MM", not {override}. Nothing was made.')
        hh, mm = (int(m.group(4)), int(m.group(5))) if m.group(4) else (now.hour, now.minute)
        now = now.replace(year=int(m.group(1)), month=int(m.group(2)), day=int(m.group(3)), hour=hh, minute=mm, second=0, microsecond=0)
    return now


def main() -> int:
    args, override = [], ""
    i = 1
    while i < len(sys.argv):
        if sys.argv[i] in ("--today", "--date", "--now"):
            if i + 1 >= len(sys.argv):
                print(f"STOP: give a date after {sys.argv[i]}, for example {sys.argv[i]} 2026-11-24.")
                return 2
            override = sys.argv[i + 1]
            i += 2
            continue
        args.append(sys.argv[i])
        i += 1
    usage = 'Usage: python3 chief-of-staff/scripts/new_run.py "short-name" | morning | night | plate [--today YYYY-MM-DD] [--now "YYYY-MM-DD HH:MM"]'
    flags = [a for a in args if a.startswith("-")]
    if flags:
        # --help, -h or any other flag is never a run name: print the usage and make nothing.
        print(usage if flags[0] in ("-h", "--help") else f"STOP: {flags[0]} is not a run name or a known flag. Nothing was made.\n{usage}")
        return 0 if flags[0] in ("-h", "--help") else 2
    if not args:
        print(usage)
        return 2
    now = owner_now(override)
    kind = slug(args[0])
    runs = HERE / "runs"
    runs.mkdir(exist_ok=True)

    if kind in ("morning", "night"):
        target = runs / f"{now:%Y-%m-%d}-{kind}"
        if target.exists():
            print(f"Using existing chief-of-staff/runs/{target.name}")
        else:
            target.mkdir()
            print(f"Created chief-of-staff/runs/{target.name}")
        return 0

    name = f"{now:%Y-%m-%d}-{kind}"
    target = runs / name
    n = 2
    while target.exists():
        target = runs / f"{name}-{n}"
        n += 1
    shutil.copytree(HERE / "_templates" / ("plate" if kind == "plate" else "run"), target)
    for f in ("01_intake.md", "07_plate.md", "08_rank.md"):
        p = target / f
        if p.exists():
            text = p.read_text(encoding="utf-8")
            text = text.replace("{{run_name}}", target.name)
            text = text.replace("{{YYYY-MM-DD HH:MM}}", f"{now:%Y-%m-%d %H:%M}")
            p.write_text(text, encoding="utf-8")
    print(f"Created chief-of-staff/runs/{target.name}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
