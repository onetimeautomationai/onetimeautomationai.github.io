#!/usr/bin/env python3
"""Rank the "now" items on the owner's plate, two at a time (pairwise ranking).

Usage (from the ceo-ai-toolkit folder, works from any folder):
    python3 chief-of-staff/scripts/rank_plate.py start  RUN/08_rank.md          drop unused item rows and pairs, print the pair count
    python3 chief-of-staff/scripts/rank_plate.py next   RUN/08_rank.md [N]      how many pairs are answered, then the next N open pairs (default 9)
    python3 chief-of-staff/scripts/rank_plate.py answer RUN/08_rank.md LETTERS  fill the batch the owner saw, in order, for example ACADAEAFG
                                                                                (add --batch N when a lesson changed the batch size from 9)
    python3 chief-of-staff/scripts/rank_plate.py set    RUN/08_rank.md A-C C    change one pair (the owner flips a pick)
    python3 chief-of-staff/scripts/rank_plate.py tally  RUN/08_rank.md          count wins, break ties, find loops, write the ## Result table
    python3 chief-of-staff/scripts/rank_plate.py check  RUN/08_rank.md          read only: list problems, exit 1 if there are any

Automatic ranking (rank_mode: auto, plate rule PL18). The Chief of Staff picks, the owner reviews:
    python3 chief-of-staff/scripts/rank_plate.py auto   RUN/08_rank.md          read only: every open pair with all its facts, marked [facts missing], [facts equal]
                                                                                (no deciding fact by plate rule PL22) or [check why now] (only Why now differs)
    python3 chief-of-staff/scripts/rank_plate.py auto   RUN/08_rank.md PICKS    write the Chief of Staff's picks from a text file, one line per pair:
                                                                                A-B A: one-line reason from the recorded facts
    python3 chief-of-staff/scripts/rank_plate.py picks  RUN/08_rank.md          read only: every pair by number, with its winner, who picked it and why
    python3 chief-of-staff/scripts/rank_plate.py flip   RUN/08_rank.md 7 [12]   the owner flips pair 7 (and 12): the pick becomes theirs, then tally runs again
    python3 chief-of-staff/scripts/rank_plate.py clear  RUN/08_rank.md          the owner said "I'll pick": remove the Chief of Staff's picks, keep the owner's

Light path for one new item between full rankings (stage 10 section B), on handoffs/priorities.md:
    python3 chief-of-staff/scripts/rank_plate.py light  handoffs/priorities.md P21          print the pairs: N (the new item) against the open #3, #2, #1
    python3 chief-of-staff/scripts/rank_plate.py light  handoffs/priorities.md P21 NNO      place it from the owner's letters (- when there were no pairs)
                                                                                           (add --result "..." to set its result this week)
                                                                                           (add --by cos when the Chief of Staff picked: a letter for every pair)
                                                                                           (add --again to place it again after a flip: it leaves its place first)
    python3 chief-of-staff/scripts/rank_plate.py top    handoffs/priorities.md              read only: the top 3 the readers use, and rows waiting for picks

Any command takes --today YYYY-MM-DD (or --date, optionally with a time: --today "2026-11-24 08:00") to stamp
a made-up date in a test or a replay. Without it, the date and time come from the owner's time zone.

RUN is a plate run folder, for example chief-of-staff/runs/2026-11-20-plate/.
The run file has an "## Items" table (Key A to J, Item, P#, then the facts: Due, If it slips,
Who waits, Only you?, Size, Why now) and a "## Head-to-head" table with one row per pair
(| A-B | winner | by | reason |). By is "owner" or "chief of staff". Older files with only
| A-B | winner | still work.
Rules (chief-of-staff/_shared/plate-rules.md): most wins ranks first. Items with the same
wins are ordered by the pairs they won against each other. If that still ties (a loop,
A beat B, B beat C, C beat A), letter order is used and the owner picks the order.

Standard library only. Python 3.8 or newer. No Python? Do the same steps by hand
(chief-of-staff/scripts/README.md, "Ranking by hand").
"""
import datetime
import itertools
import re
import sys
from pathlib import Path

KEYS = "ABCDEFGHIJ"
PAIR_CELL = re.compile(r"^([A-J])-([A-J])$")
BY_OWNER = "owner"
BY_COS = "chief of staff"
UNKNOWN = ("", "?", "not given", "unknown")
STANDARD_BATCH = 9  # plate rule PL6


def cells_of(line):
    s = line.strip()
    if not s.startswith("|") or set(s) <= set("|-: "):
        return None
    return [c.strip() for c in s.strip("|").split("|")]


def is_cos(by):
    return by.strip().lower() in (BY_COS, "cos")


def front_matter(lines):
    """The key: value lines between the first two --- lines."""
    out = {}
    if lines and lines[0].strip() == "---":
        for line in lines[1:]:
            if line.strip() == "---":
                break
            if ":" in line:
                k, v = line.split(":", 1)
                out[k.strip().lower()] = v.strip()
    return out


def set_front(lines, key, value):
    """Set one front matter line (added before the closing --- if missing)."""
    if not lines or lines[0].strip() != "---":
        return lines
    for i in range(1, len(lines)):
        if lines[i].strip() == "---":
            return lines[:i] + [f"{key}: {value}"] + lines[i:]
        if lines[i].lower().startswith(key + ":"):
            lines[i] = f"{key}: {value}"
            return lines
    return lines


APPROVED = re.compile(r"^\W*looks right,?\s+\d{4}-\d{2}-\d{2}[ T]\d{1,2}:\d{2}\b", re.I)
CHANGE_ASKED = re.compile(r"\b(except|but|apart from|other than|flip|swap)\b", re.I)


def approved(value):
    """True only for owner_review: looks right YYYY-MM-DD HH:MM, "<words>", where the owner's words ask no change.
    "looks right except flip 3" is a flip first (stage 08 step A9), not an approval."""
    v = value.strip().strip('"')
    return bool(APPROVED.match(v)) and not CHANGE_ASKED.search(v)


def reopen_review(lines):
    """After the owner changes a pick: owner_review goes back to not yet, and a ranked file goes back to waiting for your review,
    so the route in chief-of-staff/CLAUDE.md (flip, looks right, show the picks) matches it again."""
    lines = set_front(lines, "owner_review", "not yet")
    if front_matter(lines).get("status", "").strip().strip('"').lower() == "ranked":
        lines = set_front(lines, "status", "waiting for your review")
    return lines


def missing_facts(facts):
    """Names of the facts that are not known (plate rule PL22: written ?, left empty, or not given).
    A Due with no date is written 'no date' (or none, -). If it slips is needed only when there is a date."""
    due = facts.get("due", "").strip().lower()
    no_date = due in ("-", "none", "no date")
    out = []
    for name, v in facts.items():
        low = v.strip().lower()
        if "{{" in v:
            low = ""
        if name == "due":
            if low in UNKNOWN:
                out.append(name)
        elif name == "if it slips" and no_date:
            continue
        elif low in UNKNOWN:
            out.append(name)
    return out


def labeled_facts(every):
    """Due, who waits and size with their labels, as stage 08 step 3 shows them: 'due Fri Nov 27, Harbor Grill waits, half a day'."""
    def val(name):
        v = every.get(name, "")
        return "" if "{{" in v else v.strip()
    out = []
    if "due" in every:
        d = val("due")
        low = d.lower()
        if low in ("-", "none", "no date"):
            out.append("no date")
        elif low in UNKNOWN:
            out.append("due date not known")
        else:
            out.append(d if low.startswith("due") else f"due {d}")
    if "who waits" in every:
        w = val("who waits")
        low = w.lower()
        if low in ("nobody", "none", "no one", "-"):
            out.append("nobody waits")
        elif low in UNKNOWN:
            out.append("who waits not known")
        else:
            out.append(w if low.endswith("waits") or low.endswith("wait") else f"{w} waits")
    if "size" in every:
        s = val("size")
        out.append("size not known" if s.lower() in UNKNOWN or s == "-" else s)
    return ", ".join(out)


FIVE = ("due", "who waits", "if it slips", "why now", "size")


def norm(v):
    return re.sub(r"\s+", " ", v.strip().lower().rstrip("."))


MONTHS = {m: i for i, m in enumerate(("jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"), 1)}
NO_DATE = ("none", "no date", "-")
NOBODY = ("nobody", "none", "no one", "-")
NO_COST = ("none", "no cost", "nothing", "no cost named", "-")
SIZES = (("under an hour", 1), ("less than an hour", 1), ("1 hour", 1), ("an hour", 1), ("half a day", 2),
         ("more than a day", 3), ("a day or more", 3), ("a full day", 3), ("1 day", 3))


def parse_day(text, today):
    """The date in a Due cell ("Fri Nov 27", "Dec 5", "January 15", "2026-12-05"), or None. The year is the
    next one that puts the date no more than 60 days in the past."""
    t = text.strip().lower()
    m = re.search(r"(\d{4})-(\d{2})-(\d{2})", t)
    if m:
        try:
            return datetime.date(int(m.group(1)), int(m.group(2)), int(m.group(3)))
        except ValueError:
            return None
    m = re.search(r"\b(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\.?\s+(\d{1,2})\b", t) or \
        re.search(r"\b(\d{1,2})\s+(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)", t)
    if not m:
        return None
    mon, day = (m.group(1), m.group(2)) if m.group(1).isalpha() else (m.group(2), m.group(1))
    for year in (today.year, today.year + 1):
        try:
            d = datetime.date(year, MONTHS[mon[:3]], int(day))
        except ValueError:
            return None
        if (d - today).days >= -60:
            return d
    return None


def fact_kind(name, value, today):
    """What a fact counts as in the PL22 reading order, so two values of the same kind are equal:
    Due: the date when it is within the next 30 days, else 'later' (a later date and no date are the same kind).
    Who waits: someone or nobody. If it slips: a cost or none. Size: 1, 2 or 3. Why now: its own words."""
    v = norm(value)
    if name == "due":
        if v in NO_DATE:
            return "later"
        d = parse_day(value, today)
        if d is None:
            return "text:" + v
        return d.isoformat() if (d - today).days <= 30 else "later"
    if name == "who waits":
        return "nobody" if v in NOBODY else "someone"
    if name == "if it slips":
        # Not missing here means the item has no date, so an unnamed cost is none (PL22).
        return "none" if v in NO_COST or v in UNKNOWN else "cost"
    if name == "size":
        return next((n for words, n in SIZES if v.startswith(words) or v == words), "text:" + v)
    return v


def same_kind(items, a, b, names):
    fa, fb = items[a]["all"], items[b]["all"]
    if not all(n in fa and n in fb for n in names):
        return False
    today = owner_now()[0].date()
    return all(fact_kind(n, fa[n], today) == fact_kind(n, fb[n], today) for n in names)


def facts_equal(items, a, b):
    """True when no fact decides the pair (plate rule PL22, facts equal): every deciding fact is known for both and the
    same KIND in the reading order (both dates in 30 days the same day or both later, both someone waits or both
    nobody, both a cost or both none, the same size), and the Why now words are the same."""
    if items[a]["missing"] or items[b]["missing"]:
        return False
    return same_kind(items, a, b, FIVE[:3] + FIVE[4:]) and same_kind(items, a, b, ("why now",))


def why_now_decides(items, a, b):
    """True when Due, Who waits and If it slips are the same kind and the Why now words differ (Size comes after
    Why now in the PL22 reading order, so it does not matter here). Then the pair turns on PL22 step 4 (does Why now
    name goal 1's result?), which only the Chief of Staff can judge. If neither or both do, Size decides or the pair is open."""
    if items[a]["missing"] or items[b]["missing"]:
        return False
    return same_kind(items, a, b, FIVE[:3]) and not same_kind(items, a, b, ("why now",))


def deciding_fact(items, a, b):
    """The first fact in the PL22 reading order (Due, Who waits, If it slips, Why now, Size) that is known for both
    items and differs in kind, skipping a missing fact. '' when none does (an open pair). 'why now' means the
    Chief of Staff judges PL22 step 4 there."""
    fa, fb = items[a]["all"], items[b]["all"]
    miss = set(items[a]["missing"]) | set(items[b]["missing"])
    today = owner_now()[0].date()
    for n in FIVE:
        if n in miss or n not in fa or n not in fb:
            continue
        if fact_kind(n, fa[n], today) != fact_kind(n, fb[n], today):
            return n
    return ""


def p_number(items, k):
    m = re.search(r"\d+", items[k].get("p", ""))
    return int(m.group(0)) if m else None


def load(path):
    """Read the run file. Returns lines, items, pairs.
    items: {key: {"text": str, "facts": str, "all": {name: value}, "missing": [names], "line": int}}
    pairs: {(a, b): {"winner": str, "by": str, "reason": str, "line": int}} in file order, only pairs whose two items exist.
    pairs and raw_pairs also carry "width": the number of columns in the Head-to-head table."""
    with open(path, encoding="utf-8") as f:
        lines = f.read().split("\n")
    section, header = "", None
    items, raw_pairs, dup_pairs = {}, {}, []
    for i, line in enumerate(lines):
        if line.startswith("## "):
            section, header = line[3:].strip().lower(), None
            continue
        cells = cells_of(line)
        if cells is None:
            continue
        if section.startswith("items"):
            if header is None:
                header = [c.lower() for c in cells]
                continue
            key = cells[0]
            if len(key) != 1 or key not in KEYS:
                continue
            text = cells[1] if len(cells) > 1 else ""
            if not text or "{{" in text:
                continue  # unused row
            every = {}
            for n, name in enumerate(header):
                if name in ("key", "item", "p#") or not name:
                    continue
                every[name] = cells[n] if n < len(cells) else ""
            pnum = cells[header.index("p#")] if "p#" in header and header.index("p#") < len(cells) else ""
            items[key] = {"text": text, "facts": labeled_facts(every), "all": every, "p": pnum.strip().upper(),
                          "missing": missing_facts(every), "line": i}
        elif section.startswith("head-to-head"):
            m = PAIR_CELL.match(cells[0])
            if not m:
                if header is None:
                    header = [c.lower() for c in cells]
                continue
            a, b = m.group(1), m.group(2)
            h = header or ["pair", "winner"]
            get = lambda name: cells[h.index(name)] if name in h and h.index(name) < len(cells) else ""
            winner = cells[1].upper() if len(cells) > 1 else ""
            if (a, b) in raw_pairs:
                dup_pairs.append(f"{a}-{b}")
            raw_pairs[(a, b)] = {"winner": winner, "by": get("by"), "reason": get("reason"),
                                 "line": i, "width": len(h)}
    pairs = {p: v for p, v in raw_pairs.items() if p[0] in items and p[1] in items}
    return lines, items, pairs, raw_pairs, dup_pairs


def pair_line(a, b, winner, by, reason, width):
    """One Head-to-head row, with By and Reason when the table has them."""
    if width >= 4:
        return f"| {a}-{b} | {winner} | {by} | {reason.replace('|', '/')} |"
    return f"| {a}-{b} | {winner} |"


def save(path, lines):
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))


def label(items, k):
    it = items[k]
    return f"{k} ({it['text']}{', ' + it['facts'] if it['facts'] else ''})"


def full_label(items, k):
    """The item with every recorded fact, named, for the Chief of Staff's own picks."""
    it = items[k]
    facts = "; ".join(f"{n}: {v if v.strip() and '{{' not in v else '(empty)'}" for n, v in it["all"].items())
    return f"{k} ({it['text']}{'; ' + facts if facts else ''})"


def pair_number(pairs, pair):
    return list(pairs).index(pair) + 1


def open_pairs(pairs):
    return [p for p, v in pairs.items() if not v["winner"]]


def cmd_start(path):
    lines, items, pairs, raw_pairs, _ = load(path)
    if len(items) < 2:
        sys.exit("STOP: fewer than 2 items in the Items table. Nothing to rank.")
    drop = set()
    section = ""
    for i, line in enumerate(lines):
        if line.startswith("## "):
            section = line[3:].strip().lower()
            continue
        cells = cells_of(line)
        if cells is None:
            continue
        if section.startswith("items") and len(cells[0]) == 1 and cells[0] in KEYS and cells[0] not in items:
            drop.add(i)
        if section.startswith("head-to-head"):
            m = PAIR_CELL.match(cells[0])
            if m and (m.group(1) not in items or m.group(2) not in items):
                drop.add(i)
    save(path, [l for i, l in enumerate(lines) if i not in drop])
    n = len(items)
    print(f"{n} items, {n * (n - 1) // 2} pairs. Removed {len(drop)} unused rows.")
    cmd_next(path)


def cmd_next(path, n=9):
    _, items, pairs, _, _ = load(path)
    if len(items) < 2:
        print("Fewer than 2 items in the Items table. Fill it from the now items first (stage 08 step 1).")
        return
    todo = open_pairs(pairs)
    print(f"{len(pairs) - len(todo)}/{len(pairs)} pairs answered")
    for num, (a, b) in enumerate(todo[:n], 1):
        print(f"{num}. {a}-{b}: {label(items, a)}  vs  {label(items, b)}")
    if todo:
        k = len(todo[:n])
        print(f"Show these {k} pair(s) and ask for exactly {k} letter(s), one per pair shown. "
              f"Save the reply with: answer {path} LETTERS --batch {k} (keep --batch {k} until these pairs are filled, also after a STOP).")
    else:
        print("All pairs answered. Next: tally.")


def clean_letters(text, path, batch):
    """Letters A to J from the owner's reply. Spaces, commas, periods, dashes and pair numbers are ignored."""
    stripped = re.sub(r"[\s,.;:\-()0-9]", "", text)
    bad = re.sub(r"[A-Ja-j]", "", stripped)
    if bad:
        print(f"STOP: the reply has characters that are not item letters ({bad[:10]}). Nothing was written. Show these pairs again and ask for letters only, one per pair, in order (never show the owner an example string):")
        cmd_next(path, batch)
        sys.exit(1)
    return stripped.upper()


def cmd_answer(path, text, batch=9):
    lines, items, pairs, _, _ = load(path)
    todo = open_pairs(pairs)[:batch]  # only the pairs the owner was shown
    letters = clean_letters(text, path, batch)
    written, stop = 0, ""
    for (a, b), w in zip(todo, letters):
        if w not in (a, b):
            stop = f"STOP: {w} is not in pair {a}-{b} ({label(items, a)} vs {label(items, b)}). {written} answer(s) before it were saved. Nothing after it was written."
            break
        v = pairs[(a, b)]
        lines[v["line"]] = pair_line(a, b, w, BY_OWNER, "", v["width"])
        written += 1
    save(path, lines)
    if stop:
        print(stop)
        print(f"Show the owner only the {len(todo) - written} pair(s) left from the batch they saw, starting with this one, and ask for those letters:")
        cmd_next(path, len(todo) - written)
        sys.exit(1)
    if len(letters) > len(todo):
        print(f"Note: {len(letters) - len(todo)} extra letter(s) ignored. Only {len(todo)} pair(s) were shown.")
    elif len(letters) < len(todo):
        print(f"Note: {len(todo) - len(letters)} pair(s) from this batch still need a letter. They come first in the next batch.")
        cmd_next(path, batch)
        return
    # The batch the owner saw is complete (a leftover batch after a STOP too): the next batch is a full one again.
    if batch < STANDARD_BATCH:
        print(f"This batch is complete. The next batch is back to {STANDARD_BATCH} pairs (a lesson that set another size: run next {path} N).")
    cmd_next(path, max(batch, STANDARD_BATCH))


def cmd_set(path, pair, winner):
    lines, items, pairs, _, _ = load(path)
    m = PAIR_CELL.match(pair.upper())
    w = winner.strip().upper()
    if not m:
        sys.exit("STOP: write the pair like A-C.")
    a, b = m.group(1), m.group(2)
    if (a, b) not in pairs:
        a, b = b, a
    if (a, b) not in pairs:
        sys.exit(f"STOP: pair {pair.upper()} is not in this run.")
    if w not in (a, b):
        sys.exit(f"STOP: {w} is not in pair {a}-{b}.")
    v = pairs[(a, b)]
    lines[v["line"]] = pair_line(a, b, w, BY_OWNER, flip_reason(v, w, (a, b)), v["width"])
    auto = file_mode(lines) == "auto" or any(is_cos(x["by"]) for x in pairs.values())
    save(path, reopen_review(lines) if auto else lines)
    print(f"{a}-{b} is now {w}, picked by the owner. Run tally again.")


def file_mode(lines):
    """manual, auto or '' from the mode line of the front matter (a # note after it is ignored)."""
    return re.sub(r"\s#.*$", "", front_matter(lines).get("mode", "")).strip().strip('"').strip().lower()


def flip_reason(v, new_winner, pair=None):
    """Reason kept on a pair the owner changed, so the Chief of Staff's pick stays visible.
    A winner that was not in the pair (a broken row being repaired) leaves no reason."""
    if pair and v["winner"] and v["winner"] not in pair:
        return ""
    if not v["winner"] or v["winner"] == new_winner:
        return v["reason"] if not is_cos(v["by"]) else ""
    if is_cos(v["by"]):
        return f"you flipped it. The Chief of Staff had picked {v['winner']}: {v['reason']}"
    return "you changed your own pick"


# ---- Automatic ranking (plate rule PL18): the Chief of Staff picks, the owner reviews ----

LIST_POSITION = re.compile(r"\blisted\s+(?:first|second|last|after|before|earlier|later|above|below)\b|\bletter order\b|\b(?:first|earlier|higher|lower)\s+in\s+the\s+list\b", re.I)
PICK_LINE = re.compile(r"^\s*(?:\d+\s*[.)]\s*)?([A-Ja-j])\s*-\s*([A-Ja-j])\s*[:,]?\s+([A-Ja-j])\s*[:\-]\s*(.*)$")


def pair_missing(items, a, b):
    """'A: size; B: who waits' for the facts missing in a pair, or ''."""
    parts = [f"{k}: {', '.join(items[k]['missing'])}" for k in (a, b) if items[k]["missing"]]
    return "; ".join(parts)


def cmd_auto(path, picks_file=None):
    lines, items, pairs, _, _ = load(path)
    if len(items) < 2:
        sys.exit("STOP: fewer than 2 items in the Items table. Fill it first (stage 08 step 1), then run start.")
    width = next(iter(pairs.values()))["width"] if pairs else 2
    if width < 4:
        sys.exit("STOP: the Head-to-head table has no By and Reason columns, so the Chief of Staff's picks cannot be shown with their reasons. "
                 "Add them: make the header | Pair | Winner | By | Reason | and add two empty cells at the end of each pair row (template: chief-of-staff/_templates/plate/08_rank.md).")
    mode = file_mode(lines)
    if owner_rank_mode() == "manual":
        sys.exit("STOP: the owner profile says rank_mode: manual, so the owner picks every pair. Nothing was written. "
                 "Only 'Rank it for me' switches it to auto (stage 08 step 0). Ask the pairs with next and answer.")
    if mode != "auto":  # the list form too (C:P2-C11): a manual file is never judged by the Chief of Staff
        sys.exit(f"STOP: this file says mode: {mode or '(none)'}, not mode: auto, so the owner picks every pair. Nothing was written. "
                 "Set mode: auto in the front matter only after the owner chose it: 'Rank it for me', or the default at stage 08 step 0 "
                 "(rank_mode: auto in the owner profile).")
    if picks_file is None:
        todo = open_pairs(pairs)
        crit = front_matter(lines).get("criterion", "").strip('"') or "the question in this file"
        print(f"{len(pairs) - len(todo)}/{len(pairs)} pairs answered. Judge every open pair on: {crit}")
        flagged = decided = equal = why = 0
        for a, b in todo:
            miss = pair_missing(items, a, b)
            # PL22: a missing fact is skipped, so the first known fact that differs still decides (A:P2-C9).
            decider = deciding_fact(items, a, b) if miss else ""
            same = not miss and facts_equal(items, a, b)
            only_why = (not miss and not same and why_now_decides(items, a, b)) or decider == "why now"
            flagged += bool(miss) and not decider
            decided += bool(miss) and bool(decider) and decider != "why now"
            equal += same
            why += only_why
            note = ""
            if miss:
                note = f", {decider} decides" if decider and decider != "why now" else ("" if decider else ", no known fact decides")
            print(f"{pair_number(pairs, (a, b))}. {a}-{b}: {full_label(items, a)}  vs  {full_label(items, b)}"
                  + (f"  [facts missing: {miss}{note}]" if miss else "") + ("  [facts equal]" if same else "")
                  + ("  [check why now]" if only_why else ""))
        if not todo:
            print("All pairs answered. Next: tally.")
            return
        print(f"Write one line per pair in a text file, for example chief-of-staff/runs/<run>/08_picks.txt:  A-B A: <one-line reason from the facts above>")
        if decided:
            print(f"{decided} pair(s) have a fact missing, but a known fact still decides them (marked '<fact> decides', plate rule PL22): "
                  "they are yours to pick, also with the owner here. Start the reason with 'facts missing:', name the missing fact, "
                  "then the deciding fact, for example 'facts missing: size of B. A due Fri Nov 27, B has no date'.")
        if flagged or equal:
            print(f"{flagged} pair(s) have facts missing and no known fact decides them, and {equal} have no deciding fact (the same kind "
                  "of Due, Who waits, If it slips and Size, and the same Why now, plate rule PL22). Owner here: leave them out and ask "
                  "them as pairs (stage 08 step A5). Nobody here: pick them by plate rule PL22 (the lower P# wins an open pair), "
                  "and start the reason with 'facts missing:' or 'facts equal:'.")
        if why:
            print(f"{why} pair(s) are marked [check why now]: Due, Who waits and If it slips are the same kind (or missing), so Why now "
                  "decides (PL22 step 4) when one item's words name goal 1's result and the other's do not. Name it in the reason "
                  "('why now: ...'). When neither or both name it, Size decides when it is known for both and differs, otherwise "
                  "the pair is open: start with 'facts equal:' (or 'facts missing:') and use the tie rule, or ask the owner.")
        print(f"Then run: rank_plate.py auto {path} <that file>")
        return
    try:
        raw = Path(picks_file).read_text(encoding="utf-8").split("\n")
    except OSError as e:
        sys.exit(f"STOP: cannot read {picks_file}: {e}")
    picks, problems, seen = [], [], set()
    for n, line in enumerate(raw, 1):
        s = line.strip()
        if not s or s.startswith("#"):
            continue
        m = PICK_LINE.match(s)
        if not m:
            problems.append(f"line {n} is not 'A-B A: reason': {s[:60]}")
            continue
        a, b, w, reason = m.group(1).upper(), m.group(2).upper(), m.group(3).upper(), m.group(4).strip()
        if (a, b) not in pairs:
            a, b = b, a
        if (a, b) not in pairs:
            problems.append(f"line {n}: pair {m.group(1).upper()}-{m.group(2).upper()} is not in this run")
            continue
        if (a, b) in seen:
            problems.append(f"line {n}: pair {a}-{b} is picked twice")
            continue
        seen.add((a, b))
        if w not in (a, b):
            problems.append(f"line {n}: {w} is not in pair {a}-{b}")
            continue
        if len(reason.split()) < 3:
            problems.append(f"line {n}: pair {a}-{b} needs a one-line reason from the recorded facts (at least 3 words)")
            continue
        if LIST_POSITION.search(reason):
            problems.append(f"line {n}: pair {a}-{b} leans on list position ('{LIST_POSITION.search(reason).group(0)}'). A pick names a fact (plate rule PL22). For equal facts start with 'facts equal:' and use the tie rule")
            continue
        miss = pair_missing(items, a, b)
        if miss and not reason.lower().startswith("facts missing"):
            problems.append(f"line {n}: pair {a}-{b} has facts missing ({miss}). Start the reason with 'facts missing:', for example 'facts missing: size of B. ...'")
            continue
        pa, pb = p_number(items, a), p_number(items, b)
        lower = (a if pa < pb else b) if pa is not None and pb is not None and pa != pb else None
        if not miss and facts_equal(items, a, b):
            if not reason.lower().startswith("facts equal"):
                problems.append(f"line {n}: pair {a}-{b} has no deciding fact (the same kind of every fact, plate rule PL22). Start the reason with 'facts equal:' and the facts both share, or leave it out and ask the owner")
                continue
            if lower and w != lower:
                problems.append(f"line {n}: pair {a}-{b} has every fact the same, so the lower P# ({items[lower]['p']}, {lower}) wins (plate rule PL22 tie rule), not {w}")
                continue
        elif not miss and why_now_decides(items, a, b):
            low = reason.lower()
            if low.startswith("facts equal"):
                if not same_kind(items, a, b, ("size",)):
                    problems.append(f"line {n}: pair {a}-{b} has a different Size, so when neither or both Why now name goal 1's result, "
                                    "Size decides (the smaller item wins, plate rule PL22 step 5). Name it ('why now: neither names a sale. Size: ...')")
                    continue
                if lower and w != lower:
                    problems.append(f"line {n}: pair {a}-{b} is open (neither or both Why now name goal 1's result), so the lower P# ({items[lower]['p']}, {lower}) wins (plate rule PL22 tie rule), not {w}")
                    continue
            elif "why now" not in low:
                problems.append(f"line {n}: pair {a}-{b} turns on Why now (Due, Who waits and If it slips are the same kind, plate rule PL22). "
                                "Name Why now in the reason ('why now: A names a sale, B does not', or 'why now: neither names a sale. Size: ...'), "
                                "or start with 'facts equal:' when neither or both name goal 1's result and the sizes are the same")
                continue
        picks.append((a, b, w, reason))
    if problems:
        print("STOP: nothing was written. Fix these lines and run auto again:")
        print("\n".join("- " + p for p in problems))
        sys.exit(1)
    written, kept = 0, []
    for a, b, w, reason in picks:
        v = pairs[(a, b)]
        if v["winner"] and not is_cos(v["by"]):
            kept.append(f"{a}-{b}")
            continue
        lines[v["line"]] = pair_line(a, b, w, BY_COS, reason, v["width"])
        written += 1
    lines = set_front(lines, "owner_review", "not yet")
    save(path, lines)
    print(f"{written} pick(s) written by the Chief of Staff.")
    if kept:
        print(f"Kept the owner's own pick on {', '.join(kept)} (an owner's pick is never replaced).")
    _, items, pairs, _, _ = load(path)
    todo = open_pairs(pairs)
    if todo:
        print(f"{len(todo)} pair(s) still open: {', '.join(f'{pair_number(pairs, p)} {p[0]}-{p[1]}' for p in todo)}. "
              "Owner here: ask them as pairs, numbered from 1, and save the letters with answer --batch N. Then tally.")
    else:
        print("All pairs answered. Next: tally, then the review (stage 08 step A7). Not final until the owner says it looks right.")


def cmd_picks(path):
    _, items, pairs, _, _ = load(path)
    print("Every pair, by number. Say 'flip 7' to change pair 7.")
    for n, ((a, b), v) in enumerate(pairs.items(), 1):
        if not v["winner"]:
            print(f"{n}. {label(items, a)} vs {label(items, b)}: open")
            continue
        loser = b if v["winner"] == a else a
        who = "Chief of Staff" if is_cos(v["by"]) else "you"
        why = f": {v['reason']}" if v["reason"] else ""
        print(f"{n}. {items[v['winner']]['text']} over {items[loser]['text']} ({v['winner']} over {loser}, picked by {who}){why}")


def cmd_flip(path, nums):
    lines, items, pairs, _, _ = load(path)
    order = list(pairs)
    done = []
    for raw in nums:
        if not raw.strip().isdigit() or not 1 <= int(raw) <= len(order):
            sys.exit(f"STOP: {raw} is not a pair number. Pairs run 1 to {len(order)} (rank_plate.py picks lists them). Nothing was written.")
    for raw in nums:
        a, b = order[int(raw) - 1]
        v = pairs[(a, b)]
        if not v["winner"]:
            sys.exit(f"STOP: pair {raw} ({a}-{b}) has no pick yet, so there is nothing to flip. Nothing was written.")
    for raw in nums:
        a, b = order[int(raw) - 1]
        v = pairs[(a, b)]
        w = b if v["winner"] == a else a
        lines[v["line"]] = pair_line(a, b, w, BY_OWNER, flip_reason(v, w), v["width"])
        done.append(f"pair {raw} {a}-{b} is now {w} ({items[w]['text']})")
    lines = reopen_review(lines)
    save(path, lines)
    print("Flipped: " + ". ".join(done) + ". Picked by the owner. Counting again:")
    cmd_tally(path)


def cmd_clear(path):
    lines, items, pairs, _, _ = load(path)
    n = 0
    for (a, b), v in pairs.items():
        if v["winner"] and is_cos(v["by"]):
            lines[v["line"]] = pair_line(a, b, "", "", "", v["width"])
            n += 1
    for key, value in (("status", "battling"), ("mode", "manual"), ("owner_review", "not yet")):
        lines = set_front(lines, key, value)
    body = "\n".join(lines)
    if n:
        body = re.sub(r"\n## Result\n.*?(?=\n## |\Z)", "", body, flags=re.S).rstrip() + "\n"
    with open(path, "w", encoding="utf-8") as f:
        f.write(body)
    # The picks file keeps its lines for the record, each marked "# cleared", so a later auto run cannot write them back.
    picks = Path(path).with_name(Path(path).name.replace("08_rank", "08_picks").rsplit(".", 1)[0] + ".txt")
    cleared = 0
    if picks.exists():
        old = picks.read_text(encoding="utf-8").split("\n")
        new = []
        for line in old:
            if line.strip() and not line.strip().startswith("#"):
                new.append("# cleared: " + line)
                cleared += 1
            else:
                new.append(line)
        picks.write_text("\n".join(new), encoding="utf-8")
    # A saved review of the removed picks no longer describes this file: mark it superseded at the top, so its
    # last line (the verdict the decision log row points at) stays as it was, but nobody reads it as current.
    review = Path(path).with_name(Path(path).name.replace("08_rank", "08_review"))
    superseded = ""
    if n and review.exists():
        old = review.read_text(encoding="utf-8")
        if not old.startswith("Superseded"):
            stamp = owner_now()[0].strftime("%Y-%m-%d %H:%M")
            review.write_text(f"Superseded {stamp}: the owner chose to pick the pairs (rank_plate.py clear removed the {n} pick(s) this review covered). "
                              "It reviews no pick in the current file.\n\n" + old, encoding="utf-8")
            superseded = (f" Marked {review.name} superseded. Add a decision log row 'corrects L#: the Chief of Staff's picks were cleared, "
                          "the owner picks the pairs' (T1, the owner's words, Result done) for the T2 row that names it.")
    print(f"Removed {n} pick(s) made by the Chief of Staff. The owner's own picks stay. Front matter: status battling, mode manual."
          + (f" Marked {cleared} line(s) of {picks.name} '# cleared'." if picks.exists() else "")
          + superseded
          + f" Next: rank_plate.py next {path}")


def winner_of(pairs, x, y):
    v = pairs.get((x, y)) or pairs.get((y, x))
    return v["winner"] if v else ""


def rank(items, pairs):
    """Returns wins, order, h2h (wins against items with the same total), loops (keys the owner must order)."""
    keys = sorted(items)
    wins = {k: 0 for k in keys}
    for v in pairs.values():
        if v["winner"] in wins:
            wins[v["winner"]] += 1
    h2h = {}
    for k in keys:
        same = [o for o in keys if o != k and wins[o] == wins[k]]
        h2h[k] = sum(1 for o in same if winner_of(pairs, k, o) == k)
    order = sorted(keys, key=lambda k: (-wins[k], -h2h[k], k))
    loops = [k for k in keys if any(o != k and wins[o] == wins[k] and h2h[o] == h2h[k] for o in keys)]
    return wins, order, h2h, loops


def cycles(items, pairs):
    """Every set of three items where each beat one and lost to one (A beat B, B beat C, C beat A)."""
    out = []
    for x, y, z in itertools.combinations(sorted(items), 3):
        a, b, c = winner_of(pairs, x, y), winner_of(pairs, y, z), winner_of(pairs, x, z)
        if a == x and b == y and c == z:
            out.append((x, y, z))  # x beat y, y beat z, z beat x
        elif a == y and b == z and c == x:
            out.append((x, z, y))  # x beat z, z beat y, y beat x
    return out


def notes_for(order, wins, h2h, loops, pairs):
    notes = {}
    for k in order:
        same = [o for o in order if o != k and wins[o] == wins[k]]
        if not same:
            notes[k] = ""
        elif k in loops:
            tied = [o for o in same if h2h[o] == h2h[k]]
            notes[k] = f"loop with {', '.join(tied)}: owner picks the order"
        elif len(same) == 1:
            o = same[0]
            notes[k] = f"tied with {o}, {'won' if winner_of(pairs, k, o) == k else 'lost'} their pair"
        else:
            notes[k] = f"tied with {', '.join(same)}, ordered by wins among them ({h2h[k]})"
    return notes


def cmd_tally(path):
    lines, items, pairs, _, _ = load(path)
    if len(items) < 2:
        sys.exit("STOP: fewer than 2 items. Nothing to rank.")
    todo = open_pairs(pairs)
    if todo:
        sys.exit(f"STOP: {len(todo)} pair(s) unanswered: {', '.join(a + '-' + b for a, b in todo[:10])}")
    wins, order, h2h, loops = rank(items, pairs)
    # The owner's own order inside a tied loop (stage 08 step 10) survives a new tally while the group is the same.
    old_result = re.search(r"\n## Result\n(.*?)(?=\n## |\Z)", "\n".join(lines), flags=re.S)
    picked = [[x.strip() for x in m.group(1).split(",")]
              for m in re.finditer(r"Owner picked the order:\s*([A-J](?:\s*,\s*[A-J])*)\s*\.", old_result.group(1) if old_result else "")]
    groups = {}  # one group per tied loop: same wins and same wins among them
    for k in order:
        if k in loops:
            groups.setdefault((wins[k], h2h[k]), []).append(k)
    kept = []
    for g in groups.values():
        mine = next((p for p in picked if sorted(p) == sorted(g)), None)
        if mine:
            slots = sorted(order.index(k) for k in g)
            for slot, k in zip(slots, mine):
                order[slot] = k
            kept.append(mine)
    notes = notes_for(order, wins, h2h, loops, pairs)
    loop3 = cycles(items, pairs)
    top = set(order[:3])
    top_loops = [c for c in loop3 if top & set(c)]
    res = ["## Result", "",
           f"Written by `rank_plate.py tally` on {owner_now()[0].date().isoformat()}. {len(items)} items, {len(pairs)} pairs.", "",
           "| Rank | Key | Item | Wins | Note |", "|---|---|---|---|---|"]
    res += [f"| {r + 1} | {k} | {items[k]['text']} | {wins[k]} | {notes[k]} |" for r, k in enumerate(order)]
    res += ["", f"Loops in the picks (three items that each beat one and lost to one): {len(loop3)}."]
    if top_loops:
        res.append("Loops that touch the top 3: " + " Also: ".join(f"{a} beat {b}, {b} beat {c}, {c} beat {a}." for a, b, c in top_loops[:3]))
    open_groups = [g for g in groups.values() if not any(sorted(g) == sorted(m) for m in kept)]
    if open_groups:
        res.append("Owner picks the order inside each group, one group at a time (the order question only, never keep or flip): "
                   + ". Separately: ".join(", ".join(g) for g in open_groups)
                   + " (same wins and same wins among them). Letter order is used until the owner picks.")
    for m in kept:
        res.append(f"Owner picked the order: {', '.join(m)}.")
    if not groups:
        res.append("Owner to order: none. Every tie was settled by the pairs.")
    by_cos = sum(1 for v in pairs.values() if is_cos(v["by"]))
    flipped = sum(1 for v in pairs.values() if not is_cos(v["by"]) and v["reason"].lower().startswith("you flipped it"))
    answered = len(pairs) - by_cos - flipped
    if by_cos or flipped:
        ok = approved(front_matter(lines).get("owner_review", ""))
        res.append(f"Picked by: {answered} pair(s) answered by the owner, {flipped} flipped by the owner, {by_cos} by the Chief of Staff. "
                   + ("" if ok else "Not final until the owner reads it and says it looks right (plate rule PL18). ")
                   + "Every pick with its reason: rank_plate.py picks.")
    else:
        # Stage 09 step 3 copies this line, also when the owner made every pick ("you, two at a time").
        res.append(f"Picked by: {answered} pair(s) answered by the owner, 0 flipped by the owner, 0 by the Chief of Staff.")
    body = "\n".join(lines)
    body = re.sub(r"\n## Result\n.*?(?=\n## |\Z)", "", body, flags=re.S).rstrip() + "\n\n" + "\n".join(res) + "\n"
    with open(path, "w", encoding="utf-8") as f:
        f.write(body)
    print("\n".join(res))
    if not TODAY_OVERRIDE[0]:
        print(f"\nThe footer date {owner_now()[0].date().isoformat()} is from the clock. In a replay or a test on a made-up day, run tally again with --today YYYY-MM-DD.")
    if front_matter(lines).get("status", "").strip().strip('"').lower() == "battling":
        print("\nNext (stage 08): read the order back with every tie (step 9), ask any loop once (step 10), "
              "then run check and set status: ranked (step 12, in auto mode only after the owner says it looks right), "
              "then the decision log row (step 14).")


def check_file(path):
    """Problems with a run file, as a list of strings. Empty list = fine. Used by check_gates.py (C9)."""
    problems = []
    try:
        lines, items, pairs, raw_pairs, dups = load(path)
    except OSError as e:
        return [f"cannot read: {e}"]
    for d in dups:
        problems.append(f"pair {d} is listed twice")
    for (a, b), v in raw_pairs.items():
        if v["winner"] and v["winner"] not in (a, b):
            problems.append(f"pair {a}-{b} has winner '{v['winner']}', which is not in the pair. Ask the owner that one pair again "
                            f"(its pair number, both items with their facts), write the letter with: rank_plate.py set chief-of-staff/runs/{Path(path).parent.name}/{Path(path).name} {a}-{b} <letter> "
                            "(by hand: Winner cell, By owner), then run tally (scripts/README.md)")
        if v["winner"] and v["width"] >= 4:
            if not v["by"].strip():
                problems.append(f"pair {a}-{b} has a winner but no By (owner or chief of staff)")
            elif v["by"].strip().lower() != BY_OWNER and not is_cos(v["by"]):
                problems.append(f"pair {a}-{b} says By '{v['by']}'. It must be owner or chief of staff")
            elif is_cos(v["by"]) and len(v["reason"].split()) < 3:
                problems.append(f"pair {a}-{b} was picked by the Chief of Staff with no reason. Every automatic pick needs a one-line reason (plate rule PL18)")
    cos_picks = sum(1 for v in pairs.values() if v["winner"] and is_cos(v["by"]))
    review = front_matter(lines).get("owner_review", "")
    page = (Path(path).parent / "09_priorities.md").exists()
    if cos_picks and page and not approved(review):
        problems.append(f"the Chief of Staff picked {cos_picks} pair(s) and 09_priorities.md exists, but owner_review does not say "
                        "'looks right YYYY-MM-DD HH:MM' with words that ask no change. "
                        "An automatic ranking goes to the managers only after the owner reviews it (plate rule PL18)")
    status = front_matter(lines).get("status", "").strip().strip('"').lower()
    if cos_picks and status in ("ranked", "waiting for your review"):
        problems += review_problems(path, cos_picks, status)
    if page and status == "ranked" and (not cos_picks or approved(review)):
        problems += stale_page_problems(path, lines, items)
    still_open = open_pairs(pairs)
    if page and pairs and not still_open and status != "ranked":
        problems.append(f"every pair is answered and 09_priorities.md exists, but the file says status '{status}'. "
                        "Stage 08 step 12: run check, then set status: ranked (auto mode: after the owner's looks right)")
    if still_open and (status in ("ranked", "waiting for your review") or (Path(path).parent / "09_priorities.md").exists()):
        problems.append(f"{len(still_open)} pair(s) still have no winner, for example {still_open[0][0]}-{still_open[0][1]}, "
                        f"but the file says status '{status}'" + (" and 09_priorities.md exists" if (Path(path).parent / "09_priorities.md").exists() else "")
                        + ". Every pair needs a pick before the ranking is used")
    n = len(items)
    missing = [f"{a}-{b}" for a, b in itertools.combinations(sorted(items), 2) if (a, b) not in pairs]
    if missing and n >= 2:
        problems.append(f"{len(missing)} pair row(s) missing, for example {missing[0]}")
    # Result table, if written, must follow from the pairs
    rows, in_result = [], False
    for line in lines:
        if line.startswith("## "):
            in_result = line[3:].strip().lower().startswith("result")
            continue
        c = cells_of(line)
        if in_result and c and c[0].isdigit():
            rows.append(c)
    if rows:
        if open_pairs(pairs):
            problems.append("a Result table is written but some pairs are still empty")
            return problems
        wins, _, h2h, _ = rank(items, pairs)
        keys = [r[1] if len(r) > 1 else "" for r in rows]
        if sorted(keys) != sorted(items):
            problems.append("the Result table does not list every item exactly once")
            return problems
        for r in rows:
            k = r[1]
            try:
                w = int(r[3])
            except (IndexError, ValueError):
                problems.append(f"Result row for {k} has no wins number")
                continue
            if w != wins[k]:
                problems.append(f"Result says {k} has {w} wins, the pairs give {wins[k]}. Run tally again")
        for (r1, k1), (r2, k2) in zip(enumerate(keys), list(enumerate(keys))[1:]):
            if (wins[k1], h2h[k1]) < (wins[k2], h2h[k2]):
                problems.append(f"Result puts {k1} above {k2}, but the pairs rank {k2} higher. Change a pair with 'set', then run tally again")
        ranks = [r[0] for r in rows]
        if ranks != [str(i) for i in range(1, len(rows) + 1)]:
            problems.append("Result ranks are not 1, 2, 3 in order")
    return problems


def last_line(p):
    try:
        lines = [ln.strip() for ln in Path(p).read_text(encoding="utf-8").splitlines() if ln.strip()]
    except OSError:
        return None
    return lines[-1] if lines else ""


def review_problems(path, cos_picks, status):
    """An automatic ranking shown to the owner (waiting for your review, or ranked) has its saved review (stage 08 step A7):
    08_review.md whose last line is 'Verdict: pass', or 'Verdict: fail' after two fails with the T3 row that says so."""
    review = Path(path).with_name(Path(path).name.replace("08_rank", "08_review"))
    last = last_line(review)
    if last is None:
        return [f"the Chief of Staff picked {cos_picks} pair(s) and the file says status '{status}', but {review.name} does not exist. "
                "An automatic ranking is reviewed before the owner sees it, and the verdict is saved (stage 08 step A7)"]
    run = Path(path).parent.name
    rows = log_rows(Path(path).resolve().parents[2] / "_shared" / "decision-log.md")
    names_run = lambda r: run in " ".join(r)
    if re.match(r"^\W*verdict\s*:\s*pass\b", last, re.I):
        # The pass is logged: a T2 row whose Evidence names this run's review file (stage 08 step A7).
        if any(r[3].upper() == "T2" and names_run(r) and review.name in r[5] for r in rows):
            return []
        return [f"{review.name} ends 'Verdict: pass', but no T2 decision log row names runs/{run}/{review.name}. "
                f"Add the row 'Chief of Staff ranked N plate items for the owner's review', T2, Evidence 'review: pass (separate), runs/{run}/{review.name}, M of M pairs' "
                "(stage 08 step A7)"]
    if re.match(r"^\W*verdict\s*:\s*fail\b", last, re.I):
        # Red after two fails: a T3 row for THIS run, shown to the owner with the notes (stage 08 step A7).
        if any(r[3].upper() == "T3" and re.search(r"failed review twice", r[2], re.I) and names_run(r) for r in rows):
            return []
        return [f"{review.name} ends 'Verdict: fail', and the decision log has no T3 row 'Chief of Staff's ranking failed review twice' "
                f"naming runs/{run}. Fix what the reviewer listed and review again, or follow the red path in stage 08 step A7 "
                f"(Evidence: runs/{run}/{review.name})"]
    return [f"{review.name} does not end with 'Verdict: pass' or 'Verdict: fail' (review rubric)"]


def log_rows(log):
    """The decision log's 8-cell rows (L#, Time, Decision, Tier, Why, Evidence, Owner's words, Result), or [] when there is none."""
    try:
        text = log.read_text(encoding="utf-8")
    except OSError:
        return []
    out = []
    for line in text.split("\n"):
        c = cells_of(line)
        if c and len(c) == 8 and re.fullmatch(r"L\d+", c[0], re.I):
            out.append(c)
    return out


def stale_page_problems(path, lines, items):
    """09_priorities.md must show the order of the Result table it was written from. After a flip and a new looks right,
    the page is written again (stage 09 step 1)."""
    name = Path(path).name
    section = "the full order" if name == "08_rank.md" else ("personal" if name == "08_rank-personal.md" else None)
    if section is None:
        return []
    result, in_result = [], False
    for line in lines:
        if line.startswith("## "):
            in_result = line[3:].strip().lower().startswith("result")
            continue
        c = cells_of(line)
        if in_result and c and c[0].isdigit() and len(c) > 1 and c[1] in items:
            result.append(items[c[1]]["p"])
    try:
        page = (Path(path).parent / "09_priorities.md").read_text(encoding="utf-8").split("\n")
    except OSError:
        return []
    shown, here, head = [], False, None
    for line in page:
        if line.startswith("## "):
            here = line[3:].strip().lower().startswith(section)
            head = None
            continue
        c = cells_of(line)
        if not here or c is None:
            continue
        if head is None:
            head = [x.lower() for x in c]
            continue
        if "p#" in head and c[0].isdigit() and head.index("p#") < len(c):
            shown.append(c[head.index("p#")].upper())
    if result and shown and all(result) and shown != result:
        return [f"09_priorities.md shows the order {', '.join(shown)}, but the Result of {name} gives {', '.join(result)}. "
                "The page is from an older order: write it again from stage 09 step 1 after the owner's new looks right"]
    return []


def cmd_check(path):
    problems = check_file(path)
    if problems:
        print("\n".join("Problem: " + p for p in problems))
        sys.exit(1)
    print("Run file OK.")
    lines, _, pairs, _, _ = load(path)
    fm = front_matter(lines)
    if pairs and not open_pairs(pairs) and fm.get("status", "").strip().strip('"').lower() == "battling":
        if any(is_cos(v["by"]) for v in pairs.values()) and not approved(fm.get("owner_review", "")):
            print("Reminder: every pair is answered. Status stays battling until the owner says it looks right (stage 08 step A10), then set status: ranked.")
        else:
            print("Reminder: every pair is answered and the status still says battling. Set status: ranked now (stage 08 step 12), then log it (step 14).")


# ---- Light path on handoffs/priorities.md (stage 10 section B, plate rules PL13 and PL17) ----

WAITING_PICKS = "waiting: your picks"


def is_open(status):
    s = status.strip().lower()
    return not (s == "done" or s.startswith("waiting"))


def prio_rows(lines):
    """Ranked and New since the ranking rows of handoffs/priorities.md.
    Each row: {"line", "cells", "p", "status"} (Ranked rows also "rank").
    heads: column names per section. last: the last table line of each section."""
    section, ranked, new, heads, last = "", [], [], {}, {}
    for i, line in enumerate(lines):
        if line.startswith("## "):
            section = line[3:].strip().lower()
            continue
        if section not in ("ranked", "new since the ranking"):
            continue
        s = line.strip()
        if s.startswith("|"):
            last[section] = i
        cells = cells_of(line)
        if cells is None:
            continue
        if section == "ranked" and cells[0].isdigit():
            ranked.append({"line": i, "cells": cells, "rank": int(cells[0]), "p": cells[1].upper(), "status": cells[-1]})
        elif section == "new since the ranking" and re.fullmatch(r"P\d+", cells[0], re.I):
            new.append({"line": i, "cells": cells, "p": cells[0].upper(), "status": cells[-1]})
        elif section not in heads:
            heads[section] = [c.lower() for c in cells]
    return ranked, new, heads, last


def reading_order(ranked, new):
    """What the readers use: open Ranked rows by rank, then open New since the ranking rows as listed."""
    return [r for r in sorted(ranked, key=lambda r: r["rank"]) if is_open(r["status"])] + [n for n in new if is_open(n["status"])]


def row_line(cells):
    return "| " + " | ".join(cells) + " |"


def plate_facts(p):
    """Who does it, due, who waits and size for P# from chief-of-staff/board/plate.md, '-' when unknown.
    Who does it is the part of the Goes to cell before any colon ("Email Manager: draft the note" gives "Email Manager")."""
    facts = {"who": "-", "due": "-", "waits": "-", "size": "-", "missing": ["every fact (no row in chief-of-staff/board/plate.md)"]}
    plate = Path(__file__).resolve().parent.parent / "board" / "plate.md"
    if not plate.exists():
        return facts
    header = None
    for line in plate.read_text(encoding="utf-8").split("\n"):
        cells = cells_of(line)
        if cells is None:
            continue
        if cells[0].lower() == "p#" and header is None:
            header = [c.lower() for c in cells]
            continue
        if header and cells[0].upper() == p and len(cells) == len(header):
            for name, key in (("goes to", "who"), ("due", "due"), ("who waits", "waits"), ("size", "size")):
                if name in header and cells[header.index(name)]:
                    facts[key] = cells[header.index(name)]
            # The deciding facts on the board (plate rule PL22). "Only you?" is shown but never decides, so it is never
            # "missing". An empty or "-" cell is missing, like "?": a Due with no date is written "no date".
            seen = {n: cells[header.index(n)] for n in ("due", "who waits", "size") if n in header}
            facts["missing"] = [n for n, v in seen.items() if v.strip().lower() in UNKNOWN + ("-",) or "{{" in v]
            break
    who = facts["who"].strip()
    m = re.match(r"you\s*\([^)]*\)", who, re.I)  # "you (who does it: asked)" stays whole (plate rule PL17)
    facts["who"] = m.group(0) if m else (who.split(":")[0].strip() or "-")
    return facts


def facts_text(p):
    f = plate_facts(p)
    d, w, s = f["due"].strip(), f["waits"].strip(), f["size"].strip()
    if d.lower() in UNKNOWN + ("-",):
        due = "due date not known"
    elif d.lower() in ("none", "no date"):
        due = "no date"
    else:
        due = d if d.lower().startswith("due") else f"due {d}"
    if w.lower() in ("none", "nobody", "no one"):
        waits = "nobody waits"
    elif w.lower() in UNKNOWN + ("-",):
        waits = "who waits not known"
    else:
        waits = f"{w} waits"
    size = "size not known" if s.lower() in UNKNOWN + ("-",) else s
    return f"{due}, {waits}, {size}"


ZONE_NAMES = {"pacific": "America/Los_Angeles", "pst": "America/Los_Angeles", "pdt": "America/Los_Angeles", "mountain": "America/Denver", "mst": "America/Denver", "mdt": "America/Denver", "central": "America/Chicago", "cst": "America/Chicago", "cdt": "America/Chicago", "eastern": "America/New_York", "est": "America/New_York", "edt": "America/New_York", "utc": "UTC", "gmt": "UTC"}


def owner_zone_name(text):
    """The zone named on the 'Time zone:' line: an IANA name (America/Chicago) or a common name (Pacific, PST, Eastern). Empty if none."""
    m = re.search(r"^-?\s*Time zone[^:\n]*:([^\n]*)", text, re.M | re.I)
    if not m:
        return ""
    line = m.group(1)
    i = re.search(r"([A-Za-z]+/[A-Za-z_]+(?:/[A-Za-z_]+)?)", line)
    if i:
        return i.group(1)
    for w in re.findall(r"[A-Za-z]+", line):
        if w.lower() in ZONE_NAMES:
            return ZONE_NAMES[w.lower()]
    return ""


def owner_rank_mode():
    """auto or manual, from the rank_mode line of the owner profile. Auto when not set."""
    profile = Path(__file__).resolve().parent.parent / "_shared" / "owner-profile.md"
    try:
        m = re.search(r"^-?\s*rank_mode\s*:\s*(auto|manual)", profile.read_text(encoding="utf-8"), re.M | re.I)
        return m.group(1).lower() if m else "auto"
    except OSError:
        return "auto"


TODAY_OVERRIDE = [""]  # set from --today / --date on the command line


def take_today_flag(argv):
    """Remove --today VALUE (or --date VALUE) from argv and keep VALUE. Returns the rest of argv."""
    out, i = [], 0
    while i < len(argv):
        if argv[i] in ("--today", "--date"):
            if i + 1 >= len(argv):
                sys.exit(f"STOP: give a date after {argv[i]}, for example {argv[i]} 2026-11-24. Nothing was written.")
            TODAY_OVERRIDE[0] = argv[i + 1]
            i += 2
            continue
        out.append(argv[i])
        i += 1
    return out


def owner_now():
    """Now in the owner's time zone (the 'Time zone:' line of the owner profile), else this computer's clock.
    With --today YYYY-MM-DD the date is that day (the time is the clock's, or the one given as "YYYY-MM-DD HH:MM")."""
    profile = Path(__file__).resolve().parent.parent / "_shared" / "owner-profile.md"
    now, clock = datetime.datetime.now(), "this computer's clock (no time zone in the owner profile)"
    try:
        from zoneinfo import ZoneInfo
        name = owner_zone_name(profile.read_text(encoding="utf-8"))
        if name:
            now, clock = datetime.datetime.now(ZoneInfo(name)), "the owner's time zone"
    except Exception:
        pass
    if TODAY_OVERRIDE[0]:
        m = re.match(r"^(\d{4})-(\d{2})-(\d{2})(?:[ T](\d{1,2}):(\d{2}))?$", TODAY_OVERRIDE[0].strip())
        if not m:
            sys.exit(f"STOP: --today takes YYYY-MM-DD or \"YYYY-MM-DD HH:MM\", not {TODAY_OVERRIDE[0]}. Nothing was written.")
        y, mo, d = int(m.group(1)), int(m.group(2)), int(m.group(3))
        hh, mm = (int(m.group(4)), int(m.group(5))) if m.group(4) else (now.hour, now.minute)
        now = now.replace(year=y, month=mo, day=d, hour=hh, minute=mm, second=0, microsecond=0)
        clock = "the --today date given"
    return now, clock


def read_prio(path):
    if not Path(path).exists():
        sys.exit(f"STOP: {path} does not exist. There is no ranking yet, so there is no light path. Hand the item out as before (stage 02 step 8).")
    with open(path, encoding="utf-8") as f:
        return f.read().split("\n")


def say_top(ranked, new):
    top = reading_order(ranked, new)[:3]
    return ", ".join(f"{r['p']} ({r['cells'][2] if 'rank' in r else r['cells'][1]})" for r in top) or "none open"


def cmd_top(path):
    lines = read_prio(path)
    ranked, new, _, _ = prio_rows(lines)
    top = reading_order(ranked, new)[:3]
    print("Top 3 (open Ranked rows by rank, then open New since the ranking rows):")
    for n, r in enumerate(top, 1):
        where = f"Ranked #{r['rank']}" if "rank" in r else "New since the ranking"
        print(f"{n}. {r['p']} {r['cells'][2] if 'rank' in r else r['cells'][1]} ({where})")
    if not top:
        print("none open")
    waiting = [n["p"] for n in new if n["status"].strip().lower().startswith(WAITING_PICKS)]
    print("Waiting for the owner's picks: " + (", ".join(waiting) if waiting else "none"))


def take_out(lines, ranked, heads, last, r, today):
    """Move a Ranked row back under New since the ranking (to place it again after a flip).
    Rows ranked below it move up one rank number, which undoes the earlier placement."""
    out = list(lines)
    for o in ranked:
        if o["rank"] > r["rank"]:
            cells = list(o["cells"])
            cells[0] = str(o["rank"] - 1)
            out[o["line"]] = row_line(cells)
    hr = heads["ranked"]
    item = r["cells"][hr.index("item")] if "item" in hr else r["cells"][2]
    cells = []
    for name in heads["new since the ranking"]:
        if name == "p#":
            cells.append(r["p"])
        elif name == "item":
            cells.append(item)
        elif name == "placed":
            cells.append(f"taken out of rank {r['rank']} on {today} to place again")
        elif name.startswith("status"):
            cells.append(WAITING_PICKS)
        else:
            cells.append("-")
    del out[r["line"]]
    at = last["new since the ranking"] - (1 if r["line"] < last["new since the ranking"] else 0) + 1
    return out[:at] + [row_line(cells)] + out[at:]


def cmd_light(path, p, letters=None, result=None, by=None, again=False):
    lines = read_prio(path)
    ranked, new, heads, last = prio_rows(lines)
    p = p.upper()
    cos = bool(by) and is_cos(by)
    if by and not cos and by.strip().lower() != BY_OWNER:
        sys.exit("STOP: --by takes cos (the Chief of Staff picked) or owner. Nothing was written.")
    old = next((r for r in ranked if r["p"] == p), None)
    old_result = None
    old_top = [r["p"] for r in reading_order(ranked, new)[:3]]  # the top 3 before anything moves
    if old:
        if not again:
            sys.exit(f"STOP: {p} is already in the Ranked table. To place it again after the owner flips a pick, add --again. Nothing was written.")
        if "new since the ranking" not in heads or "ranked" not in heads:
            sys.exit("STOP: handoffs/priorities.md needs both the Ranked and New since the ranking tables. Nothing was written.")
        hr = heads["ranked"]
        rc = [i for i, name in enumerate(hr) if name.startswith("result")]
        if rc and rc[0] < len(old["cells"]) and not old["cells"][rc[0]].startswith("not set yet"):
            old_result = old["cells"][rc[0]]
        lines = take_out(lines, ranked, heads, last, old, owner_now()[0].date().isoformat())
        ranked, new, heads, last = prio_rows(lines)
        if letters is None:
            print(f"{p} is at rank {old['rank']}. With --again it first leaves that place (nothing is written until the letters are given). Its pairs from there:")
        else:
            print(f"{p} left rank {old['rank']} and the rows below it moved up one, as before it was placed. Placing it again:")
    row = next((n for n in new if n["p"] == p), None)
    if row is None or "new since the ranking" not in heads or "ranked" not in heads:
        sys.exit(f"STOP: {p} is not under \"New since the ranking\". For a \"now\" item, add it there first with Status `{WAITING_PICKS}` (stage 10 section B step 1). A must, a later or a no item takes no pairs. Nothing was written.")
    item = row["cells"][1]
    opens = [r for r in sorted(ranked, key=lambda r: r["rank"]) if is_open(r["status"])][:3]
    pairs = list(reversed(opens))  # #3 first, then #2, then #1
    if letters is None:
        if not pairs:
            print(f"No ranked item is open, so there are no pairs. {p} becomes #1. Place it with: rank_plate.py light {path} {p} -")
            return
        today = owner_now()[0].date()
        for n, o in enumerate(pairs, 1):
            fn, fo = plate_facts(p), plate_facts(o["p"])
            miss = [f"{x}: {', '.join(f['missing'])}" for x, f in ((p, fn), (o["p"], fo)) if f["missing"]]
            # PL22: a missing fact is skipped, so a known Due or Who waits that differs still decides the pair.
            decider = ""
            no_row = any(m.startswith("every fact") for m in fn["missing"] + fo["missing"])
            for name, key in (() if no_row else (("due", "due"), ("who waits", "waits"))):
                if name in fn["missing"] or name in fo["missing"]:
                    continue
                if fact_kind(name, fn[key], today) != fact_kind(name, fo[key], today):
                    decider = name
                    break
            print(f"{n}. N ({item}, {facts_text(p)}) vs O (#{o['rank']} {o['p']}: {o['cells'][2]}, {facts_text(o['p'])})"
                  + (f"  [facts missing: {'; '.join(miss)}{', ' + decider + ' decides' if decider else ''}]" if miss else ""))
        print("The board has no If it slips or Why now. Read them from the sources in plate rule PL22 (the newest plate run's 07_plate.md "
              "for a ranked item, the owner's own words for the new item). A fact found in no source is missing too.")
        print(f"Reply with {len(pairs)} letter(s), N or O, for example {'N' * (len(pairs) - 1)}O.")
        if owner_rank_mode() == "manual":
            print(f"Manual ranking (rank_mode: manual): show the pairs to the owner, ask for the letters, then run light {path} {p} LETTERS. Never fill a pair for them.")
        else:
            print(f"Automatic ranking (rank_mode: auto): the Chief of Staff gives a letter and a one-line reason for every pair, then runs light {path} {p} LETTERS --by cos.")
        return
    clean = re.sub(r"[\s,.;:\-()0-9]", "", letters).upper()
    bad = re.sub(r"[NO]", "", clean)
    if bad:
        sys.exit(f"STOP: the reply has characters other than N and O ({bad[:10]}). Nothing was written. Show the pairs again and ask for N or O only.")
    if cos and len(clean) < len(pairs):
        sys.exit(f"STOP: with --by cos, give a letter for every pair ({len(pairs)}), even after the first O, so the owner can flip any of them. Nothing was written.")
    wins = 0
    for n in range(len(pairs)):
        if n >= len(clean):
            sys.exit(f"STOP: pair {n + 1} has no letter and every pair before it was won by N. Nothing was written. Ask pair {n + 1} again.")
        if clean[n] == "O":
            break
        wins += 1
    if len(clean) > len(pairs):
        print(f"Note: {len(clean) - len(pairs)} extra letter(s) ignored. Only {len(pairs)} pair(s) were shown.")
    now, clock = owner_now()
    today = now.date().isoformat()
    out = list(lines)
    if pairs and wins == 0:
        cells = list(row["cells"])
        h = heads["new since the ranking"]
        if "placed" in h and h.index("placed") < len(cells):
            cells[h.index("placed")] = f"below the top 3 on {today}{' (Chief of Staff picks)' if cos else ''}, ranked at the next weekly re-rank"
        cells[-1] = "open"
        out[row["line"]] = row_line(cells)
        print(f"{p} lost to #{pairs[0]['rank']} ({pairs[0]['p']}). It stays under \"New since the ranking\", below the top 3. Status open.")
    else:
        target = pairs[wins - 1]["rank"] if pairs else (min((r["rank"] for r in ranked), default=1))
        facts = plate_facts(p)
        new_cells = []
        for name in heads["ranked"]:
            if name == "rank":
                new_cells.append(str(target))
            elif name == "p#":
                new_cells.append(p)
            elif name == "item":
                new_cells.append(item)
            elif name.startswith("who"):
                new_cells.append(facts["who"])
            elif name == "due":
                new_cells.append(facts["due"])
            elif name == "size":
                new_cells.append(facts["size"])
            elif name.startswith("result"):
                new_cells.append(result or old_result or "not set yet: write one")
            elif name.startswith("status"):
                new_cells.append("open")
            else:
                new_cells.append("-")
        for r in ranked:
            if r["rank"] >= target:
                cells = list(r["cells"])
                cells[0] = str(r["rank"] + 1)
                out[r["line"]] = row_line(cells)
        below = [r["line"] for r in ranked if r["rank"] >= target]
        insert_at = min(below) if below else last["ranked"] + 1
        out = out[:insert_at] + [row_line(new_cells)] + out[insert_at:]
        shift = 1 if row["line"] >= insert_at else 0
        del out[row["line"] + shift]
        beat = ", ".join(f"#{o['rank']}" for o in pairs[:wins]) or "no pairs"
        print(f"{p} placed at rank {target} ({'beat ' + beat if pairs else beat}). The rows from rank {target} down moved down one.")
        if not (result or old_result):
            print(f"Write its result this week in its Ranked row (it says \"not set yet: write one\").")
    stamp = now.strftime("%Y-%m-%d %H:%M")
    if out and out[0].strip() == "---":
        for i in range(1, len(out)):
            if out[i].strip() == "---":
                break
            if out[i].startswith("updated:"):
                out[i] = f"updated: {stamp}"
    save(path, out)
    ranked2, new2, _, _ = prio_rows(out)
    new_top = [r["p"] for r in reading_order(ranked2, new2)[:3]]
    print(f"Top 3 now: {say_top(ranked2, new2)}.")
    order = [r["p"] for r in reading_order(ranked2, new2)]
    used = clean[:len(pairs)] if cos else clean[:min(len(pairs), wins + 1)]
    print(f"Pairs answered: {len(used)}. In the row of \"Changes since the last full ranking\" write {len(used)} under Pairs answered and the letters "
          f"{used or '-'} in the next cell (one letter per pair, so the number and the letters always agree, check C10).")
    if pairs and wins == 0:
        print(f"Tell the owner: {p} is placed below your top 3, and ranked at the next weekly re-rank. Never give it a number in the order: it has no rank yet.")
    elif p in order:
        print(f"Tell the owner: {p} is #{order.index(p) + 1} in the order the readers use (done and waiting rows skipped).")
    if p in new_top:
        print(f"{p} is in the top 3. Hand out its hand-off now if handoffs/jobs.md has no job for {p} yet (stage 10 section B step 6).")
    else:
        print(f"{p} is below the top 3. Hand out nothing for it now. The morning brief hands it out when it reaches the top 3 (stage 04 step 2a).")
    for o in old_top:
        if o not in new_top:
            print(f"{o} moved out of the top 3. A job already handed out for it keeps going. A hand-off not handed out yet waits until it is back in the top 3.")
    if cos:
        print(f"Picks by the Chief of Staff. Tell the owner the place with each pick's one-line reason, and that they can flip any pair (stage 10 section B step 3a). A flip places it again with --again.")
    print(f"ranked_on was not changed. updated was set from {clock}.")


if __name__ == "__main__":
    sys.argv = take_today_flag(sys.argv)
    cmds = ("start", "next", "answer", "set", "tally", "check", "light", "top", "auto", "picks", "flip", "clear")
    if len(sys.argv) < 3 or sys.argv[1] not in cmds:
        sys.exit(__doc__)
    c, p = sys.argv[1], sys.argv[2]
    if c == "light":
        args = sys.argv[3:]
        res, by, again = None, None, False
        for flag in ("--result", "--by"):
            if flag in args:
                i = args.index(flag)
                if i + 1 >= len(args):
                    sys.exit(f"STOP: give a value after {flag}" + (", in quotes." if flag == "--result" else ", for example --by cos."))
                if flag == "--result":
                    res = args[i + 1]
                else:
                    by = args[i + 1]
                args = args[:i] + args[i + 2:]
        if "--again" in args:
            again = True
            args = [a for a in args if a != "--again"]
        if not args:
            sys.exit("STOP: give the P number, for example P21")
        cmd_light(p, args[0], " ".join(args[1:]) if len(args) > 1 else None, res, by, again)
        sys.exit(0)
    if c == "auto":
        cmd_auto(p, sys.argv[3] if len(sys.argv) > 3 else None)
        sys.exit(0)
    if c == "picks":
        cmd_picks(p)
        sys.exit(0)
    if c == "flip":
        if len(sys.argv) < 4:
            sys.exit("STOP: give the pair number, for example flip RUN/08_rank.md 7")
        cmd_flip(p, [x for a in sys.argv[3:] for x in re.split(r"[,\s]+", a) if x])
        sys.exit(0)
    if c == "clear":
        cmd_clear(p)
        sys.exit(0)
    if c == "top":
        cmd_top(p)
        sys.exit(0)
    if c == "start":
        cmd_start(p)
    elif c == "next":
        cmd_next(p, int(sys.argv[3]) if len(sys.argv) > 3 else 9)
    elif c == "answer":
        if len(sys.argv) < 4:
            sys.exit("STOP: give the letters, for example ACADAEAFG")
        args, batch = sys.argv[3:], 9
        if "--batch" in args:
            i = args.index("--batch")
            batch = int(args[i + 1])
            args = args[:i] + args[i + 2:]
        cmd_answer(p, " ".join(args), batch)
    elif c == "set":
        if len(sys.argv) < 5:
            sys.exit("STOP: give the pair and the winner, for example A-C C")
        cmd_set(p, sys.argv[3], sys.argv[4])
    elif c == "tally":
        cmd_tally(p)
    else:
        cmd_check(p)
