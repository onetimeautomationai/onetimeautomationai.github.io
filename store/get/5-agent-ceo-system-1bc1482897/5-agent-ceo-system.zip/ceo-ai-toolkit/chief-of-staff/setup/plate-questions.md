# Plate questions

Asked by `chief-of-staff/stages/07_plate/CONTEXT.md`. At most 12 questions: 11 for business use or personal use, 12 when the owner uses the team for both. About 8 minutes, then the pairs (about 5 more minutes for 10 items).

## How to ask

- One question per turn, in this order. End every question you say aloud with its default in brackets, so the owner sees it, for example "... [none]". The Default column below is what goes in the brackets.
- "Skip" uses the default. "That's all" in Part A jumps to PQ7. "Just rank it" uses the default for every question left and goes to the pairs.
- Never ask what the owner profile already holds (SR10): goal 1, the daily actions that move it, business or personal use, work hours, the first-week job. Use them.
- Personal use: word PQ1 to PQ5 for the owner's life (the wording is in brackets after the business wording).
- Write each answer into `07_plate.md` the moment you get it, as new P# rows or as facts on rows already there. If the owner stops halfway, the answers so far are saved.
- After each Part A answer, say how many items are on the plate in one line ("14 on your plate so far"). Never repeat the whole list until PQ8.

## Opening (not a question)

"Let's get everything on your plate out of your head, then rank it. I'll ask up to [11, or 12 when the owner profile says "both"] short questions, one at a time. Then I compare your items two at a time: you pick each pair, or I rank them for you to review [the owner's `rank_mode`, or both choices when it is `not asked yet`]. About 15 minutes. Say 'skip' to use the default in brackets, 'that's all' to move on, or 'stop' to pause. Here is what I already have: [the seed list from step 6 of stage 07, one short line each]."

## Part A: what is on your plate

| # | Question | Default | Ask when |
|---|---|---|---|
| PQ1 | What projects are you in the middle of right now, the ones with more than one step left? (Personal: What plans or projects are you in the middle of, like a move, a trip or a home repair?) [none beyond the list above] | [none beyond the list above] | Always |
| PQ2 | What have you promised someone, or what has a date in the next 30 days? Include anyone waiting on you for a reply, a decision or a delivery. [nothing beyond the list above] | [nothing beyond the list above] | Always |
| PQ3 | What are you waiting on from other people before you can move something forward? [nothing] | [nothing] | Always |
| PQ4 | What do you do every week or month that takes real time, like payroll, reports or invoicing? (Personal: like bills, appointments or the chores that pile up) [nothing to add] | [nothing to add] | Always |
| PQ5 | Which ideas keep coming back that you have not started? [none] | [none] | Always |
| PQ6 | What personal things are on your mind: health, family, home, money, errands? For each, in a few words, why it matters this month (a date, someone waiting, something broken). [none] | [none] | Only when the owner profile says "both" |

## Part B: what the ranking needs

| # | Question | Default | Ask when |
|---|---|---|---|
| PQ7 | Here are the items with a date: [list]. For each one, what happens if it slips? Add any date I missed. (Promises with no date go under their own line in the same question: "Promises with no date: [list]. By when, if anything?") | [the dates as listed, and treat a missed date as costly. A promise with no date stays `no date`] | At least one item has a date or a promise. Otherwise skip |
| PQ8 | Here is my first sort against your goal 1 ([goal 1]). Now: it moves goal 1 this month. Must: a hard date with a cost, even if it does not move goal 1. Later: with what it waits on. No: with the reason. [the sort]. Move anything? | [keep my sort] | Always |
| PQ9 | Who else is waiting on each of these: a client, your team, your family, or nobody? [the now and must items, with my guess next to each] | [as I marked from your words, nobody for the rest] | Some now or must item has no answer yet from the owner's own words |
| PQ10 | Which of these can only you do? I'll suggest handing the rest to a manager or a person on your team, and nothing leaves without your yes. [the now and must items, with my guess next to each] | [as I marked from the work you said in setup you still do yourself: calls, sales and anything in your own voice are yours, the rest can be handed off] | Always, unless every now and must item is already marked |
| PQ11 | Roughly how big is each one: under an hour, half a day, or more than a day? [the now and must items, with the size the owner already gave, and ? where none is known] | [sizes as marked, an unknown size stays ?] | Same as PQ10 |
| PQ12 | I'll judge every pair with one question: "Which one moves [goal 1] forward most this month?" Keep it, or give me a different question? | [keep it] | Skip when `chief-of-staff/board/plate.md` already holds a question the owner approved and goal 1 has not changed since |

PQ9 to PQ11 ask only about the "now" and "must" items, personal ones included. Later and no items need no more facts. An item marked "now, over the cap" (PL4) is left out of PQ9 to PQ11, because it is not in the pairs: its facts stay as the owner's words gave them, `?` for the rest, and a fact still `?` when it enters a ranking is a missing fact there (PL22). For "both" use, personal items are sorted on "Does it matter most for your life this month?" in place of goal 1 (PL12), and the personal "now" and "must" items are in PQ9 to PQ11 too, listed under their own heading.

## Re-rank runs (stage 10)

Replace PQ1 to PQ6 with one question: "What is new, done, or no longer on your plate since [date of the last ranking]?" [nothing changed]. Then ask PQ7 and PQ9 to PQ11 for the new items only, PQ8 only for the items whose sort changed, and skip PQ12 unless goal 1 changed.

## The pairs (not counted as questions)

The one-time choice between picking each pair and an automatic ranking is asked once at the start of the pairs (`chief-of-staff/stages/08_rank/CONTEXT.md` step 0, PL18). It does not count as one of the 12 questions, and neither does the one start-time question for a standing item (`chief-of-staff/stages/07_plate/CONTEXT.md` step 9). In auto mode the owner sees no pairs, only the ranking to review (step A8), and any pair that no known fact decides (the open pairs of plate rule PL22: facts equal, or a fact missing with every known fact equal).

Manual mode: "Pairs 1 to 9. For each pair, the one that moves [goal 1] forward most this month. Reply with 9 letters, one per pair, in order." Never show an example string of letters: it would be built for other pairs. Then the 9 pairs, numbered, each item with its facts (due, who waits, size). See `chief-of-staff/stages/08_rank/CONTEXT.md`.
