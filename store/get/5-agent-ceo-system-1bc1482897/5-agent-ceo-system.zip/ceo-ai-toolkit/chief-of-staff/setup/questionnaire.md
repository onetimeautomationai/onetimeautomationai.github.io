# Setup questions

Ask one per turn, in this order. The default is in brackets. Write each answer into `chief-of-staff/_shared/owner-profile.md` the moment you get it. "Required" means there is no default (see onboarding step 5). If the owner says this is for personal use, word Q6 and Q13 for their life instead of a business.

## About you
1. What should your team call you? [required]
2. Is this for your business, your personal life, or both? [business]
3. Tell me about your business in as much detail as you like: what you sell, who buys it, how you get customers, how many people work with you, and what a normal week looks like. (Personal use: what do you want your team to help you run?) [required]
4. What is your role, and which parts of the work do you still do yourself today? [required]
5. What time zone are you in? [the time zone your computer shows]

## Your goals
6. What is your number one goal right now, with a number and a date? For example: "$10,000 in new sales by December 31." [required]
7. What comes after that goal? [none for now]
8. What daily actions move your number one goal the most? For example: new conversations, follow-ups, offers made. [not given, ask again in week one]

## Your tools
9. Which tools do you use for email, calendar, and notes or tasks? If you have no connected calendar, say "plain file" and your Time Manager keeps your calendar in a file. [email: whatever your agent can reach, calendar: plain file, notes: this folder]

## Your day
10. Which days and hours do you work, and which hours are protected (family, health, no work questions)? [Monday to Friday, 9 AM to 5 PM, evenings and weekends protected]
11. When do you want your morning brief and your night wrap? [first session of the day, last session of the day]

## How to write for you
12. How do you like reports: short or detailed, lists or sentences? [short, lists, most important line last]
13. How should drafts sound when written in your name: tone, words to avoid, sign-off? [plain and friendly, first name sign-off]
14. Where can I read your real writing to learn how you sound? Best is your sent email, if I can reach it. Or point me to a folder of documents, posts or texts you wrote, or paste 3 to 5 messages you're happy with. [sent email, the last 50 replies you wrote yourself]

## Limits
15. Sending, posting, publishing, paying, buying, deleting and booking with other people always need your yes. Is there anything else that should? [nothing else]
16. Any people, brands or topics your team must never mention or contact? [none]

## First week
17. What is the one job you want from your team this week? [a clear morning brief every day]

## Last one
18. What else is on your mind that you'd like handled? Dump it all: open loops, things you keep forgetting, people you owe a reply, ideas you haven't acted on, anything nagging you. No order needed. [nothing right now]
