# 01_intake: catch everything the owner drops

One job: every idea, ask or brain dump lands on the board the same turn, so nothing is lost. Paths start from the `ceo-ai-toolkit` folder.

## Inputs
- Working: the owner's message
- Reference: `chief-of-staff/_shared/standing-rules.md`, `chief-of-staff/_shared/lessons.md`, `chief-of-staff/board/board.md` (Inbox)

## Process
1. Check the clock (SR2). Start a run: `python3 chief-of-staff/scripts/new_run.py "short-name"`, or copy `chief-of-staff/_templates/run/` by hand.
2. Split a brain dump into separate items. One idea per item.
3. For each item, add an Inbox row (IN#) to the board with the owner's exact words and status "needs decision". Stage 02 step 5 sets the status once the item is decided.
4. If the same idea is already on the board, add the new words to that row instead of a new one. If it is already a plate item (`chief-of-staff/board/plate.md`, for example a Watch memo about the chamber follow-up that is P1), still add its Inbox row with the owner's words, name the P# in it ("same as P1"), and give it no new P#: stage 02 decides it as part of that plate item.
5. Stray notes (a reminder, not an idea or ask) go to the Focus Manager's quick capture if it is installed. Otherwise add an Inbox row with status "note".
6. Protected time (SR14): set each new row's status to "held", and say in one line when they come back, with a day and time: the next morning brief inside the owner's work days and hours (SR15: the profile's line, else `work_days` in `time-manager/config.json`, else Monday to Friday), for example "comes back in your brief Monday 8:00 AM". Ask nothing and decide nothing. The hold gets one decision log row: "IN4: held for protected time, back <day> <time>", T1, Result `done` (the hold is done, the item is not decided yet), never `parked`, which means put away. Then close the run as usual: `06_log.md` and its activity line (`chief-of-staff/stages/06_log/CONTEXT.md`) still apply. The morning brief on the next work day turns "held" rows back to "needs decision" (`chief-of-staff/stages/04_morning-brief/CONTEXT.md` step 1a). Skip this step if the owner said "work now".
7. Otherwise go to `chief-of-staff/stages/02_decide/CONTEXT.md`.

## Output
- `01_intake.md` in the run folder: the items, each with its IN# number.
- New Inbox rows on the board.

## Human check
None. Intake is logged the same turn.
