# 06_log: close the loop

One job: every file shows the true state before the session ends. Paths start from the `ceo-ai-toolkit` folder.

## Inputs
- Working: the run folder
- Reference: `chief-of-staff/board/board.md`, `chief-of-staff/_shared/decision-log.md`, `chief-of-staff/_shared/lessons.md`
- Template: `chief-of-staff/_templates/outputs/06_log.md`

## Process
1. Board: every job has a current status (a job that could not run stays `open`, `03_dispatch` step 8). Every answered decision is in Decided. Every board row has as many cells as its table header (C12).
2. Decision log: every decision made this session has a row. Any T3 marked done has the owner's words. Any T2 marked done says `review: pass (separate)` or `review: pass (self)` and the path of its saved review file (C8). Every open "Your list" row has its `A#: Owner task:` row (C12).
3. Lessons: every correction the owner gave this session is a line (SR11).
4. Run `python3 chief-of-staff/scripts/check_gates.py`. If it fails, fix what it names and run it again. To fix a log row, add a `corrects L#` row (it names a row above it, never itself). Never edit the old one. A `corrects` row that turns an item into T3 with Result `pending` (a red step still waiting for the owner) also gets a board "Waiting on you" row with the next D number, the question and your recommendation, the same turn, as in `02_decide` step 4, so the owner sees it in the next brief. No Python: do the checks in `chief-of-staff/scripts/README.md` by hand.
5. Write `06_log.md` in the run folder: files updated, check result, anything still open. A plate run paused partway gets one too, with "Still open: plate questions answered N of M" or "pairs answered N of M". It resumes from its files (`chief-of-staff/stages/07_plate/CONTEXT.md` step 2).
6. Last, add one line to `logs/activity.md` for each job you finished this session, with Agent `chief-of-staff` and the proof copied from a file in this run folder, such as `06_log.md` (format and rules at the top of that file). A night wrap already wrote its line in `chief-of-staff/stages/05_night-wrap/CONTEXT.md` step 2a: add no second line for the wrap itself. Never edit a line already there. If `handoffs/scoreboard-report.md` lists flags under `## Agent flags`, put each one on the board's Job queue as the fix it names, once (skip a flag code and date already there). A flag on your own line: fix the job, then add a line whose Job starts `corrects AL#`.

## Output
- `06_log.md` in the run folder.

## Human check
The check passes. A request run is done only when this file exists.
