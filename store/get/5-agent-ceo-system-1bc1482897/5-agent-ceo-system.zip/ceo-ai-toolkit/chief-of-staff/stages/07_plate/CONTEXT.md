# 07_plate: get everything on the owner's plate onto one list

One job: every project, promise, deadline, wait, recurring duty and idea the owner carries is on one list, with the facts the ranking needs, sorted now, must, later, no or standing (a repeating item, PL19). Paths start from the `ceo-ai-toolkit` folder.

## When it runs
- Right after setup, when the owner says yes to the offer (`chief-of-staff/00_onboarding/CONTEXT.md` step 10).
- "Prioritize my plate", "Rank my list", "Rank my plate" when the owner has no ranking yet. With a ranking (`handoffs/priorities.md` exists), these go to `chief-of-staff/stages/10_re-rank/CONTEXT.md` section A.
- "What should I work on?" or "I'm overwhelmed" (step 3 first).
- The brief offers it if the owner said "later" (`chief-of-staff/stages/04_morning-brief/CONTEXT.md` step 5).

## Inputs
- Working: the owner's message
- Reference: `chief-of-staff/_shared/owner-profile.md` (goal 1, daily actions, use, work days and hours), `chief-of-staff/_shared/plate-rules.md`, `chief-of-staff/setup/plate-questions.md`, `chief-of-staff/_shared/standing-rules.md`, `chief-of-staff/_shared/lessons.md`
- Seed: `chief-of-staff/board/board.md` (Inbox, Waiting on you, Decided, Your list, Job queue), `chief-of-staff/board/plate.md`, `handoffs/email-manager-report.md` ("Waiting on you", only if dated today)
- Templates: `chief-of-staff/_templates/plate/07_plate.md`, `chief-of-staff/_templates/plate/08_rank.md`

Do NOT load: old runs, the decision log, the managers' folders.

## Process
1. Check the clock (SR2).
2. **A ranking already in progress.** If the newest `chief-of-staff/runs/YYYY-MM-DD-plate/` folder (or `-plate-2` and so on) has no `09_priorities.md`, resume it: the first unanswered question in `07_plate.md`, or `chief-of-staff/stages/08_rank/CONTEXT.md` if the Items table in `08_rank.md` is filled (step A8 when its `status` is `waiting for your review`: show the owner the Chief of Staff's ranking again, and nothing else). Never re-ask an answered question. For "What should I work on?" or "I'm overwhelmed", first say one line: "We're partway through ranking your plate. Let's finish it, about N minutes left." If the owner says "start over", leave that run as it is (its `06_log.md` says it was left) and go to step 5.
3. **"What should I work on?" or "I'm overwhelmed".**
   - If `handoffs/priorities.md` exists, answer from it in three lines: today's Top 3 from `handoffs/top3-today.md` if it is dated today, otherwise the top 3 open ranked items. If its `ranked_on` date is 7 or more days old, add: "Your ranking is from [date]. Say 'Re-rank my plate' to refresh it." Otherwise add: "Say 'Re-rank my plate' if this feels wrong." This is a lookup: no run, no file changes. Stop.
   - If there is no ranking, say one line ("Let's get it all out of your head, then rank it. About 15 minutes.") and offer one shortcut: "Or say 'just tell me' and I give you three from what I already have." On "just tell me": name the three open board items closest to goal 1 (a daily action from the profile, a date this week, the owner's words today, the oldest), say they are your picks and not yet ranked by the owner, change no files, and stop. On any go-ahead ("ok", "let's do it", "rank it"), go on to step 4.
4. **Protected time (SR14).** The lookup in step 3 is fine. Ask no questions. Add a Job queue row "Rank your plate" for the Chief of Staff with the owner's words, say in one line when ranking comes back, and stop. Skip this if the owner said "work now".
5. Start a run: `python3 chief-of-staff/scripts/new_run.py plate`. It makes `chief-of-staff/runs/YYYY-MM-DD-plate/` (or `-plate-2` for a second one that day) with `07_plate.md` and `08_rank.md`. By hand: copy `chief-of-staff/_templates/plate/` to that folder and fill the run name and time.
6. **Seed the list.** Read every source under Seed in Inputs. Each open item becomes a row in `07_plate.md` with the next free P number from `chief-of-staff/board/plate.md` and its source:
   - Inbox rows still `needs decision` or `held` (IN#).
   - "Waiting on you" rows (D#). The item keeps its D number, so the owner is never asked the same thing twice.
   - Decided rows ranked "now" or "later" whose work is not done (IN# or D#). The setup brain dump arrives here, because onboarding already decided it.
   - Inbox rows marked `decided` whose work is not done and that have no Decided row, no job and no A number (a green item decided in `02_decide` and never handed out). Nothing from the brain dump is lost this way.
   - "Your list" rows still open (A#). Job queue rows still open that carry real owner work (Job#).
   - Email Manager "Waiting on you" people, only if the report is dated today.
   Never seed: a manager's routine run (sort email, block the Top 3, score the day), a "Rank your plate" or "Re-rank your plate" row, or a job that names a P number (it is already on the plate). Merge the same item from two sources into one row. Fill the Seed section.
7. Say the opening line from `chief-of-staff/setup/plate-questions.md` with the seed list.
8. Ask the questions in `chief-of-staff/setup/plate-questions.md`, one per turn, by its rules (defaults, skips, "that's all", "just rank it", personal wording). Write the owner's exact words in "Owner's answers" and turn each answer into rows at once: one item per row, its kind, and any date, person or size the owner's own words give.
9. **Before PQ8, draft the sort** with the sort test in PL3, line by line, first line that fits, for every item. Use goal 1, the daily actions and the customer source from the profile, and the dates and costs from PQ7. An item that moves goal 1 this month stays now even with a date inside 14 days (only an item that does not move goal 1 is a must). Anything that needs something done first is later: name what. Never sort by a feeling of importance: the "Why" cell names the PL3 line that fit. Apply the cap (PL4) and mark the rows over the cap "now, over the cap". For "both" use, keep personal items apart and sort them with the personal sort test in PL12, line by line, so a personal item that matters this month (a date, someone waiting, something broken) is now. A recurring item on named days (Kind `recurring`: "Tuesday sales calls", "every morning") is `standing`, never now (PL19). A cadence with no named day ("LinkedIn posts twice a week") is sorted like any item, and dated work that repeats every other week or less often ("payroll every other Friday") is sorted by its next date (PL19). Show the sort in five short groups (now, must, later, no, standing) with the reason for each no, the wait for each later, and for each standing item the day and size the owner gave. If the owner gave no start time for a standing item, ask for it right after the sort is approved. This is the only place the start time is asked (PL19), and it is not one of the 11 or 12 plate questions (like the mode question in stage 08 step 0): stage 09 never asks it again, and with no answer the page says the block waits for a start time. Never guess it. The owner's changes are final.
10. After PQ12, write the question in three places, then tick each one before going on:
   - the `criterion` line in the front matter of `08_rank.md`,
   - its "Question for every pair" line (no `{{` left in it),
   - the front matter of `chief-of-staff/board/plate.md` (`criterion`, `criterion_approved` with today's date, `goal_1_when_approved` with goal 1 as the profile says it).
11. **Update the board.** Add or update a row in `chief-of-staff/board/plate.md` for every item: its facts, its sort, Status `open` (a "no" item is `parked`, and an item seeded from a "Waiting on you" D row that asks whether to do it at all, for example "Renew the software?", is `waiting: D# answer` with that D number, so stages 05, 09 and 10 hold its block until the owner's yes. A D row that asks only a red last step, "File and pay ...?", leaves the item `open`, PL17). Inbox rows seeded while still `needs decision` or `held` get status `decided`, with one Decided row: "IN3, IN5: on your plate as P2, P4 (run YYYY-MM-DD-plate)". D rows stay where they are until the owner answers.
12. Add one decision log row: "Plate inventory: N items, sorted A now, B must, C later, D no, E standing", T1, Evidence: the run folder, Owner's words: their PQ8 answer, Result `done`. Name items by P# only (PL15).
13. Two or more "now" items: go to `chief-of-staff/stages/08_rank/CONTEXT.md`. It asks once whether the owner picks each pair or the Chief of Staff ranks it for review (step 0, PL18), unless `rank_mode` is already set. One or none: write "no pairs needed" under the title of `08_rank.md` and go to `chief-of-staff/stages/09_organize/CONTEXT.md`.

## Output
- `07_plate.md` in the run folder: the seed, the owner's exact answers, every item with its facts and sort.
- `chief-of-staff/board/plate.md` updated. One decision log row.

## Human check
The owner approves the sort at PQ8 and the ranking question at PQ12 before the first pair is shown.
