# stages: map

| Folder | One line |
|---|---|
| `01_intake/` | Every idea or ask lands on the board |
| `02_decide/` | Yes, later or no, and T3 waits for the owner |
| `03_dispatch/` | Each "now" goes to one manager with proof back |
| `04_morning-brief/` | One brief: Top 3, calendar, who waits, decisions |
| `05_night-wrap/` | Score, done, carried, tomorrow's first thing |
| `06_log/` | Board, log, lessons true, checks pass |
| `07_plate/` | Everything on the owner's plate, with its facts, sorted now, must, later, no or standing |
| `08_rank/` | Two items at a time: the owner picks, or the Chief of Staff picks with reasons for the owner to review. The script counts the wins |
| `09_organize/` | One page: Top 3 this week, full order, dates, hand-offs, drops, and the handoff to the managers |
| `10_re-rank/` | Weekly re-rank, and the light path for a new item |
