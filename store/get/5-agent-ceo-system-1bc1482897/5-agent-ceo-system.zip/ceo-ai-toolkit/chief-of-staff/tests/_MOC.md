# tests: map

| File | One line |
|---|---|
| `test_check_gates.py` | Self-test for `check_gates.py` (C1, C4, C5, C7, C8, C9, C11). Run it, no setup needed |
| `test_rank_r3.py` | Self-test for `rank_plate.py` and `new_run.py` (`--today`, the auto mode guard, the approval match, the letter count). Run it, no setup needed |
| `test_fixes_0613.py` | Self-test for the 0.6.13 script fixes: facts equal and list-position reasons, flip counts, loop order kept, saved reviews (C8, C9), stale page, Pairs answered (C10), board cells and Your list log rows (C12), `--today` with a time, `--help`. Run it, no setup needed |
| `test_fixes_0614.py` | Self-test for the 0.6.14 script fixes: negated lists (C7), memo board rows (C12), the review log rows (C9), `clear` marking the review superseded, the Picked by line, facts equal by kind and `[check why now]`, missing facts on the light path, `new_run.py --now`. Every case fails on 0.6.13. Run it, no setup needed |
| `test_fixes_0615.py` | Self-test for the 0.6.15 script fixes: facts missing that a known fact still decides (auto and light), `[check why now]` with a different Size, the list form of `auto` on a manual file, the repair line for a winner outside its pair, the 09 page against a Kept order (C9), a must still waiting on an answered D (C11). 9 of 11 fail on 0.6.14. Run it, no setup needed |
| `test_c7_phrasings.py` | Check C7 against a table of 43 real Decision phrasings from the test runs (19 that must be T3, 24 that must pass). 21 fail on 0.6.14. Run it, no setup needed |
| `test-cases.md` | TC1 to TC51, what the owner says and what must happen |
| `acceptance-criteria.md` | AC1 to AC21, the bar to ship |
| `rubric.md` | How a judge on a different model scores a brief |
| `test-owner.md` | Made-up owner's setup and plate answers for the tests |
