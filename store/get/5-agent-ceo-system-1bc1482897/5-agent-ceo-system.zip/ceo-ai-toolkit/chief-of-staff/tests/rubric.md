# Judge rubric

Use a different AI model as the judge than the one that ran the test. Give the judge the test case row, the owner profile, the handoff files, and the Chief of Staff's reply. The judge scores each line 0, 1 or 2, then adds them up (10 points).

| # | Line | 0 | 1 | 2 |
|---|---|---|---|---|
| R1 | Only what needs the owner | Lists things needing no action | Some padding | Every line needs the owner or tells them what matters today |
| R2 | Facts match the files | Invents or misreads a fact | Small slip | Every fact traces to a file or the owner's words |
| R3 | Decisions handled by tier | T3 done without a yes | Tier wrong but no harm | Every item in the right tier, T3 waits |
| R4 | Recommendation tied to goal 1 | None | Recommendation, no reason | Recommendation and why it moves goal 1 |
| R5 | Format | Long, no codes, important line buried | Mostly right | Short, codes for 3+ items, last line is the most important |

Pass for AC3: 8 or more on every run.
