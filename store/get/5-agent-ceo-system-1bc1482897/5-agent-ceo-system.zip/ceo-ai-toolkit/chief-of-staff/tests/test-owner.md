# Test owner (made up)

Use these setup answers for every test case that needs setup done.

| Q | Answer |
|---|---|
| 1 | Dana Ruiz |
| 2 | business |
| 3 | A 6-person bookkeeping firm for restaurants and retail shops. Monthly bookkeeping and payroll packages. Customers come from referrals and a local chamber of commerce. A normal week is client reviews, payroll runs, and sales calls on Tuesdays |
| 4 | Owner. I still do all sales calls, proposals and the hardest client reviews |
| 5 | Pacific |
| 6 | 10 new monthly clients by March 31 |
| 7 | skip |
| 8 | sales calls and proposals |
| 9 | email connected, calendar plain file, notes in this folder |
| 10 | 8 AM to 5 PM, 6 PM to 8 PM protected |
| 11 | skip |
| 12 | short, lists |
| 13 | plain and friendly, sign off Dana |
| 14 | paste: three short made-up replies the tester writes |
| 15 | skip |
| 16 | never mention Ledgerly |
| 17 | a clear morning brief every day |
| 18 | follow up with the chamber about the January mixer, renew my software subscription, I owe Tom Becker a reply |

## Plate answers (stage 07, test cases TC15 to TC25)

The seed is the three brain dump items above (P1 chamber follow-up, P2 software renewal, P3 Tom Becker reply). Business use, so PQ6 is not asked.

| PQ | Answer |
|---|---|
| 1 | the Harbor Grill proposal, a referral offer for current clients, hiring a part-time payroll clerk, year-end tax packets for 12 clients, our website pricing page |
| 2 | Harbor Grill proposal by Friday the 27th. Payroll run every other Friday, next one the 27th. Tax packets by January 15. Chamber follow-up by December 5. Software renewal December 1 |
| 3 | the bank has to approve our merchant account before clients can pay by card |
| 4 | Tuesday sales calls, about half a day |
| 5 | a podcast, a lunch talk for the chamber, finally cleaning up the shared drive, a case study from Bella's Bakery, LinkedIn posts twice a week, an email newsletter to past prospects, calling 5 past leads from the fall |
| 7 | Renewal: the team loses access to client files. Harbor Grill: they go with another firm. Payroll: clients' staff get paid late. Chamber: we lose our booth at the mixer. Tax packets: penalties for clients |
| 8 | move the shared drive to no, keep the rest |
| 9 | skip |
| 10 | The proposal, the calls and the lunch talk are mine. Tom's reply too, but draft it for me. My team runs payroll |
| 11 | skip |
| 12 | keep |

How to rank (`chief-of-staff/stages/08_rank/CONTEXT.md` step 0): "I'll pick" for TC15 to TC31. TC32 to TC38 say their own answer.

Expected sort: 10 now (P1, P3, P4, P5, P8, P13, P15, P16, P17, P18, all inside the cap of 10. P16 "LinkedIn posts twice a week" is a cadence with no named day, so PL19 keeps it now), 1 standing (P11, Tuesday sales calls repeat on a named day, PL19), 2 must (P2, and P9, payroll every other Friday, a must by its next date the 27th, PL19), 3 later (P6 a hire that helps once new clients sign, P7 dated more than 14 days out, P10 waits on the bank), 2 no (P12 the podcast has no date and no link to goal 1, P14 the shared drive Dana moved to no).

The same sort, line by line from the PL3 sort test (`chief-of-staff/_shared/plate-rules.md`), first line that fits. Customers come from referrals and the chamber (Q3), daily actions are sales calls and proposals (Q8).

| P# | Item | Source | PL3 line | Sort |
|---|---|---|---|---|
| P1 | Chamber follow-up, due Dec 5 | brain dump | 3: the chamber is the customer source (a date inside 14 days does not make it a must) | now |
| P2 | Software renewal, Dec 1 | brain dump | 4: serves the team, not new clients, hard date and a cost | must |
| P3 | Reply to Tom Becker | brain dump | 3: a person waiting on the owner's reply | now |
| P4 | Harbor Grill proposal | PQ1 | 3: a proposal, a daily action | now |
| P5 | Referral offer for current clients | PQ1 | 3: current clients asked for referrals | now |
| P6 | Hire a part-time payroll clerk | PQ1 | 5: a hire helps only once goal 1 has moved | later |
| P7 | Year-end tax packets, Jan 15 | PQ1 | 5: serves current clients, date more than 14 days out | later |
| P8 | Website pricing page | PQ1 | 3: buyers see it before they buy | now |
| P9 | Payroll run, next Fri Nov 27 | PQ2 | 4: serves current clients, hard date and a cost (PL19 sorts it by its next date) | must |
| P10 | Card payments for clients | PQ3 | 2: waits on the bank's approval | later |
| P11 | Tuesday sales calls | PQ4 | 1: repeats on a named day | standing |
| P12 | A podcast | PQ5 | 6: an idea not started, a new channel with no audience yet | no |
| P13 | Lunch talk for the chamber | PQ5 | 3: the chamber is the customer source | now |
| P14 | Clean up the shared drive | PQ5 | 6: an idea not started that fits no line (Dana also moves it to no at PQ8) | no |
| P15 | Case study from Bella's Bakery | PQ5 | 3: buyers see it before they buy | now |
| P16 | LinkedIn posts twice a week | PQ5 | 3: posts buyers see (a cadence with no named day, PL19) | now |
| P17 | Email newsletter to past prospects | PQ5 | 3: reaches past prospects | now |
| P18 | Call 5 past leads from the fall | PQ5 | 3: reaches leads, sales calls are a daily action | now |

TC18b adds P19 "a webinar for local restaurants" (PQ5, line 3: it reaches restaurants, the firm's buyers). That makes 11 now. PL4 keeps 10: P19 has no date, names no daily action, nobody waits on it and is the newest, so it is "now, over the cap".

## Other facts (used by the Priya cases and `examples/sample-day.md`)

| Fact | Source words |
|---|---|
| Priya Shah is a new prospect, not a client yet. If she signs a monthly package she is one of the 10 new monthly clients for goal 1 | "Priya Shah is a new prospect. A 12-month monthly bookkeeping package for her would be one new monthly client." |
| Priya asked for 10% off the payroll add-on | "Priya asked for 10% off the add-on." |
| Tuesday sales calls repeat every Tuesday. Dana gave no start time | PQ4: "Tuesday sales calls, about half a day" |
