#!/usr/bin/env python3
"""Self-test for check_gates.py (C1, C4, C5, C7, C9, C11).
Run: python3 chief-of-staff/tests/test_check_gates.py
Builds a throwaway toolkit in a temp folder with made-up data and removes it after. Changes nothing in the real toolkit. Exit 0 = all pass.
To test other copies of the scripts (for example an older version), set COS_SCRIPTS to their folder."""
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

SRC = Path(__file__).resolve().parent.parent
SCRIPTS = Path(os.environ.get("COS_SCRIPTS") or SRC / "scripts")
PROFILE = "---\nsetup_done: yes\n---\n# Owner\nTime zone: Pacific\n"
PLATE_HEAD = ("| P# | Added | Item | Kind | Due | Who waits | Only you? | Size | Waits on | Sort | Rank | Goes to | Status |\n"
              "|---|---|---|---|---|---|---|---|---|---|---|---|---|\n")
LOG_HEAD = "| L# | Time | Decision | Tier | Why | Evidence | Owner's words | Result |\n|---|---|---|---|---|---|---|---|\n"
JOBS_HEAD = "| Job# | For | Job | Write result to | Due | Light | Status |\n|---|---|---|---|---|---|---|\n"


LAST = [""]
MADE = []


def build(plate_rows, jobs_rows="", log_rows="", profile=PROFILE):
    tk = Path(tempfile.mkdtemp())
    MADE.append(tk)
    cos = tk / "chief-of-staff"
    (cos / "scripts").mkdir(parents=True)
    (cos / "_shared").mkdir()
    (cos / "board").mkdir()
    (tk / "handoffs").mkdir()
    for n in ("check_gates.py", "rank_plate.py"):
        shutil.copy(SCRIPTS / n, cos / "scripts" / n)
    (cos / "_shared" / "owner-profile.md").write_text(profile)
    (cos / "_shared" / "decision-log.md").write_text(LOG_HEAD + log_rows)
    (cos / "board" / "plate.md").write_text(PLATE_HEAD + plate_rows)
    (cos / "board" / "board.md").write_text("# Board\n")
    (tk / "handoffs" / "jobs.md").write_text(JOBS_HEAD + jobs_rows)
    return tk


def run(tk, today="2026-11-23", flag="--today"):
    r = subprocess.run([sys.executable, "-B", str(tk / "chief-of-staff/scripts/check_gates.py"), flag, today],
                       capture_output=True, text=True)
    LAST[0] = r.stdout + r.stderr
    return r.returncode, r.stdout + r.stderr


def must(p, due, goes="you", status="open"):
    return f"| {p} | 2026-11-20 | Item {p} | one-off | {due} | | no | 1 hour | | must | | {goes} | {status} |\n"


results = []


def case(name, ok):
    results.append(ok)
    print(("PASS " if ok else "FAIL ") + name)
    if not ok:
        print("  output was: " + LAST[0].strip().replace("\n", " / "))


# C11
rc, out = run(build(must("P2", "2026-12-01")))
case("C11 must due in 8 days, no job: exit 1 naming P2", rc == 1 and "C11 FAIL: P2" in out)

rc, out = run(build(must("P2", "2026-12-01"), "| J1 | Time Manager | Block 1 hour before Dec 1 for Must P2: Item P2 | x | | yellow | open |\n"))
case("C11 same must with a Must P2 job: exit 0", rc == 0 and "C11 FAIL" not in out)

rc, out = run(build(must("P7", "2027-01-15")))
case("C11 must 53 days out: no job needed", rc == 0)

rc, out = run(build(must("P9", "2026-11-27", goes="Your team")))
case("C11 must done by the owner's team: no block", rc == 0)

rc, out = run(build(must("P2", "2026-12-01", status="waiting: D1 answer")))
case("C11 must waiting on a D answer: no job yet", rc == 0)

rc, out = run(build(must("P2", "2026-12-06")))
case("C11 must due in 13 days, no job: flagged", rc == 1 and "C11 FAIL: P2" in out)

rc, out = run(build(must("P2", "2026-12-07")))
case("C11 must due in 14 days, no job: flagged", rc == 1 and "C11 FAIL: P2" in out)

rc, out = run(build(must("P2", "2026-12-08")))
case("C11 must due in 15 days: no job needed yet", rc == 0)

rc, out = run(build(must("P2", "2026-11-20")))
case("C11 overdue open must with no job: flagged (R2-C11)", rc == 1 and "C11 FAIL: P2" in out and "overdue" in out)

rc, out = run(build(must("P2", "2026-12-01", goes="time-manager: block it")))
case("C11 'time-manager' with a hyphen in Goes to is still checked (R3-W5)", rc == 1 and "C11 FAIL: P2" in out)

rc, out = run(build(must("P2", "2026-12-01", goes="Owner's team")))
case("C11 'Owner's team' is the team, not the owner: no block (R2-C11)", rc == 0)

rc, out = run(build(must("P2", "2026-12-01", goes="Your team: flagged, you asked them first")))
case("C11 reads who does it before the first colon only, a note after it changes nothing (R2-B7)", rc == 0)

rc, out = run(build(must("P2", "2026-12-01", goes="")))
case("C11 blank Goes to with no plate run in progress: the doer is not known, still flagged (R2-B5)", rc == 1 and "C11 FAIL: P2" in out)

tk = build(must("P2", "2026-12-01", goes=""))
(tk / "chief-of-staff/runs/2026-11-23-plate").mkdir(parents=True)
(tk / "chief-of-staff/runs/2026-11-23-plate/07_plate.md").write_text("# Plate\n")
rc, out = run(tk)
case("C11 blank Goes to while a plate ranking is still in progress: skipped (R2-B7)", "C11 FAIL" not in out)

# Time order and log time
log = ("| L1 | 2026-11-23 06:10 | Intake | T1 | a | b | | done |\n"
       "| L2 | 2026-11-23 06:06 | Decide | T1 | a | b | | done |\n")
rc, out = run(build("", log_rows=log))
case("C4 row timed earlier than the row above: exit 1 naming L2", rc == 1 and "C4 FAIL: L2" in out)

log_ok = log + "| L3 | 2026-11-23 06:20 | corrects L2: right time | T1 | a | b | | done |\n"
rc, out = run(build("", log_rows=log_ok))
case("C4 a corrects L2 row clears the order flag", rc == 0)

rc, out = run(build("", log_rows="| L1 | today | Intake | T1 | a | b | | done |\n"))
case("C4 a Time with no YYYY-MM-DD HH:MM fails (R2-C13)", rc == 1 and "C4 FAIL: L1" in out)

rc, out = run(build("", log_rows="| L1 | 2026-11-23 06:10 | corrects L1: Send the discount email to the list | T1 | a | b | | done |\n"))
case("C4 a row that corrects itself fails and hides nothing (R2-C12)", rc == 1 and "C4 FAIL: L1" in out and "C7 FAIL: L1" in out)

# C7


def c7(decision, tier="T1", evidence="b"):
    return run(build("", log_rows=f"| L1 | 2026-11-23 06:10 | {decision} | {tier} | a | {evidence} | | done |\n"))


for text in ("Memo handled, nothing sent", "Draft saved, not sent", "Draft an email to Tom Becker", "Reply never posted"):
    rc, out = c7(text)
    case(f"C7 no false alarm on '{text}'", rc == 0 and "C7 FAIL" not in out)
rc, out = c7("Send the discount email to the list")
case("C7 still flags a real send at T1", rc == 1 and "C7 FAIL: L1" in out)
rc, out = c7("Nothing sent yet, then sent the offer to Tom")
case("C7 still flags a send that follows a negation", rc == 1 and "C7 FAIL: L1" in out)
rc, out = c7("Reorder the Top 3: put the reply to Tom Becker first", tier="T2", evidence="review: pass (self), brief")
case("C7 no false alarm on naming 'the reply to Tom' in a reorder (R2-A1)", "C7 FAIL" not in out)
rc, out = c7("Send the reply to Tom Becker")
case("C7 still flags 'Send the reply to Tom' at T1", rc == 1 and "C7 FAIL: L1" in out)
rc, out = c7("IN3: Owner task: send the invoice to Tom")
case("C7 an item code before 'Owner task:' is allowed (R2-A1)", rc == 0 and "C7 FAIL" not in out)
rc, out = c7("Owner task: send the discount email", evidence="the Time Manager sent it")
case("C7 'Owner task:' with Evidence 'the Time Manager sent it' fails (R2-C12)", rc == 1 and "C7 FAIL: L1" in out)
rc, out = c7("Owner task: book the dentist", evidence="booked by the Email Manager")
case("C7 'Owner task:' with Evidence 'booked by the Email Manager' fails (R2-C12)", rc == 1 and "C7 FAIL: L1" in out)
rc, out = c7("Owner task: send the discount email", evidence="owner sent it, found in Sent folder")
case("C7 'Owner task:' with owner evidence still passes", rc == 0)

# C5: run folders
tk = build("")
for name in ("2026-11-20-pricing", "2026-12-01-pricing"):
    (tk / "chief-of-staff/runs" / name).mkdir(parents=True)
    (tk / "chief-of-staff/runs" / name / "01_intake.md").write_text("# Intake\n")
rc, out = run(tk, today="2026-11-24")
case("C5 a run dated after today is not flagged, an older one is (R2-C14)",
     rc == 1 and "C5 FAIL: runs/2026-11-20-pricing" in out and "2026-12-01-pricing" not in out)

# C1 count
prof = "---\nsetup_done: no\n---\n# Owner\n- Name: {{owner_name}}\nTime zone: Pacific\n- Email Manager: {{email_manager_installed}}\n- Time Manager: {{time_manager_installed}}\n"
rc, out = run(build("", profile=prof))
case("C1 counts the owner's questions apart from the Installed hires lines (R2-A4)",
     rc == 1 and "1 unanswered setup answer(s)" in out and "2 'Installed hires' line(s)" in out)

# --date works like --today (R2-A5)
rc, out = run(build(must("P2", "2031-03-01")), today="2031-02-20", flag="--date")
case("--date is the same as --today (R2-A5)", rc == 1 and "C11 FAIL: P2" in out)

# C9: plate run files
RANK = ("---\ntype: plate-ranking\nstatus: {status}\nmode: {mode}\nowner_review: {review}\ncriterion: \"q\"\n---\n\n## Items\n\n"
        "| Key | Item | P# | Due | If it slips | Who waits | Only you? | Size | Why now |\n|---|---|---|---|---|---|---|---|---|\n"
        "| A | Proposal | P4 | Fri | lose it | Grill | yes | half a day | sale |\n"
        "| B | Calls | P18 | no date | none | nobody | yes | half a day | leads |\n\n"
        "## Head-to-head\n\n| Pair | Winner | By | Reason |\n|---|---|---|---|\n| A-B | A | {by} | {reason} |\n")


def plate_run(status="battling", mode="manual", review="not yet", by="owner", reason="", page=True, keep=None, verdict=None,
              rank_review="No failed items.\nVerdict: pass\n", log=""):
    tk = build("", log_rows=log)
    run_dir = tk / "chief-of-staff/runs/2026-11-23-plate"
    run_dir.mkdir(parents=True)
    (run_dir / "08_rank.md").write_text(RANK.format(status=status, mode=mode, review=review, by=by, reason=reason))
    if rank_review:
        (run_dir / "08_review.md").write_text(rank_review)
    (run_dir / "07_plate.md").write_text("# Plate\n" + (keep or ""))
    (run_dir / "06_log.md").write_text("# Log\n")
    if page:
        (run_dir / "09_priorities.md").write_text("# Page\n")
    if verdict:
        (run_dir / "10_review.md").write_text(verdict)
    return tk


rc, out = run(plate_run(status="battling"))
case("C9 every pair answered, 09 page written, status still battling: fails (R2-B12, R2-D8)", rc == 1 and "C9 FAIL" in out and "status: ranked" in out)
rc, out = run(plate_run(status="ranked"))
case("C9 the same file with status ranked passes", rc == 0)
rc, out = run(plate_run(status="ranked", mode="auto", by="chief of staff", reason="due Fri and Grill waits",
                        review='looks right 2026-11-23 09:10, "looks right except flip 3"'))
case("C9 'looks right except flip 3' is not an approval (R2-C9)", rc == 1 and "C9 FAIL" in out)
rc, out = run(plate_run(status="ranked", mode="auto", by="chief of staff", reason="due Fri and Grill waits",
                        review='looks right 2026-11-23 09:10, "yes, looks right"',
                        log="| L1 | 2026-11-23 09:00 | Chief of Staff ranked 2 plate items for the owner's review | T2 | a | review: pass (separate), runs/2026-11-23-plate/08_review.md, 1 of 1 pairs | | done |\n"))
case("C9 'looks right YYYY-MM-DD HH:MM' with plain words is an approval (with its T2 review row, 0.6.14)", rc == 0)

KEEP = ("\n## Kept order\n\n| Rank | P# | Item |\n|---|---|---|\n| 1 | P4 | Proposal |\n\n"
        "Pair 1: P21 vs #3 P1, winner P1, Chief of Staff: P1 is due Dec 5 and the chamber waits, P21 has no date\n\n")
tk = plate_run(status="ranked", page=False, keep=KEEP + 'owner_review: looks right 2026-11-23 09:10, "fine"\n')
(tk / "handoffs/priorities.md").write_text("---\nfrom: chief-of-staff\nupdated: 2026-11-23 09:20\nranked_on: 2026-11-23\nstatus: ok\n---\n## Ranked\n| Rank | P# | Item | Who does it | Due | Size | Result this week | Status |\n|---|---|---|---|---|---|---|---|\n| 1 | P4 | Proposal | you | Fri | half a day | sent | open |\n")
rc, out = run(tk)
case("C9 a kept order used by handoffs/priorities.md (ranked_on = run date) needs its saved review (R2-C10)", rc == 1 and "10_review.md" in out)
(tk / "chief-of-staff/runs/2026-11-23-plate/10_review.md").write_text("Failed: reason 1 cites the profile.\nFixed.\nVerdict: pass\n")
rc, out = run(tk)
case("C9 the same kept order with 10_review.md ending 'Verdict: pass' passes", rc == 0)

for tk in MADE:
    shutil.rmtree(tk, ignore_errors=True)
print(f"\n{sum(results)} of {len(results)} pass")
sys.exit(0 if all(results) else 1)
