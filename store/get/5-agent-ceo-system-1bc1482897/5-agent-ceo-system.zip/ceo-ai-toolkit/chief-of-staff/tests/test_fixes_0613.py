#!/usr/bin/env python3
"""Self-test for the 0.6.13 script fixes (final round on 0.6.12: slices A, B, C and the bonus run).
Run: python3 chief-of-staff/tests/test_fixes_0613.py
Builds a throwaway toolkit in a temp folder with made-up data and removes it after. Exit 0 = all pass.
To test other copies of the scripts (for example an older version), set COS_SCRIPTS to their folder."""
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

SRC = Path(__file__).resolve().parent.parent
SCRIPTS = Path(os.environ.get("COS_SCRIPTS") or SRC / "scripts")
MADE, LAST, results = [], [""], []

LOG_HEAD = "| L# | Time | Decision | Tier | Why | Evidence | Owner's words | Result |\n|---|---|---|---|---|---|---|---|\n"
PLATE_HEAD = ("| P# | Added | Item | Kind | Due | Who waits | Only you? | Size | Waits on | Sort: now / must / later / no / standing | Rank | Goes to | Status |\n"
              "|---|---|---|---|---|---|---|---|---|---|---|---|---|\n")
CHANGES_HEAD = ("\n## Changes since the last full ranking\n| Date | P# | What changed | Pairs answered | Letters and who picked | Reasons (Chief of Staff's picks) | Lands at | Shown to you |\n"
                "|---|---|---|---|---|---|---|---|\n")
JOBS_HEAD = "| Job# | For | Job | Write result to | Due | Light | Status |\n|---|---|---|---|---|---|---|\n"
BOARD = ("# Board\n\n## Your list (tasks only the owner does)\n| A# | Date | Task | Why it matters | Status: open / done |\n|---|---|---|---|---|\n{rows}\n"
         "## Job queue\n| Job# | Job | Manager | Result goes to | Due | Light | Status |\n|---|---|---|---|---|---|---|\n")

ITEMS = ("## Items\n\n| Key | Item | P# | Due | If it slips | Who waits | Only you? | Size | Why now |\n|---|---|---|---|---|---|---|---|---|\n"
         "| A | Proposal | P4 | Fri Nov 27 | lose the sale | Harbor Grill | yes | half a day | a sale |\n"
         "| B | Calls | P18 | no date | none | nobody | yes | half a day | new clients |\n"
         "| C | Chamber | P1 | Dec 5 | lose the slot | the chamber | no | 1 hour | referrals |\n"
         "| D | Checklist | P21 | no date | none | nobody | no | half a day | new clients |\n\n")
H2H = "## Head-to-head\n\n| Pair | Winner | By | Reason |\n|---|---|---|---|\n"
PAIRS = ("A-B", "A-C", "A-D", "B-C", "B-D", "C-D")


def toolkit(rank_mode="auto"):
    tk = Path(tempfile.mkdtemp())
    MADE.append(tk)
    cos = tk / "chief-of-staff"
    for d in ("scripts", "_shared", "board", "runs", "_templates/run", "_templates/plate"):
        (cos / d).mkdir(parents=True)
    (tk / "handoffs").mkdir()
    for n in ("rank_plate.py", "new_run.py", "check_gates.py"):
        shutil.copy(SCRIPTS / n, cos / "scripts" / n)
    (cos / "_shared/owner-profile.md").write_text(f"---\nsetup_done: yes\n---\nTime zone: Pacific\n- rank_mode: {rank_mode}\n")
    (cos / "_shared/decision-log.md").write_text(LOG_HEAD)
    (cos / "board/plate.md").write_text("## Plate\n" + PLATE_HEAD)
    (cos / "board/board.md").write_text("# Board\n")
    (tk / "handoffs/jobs.md").write_text(JOBS_HEAD)
    (cos / "_templates/run/01_intake.md").write_text("# {{run_name}} {{YYYY-MM-DD HH:MM}}\n")
    (cos / "_templates/plate/07_plate.md").write_text("# {{run_name}}\n")
    (cos / "_templates/plate/08_rank.md").write_text("# {{run_name}}\n")
    return tk


def rank_file(tk, front, rows, items=ITEMS):
    p = tk / "chief-of-staff/runs/2026-11-24-plate"
    p.mkdir(parents=True, exist_ok=True)
    f = p / "08_rank.md"
    f.write_text("---\n" + front + "\ncriterion: \"q\"\n---\n\n" + items + H2H + rows)
    return f


def open_rows(pairs=PAIRS):
    return "".join(f"| {p} |  |  |  |\n" for p in pairs)


def rp(tk, *args):
    r = subprocess.run([sys.executable, "-B", str(tk / "chief-of-staff/scripts/rank_plate.py"), *args], capture_output=True, text=True)
    LAST[0] = r.stdout + r.stderr
    return r.returncode, LAST[0]


def gates(tk, today="2026-11-24"):
    r = subprocess.run([sys.executable, "-B", str(tk / "chief-of-staff/scripts/check_gates.py"), "--today", today], capture_output=True, text=True)
    LAST[0] = r.stdout + r.stderr
    return r.returncode, LAST[0]


def case(name, ok):
    results.append(ok)
    print(("PASS " if ok else "FAIL ") + name)
    if not ok:
        print("  output was: " + LAST[0].strip().replace("\n", " / ")[:700])


# ---- rank_plate.py ----

# B:F-C3: next shows labeled facts (due X, Y waits, nobody waits)
tk = toolkit("manual")
f = rank_file(tk, "status: battling\nmode: manual\nowner_review: not yet", open_rows())
rc, out = rp(tk, "next", str(f))
case("B:F-C3 next labels the facts ('due Fri Nov 27', 'Harbor Grill waits', 'nobody waits')",
     "due Fri Nov 27" in out and "Harbor Grill waits" in out and "nobody waits" in out)

# B:F-C4: the letters-only STOP shows no example string built for other pairs
rc, out = rp(tk, "answer", str(f), "A then B")
case("B:F-C4 a words reply STOP shows no example letters (ACADAEAFG)", rc == 1 and "ACADAEAFG" not in out)

# B:F-C2: after a leftover batch is complete, the next batch is 9 again
SEVEN = ("## Items\n\n| Key | Item | P# | Due | If it slips | Who waits | Only you? | Size | Why now |\n|---|---|---|---|---|---|---|---|---|\n"
         + "".join(f"| {k} | Item {k} | P{n} | no date | none | nobody | yes | 1 hour | w{k} |\n" for n, k in enumerate("ABCDEFG", 1)) + "\n")
pairs7 = [f"{a}-{b}" for i, a in enumerate("ABCDEFG") for b in "ABCDEFG"[i + 1:]]
tk = toolkit("manual")
f = rank_file(tk, "status: battling\nmode: manual\nowner_review: not yet", open_rows(pairs7), items=SEVEN)
rc, out = rp(tk, "answer", str(f), "AAG", "--batch", "9")  # pair 3 is A-D and G is not in it: STOP, 2 saved, 7 left
rc, out = rp(tk, "answer", str(f), "AAAABBB", "--batch", "7")  # the 7 left: A-D A-E A-F A-G B-C B-D B-E
case("B:F-C2 a complete leftover batch of 7 is followed by a batch of 9", "exactly 9 letter(s)" in out and "--batch 9" in out)

# B:F-C13: set repairing a broken row (winner not in its pair) leaves no "you changed your own pick"
tk = toolkit("manual")
rows = open_rows(PAIRS).replace("| A-B |  |  |  |", "| A-B | Z | owner |  |")
f = rank_file(tk, "status: battling\nmode: manual\nowner_review: not yet", rows)
rp(tk, "set", str(f), "A-B", "A")
case("B:F-C13 set on a broken row writes no 'you changed your own pick'", "you changed your own pick" not in f.read_text())

# C:F-C13: set reopens the review on an approved auto file even when no Chief of Staff pick is left
tk = toolkit("auto")
done_owner = "".join(f"| {p} | {p[0]} | owner |  |\n" for p in PAIRS)
f = rank_file(tk, 'status: ranked\nmode: auto\nowner_review: looks right 2026-11-24 09:10, "fine"', done_owner)
rp(tk, "set", str(f), "A-B", "B")
text = f.read_text()
case("C:F-C13 set on an approved auto file sets waiting for your review and not yet", "status: waiting for your review" in text and "owner_review: not yet" in text)

# C:F-C2: auto stops when the owner profile says rank_mode: manual
tk = toolkit("manual")
f = rank_file(tk, "status: battling\nmode: auto\nowner_review: not yet", open_rows())
before = f.read_bytes()
picks = tk / "picks.txt"
picks.write_text("A-B A: A due Fri Nov 27, B has no date\n")
rc, out = rp(tk, "auto", str(f), str(picks))
case("C:F-C2 auto writes nothing when the profile says rank_mode: manual", rc != 0 and "STOP" in out and f.read_bytes() == before)

# C:F-C15: facts-equal pairs are marked, and need 'facts equal:' plus the lower P#. List position is refused.
tk = toolkit("auto")
f = rank_file(tk, "status: battling\nmode: auto\nowner_review: not yet", open_rows())
rc, out = rp(tk, "auto", str(f))
case("C:F-C15 auto marks the pair with every fact the same [facts equal]", "B-D" in out and "[facts equal]" in out)
for label, line in (("'listed after'", "B-D B: D is listed after B"),
                    ("no 'facts equal:'", "B-D B: both have no date and nobody waits"),
                    ("the higher P# winning", "B-D D: facts equal: both no date, nobody waits, half a day")):
    before = f.read_bytes()
    picks = tk / "p.txt"
    picks.write_text(line + "\n")
    rc, out = rp(tk, "auto", str(f), str(picks))
    case(f"C:F-C15 auto STOPs a facts-equal pick with {label}", rc != 0 and "STOP" in out and f.read_bytes() == before)
picks.write_text("B-D B: facts equal: both no date, nobody waits, half a day. P18 is the lower P#\n")
rc, out = rp(tk, "auto", str(f), str(picks))
case("C:F-C15 auto writes a facts-equal pick that follows the tie rule", rc == 0 and "1 pick(s) written" in out)

# C:F-C10: clear marks the picks file lines '# cleared'
tk = toolkit("auto")
f = rank_file(tk, "status: battling\nmode: auto\nowner_review: not yet", open_rows())
pf = f.parent / "08_picks.txt"
pf.write_text("A-B A: A due Fri Nov 27, B has no date\n")
rp(tk, "auto", str(f), str(pf))
rp(tk, "clear", str(f))
case("C:F-C10 clear marks every line of 08_picks.txt '# cleared'", pf.read_text().startswith("# cleared: A-B A:"))

# B:F-C11: the tally counts flips apart from the owner's own answers
tk = toolkit("auto")
cos_rows = "".join(f"| {p} | {p[0]} | chief of staff | due date decides it |\n" for p in PAIRS)
f = rank_file(tk, "status: waiting for your review\nmode: auto\nowner_review: not yet", cos_rows)
rp(tk, "flip", str(f), "1")
case("B:F-C11 tally says '1 flipped by the owner' after one flip", "1 flipped by the owner" in f.read_text())

# B:F-C5: the owner's order inside a tied loop survives a new tally
LOOP = ("| A-B | A | owner |  |\n| A-C | C | owner |  |\n| A-D | A | owner |  |\n"
        "| B-C | B | owner |  |\n| B-D | B | owner |  |\n| C-D | C | owner |  |\n")
tk = toolkit("manual")
f = rank_file(tk, "status: battling\nmode: manual\nowner_review: not yet", LOOP)
rp(tk, "tally", str(f))
t = f.read_text().replace("Letter order is used until the owner picks.", "").replace(
    "Owner picks the order inside each group", "Owner picked the order: C, B, A.\nOld")
f.write_text(t)
rp(tk, "tally", str(f))
res = f.read_text().split("## Result", 1)[-1]
case("B:F-C5 tally keeps 'Owner picked the order: C, B, A' and that row order",
     "Owner picked the order: C, B, A." in res and res.index("| C |") < res.index("| B |") < res.index("| A |"))

# C:F-C1: an automatic ranking at ranked needs 08_review.md ending Verdict: pass
tk = toolkit("auto")
f = rank_file(tk, 'status: ranked\nmode: auto\nowner_review: looks right 2026-11-24 09:10, "fine"', cos_rows)
rp(tk, "tally", str(f))
rc, out = rp(tk, "check", str(f))
case("C:F-C1 check fails an approved automatic ranking with no 08_review.md", rc == 1 and "08_review.md" in out)
(f.parent / "08_review.md").write_text("Failed: pair 3.\nVerdict: fail\n")
rc, out = rp(tk, "check", str(f))
case("C:F-C1 check fails when 08_review.md ends Verdict: fail with no red-path log row", rc == 1 and "Verdict: fail" in out)
(f.parent / "08_review.md").write_text("No failed items.\nVerdict: pass\n")
# Since 0.6.14 (C:L-C1) the pass also needs its T2 decision log row naming the review file.
(tk / "chief-of-staff/_shared/decision-log.md").write_text(
    LOG_HEAD + "| L1 | 2026-11-24 09:00 | Chief of Staff ranked 4 plate items for the owner's review | T2 | a | review: pass (self), runs/2026-11-24-plate/08_review.md, 6 of 6 pairs | | done |\n")
rc, out = rp(tk, "check", str(f))
case("C:F-C1 check passes with 08_review.md ending Verdict: pass (and its T2 row)", rc == 0)

# C:F-C14: a 09 page from an older order fails
page = ("# Your priorities\n\n## The full order\n| Rank | P# | Item | Wins | Who does it | Due |\n|---|---|---|---|---|---|\n"
        "| 1 | {0} | x | 3 | you | - |\n| 2 | {1} | x | 2 | you | - |\n| 3 | {2} | x | 1 | you | - |\n| 4 | {3} | x | 0 | you | - |\n")
(f.parent / "09_priorities.md").write_text(page.format("P18", "P4", "P1", "P21"))
rc, out = rp(tk, "check", str(f))
case("C:F-C14 check fails a 09_priorities.md whose order differs from the Result", rc == 1 and "older order" in out)
(f.parent / "09_priorities.md").write_text(page.format("P4", "P18", "P1", "P21"))
rc, out = rp(tk, "check", str(f))
case("C:F-C14 check passes a 09_priorities.md in the Result order", rc == 0)

# B:F-C6: light prints the Pairs answered count (2 for NO)
PRIO = ("---\nfrom: chief-of-staff\nupdated: 2026-11-22 09:00\nranked_on: 2026-11-22\nstatus: ok\ncriterion: \"q\"\n---\n\n"
        "## Ranked\n| Rank | P# | Item | Who does it | Due | Size | Result this week | Status |\n|---|---|---|---|---|---|---|---|\n"
        "| 1 | P4 | Proposal | you | Fri Nov 27 | half a day | sent | open |\n"
        "| 2 | P18 | Calls | you | - | half a day | held | open |\n"
        "| 3 | P1 | Chamber | Email Manager | Dec 5 | 1 hour | drafted | open |\n\n"
        "## Must do by date\n| P# | Item | Who does it | Due | Status |\n|---|---|---|---|---|\n\n"
        "## New since the ranking\n| P# | Item | Placed | Status |\n|---|---|---|---|\n| P21 | Checklist | not placed yet | waiting: your picks |\n")
tk = toolkit("manual")
(tk / "handoffs/priorities.md").write_text(PRIO)
rc, out = rp(tk, "light", str(tk / "handoffs/priorities.md"), "P21", "NO", "--today", "2026-11-24 08:00")
case("B:F-C6 light prints 'Pairs answered: 2' for NO", "Pairs answered: 2" in out)

# ---- check_gates.py ----

# C:F-C8: --today with a time
tk = toolkit()
rc, out = gates(tk, "2026-11-24 08:00")
case("C:F-C8 check_gates --today \"YYYY-MM-DD HH:MM\" runs (no ValueError)", "Traceback" not in out and rc == 0)


def log(*rows):
    return LOG_HEAD + "".join(rows)


# C:F-C19: an action word naming a document is not the action
tk = toolkit()
(tk / "chief-of-staff/_shared/decision-log.md").write_text(log("| L1 | 2026-11-24 08:10 | P6: hiring checklist drafted, nothing sent | T1 | a | b | | done |\n"))
rc, out = gates(tk)
case("C:F-C19 'hiring checklist drafted, nothing sent' at T1 is not C7", "C7 FAIL" not in out)
(tk / "chief-of-staff/_shared/decision-log.md").write_text(log("| L1 | 2026-11-24 08:10 | Send the contract draft to Tom | T1 | a | b | | done |\n"))
rc, out = gates(tk)
case("C:F-C19 'Send the contract draft to Tom' at T1 is still C7", "C7 FAIL: L1" in out)

# F-W2: C8 needs (separate) or (self) and a saved review file ending Verdict: pass
tk = toolkit()
t2 = "| L1 | 2026-11-24 08:10 | Wrote the checklist | T2 | a | {ev} | | done |\n"
for label, ev in (("a bare 'review: pass'", "review: pass, runs/2026-11-24-pricing/03_review.md"),
                  ("(self) with no saved file", "review: pass (self), runs/2026-11-24-pricing/03_review.md")):
    (tk / "chief-of-staff/_shared/decision-log.md").write_text(log(t2.format(ev=ev)))
    rc, out = gates(tk)
    case(f"F-W2 C8 fails {label}", rc == 1 and "C8 FAIL: L1" in out)
run = tk / "chief-of-staff/runs/2026-11-24-pricing"
run.mkdir(parents=True)
(run / "01_intake.md").write_text("# x\n")
(run / "03_review.md").write_text("No failed items.\nVerdict: pass\n")
(tk / "chief-of-staff/_shared/decision-log.md").write_text(log(t2.format(ev="review: pass (separate), runs/2026-11-24-pricing/03_review.md")))
rc, out = gates(tk)
case("F-W2 C8 passes '(separate)' with a saved review ending Verdict: pass", "C8 FAIL" not in out and rc == 0)

# C:F-C12: a lowercase 'chief of staff:' kept order is still checked
tk = toolkit()
run = tk / "chief-of-staff/runs/2026-11-24-plate"
run.mkdir(parents=True)
(run / "06_log.md").write_text("# Log\n")
(run / "09_priorities.md").write_text("# Page\n")
(run / "07_plate.md").write_text("# Plate\n\n## Kept order\n\n| Rank | P# | Item |\n|---|---|---|\n| 1 | P4 | Proposal |\n\n"
                                  "Pair 1: P21 vs #3 P1, winner P1, chief of staff: P1 due Dec 5, P21 has no date\n")
rc, out = gates(tk)
case("C:F-C12 C9 checks a kept order written 'chief of staff:' in lower case", rc == 1 and "C9 FAIL" in out)

# C:F-C3: a must whose status is not exactly 'open' is still checked
for status in ("Open", "open (who does it: asked)"):
    tk = toolkit()
    (tk / "chief-of-staff/board/plate.md").write_text("## Plate\n" + PLATE_HEAD + f"| P2 | 2026-11-20 | Filing | one-off | 2026-12-01 | - | no | 1 hour | - | must | - | you | {status} |\n")
    rc, out = gates(tk)
    case(f"C:F-C3 C11 flags a must with status '{status}' and no job", rc == 1 and "C11 FAIL: P2" in out)

# B:F-C6: C10 checks Pairs answered against the letters
tk = toolkit()
(tk / "chief-of-staff/board/plate.md").write_text("## Plate\n" + PLATE_HEAD + CHANGES_HEAD +
                                                    "| 2026-11-24 | P21 | placed | 1 | NO, you | - | below the top 3 | 2026-11-24 |\n")
rc, out = gates(tk)
case("B:F-C6 C10 fails Pairs answered 1 for the letters NO", rc == 1 and "C10 FAIL" in out and "Pairs answered" in out)

# A:F-C4: a board row with a different cell count from its header
tk = toolkit()
(tk / "chief-of-staff/board/board.md").write_text(BOARD.format(rows="| A2 | 2026-11-24 | Send the draft | open |\n"))
rc, out = gates(tk)
case("A:F-C4 C12 fails a Your list row with 4 cells under a 5-cell header", rc == 1 and "C12 FAIL" in out and "4 cells" in out)

# F-W7: an open Your list row needs an 'A#: Owner task:' log row
tk = toolkit()
(tk / "chief-of-staff/board/board.md").write_text(BOARD.format(rows="| A2 | 2026-11-24 | Send the draft from your own mail | sent later | open |\n"))
rc, out = gates(tk)
case("F-W7 C12 fails an open Your list row with no Owner task log row", rc == 1 and "C12 FAIL" in out and "A2" in out)
(tk / "chief-of-staff/_shared/decision-log.md").write_text(log("| L1 | 2026-11-24 08:10 | A2: Owner task: send the draft from your own mail | T1 | a | b | | done |\n"))
rc, out = gates(tk)
case("F-W7 C12 passes with 'A2: Owner task:' in the log", rc == 0)

# ---- new_run.py ----

# C:F-C9: --help makes no run folder
tk = toolkit()
r = subprocess.run([sys.executable, "-B", str(tk / "chief-of-staff/scripts/new_run.py"), "--help"], capture_output=True, text=True)
LAST[0] = r.stdout + r.stderr
case("C:F-C9 new_run.py --help makes no run folder", not any((tk / "chief-of-staff/runs").iterdir()))

for tk in MADE:
    shutil.rmtree(tk, ignore_errors=True)
print(f"\n{sum(results)} of {len(results)} pass")
sys.exit(0 if all(results) else 1)
