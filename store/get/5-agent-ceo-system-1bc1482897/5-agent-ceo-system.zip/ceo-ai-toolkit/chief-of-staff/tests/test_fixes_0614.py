#!/usr/bin/env python3
"""Self-test for the 0.6.14 script fixes (last pass on 0.6.13: slices A, B, C and the bonus run).
Run: python3 chief-of-staff/tests/test_fixes_0614.py
Builds a throwaway toolkit in a temp folder with made-up data and removes it after. Exit 0 = all pass.
To test other copies of the scripts (for example the 0.6.13 ones), set COS_SCRIPTS to their folder.
Every case here fails on 0.6.13."""
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

SRC = Path(__file__).resolve().parent.parent
SCRIPTS = Path(os.environ.get("COS_SCRIPTS") or SRC / "scripts")
MADE, LAST, results = [], [""], []

LOG_HEAD = "| L# | Time | Decision | Tier | Why | Evidence | Owner's words | Result |\n|---|---|---|---|---|---|---|---|\n"
PLATE_HEAD = ("| P# | Added | Item | Kind | Due | Who waits | Only you? | Size | Waits on | Sort: now / must / later / no / standing | Rank | Goes to | Status |\n"
              "|---|---|---|---|---|---|---|---|---|---|---|---|---|\n")
JOBS_HEAD = "| Job# | For | Job | Write result to | Due | Light | Status |\n|---|---|---|---|---|---|---|\n"
H2H = "## Head-to-head\n\n| Pair | Winner | By | Reason |\n|---|---|---|---|\n"
ITEMS_HEAD = "## Items\n\n| Key | Item | P# | Due | If it slips | Who waits | Only you? | Size | Why now |\n|---|---|---|---|---|---|---|---|---|\n"
ITEMS = (ITEMS_HEAD +
         "| A | Proposal | P4 | Fri Nov 27 | lose the sale | Harbor Grill | yes | half a day | a sale |\n"
         "| B | Calls | P18 | no date | none | nobody | yes | half a day | new clients |\n"
         "| C | Chamber | P1 | Dec 5 | lose the slot | the chamber | no | 1 hour | referrals |\n"
         "| D | Checklist | P21 | no date | none | nobody | no | half a day | new clients |\n\n")
PAIRS = ("A-B", "A-C", "A-D", "B-C", "B-D", "C-D")


def toolkit(rank_mode="auto"):
    tk = Path(tempfile.mkdtemp())
    MADE.append(tk)
    cos = tk / "chief-of-staff"
    for d in ("scripts", "_shared", "board", "runs", "_templates/run", "_templates/plate"):
        (cos / d).mkdir(parents=True)
    (tk / "handoffs").mkdir()
    (tk / "logs").mkdir()
    for n in ("rank_plate.py", "new_run.py", "check_gates.py"):
        shutil.copy(SCRIPTS / n, cos / "scripts" / n)
    (cos / "_shared/owner-profile.md").write_text(f"---\nsetup_done: yes\n---\nTime zone: Pacific\n- rank_mode: {rank_mode}\n")
    (cos / "_shared/decision-log.md").write_text(LOG_HEAD)
    (cos / "board/plate.md").write_text("## Plate\n" + PLATE_HEAD)
    (cos / "board/board.md").write_text("# Board\n")
    (tk / "handoffs/jobs.md").write_text(JOBS_HEAD)
    (cos / "_templates/run/01_intake.md").write_text("# {{run_name}} {{YYYY-MM-DD HH:MM}}\n")
    (cos / "_templates/plate/07_plate.md").write_text("# {{run_name}}\n")
    (cos / "_templates/plate/08_rank.md").write_text("# {{run_name}}\n")
    return tk


def rank_file(tk, front, rows, items=ITEMS):
    p = tk / "chief-of-staff/runs/2026-11-24-plate"
    p.mkdir(parents=True, exist_ok=True)
    f = p / "08_rank.md"
    f.write_text("---\n" + front + "\ncriterion: \"q\"\n---\n\n" + items + H2H + rows)
    return f


def open_rows(pairs=PAIRS):
    return "".join(f"| {p} |  |  |  |\n" for p in pairs)


def run(tk, script, *args):
    r = subprocess.run([sys.executable, "-B", str(tk / "chief-of-staff/scripts" / script), *args], capture_output=True, text=True)
    LAST[0] = r.stdout + r.stderr
    return r.returncode, LAST[0]


def rp(tk, *args):
    return run(tk, "rank_plate.py", *args)


def gates(tk, today="2026-11-24"):
    return run(tk, "check_gates.py", "--today", today)


def log(tk, *rows):
    (tk / "chief-of-staff/_shared/decision-log.md").write_text(LOG_HEAD + "".join(rows))


def case(name, ok):
    results.append(ok)
    print(("PASS " if ok else "FAIL ") + name)
    if not ok:
        print("  output was: " + LAST[0].strip().replace("\n", " / ")[:700])


def line_of(out, start):
    return next((ln for ln in out.split("\n") if ln.startswith(start)), "")


# ---- check_gates.py ----

# C:L-C12: the negation covers every action word in a list ("nothing sent or posted")
for text in ("P6: draft held, nothing sent or posted", "P6: draft held, not sent, posted or paid"):
    tk = toolkit()
    log(tk, f"| L1 | 2026-11-24 08:10 | {text} | T1 | a | b | | done |\n")
    rc, out = gates(tk)
    case(f"C:L-C12 '{text}' at T1 is not C7", "C7 FAIL" not in out and rc == 0)
tk = toolkit()
log(tk, "| L1 | 2026-11-24 08:10 | P6: not sent, but posted to the group | T1 | a | b | | done |\n")
rc, out = gates(tk)
case("C:L-C12 'not sent, but posted' at T1 is still C7", "C7 FAIL: L1" in out)

# L-W6: a memo named in today's activity line needs its board row
tk = toolkit()
(tk / "logs/activity.md").write_text("# Activity log\n\n| When | Agent | Job | Result | Proof |\n|---|---|---|---|---|\n"
                                     "| 2026-11-24 06:30 | watch-to-ai | Handed 1 Watch memo to the Chief of Staff | handed over | "
                                     "bonus-watch-to-ai/memos/2026-11-24-062000-ab12.md contains \"from: bonus-watch-to-ai\" |\n")
rc, out = gates(tk)
case("L-W6 C12 fails a memo in today's activity log with no board row", rc == 1 and "C12 FAIL" in out and "2026-11-24-062000-ab12.md" in out)
(tk / "chief-of-staff/board/board.md").write_text("# Board\n\n## Inbox\n| IN# | Date | Item | Status |\n|---|---|---|---|\n"
                                                    "| IN1 | 2026-11-24 | Idea: payroll checkup (Watch memo 2026-11-24-062000-ab12.md) | decided |\n")
rc, out = gates(tk)
case("L-W6 C12 passes once the memo has its board row", rc == 0)

# ---- rank_plate.py: the review rows (C9) ----

cos_rows = "".join(f"| {p} | {p[0]} | chief of staff | due date decides it |\n" for p in PAIRS)

# C:L-C1: a passed automatic ranking needs its T2 log row naming 08_review.md
tk = toolkit("auto")
f = rank_file(tk, 'status: ranked\nmode: auto\nowner_review: looks right 2026-11-24 09:10, "fine"', cos_rows)
rp(tk, "tally", str(f), "--today", "2026-11-24")
(f.parent / "08_review.md").write_text("No failed items.\nVerdict: pass\n")
rc, out = rp(tk, "check", str(f))
case("C:L-C1 check fails a passed automatic ranking with no T2 row naming 08_review.md", rc == 1 and "T2" in out)
log(tk, "| L1 | 2026-11-24 09:00 | Chief of Staff ranked 4 plate items for the owner's review | T2 | a | review: pass (self), runs/2026-11-24-plate/08_review.md, 6 of 6 pairs | | done |\n")
rc, out = rp(tk, "check", str(f))
case("C:L-C1 check passes with the T2 row", rc == 0)

# C:L-C2: "failed review twice" counts only as a T3 row that names this run
(f.parent / "08_review.md").write_text("Failed: pair 3.\nFixed.\nFailed: pair 3 again.\nVerdict: fail\n")
log(tk, "| L1 | 2026-11-10 09:00 | Chief of Staff's ranking failed review twice: shown to the owner with the notes | T3 | a | runs/2026-11-10-plate/08_review.md | | pending |\n")
rc, out = rp(tk, "check", str(f))
case("C:L-C2 a 'failed review twice' row for another run does not clear this run's Verdict: fail", rc == 1 and "failed review twice" in out)
log(tk, "| L1 | 2026-11-24 09:00 | Chief of Staff's ranking failed review twice: shown to the owner with the notes | T3 | a | runs/2026-11-24-plate/08_review.md | | pending |\n")
rc, out = rp(tk, "check", str(f))
case("C:L-C2 the T3 row naming this run clears it", rc == 0)

# C:L-C11: clear marks the saved review of the removed picks superseded, last line kept
tk = toolkit("auto")
f = rank_file(tk, "status: battling\nmode: auto\nowner_review: not yet", open_rows())
pf = f.parent / "08_picks.txt"
pf.write_text("A-C A: A due Fri Nov 27, C due Dec 5\n")
rp(tk, "auto", str(f), str(pf), "--today", "2026-11-24")
(f.parent / "08_review.md").write_text("No failed items.\nVerdict: pass\n")
rc, out = rp(tk, "clear", str(f))
text = (f.parent / "08_review.md").read_text()
case("C:L-C11 clear marks 08_review.md superseded and keeps its last line", text.startswith("Superseded") and text.rstrip().endswith("Verdict: pass") and "corrects L#" in out)

# ---- rank_plate.py: tally ----

# B:L-C11: the tally prints a Picked by line also when the owner made every pick
tk = toolkit("manual")
owner_rows = "".join(f"| {p} | {p[0]} | owner |  |\n" for p in PAIRS)
f = rank_file(tk, "status: battling\nmode: manual\nowner_review: not yet", owner_rows)
rc, out = rp(tk, "tally", str(f), "--today", "2026-11-24")
case("B:L-C11 tally prints 'Picked by: 6 pair(s) answered by the owner' when the owner picked every pair",
     "Picked by: 6 pair(s) answered by the owner" in out and "Picked by: 6" in f.read_text())

# A:L-C13: without --today the tally says its footer date is from the clock
rc, out = rp(tk, "tally", str(f))
case("A:L-C13 tally without --today names the clock date and the --today flag", "from the clock" in out and "--today" in out)

# ---- rank_plate.py: facts equal by kind (PL22) ----

KIND = (ITEMS_HEAD +
        "| A | Referral offer | P5 | no date | none | Tom | no | half a day | new clients |\n"
        "| B | Pricing page | P8 | no date | none | the chamber | no | half a day | new clients |\n"
        "| C | Tax packets | P7 | Jan 20 | penalties | clients | no | half a day | new clients |\n"
        "| D | Newsletter | P17 | no date | none | Sam | no | half a day | a sale |\n\n")
tk = toolkit("auto")
f = rank_file(tk, "status: battling\nmode: auto\nowner_review: not yet", open_rows(), items=KIND)
rc, out = rp(tk, "auto", str(f), "--today", "2026-11-24")
case("B:L-C7 two named waiters, no date, no cost, same size and why now are [facts equal] (PL22 compares by kind)",
     "[facts equal]" in line_of(out, "1. A-B"))
case("B:L-C7 a date more than 30 days out against no date is not decided by Due (A-C turns on If it slips, no mark)",
     "[facts equal]" not in line_of(out, "2. A-C") and "[check why now]" not in line_of(out, "2. A-C"))
case("C:L-C3 a pair that differs only in Why now is marked [check why now]", "[check why now]" in line_of(out, "3. A-D"))
pf = tk / "p.txt"
pf.write_text("A-D D: D is the stronger item\n")
before = f.read_bytes()
rc, out = rp(tk, "auto", str(f), str(pf), "--today", "2026-11-24")
case("C:L-C3 auto STOPs a [check why now] pick whose reason does not name why now", rc != 0 and "Why now" in out and f.read_bytes() == before)
pf.write_text("A-D D: why now: D names a sale, A names new clients only\nA-B A: facts equal: both no date, someone waits, no cost, half a day, new clients. P5 is the lower P#\n")
rc, out = rp(tk, "auto", str(f), str(pf), "--today", "2026-11-24")
case("C:L-C3 auto writes a why-now pick and a by-kind facts-equal pick", rc == 0 and "2 pick(s) written" in out)

# PL22 (L-W12 in the full ranking): an empty Due is missing, never "no date"
EMPTY = (ITEMS_HEAD +
         "| A | Proposal | P4 |  | lose the sale | Harbor Grill | yes | half a day | a sale |\n"
         "| B | Calls | P18 | no date | none | nobody | yes | half a day | new clients |\n\n")
tk = toolkit("auto")
f = rank_file(tk, "status: battling\nmode: auto\nowner_review: not yet", open_rows(("A-B",)), items=EMPTY)
rc, out = rp(tk, "auto", str(f), "--today", "2026-11-24")
case("L-W12 an empty Due cell is marked [facts missing: A: due]", "[facts missing: A: due" in out)

# ---- rank_plate.py: light path ----

PRIO = ("---\nfrom: chief-of-staff\nupdated: 2026-11-22 09:00\nranked_on: 2026-11-22\nstatus: ok\ncriterion: \"q\"\n---\n\n"
        "## Ranked\n| Rank | P# | Item | Who does it | Due | Size | Result this week | Status |\n|---|---|---|---|---|---|---|---|\n"
        "| 1 | P4 | Proposal | you | Fri Nov 27 | half a day | sent | open |\n"
        "| 2 | P18 | Calls | you | no date | half a day | held | open |\n"
        "| 3 | P1 | Chamber | Email Manager | Dec 5 | 1 hour | drafted | open |\n\n"
        "## Must do by date\n| P# | Item | Who does it | Due | Status |\n|---|---|---|---|---|\n\n"
        "## New since the ranking\n| P# | Item | Placed | Status |\n|---|---|---|---|\n| P21 | Checklist | not placed yet | waiting: your picks |\n")
BOARD_PLATE = ("## Plate\n" + PLATE_HEAD +
               "| P4 | 2026-11-20 | Proposal | project | Fri Nov 27 | Harbor Grill | yes | half a day | - | now | 1 | you | open |\n"
               "| P18 | 2026-11-20 | Calls | idea | no date | nobody | yes | half a day | - | now | 2 | you | open |\n"
               "| P1 | 2026-11-20 | Chamber | promise | - | the chamber | no | 1 hour | - | now | 3 | Email Manager: draft the follow-up | open |\n"
               "| P21 | 2026-11-24 | Checklist | idea | ? | nobody | ? | half a day | - | now | - | you (who does it: asked) | open |\n")
tk = toolkit("manual")
(tk / "handoffs/priorities.md").write_text(PRIO)
(tk / "chief-of-staff/board/plate.md").write_text(BOARD_PLATE)
rc, out = rp(tk, "light", str(tk / "handoffs/priorities.md"), "P21", "--today", "2026-11-24 08:00")
case("L-W12 light prints a Due of ? as 'due date not known', never 'due ?'", "due date not known" in line_of(out, "1. N") and "due ?" not in out)
case("L-W12 light marks a Due of - (empty) as missing, never 'no date'", "P1: due" in line_of(out, "1. N"))
case("C:L-C8 light never marks 'only you?' as a missing fact (it never decides)", "only you?" not in out)
case("C:L-C8 light says where If it slips and Why now come from", "Why now" in out and "07_plate.md" in out)
rc, out = rp(tk, "light", str(tk / "handoffs/priorities.md"), "P21", "NNN", "--today", "2026-11-24 08:00")
ranked = (tk / "handoffs/priorities.md").read_text().split("## Must do", 1)[0]
case("B:L-C6 light keeps 'you (who does it: asked)' whole in the Ranked row", "| you (who does it: asked) |" in ranked)

# ---- new_run.py ----

# L-W10: --now sets the date and the started time
tk = toolkit()
rc, out = run(tk, "new_run.py", "pricing", "--now", "2026-11-24 08:00")
made = tk / "chief-of-staff/runs/2026-11-24-pricing/01_intake.md"
case("L-W10 new_run.py --now \"2026-11-24 08:00\" dates the run and its time", made.exists() and "2026-11-24 08:00" in made.read_text())

for tk in MADE:
    shutil.rmtree(tk, ignore_errors=True)
print(f"\n{sum(results)} of {len(results)} pass")
sys.exit(0 if all(results) else 1)
