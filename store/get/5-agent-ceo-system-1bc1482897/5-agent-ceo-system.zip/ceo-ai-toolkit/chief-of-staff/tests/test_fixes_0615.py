#!/usr/bin/env python3
"""Self-test for the 0.6.15 script fixes (pass 2 on 0.6.14: slices A, B, C and the bonus run).
Run: python3 chief-of-staff/tests/test_fixes_0615.py
Builds a throwaway toolkit in a temp folder with made-up data and removes it after. Exit 0 = all pass.
To test other copies of the scripts (for example the 0.6.14 ones), set COS_SCRIPTS to their folder.
9 of the 11 cases fail on 0.6.14 (every fix has at least one). The two "passes once" cases show the fix is not a
false alarm. The C7 redesign has its own table: tests/test_c7_phrasings.py (21 of its 43 rows fail on 0.6.14)."""
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

SRC = Path(__file__).resolve().parent.parent
SCRIPTS = Path(os.environ.get("COS_SCRIPTS") or SRC / "scripts")
MADE, LAST, results = [], [""], []

LOG_HEAD = "| L# | Time | Decision | Tier | Why | Evidence | Owner's words | Result |\n|---|---|---|---|---|---|---|---|\n"
PLATE_HEAD = ("| P# | Added | Item | Kind | Due | Who waits | Only you? | Size | Waits on | Sort: now / must / later / no / standing | Rank | Goes to | Status |\n"
              "|---|---|---|---|---|---|---|---|---|---|---|---|---|\n")
JOBS_HEAD = "| Job# | For | Job | Write result to | Due | Light | Status |\n|---|---|---|---|---|---|---|\n"
H2H = "## Head-to-head\n\n| Pair | Winner | By | Reason |\n|---|---|---|---|\n"
ITEMS_HEAD = "## Items\n\n| Key | Item | P# | Due | If it slips | Who waits | Only you? | Size | Why now |\n|---|---|---|---|---|---|---|---|---|\n"
BOARD = ("# Board\n\n## Waiting on you (decisions only the owner can make)\n| D# | Date | Question | Recommendation and why it moves goal 1 | Log L# |\n"
         "|---|---|---|---|---|\n\n## Decided\n| D# or IN# | Date | Decision | Owner's words | Tier | Log L# |\n|---|---|---|---|---|---|\n")


def toolkit(rank_mode="auto"):
    tk = Path(tempfile.mkdtemp())
    MADE.append(tk)
    cos = tk / "chief-of-staff"
    for d in ("scripts", "_shared", "board", "runs"):
        (cos / d).mkdir(parents=True)
    (tk / "handoffs").mkdir()
    for n in ("rank_plate.py", "check_gates.py"):
        shutil.copy(SCRIPTS / n, cos / "scripts" / n)
    (cos / "_shared/owner-profile.md").write_text(f"---\nsetup_done: yes\n---\nTime zone: Pacific\n- rank_mode: {rank_mode}\n")
    (cos / "_shared/decision-log.md").write_text(LOG_HEAD)
    (cos / "board/plate.md").write_text("## Plate\n" + PLATE_HEAD)
    (cos / "board/board.md").write_text(BOARD)
    (tk / "handoffs/jobs.md").write_text(JOBS_HEAD)
    return tk


def rank_file(tk, front, items, pairs):
    p = tk / "chief-of-staff/runs/2026-11-24-plate"
    p.mkdir(parents=True, exist_ok=True)
    f = p / "08_rank.md"
    f.write_text("---\n" + front + "\ncriterion: \"q\"\n---\n\n" + items + H2H + "".join(f"| {x} |  |  |  |\n" for x in pairs))
    return f


def run(tk, script, *args):
    r = subprocess.run([sys.executable, "-B", str(tk / "chief-of-staff/scripts" / script), *args], capture_output=True, text=True)
    LAST[0] = r.stdout + r.stderr
    return r.returncode, LAST[0]


def case(name, ok):
    results.append(ok)
    print(("PASS " if ok else "FAIL ") + name)
    if not ok:
        print("  output was: " + LAST[0].strip().replace("\n", " / ")[:700])


def line_of(out, start):
    return next((ln for ln in out.split("\n") if ln.startswith(start)), "")


# ---- rank_plate.py auto: PL22 reading order with a fact missing (A:P2-C9) ----
# PQ11 skipped: every size is ?. Due and Who waits still decide most pairs, so they are not all sent to the owner.
NOSIZE = (ITEMS_HEAD +
          "| A | Proposal | P4 | Fri Nov 27 | lose the sale | Harbor Grill | yes | ? | a sale |\n"
          "| B | Calls | P18 | no date | none | nobody | yes | ? | new clients |\n"
          "| C | Newsletter | P17 | no date | none | nobody | no | ? | new clients |\n\n")
tk = toolkit("auto")
f = rank_file(tk, "status: battling\nmode: auto\nowner_review: not yet", NOSIZE, ("A-B", "A-C", "B-C"))
rc, out = run(tk, "rank_plate.py", "auto", str(f), "--today", "2026-11-24")
case("A:P2-C9 a pair with size missing that Due decides is marked 'due decides', not sent to the owner",
     "due decides" in line_of(out, "1. A-B") and "2 pair(s) have a fact missing, but a known fact still decides" in out)
case("A:P2-C9 a pair with size missing and every known fact equal says 'no known fact decides' and is counted for the owner",
     "no known fact decides" in line_of(out, "3. B-C") and "1 pair(s) have facts missing and no known fact decides them" in out)

# ---- rank_plate.py auto: [check why now] when Why now and Size both differ (C:P2-C7) ----
WHY = (ITEMS_HEAD +
       "| A | Referral offer | P5 | no date | none | Tom | no | half a day | new clients |\n"
       "| B | Newsletter | P17 | no date | none | Sam | no | 1 hour | a sale |\n\n")
tk = toolkit("auto")
f = rank_file(tk, "status: battling\nmode: auto\nowner_review: not yet", WHY, ("A-B",))
rc, out = run(tk, "rank_plate.py", "auto", str(f), "--today", "2026-11-24")
case("C:P2-C7 a pair where Why now and Size both differ is marked [check why now] (Why now comes before Size in PL22)",
     "[check why now]" in line_of(out, "1. A-B"))
pf = tk / "p.txt"
pf.write_text("A-B A: facts equal: both no date, someone waits, no cost. P5 is the lower P#\n")
before = f.read_bytes()
rc, out = run(tk, "rank_plate.py", "auto", str(f), str(pf), "--today", "2026-11-24")
case("C:P2-C7 auto STOPs 'facts equal:' on a pair whose sizes differ (Size decides when Why now does not)",
     rc != 0 and "Size decides" in out and f.read_bytes() == before)

# ---- rank_plate.py auto: the list form honors mode: manual (C:P2-C11) ----
tk = toolkit("auto")
f = rank_file(tk, "status: battling\nmode: manual\nowner_review: not yet", WHY, ("A-B",))
rc, out = run(tk, "rank_plate.py", "auto", str(f), "--today", "2026-11-24")
case("C:P2-C11 'auto' with no picks file STOPs on a mode: manual file and prints no pairs to judge",
     rc != 0 and "mode: manual" in out and "1. A-B" not in out)

# ---- rank_plate.py light: a known Due or Who waits still decides with a fact missing (A:P2-C9, light path) ----
PRIO = ("---\nfrom: chief-of-staff\nupdated: 2026-11-22 09:00\nranked_on: 2026-11-22\nstatus: ok\ncriterion: \"q\"\n---\n\n"
        "## Ranked\n| Rank | P# | Item | Who does it | Due | Size | Result this week | Status |\n|---|---|---|---|---|---|---|---|\n"
        "| 1 | P4 | Proposal | you | Fri Nov 27 | half a day | sent | open |\n\n"
        "## Must do by date\n| P# | Item | Who does it | Due | Status |\n|---|---|---|---|---|\n\n"
        "## New since the ranking\n| P# | Item | Placed | Status |\n|---|---|---|---|\n| P21 | Checklist | not placed yet | waiting: your picks |\n")
tk = toolkit("manual")
(tk / "handoffs/priorities.md").write_text(PRIO)
(tk / "chief-of-staff/board/plate.md").write_text("## Plate\n" + PLATE_HEAD +
    "| P4 | 2026-11-20 | Proposal | project | Fri Nov 27 | Harbor Grill | yes | half a day | - | now | 1 | you | open |\n"
    "| P21 | 2026-11-24 | Checklist | idea | no date | nobody | ? | ? | - | now | - | you (who does it: asked) | open |\n")
rc, out = run(tk, "rank_plate.py", "light", str(tk / "handoffs/priorities.md"), "P21", "--today", "2026-11-24 08:00")
case("A:P2-C9 light marks a size-missing pair that Due decides with 'due decides'", "due decides" in line_of(out, "1. N"))

# ---- rank_plate.py check: a winner outside its pair says how to repair it (B:P2-C10) ----
tk = toolkit("manual")
f = rank_file(tk, "status: battling\nmode: manual\nowner_review: not yet", WHY, ())
f.write_text(f.read_text() + "| A-B | C | owner |  |\n")
rc, out = run(tk, "rank_plate.py", "check", str(f))
case("B:P2-C10 check names the repair for a winner outside its pair: ask that pair, set, then tally",
     rc == 1 and "set chief-of-staff/runs/2026-11-24-plate/08_rank.md A-B" in out and "tally" in out)

# ---- check_gates.py C9: the 09 page against a weekly Kept order (C:P2-C9) ----
tk = toolkit("manual")
run_dir = tk / "chief-of-staff/runs/2026-11-27-plate"
run_dir.mkdir(parents=True)
(run_dir / "07_plate.md").write_text("# plate\n\n## Kept order\n| Rank | P# | Item |\n|---|---|---|\n| 1 | P4 | Proposal |\n| 2 | P18 | Calls |\n| 3 | P1 | Chamber |\n")
(run_dir / "08_rank.md").write_text("---\nstatus: ranked\nmode: manual\nowner_review: not yet\ncriterion: \"q\"\n---\nkept last week's order, no pairs\n")
(run_dir / "06_log.md").write_text("# Log\n")
page = ("# Your priorities\n\n## The full order\nPicked by: you, two at a time\n\n| Rank | P# | Item | Wins | Who does it | Due |\n|---|---|---|---|---|---|\n"
        "| 1 | P4 | Proposal | - | you | Fri Nov 27 |\n| 2 | P1 | Chamber | - | Email Manager | Dec 5 |\n| 3 | P18 | Calls | - | you | no date |\n")
(run_dir / "09_priorities.md").write_text(page)
rc, out = run(tk, "check_gates.py", "--today", "2026-11-27")
case("C:P2-C9 C9 fails a 09 page whose full order differs from the Kept order", rc == 1 and "C9 FAIL" in out and "Kept order" in out)
(run_dir / "09_priorities.md").write_text(page.replace("| 2 | P1 | Chamber | - | Email Manager | Dec 5 |\n| 3 | P18 | Calls | - | you | no date |",
                                                       "| 2 | P18 | Calls | - | you | no date |\n| 3 | P1 | Chamber | - | Email Manager | Dec 5 |"))
rc, out = run(tk, "check_gates.py", "--today", "2026-11-27")
case("C:P2-C9 C9 passes once the page shows the Kept order", rc == 0)

# ---- check_gates.py C11: a must still 'waiting: D# answer' after the owner answered D# (C:P2-C16, C:P2-C17) ----
tk = toolkit("manual")
(tk / "chief-of-staff/board/plate.md").write_text("## Plate\n" + PLATE_HEAD +
    "| P2 | 2026-11-20 | Software renewal | promise | 2026-12-01 | the team | no | 1 hour | - | must | - | you | waiting: D1 answer |\n")
(tk / "chief-of-staff/board/board.md").write_text(BOARD + "| D1 | 2026-11-24 | Renew the software: yes | yes | T3 | L3 |\n")
rc, out = run(tk, "check_gates.py", "--today", "2026-11-24")
case("C:P2-C17 C11 fails a must still 'waiting: D1 answer' once D1 is in Decided", rc == 1 and "C11 FAIL: P2" in out and "D1" in out)
(tk / "chief-of-staff/board/plate.md").write_text("## Plate\n" + PLATE_HEAD +
    "| P2 | 2026-11-20 | Software renewal | promise | 2026-12-01 | the team | no | 1 hour | - | must | - | you | open |\n")
(tk / "handoffs/jobs.md").write_text(JOBS_HEAD + "| J1 | Time Manager | Block 1 hour before 2026-12-01 for Must P2: Software renewal | handoffs/time-manager-report.md | 2026-12-01 | yellow | open |\n")
rc, out = run(tk, "check_gates.py", "--today", "2026-11-24")
case("C:P2-C17 C11 passes once the must is open with its Must P2 block", rc == 0)

for tk in MADE:
    shutil.rmtree(tk, ignore_errors=True)
print(f"\n{sum(results)} of {len(results)} pass")
sys.exit(0 if all(results) else 1)
