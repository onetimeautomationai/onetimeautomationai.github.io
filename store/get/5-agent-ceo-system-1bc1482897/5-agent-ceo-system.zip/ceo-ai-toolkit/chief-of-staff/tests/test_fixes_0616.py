#!/usr/bin/env python3
"""Self-test for the 0.6.16 fix P3-C52: check C10 compares the Rank cells of board/plate.md with the ranking.
Run: python3 chief-of-staff/tests/test_fixes_0616.py
Set COS_SCRIPTS to test other copies of the scripts. The "fails" case fails on 0.6.15. Exit 0 = all pass."""
import os, shutil, subprocess, sys, tempfile
from pathlib import Path

SRC = Path(__file__).resolve().parent.parent
SCRIPTS = Path(os.environ.get("COS_SCRIPTS") or SRC / "scripts")
LOG_HEAD = "| L# | Time | Decision | Tier | Why | Evidence | Owner's words | Result |\n|---|---|---|---|---|---|---|---|\n"
PLATE_HEAD = ("| P# | Added | Item | Kind | Due | Who waits | Only you? | Size | Waits on | Sort: now / must / later / no / standing | Rank | Goes to | Status |\n"
              "|---|---|---|---|---|---|---|---|---|---|---|---|---|\n")
PRIO = ("---\nfrom: chief-of-staff\nupdated: 2026-11-22 09:00\nranked_on: 2026-11-22\nstatus: ok\ncriterion: \"q\"\n---\n\n"
        "## Ranked\n| Rank | P# | Item | Who does it | Due | Size | Result this week | Status |\n|---|---|---|---|---|---|---|---|\n"
        "| 1 | P4 | Proposal | you | Fri Nov 27 | half a day | sent | open |\n\n"
        "## Must do by date\n| P# | Item | Who does it | Due | Status |\n|---|---|---|---|---|\n\n"
        "## New since the ranking\n| P# | Item | Placed | Status |\n|---|---|---|---|\n")
ROW4 = "| P4 | 2026-11-20 | Proposal | project | Fri Nov 27 | Harbor Grill | yes | half a day | - | now | {r} | you | open |\n"
ROW9 = "| P9 | 2026-11-20 | Calls | task | no date | nobody | yes | 1 hour | - | later | {r} | you | open |\n"
results = []


def check(rows):
    tk = Path(tempfile.mkdtemp())
    try:
        cos = tk / "chief-of-staff"
        for d in ("scripts", "_shared", "board", "runs"):
            (cos / d).mkdir(parents=True)
        (tk / "handoffs").mkdir()
        for n in ("rank_plate.py", "check_gates.py"):
            shutil.copy(SCRIPTS / n, cos / "scripts" / n)
        (cos / "_shared/owner-profile.md").write_text("---\nsetup_done: yes\n---\nTime zone: Pacific\n- rank_mode: manual\n")
        (cos / "_shared/decision-log.md").write_text(LOG_HEAD)
        (cos / "board/plate.md").write_text("## Plate\n" + PLATE_HEAD + rows)
        (tk / "handoffs/priorities.md").write_text(PRIO)
        (tk / "handoffs/jobs.md").write_text("| Job# | For | Job | Write result to | Due | Light | Status |\n|---|---|---|---|---|---|---|\n")
        r = subprocess.run([sys.executable, "-B", str(cos / "scripts/check_gates.py"), "--today", "2026-11-24"], capture_output=True, text=True)
        return r.returncode, r.stdout + r.stderr
    finally:
        shutil.rmtree(tk, ignore_errors=True)


def case(name, ok, out):
    results.append(ok)
    print(("PASS " if ok else "FAIL ") + name)
    if not ok:
        print("  output was: " + out.strip().replace("\n", " / ")[:700])


rc, out = check(ROW4.format(r="1") + ROW9.format(r="-"))
case("P3-C52 C10 passes when the Rank cells match the ranking", rc == 0, out)
rc, out = check(ROW4.format(r="1") + ROW9.format(r="hold lifted 2026-11-24"))
case("P3-C52 C10 fails words in a Rank cell (the TC43 P20 slip)", rc == 1 and "C10 FAIL" in out and "P9" in out, out)
rc, out = check(ROW4.format(r="2") + ROW9.format(r="-"))
case("P3-C52 C10 fails a Rank number that differs from the ranking", rc == 1 and "C10 FAIL" in out and "P4" in out, out)
print(f"\n{sum(results)} of {len(results)} pass")
sys.exit(0 if all(results) else 1)
