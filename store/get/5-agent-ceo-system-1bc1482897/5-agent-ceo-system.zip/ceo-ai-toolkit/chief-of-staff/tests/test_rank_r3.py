#!/usr/bin/env python3
"""Self-test for rank_plate.py and new_run.py (fixes from the 0.6.11 re-run: --today, the auto mode guard,
the approval match, the battling reminder, the letter count, the below-the-top-3 wording).
Run: python3 chief-of-staff/tests/test_rank_r3.py
Builds a throwaway toolkit in a temp folder with made-up data and removes it after. Exit 0 = all pass.
To test other copies of the scripts (for example an older version), set COS_SCRIPTS to their folder."""
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

SRC = Path(__file__).resolve().parent.parent
SCRIPTS = Path(os.environ.get("COS_SCRIPTS") or SRC / "scripts")
MADE, LAST, results = [], [""], []

ITEMS = ("## Items\n\n| Key | Item | P# | Due | If it slips | Who waits | Only you? | Size | Why now |\n|---|---|---|---|---|---|---|---|---|\n"
         "| A | Proposal | P4 | Fri Nov 27 | lose the sale | Harbor Grill | yes | half a day | a sale |\n"
         "| B | Calls | P18 | no date | none | nobody | yes | half a day | leads |\n"
         "| C | Chamber | P1 | Dec 5 | lose the slot | the chamber | no | 1 hour | referrals |\n\n")
H2H = "## Head-to-head\n\n| Pair | Winner | By | Reason |\n|---|---|---|---|\n"


def toolkit():
    tk = Path(tempfile.mkdtemp())
    MADE.append(tk)
    cos = tk / "chief-of-staff"
    for d in ("scripts", "_shared", "board", "runs", "_templates/run", "_templates/plate"):
        (cos / d).mkdir(parents=True)
    (tk / "handoffs").mkdir()
    for n in ("rank_plate.py", "new_run.py", "check_gates.py"):
        shutil.copy(SCRIPTS / n, cos / "scripts" / n)
    (cos / "_shared/owner-profile.md").write_text("---\nsetup_done: yes\n---\nTime zone: Pacific\nrank_mode: auto\n")
    (cos / "_templates/run/01_intake.md").write_text("# {{run_name}} {{YYYY-MM-DD HH:MM}}\n")
    (cos / "_templates/plate/07_plate.md").write_text("# {{run_name}}\n")
    (cos / "_templates/plate/08_rank.md").write_text("# {{run_name}}\n")
    return tk


def rank_file(tk, front, pairs):
    p = tk / "chief-of-staff/runs/2026-11-24-plate"
    p.mkdir(parents=True, exist_ok=True)
    f = p / "08_rank.md"
    f.write_text("---\n" + front + "\ncriterion: \"q\"\n---\n\n" + ITEMS + H2H + pairs)
    return f


def rp(tk, *args):
    r = subprocess.run([sys.executable, "-B", str(tk / "chief-of-staff/scripts/rank_plate.py"), *args], capture_output=True, text=True)
    LAST[0] = r.stdout + r.stderr
    return r.returncode, LAST[0]


def case(name, ok):
    results.append(ok)
    print(("PASS " if ok else "FAIL ") + name)
    if not ok:
        print("  output was: " + LAST[0].strip().replace("\n", " / ")[:600])


OPEN = "| A-B |  |  |  |\n| A-C |  |  |  |\n| B-C |  |  |  |\n"
DONE = ("| A-B | A | chief of staff | due Fri Nov 27 and Harbor Grill waits |\n"
        "| A-C | A | chief of staff | due Fri Nov 27, before Dec 5 |\n"
        "| B-C | C | chief of staff | due Dec 5 and the chamber waits, B has no date |\n")
PICKS = "A-B A: due Fri Nov 27 and Harbor Grill waits\nA-C A: due Fri Nov 27, before Dec 5\nB-C C: due Dec 5 and the chamber waits\n"

# R2-C8: auto writes only into a file that says mode: auto
for label, front in (("no mode line", "status: battling"),
                     ("the template placeholder", 'status: battling\nmode: "{{manual or auto, from rank_mode in the owner profile}}"'),
                     ("'mode: manual # note'", "status: battling\nmode: manual # owner said I'll pick")):
    tk = toolkit()
    f = rank_file(tk, front + "\nowner_review: not yet", OPEN)
    before = f.read_bytes()
    picks = tk / "picks.txt"
    picks.write_text(PICKS)
    rc, out = rp(tk, "auto", str(f), str(picks))
    case(f"auto writes nothing with {label} (R2-C8)", rc != 0 and "STOP" in out and f.read_bytes() == before)
tk = toolkit()
f = rank_file(tk, "status: battling\nmode: auto\nowner_review: not yet", OPEN)
(tk / "picks.txt").write_text(PICKS)
rc, out = rp(tk, "auto", str(f), str(tk / "picks.txt"))
case("auto with mode: auto writes the picks", rc == 0 and "3 pick(s) written" in out)

# R2-A5, R2-C6: tally stamps the --today date
rc, out = rp(tk, "tally", str(f), "--today", "2026-11-24")
case("tally --today 2026-11-24 stamps that date (R2-A5, R2-C6)", rc == 0 and "tally` on 2026-11-24" in f.read_text())

# R2-C9: "looks right except flip 3" keeps the Not final footer
tk = toolkit()
f = rank_file(tk, 'status: waiting for your review\nmode: auto\nowner_review: looks right 2026-11-24 09:10, "looks right except flip 3"', DONE)
rp(tk, "tally", str(f))
case("tally keeps 'Not final' when the owner's words ask a change (R2-C9)", "Not final" in f.read_text())
f = rank_file(tk, 'status: ranked\nmode: auto\nowner_review: looks right 2026-11-24 09:10, "good, use it"', DONE)
rp(tk, "tally", str(f))
case("tally drops 'Not final' after a plain looks right", "Not final" not in f.read_text())

# R2-B12, R2-D8: check reminds that battling must become ranked
tk = toolkit()
f = rank_file(tk, "status: battling\nmode: manual\nowner_review: not yet", DONE.replace("chief of staff", "owner").replace("due Fri Nov 27 and Harbor Grill waits", "").replace("due Fri Nov 27, before Dec 5", "").replace("due Dec 5 and the chamber waits, B has no date", ""))
rc, out = rp(tk, "check", str(f))
case("check reminds to set status: ranked when every pair is answered (R2-B12)", rc == 0 and "status: ranked" in out)

# R2-B1, R2-B2: next asks for exactly the letters shown and keeps --batch
tk = toolkit()
f = rank_file(tk, "status: battling\nmode: manual\nowner_review: not yet", OPEN)
rc, out = rp(tk, "next", str(f), "2")
case("next asks for exactly as many letters as pairs shown, with --batch (R2-B1, R2-B2)", "exactly 2 letter(s)" in out and "--batch 2" in out)

# Light path: R2-B9 wording below the top 3, --today on updated
PRIO = ("---\nfrom: chief-of-staff\nupdated: 2026-11-22 09:00\nranked_on: 2026-11-22\nstatus: ok\ncriterion: \"q\"\n---\n\n"
        "## Ranked\n| Rank | P# | Item | Who does it | Due | Size | Result this week | Status |\n|---|---|---|---|---|---|---|---|\n"
        "| 1 | P4 | Proposal | you | Fri Nov 27 | half a day | sent | open |\n"
        "| 2 | P18 | Calls | you | - | half a day | held | open |\n"
        "| 3 | P1 | Chamber | Email Manager | Dec 5 | 1 hour | drafted | open |\n"
        "| 4 | P5 | Referral | you | - | 1 hour | not this week | open |\n\n"
        "## Must do by date\n| P# | Item | Who does it | Due | Status |\n|---|---|---|---|---|\n\n"
        "## New since the ranking\n| P# | Item | Placed | Status |\n|---|---|---|---|\n| P21 | Checklist | not placed yet | waiting: your picks |\n")
tk = toolkit()
(tk / "handoffs/priorities.md").write_text(PRIO)
rc, out = rp(tk, "light", str(tk / "handoffs/priorities.md"), "P21", "OOO", "--by", "cos", "--today", "2026-11-24 08:00")
text = (tk / "handoffs/priorities.md").read_text()
case("light: an item that lost to #3 is told 'below your top 3', never a number (R2-B9)",
     rc == 0 and "below your top 3" in out and "#5 in the order" not in out)
case("light --today stamps updated and the Placed date from that day (R2-A5, R2-C6)",
     "updated: 2026-11-24 08:00" in text and "below the top 3 on 2026-11-24" in text)

# new_run.py --today (R2-A5, R2-C6)
tk = toolkit()
r = subprocess.run([sys.executable, "-B", str(tk / "chief-of-staff/scripts/new_run.py"), "plate", "--today", "2026-11-24 08:00"], capture_output=True, text=True)
LAST[0] = r.stdout + r.stderr
case("new_run.py plate --today makes 2026-11-24-plate (R2-A5, R2-C6)", (tk / "chief-of-staff/runs/2026-11-24-plate").is_dir())
r = subprocess.run([sys.executable, "-B", str(tk / "chief-of-staff/scripts/new_run.py"), "pricing page", "--date", "2026-11-24 08:00"], capture_output=True, text=True)
LAST[0] = r.stdout + r.stderr
intake = tk / "chief-of-staff/runs/2026-11-24-pricing-page/01_intake.md"
case("new_run.py --date names the run and stamps the time from that date", intake.exists() and "2026-11-24 08:00" in intake.read_text())

for tk in MADE:
    shutil.rmtree(tk, ignore_errors=True)
print(f"\n{sum(results)} of {len(results)} pass")
sys.exit(0 if all(results) else 1)
