# What to say to your Chief of Staff

| Say | It does |
|---|---|
| "Install The 5-Agent CEO System", "Start my Chief of Staff" or "hi" | First-time setup |
| "Morning" or "Start my day" | Your morning brief |
| "Idea: ..." or "Add to my board: ..." | Logs it and decides yes, later or no |
| "Brain dump: ..." | Splits it into items and logs each one |
| "Yes" / "No" / "Later" to a decision (D1, D2 and so on) | Records your decision and hands out the work |
| "Prioritize my plate" or "Rank my list" | Asks up to 12 short questions about everything on your plate. Then your items are compared two at a time: you pick each pair, or your Chief of Staff ranks them for you to review. The first time, it asks which you want, once. You get one page: your Top 3 this week, the full order, what has a date, what to hand off, what to drop |
| "Rank it for me" | From now on your Chief of Staff picks each pair from the facts you gave, with a one-line reason for each pick. You see the Top 3 and the full order before anything goes to your managers |
| "I'll pick" | From now on you pick each pair yourself, 9 pairs per message |
| "Flip 7" | Changes pair 7 of a ranking your Chief of Staff made, and counts again. "Show the picks" lists every pair with its number and reason |
| "Looks right" | Approves a ranking your Chief of Staff made, so your managers can use it |
| "What should I work on?" | Your Top 3 from your latest ranking. With no ranking yet, it offers to rank your plate |
| "I'm overwhelmed" | Same as "What should I work on?". Say "just tell me" for three picks from what it already has |
| "Re-rank my plate" | This week's re-rank. Asks only what is new, done or dropped |
| "Place it", or a reply like "NNO" to its picks | Places a new item against your top 3, in 3 picks at most (yours, or your Chief of Staff's with a reason for each, as you chose). It goes to a manager once it is in your top 3. Anything with a hard date and a real cost goes right away |
| "Show my priorities" | Your latest priorities page |
| "What needs me?" | Only the decisions waiting on you |
| "Status" or "Where is [thing]?" | The current state from your board |
| "Wrap up my day" or "Night" | Your night wrap and tomorrow's list |
| "From now on, ..." | Saves a new rule in your lessons file |
| "Redo setup" | Asks the setup questions again |
| "Relearn my voice" | Rebuilds your voice profile from your latest writing |
| "Stop" | Stops all jobs and lists what was in progress |
| "Uninstall the Chief of Staff" | Safe removal, see `UNINSTALL.md` |
