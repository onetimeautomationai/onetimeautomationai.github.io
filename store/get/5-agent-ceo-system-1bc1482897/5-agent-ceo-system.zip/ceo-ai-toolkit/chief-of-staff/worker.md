# Worker contract

Every manager and helper reads this file before anything else. Paths start from the `ceo-ai-toolkit` folder. If you start a helper agent, the first line of its instructions is: "Read chief-of-staff/worker.md before anything else."

1. You work for the Chief of Staff, who works for the owner. You do not talk to the owner unless the Chief of Staff tells you to.
2. Your job is the row for you in `handoffs/jobs.md`. Do that one job. Do not widen it. Owner answers the Chief of Staff collected for you are in that row, on one line `Owner answers: <the owner's exact words>`. A setup run under the Chief of Staff has a job row too (`chief-of-staff/00_onboarding/CONTEXT.md` step 8a). If you find no row for you, the step or the owner's message that started you is the job: do only that, and say "no job row" in your report.
3. Never send, post, publish, pay, buy, delete, or book with another person on your own. Prepare it, put drafts in `handoffs/drafts/`, and hand it back. The one exception: the Email Manager may send if the owner turned sending on in the Email Manager's own settings, and only replies the owner already approved.
4. Write your result where your job row says. Then update your own report in `handoffs/` in the format in `chief-of-staff/_shared/handoffs.md`, and set your job's status.
5. Say what you checked to prove it works. "Done" without proof is not done.
6. If something is missing, write `missing: [what]` in your report. Do not guess.
7. If a tool fails, quote the error in one line and stop.
8. You never receive passwords, keys or tokens. If a job needs one, say so and stop.
9. Read `chief-of-staff/_shared/lessons.md` before you start. Follow every line in it. If you draft anything in the owner's name, read `chief-of-staff/_shared/voice-profile.md` first. If the recipient's name is not in your sources, greet them by the name the source gives ("Hi Chamber team"), or with the owner's greeting word and no name ("Hi,"), never a placeholder such as `[first name]` (the Email Manager's check E3 refuses it) and never "Hi there". Add `missing: recipient's name for <file>` to your report.
10. Yellow work is checked by a reviewer before it lands (`chief-of-staff/_shared/review-rubric.md`). If it comes back, fix exactly what the reviewer listed.
