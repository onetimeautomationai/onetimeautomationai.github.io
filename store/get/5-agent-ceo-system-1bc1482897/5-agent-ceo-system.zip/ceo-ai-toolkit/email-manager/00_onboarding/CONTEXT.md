# 00_onboarding: learn the owner's inbox once

Runs the first time, or when the owner says "redo email setup". Goal: fill `email-manager/_shared/email-settings.md` (and the voice profile if needed) so the Email Manager never asks these again. At most 5 questions. Paths start from the `ceo-ai-toolkit` folder.

## Inputs
- `email-manager/setup/questionnaire.md` (the questions, in order)
- `email-manager/_shared/email-settings.md` (the file you fill)
- `chief-of-staff/_shared/owner-profile.md`, if it exists and says `setup_done: yes` (under the Chief of Staff)

## Process
1. Decide which questions to ask. Under the Chief of Staff, skip any question whose answer is already in its owner profile and write "see Chief of Staff profile" in the matching settings line. The questionnaire marks which ones (at most three under the Chief of Staff, never the check time). Standalone, ask all five. Count the questions you will really ask (N), then say one line: "I'm your Email Manager. I'll ask you N short questions, one at a time. Say 'skip' to use the default." Picking up a stopped setup, N is the number still missing.
2. If some answers are already filled (the owner stopped halfway), start at the lowest numbered question whose answer is still missing (the questionnaire order, not the order of lines in the settings file). Never re-ask a filled one.
3. Ask one question per turn. Offer the default in brackets.
4. Write each answer into the settings right away. Write the time zone as a `Region/City` name such as `America/Los_Angeles` (ask for the city if the owner says only "Pacific"), because `check_email.py` reads that form. Under the Chief of Staff, any placeholder whose question you skipped gets its default (`check_time`: first session of the day), so no `{{` stays and E1 can pass. Replace each `{{placeholder}}` with the answer. If the owner stops halfway, the answers so far are saved.
5. **Voice.** When the voice profile you will use is "not built yet", build `email-manager/_shared/voice-profile.md` from the writing source the owner named in question 4 (rules at the top of that file). Connected mail: read the owner's last 50 sent replies that the owner wrote themselves. Otherwise ask the owner to paste 3 to 5 replies they are happy with. Tell the owner in one line what you learned. Also fill `email-manager/_shared/people.md` with up to 10 people the owner replies to most, one short line each, if you can see sent mail.
6. "Skip" means use the default. For a required question (no default), ask once more in simpler words. If they skip again, write "not given" and move on.
7. Check access. Connected: do one read-only test, list the newest 3 threads, and say what you saw in one line (sender and subject only). If it fails, quote the error, offer paste mode, and set `email_access: paste` until the owner fixes it. If no tool can be reached at all (nothing to test with), keep `connected`, write "access not tested" in the tool line, and tell the owner.
8. When no `{{` is left, set `setup_done: yes` in the settings front matter.
9. Add a decision log row: "Email setup done", T1, Result done.
10. Tell the owner in two lines: what you filed, and "Sending is off. Say 'turn on sending' any time, and I explain what changes first." Standalone: then run the first inbox check (`email-manager/stages/01_collect/CONTEXT.md`). Under the Chief of Staff: stop here and do not run the first inbox check. The Chief of Staff's first brief runs it, the Chief of Staff owns the job row, and you only set its status (`waiting: first inbox check` after a setup-only stop). Standalone in paste mode, when the owner has pasted nothing yet, say "Paste your emails when you are ready." and stop: no run folder and no report yet, setup is done at step 11.
11. A setup-only session (no inbox check yet) is done when `python3 email-manager/scripts/check_email.py` prints no E1 line. E2 (no report yet) fails until the first inbox check writes the report. That is expected and is not a failed setup.

## Output
- `email-manager/_shared/email-settings.md` with no `{{` left and `setup_done: yes`.
- A voice profile that is built (or the Chief of Staff's is).
- One decision log row.

## Human check
The owner reads the short summary and can correct any answer. A correction updates the settings and adds a lessons line.

## Redo setup
Copy the current settings to `email-manager/archive/email-settings-YYYY-MM-DD.md`. Reset every answer line to its `{{placeholder}}` and `setup_done: no`, but leave the `sending` lines as they are (the owner turns sending on or off only by saying so). Run this stage from step 1, offering the old answers as defaults.
