# Pipeline

Paths start from the `ceo-ai-toolkit` folder. The Email Manager runs one loop per check, and two side jobs.

## Loop A: the inbox check (daily, or whenever the owner asks)

Make `email-manager/runs/YYYY-MM-DD/` and copy `email-manager/_templates/run/01_collect.md` into it. If today's folder exists, keep it and follow the second-run rule in `stages/01_collect/CONTEXT.md` step 1.

| # | Stage | Output | Light | Human check |
|---|---|---|---|---|
| 01 | collect | `01_collect.md` | green | none, read only |
| 02 | sort | `02_triage.md` | green | none, the owner can correct a bucket |
| 03 | draft | `03_drafts.md` + files in `handoffs/drafts/` | yellow | AI review before the owner sees a draft. The owner approves every send |
| 04 | handoff | `04_handoff.md`, `handoffs/email-manager-report.md`, `handoffs/schedule-items.md` | green | none |
| 06 | log | `06_log.md` | green | `check_email.py` passes |

## Side job B: a send (only when the owner approves a draft)

| # | Stage | Output | Light | Human check |
|---|---|---|---|---|
| 05 | send | `05_send.md` in the run folder of the day the send happens | red | The owner's words about that draft, every time |

Stage 05 also handles "Turn on sending" and "Turn off sending".

## Side job C: a single reply on request

"Draft a reply to X" and "Yes to Priya" run 01 for that one thread, then 03, 04 and 06.

**Stable every run:** everything in `email-manager/_shared/`.
**New every run:** the day's folder in `email-manager/runs/`, rows in the decision log, the three files in `handoffs/` that this hire owns.

Every stage reads `email-manager/_shared/standing-rules.md` and the lessons files first (see `email-manager/CLAUDE.md`, "Which mode am I in").
