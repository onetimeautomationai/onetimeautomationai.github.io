# Change how your Email Manager works

The easy way: tell it. "From now on, keep my replies to one sentence." It adds a line to `_shared/lessons.md` and follows it from then on. The line says only what you said, nothing added. A lesson about how drafts read also updates the drafts still waiting for you, at the next run.

## Safe to change

| What | File |
|---|---|
| Your addresses, VIPs, people to never draft for, never-mention list | `_shared/email-settings.md` (or say "redo email setup") |
| What counts as clutter, how far back the first check reads, how many threads per check | `_shared/email-settings.md` |
| Notes on the people you email most | `_shared/people.md` |
| How you sound | Say "relearn my voice", or edit `_shared/voice-profile.md` |
| Questions asked at setup | `setup/questionnaire.md` |
| Labels on or off | Say "Turn on labels" or "Turn off labels" |
| Sending on or off | Say "Turn on sending" or "Turn off sending" |

## Change with care (your Email Manager asks for your yes and keeps a snapshot first)

| What | Why |
|---|---|
| `_shared/buckets.md` | Changes what lands in each bucket. Keep the rule that money and legal mail is never clutter, and that when unsure it picks the safer bucket |
| `_shared/draft-rules.md` | Keep "predict, do not promise". Without it, drafts can commit you to things |
| `_shared/decision-tiers.md`, `system.md` sections 5 and 6, `_shared/standing-rules.md` | These keep your mailbox safe. Add to them. Think twice before removing a line. Sending, forwarding, deleting and booking with other people always stay red |
| `_shared/handoffs.md` | The Chief of Staff and the Time Manager read these formats. Change one and the hire that reads it must change too |
| `_shared/review-rubric.md` | What the reviewer checks. Add lines freely. Removing one lets more mistakes reach you |
| `scripts/check_email.py` | Keep E4 and E6. They catch a send with no approval |

## Do not edit by hand

`_shared/decision-log.md` is append only. To fix a row, ask your Email Manager to add a "corrects L#" row.

## Using it with the Chief of Staff later

If you start standalone and add the Chief of Staff later, say "Move my Email Manager lessons to the Chief of Staff." Your Chief of Staff copies the lines into its own lessons file and leaves the originals.
