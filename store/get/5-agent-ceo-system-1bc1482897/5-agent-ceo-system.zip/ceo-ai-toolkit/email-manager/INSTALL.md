# Install

Pick one path. Basic needs no terminal and changes nothing outside the toolkit folder. Expert adds a daily rhythm and optional switches.

## Basic (no terminal)

1. Put the `email-manager` folder inside your `ceo-ai-toolkit` folder, next to `chief-of-staff` if you have it. Do not rename the files inside.
2. Open your AI agent in the `ceo-ai-toolkit` folder. (If you open it inside `email-manager`, that works too.)
3. Say: **"Start my Email Manager."**
4. Answer the questions one at a time. Say "skip" to use the default. It saves each answer as you go.
   - If your agent can read your email, say so in question 2. It reads your sent mail to learn your voice.
   - If it cannot, say "paste". Then paste 3 to 5 replies you are happy with in question 4, and paste your emails when it asks, or drop them in `paste-here/`.
5. It runs your first inbox check and tells you what it found. Sending is off. Nothing is sent.

If your agent only has a box for custom instructions and cannot open folders, paste `INJECT-PROMPT.md` into that box instead. You get the sorting and the drafts in the chat, but no saved reports or settings, and it never sends.

## Expert (adds a daily rhythm)

Do Basic first, then:

1. **Connect your email** in your AI agent's settings (its connectors or plugins) if you have not. Read access is enough. Run "Check my email" and confirm it lists your newest threads.
2. **Run the check on a schedule**, if your agent supports scheduled tasks. Make one task that opens the `ceo-ai-toolkit` folder at your daily check time and says "Check my email." Your agent follows the safe change rules below before it creates it.
3. **Turn on the script check**, if your agent can run commands. From the `ceo-ai-toolkit` folder, run `python3 email-manager/scripts/check_email.py`. Before setup is done it fails its first check (E1). That is expected.
4. **Optional, labels.** Say "Turn on labels" and it adds one label per bucket to your threads. Labels only. It never archives, marks read, moves or deletes. You say yes first.
5. **Optional, sending.** Say "Turn on sending" only when you want it. It explains what changes and asks you once. Sending can be turned off in one sentence: "Turn off sending."

## Safe change rules

The AI follows these for any change outside the `ceo-ai-toolkit` folder (scheduled tasks, your agent's settings or rules file, labels in your mailbox), for turning sending or labels on, and for any change to the Email Manager's rules files (`system.md`, `decision-tiers.md`, `standing-rules.md`).

1. If it cannot read and write files here, it says so and gives you manual steps instead.
2. Before changing anything, it tells you the time and lists every file and outside item it will create or change. It waits for your yes.
3. It copies each existing file it will change into `.ceo-toolkit/snapshots/email-manager-<YYYYMMDD-HHMMSS>/`, keeping its path, and adds a row to `.ceo-toolkit/install-log.md`: time, action, snapshot, files changed, files created, notes. It creates the log with a header row if it is missing.
4. It never overwrites your agent's own rules file. It adds a block between `<!-- ceo-toolkit:email-manager:start -->` and `<!-- ceo-toolkit:email-manager:end -->` instead.
5. It never deletes your data, and never deletes anything in `.ceo-toolkit/`.

`.ceo-toolkit/` lives in the `ceo-ai-toolkit` folder. It is your record of every change.
