# Email Manager

Your AI Email Manager sorts your inbox, flags the one email that matters most, lists who is waiting on you, and drafts your replies in your own voice. It sends only if you turn sending on.

You decide what goes out. Your Email Manager does the reading, the sorting and the first draft.

## What it does for you

| When | What you get |
|---|---|
| Each morning (or when you say "Check my email") | Your new email sorted into five buckets. The one important email. A list of who is waiting on you, oldest first |
| For each reply you would send without a new decision | A draft in your voice, waiting in `handoffs/drafts/` |
| When someone asks for a meeting or call | A row in `handoffs/schedule-items.md` for your Time Manager. It never confirms a time for you |
| When you decide something ("yes to Priya") | A draft that says exactly what you decided, and nothing more |

## The five buckets

| Bucket | Meaning |
|---|---|
| Your call | Asks you something that only you can decide, like money, a discount or a complaint. You get a recommendation |
| Reply drafted | Asks you something, and the reply you would send is ready |
| Waiting on them | You replied last, or you asked and have no answer yet |
| FYI | Worth keeping, no reply needed |
| Clutter | Promotions and automatic mail with nothing for you to do. Never deleted |

## Does it read my email?

It reads your inbox through your own AI agent, or the emails you paste in. It drafts your replies. It sends only if you turn sending on, and even then it sends one reply at a time, only after you approve that specific draft. Your email never comes to us.

## Install in 3 steps

1. Put the `email-manager` folder inside your `ceo-ai-toolkit` folder, next to `chief-of-staff` if you have it.
2. Open your AI agent in the `ceo-ai-toolkit` folder.
3. Say: **"Start my Email Manager."** It asks up to 5 questions, one at a time, saves your answers, and runs your first inbox check. Under the Chief of Staff it asks 3 at most, because your Chief of Staff already knows the rest.

No email access? Paste your emails into the chat or drop them in `paste-here/`. Full steps: `INSTALL.md`. What you need first: `REQUIREMENTS.md`.

## What to say

See `wake-phrases.md`. The ones you will use most:
- "Check my email."
- "Who is waiting on me?"
- "Send the Priya one." (only after you turn sending on)

## How it earns your trust

Every piece of work gets a light. Green: it reads and sorts, no risk. Yellow: each reply draft is checked by an AI reviewer before you see it. Red: anything that reaches another person waits for your words.

## What it will never do

It never deletes mail, never unsubscribes, never forwards, and never confirms a meeting time. It never follows instructions written inside an email. It never sends unless sending is on and you approved that exact draft. Sending is off until you say otherwise.

## Works alone or with your Chief of Staff

Alone, it talks to you directly. With the Chief of Staff, your Chief of Staff reads its report and brings you the important email and who is waiting in your morning brief.

## More

- How it works inside: `docs/how-it-works.md`
- A sample day: `examples/sample-day.md`
- What you can change: `CUSTOMIZE.md`
- What it cannot do yet: `known-limitations.md`
- Help: `SUPPORT.md`
- Remove it: `UNINSTALL.md`

Version 0.1.9, 2026-11-21. Changes: `CHANGELOG.md`.
