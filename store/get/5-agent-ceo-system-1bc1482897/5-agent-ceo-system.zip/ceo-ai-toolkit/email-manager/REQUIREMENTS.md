# What you need

## Required
- **An AI agent that can read and write files in a folder on your computer.** A chat window that cannot open files is not enough on its own. The setup guide in the toolkit lists the agents we have tested.
- **This folder on your computer.** Your drafts, reports and settings live here and nowhere else.

## Needed for the full Email Manager
- **Email your AI agent can reach** (through a connector or plugin). To read your Sent folder, so it never drafts a reply you already sent, the connection must be able to read sent mail.
- **To send, the connection must be able to send.** Many connections can only read and create drafts. Then sending stays off and you send each approved draft yourself.

## Without email access
You can still use it. Paste your emails into the chat, or drop them in `paste-here/`. Paste your sent replies too if you want it to know what you already answered. You send every reply yourself.

## Optional
- **Python 3**, if your agent can run commands. One small script checks the report, the drafts and the log. Without it, your agent does the same steps by hand.
- **The Chief of Staff and Time Manager.** Not required. With them, your morning brief shows who is waiting, and scheduling asks land on your calendar plan.

## You do not need
- To write code.
- A subscription. You pay once and keep every file.
- Any other app.

## Tested with

| Agent | Model | Date | Result |
|---|---|---|---|
| Not yet tested | | | First draft. Walk tests are listed in `tests/acceptance-criteria.md` |

Model updates can change how an agent behaves. Before you switch to a new model, run the test cases in `tests/test-cases.md` and compare.

## Before you buy, check
1. Can your AI agent open a folder and edit a file in it?
2. Can it read your email, or are you willing to paste it?
3. Are you OK with your AI drafting replies that you approve before anything is sent?
