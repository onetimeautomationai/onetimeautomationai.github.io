# Remove the Email Manager

## The simple way
Say "Turn off sending" first if it is on. Then delete the `email-manager` folder. Nothing else on your computer depends on it. Your other hires keep working, but nobody sorts your inbox or writes `handoffs/email-manager-report.md`, and your Chief of Staff will say it cannot see your inbox.

The files the Email Manager wrote in `handoffs/` stay: `email-manager-report.md`, `schedule-items.md` and the `drafts/` folder. Keep a copy of them, and of `email-manager/runs/` and `email-manager/_shared/decision-log.md`, if you want your history. If you did the Expert install or let it change anything outside the folder, use the next section instead.

## If your AI made changes outside the folder
Say: **"Uninstall the Email Manager."** Your AI then:

1. Sets sending to off and tells you.
2. Copies your data (`email-manager/runs/`, `email-manager/_shared/`, and from `handoffs/` the report, `schedule-items.md` and `drafts/`) into `.ceo-toolkit/removed/email-manager-<YYYYMMDD-HHMMSS>/`.
3. Restores each file it changed from its snapshot in `.ceo-toolkit/snapshots/`.
4. In shared files, removes only the block between `<!-- ceo-toolkit:email-manager:start -->` and `<!-- ceo-toolkit:email-manager:end -->`. Other hires' blocks stay.
5. Lists anything outside the folder it created (a scheduled task, labels in your mailbox) and asks you before removing each. Removing a label only removes the tag. It never touches the email.
6. Adds a row to `.ceo-toolkit/install-log.md` and tells you what was restored, removed and kept.

Say **"Show what uninstalling would change"** to see the list without changing anything.

## Rolling back one change
- Sending: say "Turn off sending." It takes effect at once. Drafts already approved stay approved and are not sent.
- Labels: say "Turn off labels." Existing labels stay in your mailbox until you say remove them.
- Any rules file it changed: it restores the snapshot in `.ceo-toolkit/snapshots/` on your yes.

## What stays on your computer
Everything in `.ceo-toolkit/` stays. It is your record. Your toolkit files are never sent to us, so there is nothing to delete anywhere else. Emails already sent stay sent. Nothing here can unsend them.
