# Email Manager: map

Paths start from the `ceo-ai-toolkit` folder.

| Path in `email-manager/` | One line |
|---|---|
| `CLAUDE.md` | Start file for the AI: mode, first-run check, routes, rules that never bend |
| `CONTEXT.md` | The inbox check loop, the send side job, single replies |
| `system.md` | The AI's full operating rules, including the five sending conditions |
| `worker.md` | The contract when the Chief of Staff calls this hire |
| `README.md` | The owner's one-page guide |
| `REQUIREMENTS.md` | What you need, tested-with record |
| `INSTALL.md` | Basic and Expert install, safe change rules |
| `UNINSTALL.md` | Safe removal and rollback |
| `CUSTOMIZE.md` | What you can change and where |
| `permissions.md` | What it can read and write |
| `known-limitations.md` | What it cannot do yet |
| `SUPPORT.md` | Help and the update promise |
| `LICENSE.md` | Use and resale terms |
| `CHANGELOG.md`, `manifest.json` | Version, file list, checksums |
| `wake-phrases.md` | What to say |
| `INJECT-PROMPT.md` | One-paste version for agents without folders |
| `00_onboarding/`, `setup/` | First-run setup, 5 questions or fewer |
| `_shared/` | Stable files every stage reads |
| `stages/` | 01 collect, 02 sort, 03 draft, 04 handoff, 05 send, 06 log |
| `_templates/` | Run starter and output templates |
| `runs/` | One folder per day |
| `paste-here/` | Where emails go when the agent cannot reach your mailbox |
| `scripts/` | `check_email.py` and its by-hand version |
| `docs/` | How it works |
| `examples/` | A sample day with made-up data |
| `tests/` | Test cases, acceptance criteria, judge rubric, made-up inbox |
