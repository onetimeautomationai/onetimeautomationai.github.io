# _shared: map

| File | One line |
|---|---|
| `email-settings.md` | Addresses, email access, VIPs, never lists, the sending switch. Filled by setup |
| `buckets.md` | The five buckets, the order of checks, the important one, scheduling asks |
| `draft-rules.md` | Predict, do not promise. How a draft is written, named and kept |
| `decision-tiers.md` | The trust lights, the safety floor, what to log |
| `review-rubric.md` | How reply drafts are checked before the owner sees them |
| `voice-profile.md` | How the owner writes email. Used standalone or when the Chief of Staff has none |
| `people.md` | Short notes on the people the owner emails most |
| `standing-rules.md` | ER1 to ER14, read by every stage |
| `adapters.md` | Which tool does which job |
| `handoffs.md` | The formats of the files this hire writes into `handoffs/` |
| `lessons.md` | Owner corrections, read every run |
| `decision-log.md` | Append-only record of every decision, approval and send |
