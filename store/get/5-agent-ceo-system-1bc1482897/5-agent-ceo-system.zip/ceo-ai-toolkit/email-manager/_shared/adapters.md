---
type: factory
---

# Adapters

The Email Manager names the job, not the vendor. Setup records which tool the owner uses in `email-manager/_shared/email-settings.md`.

| Job | The owner's tool | Allowed when | Options that work |
|---|---|---|---|
| Read new mail, read a thread, read the Sent folder | The email tool named in settings | Always, read only | Any email your AI agent can reach through a connector or plugin |
| Read pasted emails | Chat, or files in `email-manager/paste-here/` | Always. This is the Basic install without email access | Plain text or markdown, one email per file, or many in one paste |
| Add a label to a thread | The email tool | Only if `labels: on` in settings | A label only. Never archive, mark read, star, move or delete |
| Send a reply | The email tool | Only if `sending: on` and the five conditions in `email-manager/system.md` section 5 are met | The connection must be able to send. If it can only draft, sending stays off |
| Save notes, drafts and reports | Files in this toolkit | Always | Plain markdown |
| Run the check script | Python 3, if your agent can run it | Optional | Every script check can also be done by hand (`email-manager/scripts/README.md`) |

The Email Manager never reaches the calendar. The Time Manager does.
