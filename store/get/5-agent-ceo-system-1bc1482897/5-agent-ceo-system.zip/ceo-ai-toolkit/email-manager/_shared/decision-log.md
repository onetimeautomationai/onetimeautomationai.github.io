---
type: log
rule: append only. Never edit or delete a row.
---

# Decision log

Every decision the Email Manager makes or records goes here before it is reported. Rows are numbered L1, L2, L3. (Under the Chief of Staff, its board numbers like D1 are different from these L numbers, and its own log is separate.)

- **Tier:** T1, T2 or T3 (`email-manager/_shared/decision-tiers.md`). Anything that sends, forwards, books or confirms with another person is T3.
- **Owner's words:** required for a T3 row whose Result is `done`, copied exactly. Leave it empty while you wait, and set Result to `pending`.
- **Result:** one of `done`, `pending`, `parked`, `no`.
- **Decision:** start with `Owner task:` when the owner will do it themselves, for example sending a draft by hand.
- **Evidence:** for a T2 (yellow) row marked done, write `review: pass`. For a send, write where you confirmed the message in Sent, and when.
- **To fix a row:** add a new row whose Decision starts with `corrects L#` (for example "corrects L4: owner said yes"). The check script then reads the new row instead of the old one.
- **Rows the check treats as the send guard** (always T3, Result done, the owner's exact words, never "maybe"): `Sending turned on`, `Sending turned off`, `Owner approved draft <file>`, `Sent reply to <person>, <file>` (Evidence must say `found in Sent at HH:MM`). A draft marked `approved` or `sent` needs its `Owner approved draft <file>` row. A draft marked `sent` also needs a `Sent reply` row (and a `Sending turned on` row), or, when the owner sent it by hand, `Owner task: sent <file>`. The draft file's own status never counts as proof.
- `Owner task:` rows with an action word (send, forward, pay and so on) are allowed at T1 only in the form `Owner task: sent <draft file>`. Any other action row is T3.
- A `corrects L#` row for a guard row restates the wording, for example `corrects L4: Owner approved draft <file>`.
- **Exact wording for rows that touch no one** (the check reads these as neutral): one batch of drafts `Wrote 1 reply draft` when there is one and `Wrote N reply drafts` when there are two or more (T2, `review: pass`), a stopped send `Dropped draft <file>, send stopped at condition N (<why>)` (T1). A forward draft `Wrote 1 forward draft for <person>, waiting for owner` (T2, `review: pass`). A draft that failed review twice `Draft for <person> failed review twice, file kept: <file>` (T2, Evidence `review: fail, 2 rounds`, Result pending). A failed run `Run failed, email not read` (T1). A run with no drafts `Wrote 0 reply drafts, no thread needed one` (T1). A pass after a fix `Re-reviewed draft <file> after fix` (T2, `review: pass`). A style lesson re-applied `Updated N waiting drafts for the lesson of <date>` (T2, `review: pass`). The same with red drafts `Updated N waiting drafts for the lesson of <date>, M red` (T2, Evidence `review: fail, 2 rounds`, Result pending). A review by the same agent writes `review: pass (self)`. A first review that failed `Draft for <person> failed review, sent back once: <file>` (T2, Evidence `review: fail, round 1`, Result pending), written before the fix. A sort or draft row when Sent was not visible may end `, Sent not checked` (neutral wording).
- **Exact wording for refusals** (T3, the owner's ask copied into Owner's words, Result `no`): `Refused: delete the clutter, never allowed. Listed N clutter senders for the owner`. `Refused: unsubscribe, never allowed. Listed N senders for the owner`. `Refused: standing send to <person>, each send needs the owner's words`.
- **Time:** the owner's clock now, as `YYYY-MM-DD HH:MM`. A row is never earlier than the row above it, and the check fails a row that is. The words "forward draft", "send stopped", "did not send" and "did not forward" are neutral, any other send, forward or approval word in a Decision still needs T3.
- Name the draft file in the Decision text for every approval, send and owner send. The check script matches on the file name.
- **Take back a send that never happened:** add `corrects L#: did not send, row logged in error` (T1, Evidence `not in Sent, checked HH:MM`, Result no). A draft file's status never counts as the evidence.
- Replace any pipe character in the owner's words with a slash so the table stays readable.

`email-manager/scripts/check_email.py` enforces all of this.

| L# | Time | Decision | Tier | Why | Evidence | Owner's words | Result |
|---|---|---|---|---|---|---|---|
