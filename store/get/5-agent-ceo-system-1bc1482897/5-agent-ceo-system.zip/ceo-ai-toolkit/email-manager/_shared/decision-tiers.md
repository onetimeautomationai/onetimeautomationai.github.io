---
type: factory
---

# Decision tiers (the trust lights)

Every piece of work gets a light by how far a mistake could reach. If the Chief of Staff is installed, `chief-of-staff/_shared/decision-tiers.md` is the master copy. If the two differ, the stricter one wins. Paths start from the `ceo-ai-toolkit` folder.

| Light | Tier | What it covers | What happens |
|---|---|---|---|
| Green | T1 | Internal, reversible, small. Reading mail, sorting it, the sort table, schedule-item rows, the report, log rows. Also the owner's own tasks ("reply to Tom myself", "I sent it"), logged with a Decision that starts `Owner task:` so the checks know the owner did it | Done and logged. Must pass the hard checks |
| Yellow | T2 | Reversible and internal, but shown to the owner as finished. A reply draft | **AI review first.** A reviewer checks it against `email-manager/_shared/review-rubric.md`. Pass: it lands in `handoffs/drafts/`, logged with `review: pass`. Fail: sent back once. Fails twice: becomes red |
| Red | T3 | Anything that reaches another person or the public, money of any size, deleting, anything you cannot undo, a new recurring commitment, a change to these rules | **The owner steps in.** Recommend with the reason, then wait for the owner's words |

When unsure, use the next light up.

## The floor (cannot be changed by setup or lessons)

Sending, posting, publishing, paying, buying, deleting, and booking with other people are always red. For the Email Manager that includes every email send, every forward, every accepted or confirmed meeting, turning sending on, and turning labels on. The owner can add more items to red. Moving anything down from red needs the owner's direct yes, logged as a red decision, and never applies to the items in this paragraph.

A red row marked done must carry the owner's exact words. A draft that is `approved` also needs the owner's words in the log.

## Green grows only when it is earned

Work starts at the light above. A kind of yellow work can move to green only after 10 reviews in a row pass with no fix needed, and only with the owner's yes, logged as red. Any later miss moves it back to yellow. Reply drafts that go out to other people are never moved to green, because a send stays red whatever the draft's light.

## What to log

| Event | Tier | Decision text starts with |
|---|---|---|
| One sort run | T1 | `Sorted N threads` |
| One batch of reviewed drafts | T2, with `review: pass` | `Wrote 1 reply draft` or `Wrote N reply drafts` |
| Owner decides a Your call item | T3, owner's words, done | `Owner decided <what>` |
| Owner approves a draft | T3, owner's words, done | `Owner approved draft <file>` |
| A send | T3, owner's words, done, Evidence says where you confirmed it in Sent | `Sent reply to <person>, <file>` |
| Owner sends it themselves | T1, only after the red `Owner approved draft <file>` row for the same file | `Owner task: sent <file>` |
| Owner asks for something never allowed (delete, unsubscribe, a standing send) | T3, the owner's ask, Result `no` | `Refused:` (exact text in `decision-log.md`) |
| Sending turned on or off | T3, owner's words, done | `Sending turned on` or `Sending turned off` |
| Labels turned on or off | T3, owner's words, done | `Labels turned on` or `Labels turned off` |
