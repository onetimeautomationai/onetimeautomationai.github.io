---
type: factory
---

# Draft rules: predict, do not promise

You write the reply the owner is most likely to send. You do not decide anything for them. Paths start from the `ceo-ai-toolkit` folder.

## Before you write
1. Read the voice profile (`email-manager/CLAUDE.md`, "Which mode am I in"), the note for this person in `email-manager/_shared/people.md`, and the lessons.
2. Read the whole thread, including what the owner already sent.
3. Re-read the live thread right now. If the owner has replied since, or the thread is closed with a pure thank you, do not draft. Move it to Waiting on them or FYI and say so in the sort table.

## What the draft says
1. Only the body: greeting, text, sign-off, the way the owner writes them. No subject line, no commentary.
2. Short. Match the owner's usual length from the voice profile. Most real replies are one to three sentences.
3. Respond only to what was asked. Do not volunteer work or offers that are not in the thread.
4. **Predict, do not promise.** Do not commit the owner to a price, discount, date, deliverable, scope, refund, introduction or meeting that the thread and the owner's words do not already settle. When a reply would need a new commitment, write what the owner usually does instead: ask a clarifying question, hand it to the person named in `people.md`, say "let me check", or send a short acknowledgement.
5. The one exception: a commitment the owner stated in this session. "Yes to 10% for 12 months" lets the draft say exactly that and nothing more. Quote the owner's words in the draft notes.
6. No placeholders. If a fact is missing, the thread is Your call, not a draft with a blank. The one exception is a forward draft for a recipient the owner did not give: write `to: (owner adds)`.
7. Never use details from another thread or about another person.
8. Never promise or add an attachment. Never add a recipient.
9. No filler openers, no corporate filler, and none of the words on the owner's avoid list. The first words after the greeting come from the voice profile or answer the ask directly. An opener the voice profile does not hold is filler, for example "I hope this finds you well", "thanks for reaching out", "I hope you're doing well", "great question". The reviewer fails it under RR3.
10. A scheduling ask gets a draft that does not confirm a time. It says the owner will confirm, in the owner's words. The date and time asked for go in `handoffs/schedule-items.md` and in the draft notes.

## A new email (not a reply)
When the owner asks for a new email ("write to the chamber about the mixer"), write it as a draft file in the same format, with `to:` and `subject:` taken from the owner's words, status `waiting for owner`. Use only what the owner said. Add no other recipient. The owner sends it from their own email. The Email Manager never sends a new email, even when sending is on, because sending covers replies on an existing thread only.

## One live draft per thread
If `handoffs/drafts/` already holds a draft for this thread with status `waiting for owner`, update that file. Do not make a second one. If the old one is `approved` but not sent and a newer message arrived, set it to `dropped` with a note and write a new file. Never delete a draft.

## A new style lesson and the drafts already waiting
A lesson about how drafts read ("one sentence shorter", "no exclamation marks") applies to every new draft, and at the next run also to every draft still `waiting for owner` (R3-EB5). At that run, re-write each waiting draft to follow the lesson, re-check its thread first, send the batch to the reviewer, and log exactly `Updated N waiting drafts for the lesson of <date>`, T2, Evidence `review: pass`, Result done. If some of them went red (a second fail), log `Updated N waiting drafts for the lesson of <date>, M red`, T2, Evidence `review: fail, 2 rounds` (or `review: pass` when only some failed and the rest passed, naming the red files in Why), Result pending. Add a line `Before lesson: <the old draft text>` to the Notes of each draft you shorten, so the change can be compared. Drafts that are `approved`, `sent` or `dropped` are never changed. A draft that is already one sentence (greeting and sign-off aside) cannot get shorter: keep its text, still add the `Before lesson:` line (the same text) with the words `already one sentence, kept`, and count it in N. A lesson about sorting (a VIP, "never clutter") changes no draft.

## The file
Name: `YYYY-MM-DD-person-subject.md` (lowercase, words joined with hyphens). The date is today's date in the owner's time zone, the day the draft is written, not the date of the thread. Format:

```
---
to: <person>
subject: <subject>
status: waiting for owner
---

## Draft
<the body, ready to send>

## Notes for the owner
- Thread: <from, date of the message answered>
- Why this reply: <one line>
- Thread re-checked: <time>. Newest message is from <person>. <Sent line>
- Scheduling: <date and time asked for, in the schedule-items format, or none>
- Source for any commitment: <the owner's words, or none>
```

The `Thread re-checked` line is updated on every run that re-reads the thread, with the new time. The Sent line is one of three, never a guess (R3-EA5):
- Sent was read (connected, or the owner pasted the Sent section): `Owner has not replied since (Sent checked)`.
- Sent was not visible: `Sent not checked, cannot tell if the owner replied`. Never write "Owner has not replied since" without Sent.
- A thread carried from an earlier day, paste mode, not in today's paste: `Not in today's paste, Sent not checked`. Use it only when you asked the owner once, in the summary, to re-paste the open threads and the Sent replies, and logged that question. Put the question in the handoff as a QN and in the report as one extra bullet under Counts, `- Question: <the QN text>` (the report has three sections only). Log it with exactly this wording: `Asked owner to re-paste N open threads, Sent not checked` (T1, Evidence `question QN1 in the report and the handoff`, Result done). Do not put "Sent replies" or any send word in that log row, the check reads it as an action. Never write a re-check time for a thread you did not read today.

Status values: `waiting for owner`, `approved`, `sent`, `dropped`. A new draft is always `waiting for owner`. Only the owner's words move it to `approved` (stage `05_send`).

## Review
Every batch of drafts is reviewed before the owner hears it is ready (`email-manager/_shared/review-rubric.md`). Fix exactly what the reviewer lists. A second fail makes the draft red: leave it in the folder, add "Reviewer concerns:" to the notes, and tell the owner.
