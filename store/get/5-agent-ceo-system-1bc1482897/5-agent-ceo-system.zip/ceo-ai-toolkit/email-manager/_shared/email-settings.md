---
type: factory
setup_done: no
---

# Email Manager settings

Filled in by setup (`email-manager/00_onboarding/CONTEXT.md`). Change a line by telling your Email Manager, or say "redo email setup" to start over. A skipped answer uses its default. A skipped required answer (no default) is written as "not given".

## About you
- Name the Email Manager should use (under the Chief of Staff: "see Chief of Staff profile"): {{owner_name}}
- Your email address or addresses: {{owner_addresses}}
- Time zone (under the Chief of Staff: "see Chief of Staff profile"): {{time_zone}}
- When to run the daily inbox check (under the Chief of Staff: first session of the day): {{check_time}}

## Email access
- How the Email Manager gets your email (connected or paste): {{email_access}}
- Email tool, if connected: {{email_tool}}

## Who matters
- Your number one goal right now (under the Chief of Staff: "see Chief of Staff profile"): {{goal_1}}
- People who always get your attention first (VIPs): {{vips}}
- People or topics you always answer yourself, so no draft is written: {{never_draft}}
- People, brands or topics to never mention or contact (under the Chief of Staff: "see Chief of Staff profile"): {{never_list}}

## Your voice
- Where your real writing lives (voice samples) (under the Chief of Staff, when its voice profile is built: "see Chief of Staff profile"): {{writing_sources}}. Learned voice: the file named under "Voice profile" in `email-manager/CLAUDE.md`

## Sending (off unless you turned it on)
- sending: off
- sending_changed: never
- owner's words when changed: none

## Other settings (defaults, change them by telling the Email Manager)
- first_window: last 24 hours (the first run also adds older inbox threads from the last 7 days you have not answered)
- max_threads: 100
- labels: off
- clutter_patterns: newsletters and promotions with an unsubscribe link, sales cold outreach from people you have never written to, automatic "no reply" notices with no action in them
