---
type: factory
---

# Handoff formats (the files the Email Manager writes)

This is the Email Manager's copy. If the Chief of Staff is installed, `chief-of-staff/_shared/handoffs.md` is the master. If the two differ, the master wins. Paths start from the `ceo-ai-toolkit` folder.

The hires pass work through plain files in `handoffs/`. Each hire overwrites only its own files. The Email Manager owns `email-manager-report.md`, `schedule-items.md` and `drafts/`.

Every report starts with this header:

```
---
from: email-manager
updated: YYYY-MM-DD HH:MM (owner's time zone)
status: ok | partial | failed
---
```

Write the report after the draft review and the last log row. `updated` is never earlier than the last row of today's decision log. Fresh means `updated` is today. Use `partial` when some mail could not be read or sorted, a reviewer fail is open, or a Sent check could not be made. Use `failed` when no email could be read at all.

## handoffs/email-manager-report.md (Chief of Staff reads. Focus Manager reads "The important one" only)

```
## The important one
- From, subject, why it matters, draft: <file in handoffs/drafts/ or "none">

## Waiting on you
| Person | Subject | Waiting since | Draft |

## Counts
- New today: N. Sorted: N. Needs you: N.
```

Rules:
- The report has exactly these three sections, in this order, and no other section or heading. The Counts section is the last one.
- "Waiting on you" lists every Your call and Reply drafted thread, oldest first. "Needs you" in Counts equals the number of rows in that table. "Waiting since" is `YYYY-MM-DD HH:MM` (owner's time zone, 24 hour clock), and the check fails any other form or any row out of oldest first order. The Draft cell is the file name or `handoffs/drafts/<file>`, or "none".
- After a send, an owner send or a drop, the thread leaves this table the same turn (`email-manager/stages/05_send/CONTEXT.md` step B2).
- "Sorted" equals the number of rows in `02_triage.md`. When every thread is sorted, "New today" plus carried threads equals "Sorted". A carried thread (from an earlier run or day, still open, copied in with Why starting `carried`) is counted in Sorted and Needs you, not in New today. When any exist, add the bullet `- Carried: N.` under Counts (`check_email.py` E8).
- Optional extra bullets under Counts, one line each: `- By bucket: your call N, reply drafted N, waiting on them N, FYI N, clutter N`. `- Suspicious: N, not acted on`. `- Question: <the QN text>` when the Sent question was asked (`draft-rules.md`). The By bucket numbers must equal the rows per bucket in the sort table, and `check_email.py` E8 fails them if not. `- missing: <what>` when status is partial or failed.
- With nothing needing the owner: "The important one" says "none today" and the table has no rows.
- With `status: failed`: "The important one" says "email not read", the table has no rows, and Counts shows 0 for all three.

## handoffs/drafts/ (one file per draft)

Format in `handoffs/drafts/README.md` and `email-manager/_shared/draft-rules.md`. Each file starts with:

```
---
to: <person>
subject: <subject>
status: waiting for owner / approved / sent / dropped
---
```

Nothing is sent without the owner's yes.

## handoffs/schedule-items.md (Time Manager reads)

```
---
from: email-manager
updated: YYYY-MM-DD HH:MM (owner's time zone)
status: ok
---

| Found in email | What | Date and time | Who | Status: new / placed / skipped |
```

Rules:
- Add new rows with Status `new`. At each run, set a row to `placed` or `skipped` only when `handoffs/time-manager-report.md` (dated today or yesterday) lists it that way under `## Schedule items handled`. Match a report line to a row by Found in email plus What (the Time Manager may write the date its own way). Never remove a row.
- Date and time is always `Day YYYY-MM-DD, time zone`, resolved against the email's date, for example `Friday 2026-11-20, 10 AM Pacific`, or `Wednesday 2026-11-18 or Thursday 2026-11-19, afternoon` for a range. Write "time not given" or "not given" for a missing part (`email-manager/_shared/buckets.md`, Scheduling asks).
- Before you write, read the file. Do not add a row that repeats one already there (same email, same date and time).
- A change or cancellation is a new row that starts with "CHANGE:" or "CANCEL:" in the What cell, for example `CHANGE: move the Thursday review to Friday`.
- Rows marked placed or skipped for more than 14 days move to `email-manager/archive/schedule-items-YYYY-MM.md` with the owner's yes. Never deleted.

## handoffs/jobs.md (only when called by the Chief of Staff)

You set the Status cell (the last column) of your own row: `done`, or `waiting: [reason]`. You never add or edit other rows.
