---
type: factory
---

# Lessons

Every correction the owner gives the Email Manager becomes one line here, the same turn. Under the Chief of Staff, the Chief of Staff keeps `chief-of-staff/_shared/lessons.md` and both files are read. Newest at the bottom. A lesson can never lower a light or weaken a rule in `email-manager/system.md` section 5 or 6.

"What we do from now on" restates only what the owner said, in plain words (R3-EB6). Add no scope, condition or example the owner did not give. Good: owner said "Marcus Webb is a VIP, never put him in clutter", lesson "Marcus Webb is a VIP. Never sort his mail as Clutter." Bad: adding "Not drafted for or acted on unless she asked", which the owner never said. If the owner's words are unclear, ask one question before writing the line. Two separate corrections in one message are two lines.

| Date | The owner said (exact words) | What we do from now on |
|---|---|---|
