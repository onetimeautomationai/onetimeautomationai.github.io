---
type: factory
---

# People notes

The people the owner emails most, and how the owner talks to each. The drafter uses these to pick the right tone and the right next step. Short notes only. Never copy emails here. Built during setup from the owner's sent mail (when the Email Manager can read it) and improved by the owner's corrections.

One line per person: name, who they are, how the owner talks to them, the usual next step. Mark "never draft" for anyone the owner always answers personally.

| Person | Who they are | How the owner talks to them | Usual next step | Never draft? |
|---|---|---|---|---|
