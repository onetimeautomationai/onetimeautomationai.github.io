---
type: factory
---

# Review rubric (reply drafts)

The reviewer sees: the job row (or the owner's ask), the draft files, `01_collect.md` and `02_triage.md` from the run (these hold the facts each thread asked for), the source mail for each thread (the pasted emails or files in `email-manager/paste-here/`, or the thread text read from the connection), `handoffs/schedule-items.md`, `email-manager/_shared/email-settings.md`, the voice profile, `email-manager/_shared/people.md`, the lessons, and this rubric. It never sees the chat. It scores each line pass or fail, one draft at a time. Paths start from the `ceo-ai-toolkit` folder.

| # | Check | Fail when |
|---|---|---|
| RR1 | Does it do the job as written? | It answers a different message than the latest one, misses part of the ask, or does more than asked |
| RR2 | Are the facts true? | A name, date, number or term contradicts the run files, or is not in them or in the owner's words. A fact found in a source passes |
| RR3 | Does it follow the lessons, the settings and the voice profile? | Breaks a lesson, the never-draft list, the never-mention list, or the voice profile (greeting, length, sign-off, words to avoid). Opens with a phrase the voice profile does not hold and that does not answer the ask, such as "thanks for reaching out" or "I hope this finds you well" (filler opener) |
| RR4 | Is the light right for what happens next? | The draft is marked `approved` or `sent` without the owner's words, or anything in the output would send, forward, book or confirm a time without the owner's yes. A draft waiting for the owner's review is fine |
| RR5 | Is it ready for the owner to see? | Unclear, too long for this owner, a placeholder left in, or it needs more than a light touch |
| RR6 | Does it predict and not promise? | It commits the owner to a price, discount, date, deliverable, meeting, refund or introduction that the thread and the owner's words do not settle |
| RR7 | Was the thread state checked? | The notes do not show a re-check (the line `Not in today's paste, Sent not checked` counts as a re-check for a carried thread in paste mode when the Sent question was asked once in the summary and logged), or the draft answers a message the owner already answered or a thread that is closed with a thank you |

**Precedence:** RR6 beats RR3. A line from the voice profile that commits the owner to a day or time ("Friday works", "I'll be there at 3") is not allowed in a draft, so the draft fails RR6 if it copies it. "Let's set up a call" or "I'll check and confirm", with no day or time, is not a commitment and passes RR6. A draft never fails RR3 for leaving out a voice-profile phrase that RR6 forbids.

**Pass:** all seven pass. Write `review: pass` in the decision log Evidence column (`review: pass (self)` for the fallback below).
**Fail:** list the failed lines and one fix each. The draft goes back once. After the fix, the review runs again. A pass after a fix is logged exactly `Re-reviewed draft <file> after fix`, T2, Evidence `review: pass` (or `review: pass (self)`), Result done, and never repeats the `Wrote N reply drafts` row. A first fail is logged before the fix, exactly `Draft for <person> failed review, sent back once: <file>`, T2, Evidence `review: fail, round 1`, Result pending, so an earlier pass row never stands alone. A second fail makes it red: the owner sees it with the reviewer's notes.

## Who reviews

1. **Best:** a separate helper agent with a fresh start (the re-review after a fix also uses a fresh helper, a resumed helper that already saw the draft is not fresh, so log it `review: pass (self)`), on a different AI model if the owner's agent allows. Its first line: "Read email-manager/worker.md and email-manager/_shared/review-rubric.md before anything else. You are the reviewer."
2. **Fallback:** if the agent cannot start helpers, the same agent does a separate review pass with this rubric, reading only the files listed at the top. This is weaker, because it checks its own work. `email-manager/known-limitations.md` says so. Log it as `review: pass (self)`, never as plain `review: pass`, and never call it a separate reviewer in the run files or the summary. The check script accepts both.
