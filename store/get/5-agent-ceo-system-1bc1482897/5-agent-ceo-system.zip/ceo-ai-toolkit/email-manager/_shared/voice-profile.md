---
type: factory
built_from: not built yet
built_on: not built yet
---

# Voice profile

How the owner writes email, learned from their real writing (setup question 4). Used when the Email Manager is standalone, or when the Chief of Staff's voice profile is not built yet. Every draft in the owner's name reads a voice profile first. Rebuilt when the owner says "relearn my voice".

Rules for building it: read the samples, never copy whole messages into this file, skip anything the owner marks private, keep each example to one or two short lines. Prefer replies the owner wrote themselves. Skip replies someone else wrote for them.

## Tone
- not built yet

## Sentence length and shape
- not built yet

## Greetings and sign-off
- not built yet

## Words and phrases they use
- not built yet

## Words and phrases they avoid
- not built yet

## How they reply by kind of message
- Scheduling: not built yet
- Short acknowledgement: not built yet
- Hand to someone else: not built yet
- Needs a check first: not built yet

## Three short examples
1. not built yet
2. not built yet
3. not built yet
