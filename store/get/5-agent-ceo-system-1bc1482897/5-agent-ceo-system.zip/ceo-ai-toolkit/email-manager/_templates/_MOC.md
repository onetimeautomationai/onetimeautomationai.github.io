# _templates: map

| Path | One line |
|---|---|
| `run/01_collect.md` | Copied into each day's run folder |
| `outputs/02_triage.md` | The sort table |
| `outputs/03_drafts.md` | The list of drafts and the reviewer result |
| `outputs/04_handoff.md` | What was handed off |
| `outputs/05_send.md` | An approval or a send |
| `outputs/06_log.md` | The close-out |
| `outputs/draft.md` | One reply draft file for `handoffs/drafts/` |
| `outputs/email-manager-report.md` | The report for `handoffs/` |
| `outputs/schedule-items.md` | The schedule items file for `handoffs/` |
