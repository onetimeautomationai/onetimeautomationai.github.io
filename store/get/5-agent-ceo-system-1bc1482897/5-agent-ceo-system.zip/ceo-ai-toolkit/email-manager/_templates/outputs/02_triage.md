# Sort

| # (1, 2, 3 or E1, E2, E3, one style) | From | Subject | Bucket: Your call / Reply drafted / Waiting on them / FYI / Clutter | Why | Draft | Thread check |
|---|---|---|---|---|---|---|

## The important one
- <from, subject, why, draft file or none> or "none today"

## Scheduling asks
| Found in email | What | Date and time | Who |
|---|---|---|---|

## Counts by bucket
- Your call N. Reply drafted N. Waiting on them N. FYI N. Clutter N.
- Suspicious N (not acted on)
