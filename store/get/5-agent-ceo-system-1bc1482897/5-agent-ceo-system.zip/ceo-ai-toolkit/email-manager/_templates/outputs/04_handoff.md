# Handoff

- Report written: yes / no. Status: ok / partial / failed
- Schedule items added: N (rows). Left as they were: N
- Job row set to: done / waiting: reason / not called by the Chief of Staff

- Given to the owner: yes / no, under the Chief of Staff

## Summary (full text, written every run)

