# Send

| Draft file | Owner's words (exact) | Sending setting | Five conditions met: 1 2 3 4 5 | Result: sent / not sent, why | Proof |
|---|---|---|---|---|---|

## Told the owner
-
