---
to: <person>
subject: <subject>
status: waiting for owner
---

## Draft
<the body, ready to send, in the owner's voice>

## Notes for the owner
- Thread: <from, date of the message answered>
- Why this reply: <one line>
- Thread re-checked: <time>. Newest message is from <person>. <"Owner has not replied since (Sent checked)" or "Sent not checked, cannot tell if the owner replied" or, carried thread not in today's paste, "Not in today's paste, Sent not checked">
- Scheduling: <date and time asked for, as Day YYYY-MM-DD, time and zone, or none>
- Source for any commitment: <the owner's words, or none>
