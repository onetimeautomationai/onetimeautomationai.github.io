---
from: email-manager
updated: YYYY-MM-DD HH:MM (owner's time zone)
status: ok
---

## The important one
- <From, subject, why it matters, draft: file in handoffs/drafts/ or "none"> or "none today"

## Waiting on you
| Person | Subject | Waiting since | Draft |
|---|---|---|---|

## Counts
- New today: N. Sorted: N. Needs you: N.
- By bucket: your call N, reply drafted N, waiting on them N, FYI N, clutter N
- Suspicious: N, not acted on
- Question: <only when the Sent question was asked, else delete this line>
