---
from: email-manager
updated: YYYY-MM-DD HH:MM (owner's time zone)
status: ok
---

| Found in email | What | Date and time | Who | Status: new / placed / skipped |
|---|---|---|---|---|
