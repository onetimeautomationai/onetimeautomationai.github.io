---
run: YYYY-MM-DD
mode: connected / paste
since: YYYY-MM-DD HH:MM
until: YYYY-MM-DD HH:MM
---

# Collect

## Sources read
- Connected mailbox, or the pasted emails, or files from `email-manager/paste-here/` (list each file name)

- Sent folder: read / pasted / not available (Sent pasted: yes or no)

## Left unread
- How many threads were over the cap, or "none"

## Threads
| # | From | Subject | Latest message | Addressed to owner: to / cc / group | The ask (one line, or none) | Key facts (names, dates, amounts) |
|---|---|---|---|---|---|---|
