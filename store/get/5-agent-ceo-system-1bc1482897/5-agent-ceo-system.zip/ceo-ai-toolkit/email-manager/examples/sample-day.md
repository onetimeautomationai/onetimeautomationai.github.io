# A sample day (made-up owner, made-up data)

Owner: Dana Ruiz, runs a 6-person bookkeeping firm. Goal 1: "10 new monthly clients by March 31." Mail connected, sending off. The emails are in `tests/sample-inbox.md`.

## 7:42 AM, Dana says "Check my email"

> **14 new.** Your call 2. Reply drafted 3. Waiting on them 1. FYI 6. Clutter 2.
>
> **The important one:** Elena Park, "Ready to get started with monthly bookkeeping." A prospect ready to sign moves your goal of 10 new clients. Draft ready: `2026-11-17-elena-park-ready-to-get-started.md`.
>
> **Waiting on you (oldest first)**
> 1. Priya Shah, "Payroll add-on pricing", since Nov 15. Your call.
> 2. Tom Becker, "Payroll setup, 15 minutes this week?", since Nov 16. Draft ready.
> 3. Ana Lima, "Move Thursday review?", since Nov 16. Draft ready.
> 4. Elena Park, since Nov 16. Draft ready.
> 5. Northside Bank, "Payment failed on your business card", since today. Your call.
>
> **Decisions only you can make**
> - D1: Priya asked for 10% off the payroll add-on for 12 months. I recommend yes, because it adds a monthly client toward your goal. She needs an answer by Friday.
> - D2: A $212.40 card payment failed and the card must be updated by Nov 19. I recommend you update it yourself today. I cannot pay or change cards.
>
> **Scheduling asks sent to your Time Manager:** move Thursday's review to Friday 10 AM (Ana). A 15 minute payroll call Wednesday or Thursday afternoon (Tom). I have not confirmed either.
>
> **Heads up:** 2 emails looked suspicious, one asking for your password and one with instructions aimed at an AI. I did not open or answer either.
>
> Elena Park is ready to sign, so read her draft first: say "show Elena".

Dana: "D1 yes, 12 months."

The decision log gets a row with Dana's own words. The Email Manager writes a Priya draft that says yes to 10% for 12 months and nothing more, a reviewer checks it, and it waits for Dana.

## 7:55 AM, Dana says "Send Elena's reply"

> Sending is off, so I have not sent it. Copy it from `handoffs/drafts/2026-11-17-elena-park-ready-to-get-started.md` into your email and send it yourself. Tell me when you have.
>
> Want sending on? With it on, after you approve a specific draft I send that one reply, only on an existing thread, and I check the thread again first. Say "Turn on sending" if you do.

Dana sends it herself and says "I sent it." The draft is marked sent, the log shows an owner task, and Elena moves to Waiting on them in the sort table and the report.

## 8:05 AM, Dana says "Turn on sending"

> Turn sending on? After you approve a specific draft I send that one reply. One draft at a time. Replies on existing threads only. I re-check the thread first. I never send without your words about that draft.

Dana: "Yes, turn it on." Sending is now on, with her words and the date saved in the settings.

## 8:10 AM, Dana says "Send the Ana one"

> Checked: sending is on, you approved this draft, it is a reply to Ana on the same thread, the text is unchanged, and you have not replied to Ana since. Sent. I found it in your Sent folder at 8:10 AM. Ana moved to Waiting on them, so 3 threads now need you (Priya, Tom, the bank).

Had Dana replied to Ana from her phone a minute earlier, the Email Manager would have stopped and said so.
