# Known limitations

- **It needs your email, or your paste.** With no connection it only sees what you paste. It cannot tell whether you already replied unless you paste your sent replies too, and it says so.
- **Many email connections cannot send.** If yours can only read and create drafts, sending stays off and you send each approved draft yourself.
- **Drafts live in files, not in your mailbox.** You copy an approved draft into your email, or turn sending on and let it send that one reply.
- **It reads text only.** It does not open links, attachments or images. A question that lives in an attachment will not be seen, so the thread may land in the wrong bucket.
- **It errs on the safe side.** When unsure, mail goes to the bucket that shows you more. In the first weeks "Your call" may be longer than you expect. Tell it what to move and it learns.
- **It only learns from your corrections and your writing samples.** There is no weekly self-tuning in this version. Say "relearn my voice" any time.
- **Your voice is only as good as the samples.** Few or old samples mean drafts that sound less like you.
- **It does not see your calendar.** It writes scheduling asks to `handoffs/schedule-items.md`. It cannot check whether a time is free, so its drafts never confirm one.
- **It does not run by itself unless your agent can schedule tasks.** Without that, you open your agent and say "Check my email."
- **Only mail since the last check.** A thread older than the first check's window is not read unless you ask.
- **Rule following depends on your AI agent and model.** Stronger agents follow the rules more closely. The checks in `email-manager/scripts/check_email.py` catch the most important misses (an approval or send with no words from you, a report whose counts do not match) when your agent can run Python.
- **The review is strongest with a second agent.** Reply drafts are checked by a separate reviewer. If your agent cannot start helper agents, the same agent reviews its own work in a separate pass. That is weaker, because it is checking itself. The log marks that case `review: pass (self)` so you can tell.
- **One owner.** It is built for one person's inbox. Several mailboxes work if your agent can reach each one.
- **No phone or text alerts built in.** It talks to you inside your AI agent.
- **Long histories slow it down.** After a few months, move old `runs/` folders into `runs/archive/`.
