# Paste here

If your AI agent cannot reach your mailbox, drop your emails in this folder as plain text or markdown files, one email or one batch per file. Or paste them straight into the chat. Say "Check my email" and the Email Manager reads them.

Include the From, To, Cc, date, subject and the message text. If you also paste the replies you already sent, the Email Manager can tell which threads you have answered.

The Email Manager never moves or deletes these files. It lists the ones it has read in the day's `01_collect.md` and skips them next time. Empty this folder whenever you like.

With paste mode, nothing can be sent. You copy each approved draft from `handoffs/drafts/` into your email yourself.
