# What the Email Manager can touch

Paths start from the `ceo-ai-toolkit` folder.

| Area | Read | Write | Notes |
|---|---|---|---|
| `email-manager/` | Yes | Yes | Its own working files. Rules files change only with your yes (`INSTALL.md`, safe change rules) |
| `handoffs/email-manager-report.md`, `handoffs/drafts/` | Yes | Yes | Its own files. It creates `handoffs/` and `handoffs/drafts/` if missing |
| `handoffs/schedule-items.md` | Yes | Adds rows, sets Status | It sets a row to placed or skipped only from the Time Manager's report. It never removes a row |
| `handoffs/time-manager-report.md` | Yes | No | For schedule statuses, from a report dated today or yesterday |
| `handoffs/jobs.md` | Yes | Only the Status cell of its own row | Only when the Chief of Staff called it |
| Other files in `handoffs/`, other hire folders, `chief-of-staff/` | Their lessons, voice profile and profile, to follow your rules and write in your voice | No | Each hire writes its own |
| `logs/activity.md` | Yes | Adds one line per finished run | Never edits or removes a line |
| `.ceo-toolkit/` | Yes | Adds snapshots and log rows only | Never deletes anything there |
| Your email, reading | Yes, when connected | n/a | List threads, read threads, read the Sent folder. Never opens links or attachments |
| Your email, labels | n/a | Only if you turned labels on | Labels only. Never archive, mark read, star, move or delete |
| Your email, sending | n/a | Only if you turned sending on, one approved reply at a time | The five conditions in `system.md` section 5 |
| Your calendar | No | No | Only the Time Manager |
| Outside the toolkit folder (scheduled tasks, your agent's settings) | No | Only with your yes, following the safe change rules in `INSTALL.md` | |
| Passwords, keys, tokens | Never stored | Never stored | If a job needs one, it stops and tells you |

## Actions that always need your yes

Sending, forwarding, deleting, unsubscribing, accepting or confirming a meeting, and anything else that reaches another person. Sending is off until you turn it on. Deleting, unsubscribing and forwarding are never done by the Email Manager at all. `email-manager/scripts/check_email.py` fails if a send is logged as green or yellow, or a draft is approved or sent without your words in the log.
