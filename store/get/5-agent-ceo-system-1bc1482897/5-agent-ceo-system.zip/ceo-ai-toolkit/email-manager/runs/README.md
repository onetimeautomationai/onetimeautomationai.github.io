# Runs

One folder per day, named `YYYY-MM-DD/`. A second check on the same day adds a "Run 2" heading to `01_collect.md` and puts the newest sort table first in `02_triage.md` (rule in `stages/01_collect/CONTEXT.md` step 1). Made by copying `email-manager/_templates/run/01_collect.md` (the other starter files come from `email-manager/_templates/outputs/`).

A day's folder holds `01_collect.md`, `02_triage.md`, `03_drafts.md`, `04_handoff.md`, `06_log.md`, and `05_send.md` on days with an approval or a send.

These files hold short summaries of your email (sender, subject, one-line ask, a few key facts). They never hold whole emails.

Never delete a run. After a few months, move old runs into `runs/archive/`.
