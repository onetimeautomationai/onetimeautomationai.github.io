# Scripts

One small script. Standard Python 3, nothing to install. It works from any folder. The docs show it run from the `ceo-ai-toolkit` folder. It is optional: if your AI agent cannot run Python, it does the same steps by hand.

| Script | What it does | By hand |
|---|---|---|
| `check_email.py` | Runs checks E1 to E9. Exit code 0 means pass. It reads files and never changes them | Do each check below and write the result in `06_log.md` |

Why a script: matching counts, file names and log rows across five files is the part an AI most often gets slightly wrong. The script does that exactly. Everything else (sorting, drafting, judging) is the AI's job.

## The checks

| # | Check |
|---|---|
| E1 | `email-manager/_shared/email-settings.md` has no `{{`, says `setup_done: yes`, and has a `- sending: on` or `- sending: off` line |
| E2 | `handoffs/email-manager-report.md` has the header (`from: email-manager`, `updated` dated today, status ok, partial or failed), the three sections and no other section, and the Counts line `New today: N. Sorted: N. Needs you: N.` |
| E3 | Every email draft in `handoffs/drafts/` (except the README) has `to:`, `subject:` and a status of waiting for owner, approved, sent or dropped, is named `YYYY-MM-DD-person-subject.md`, and has no placeholder text in the draft (any `[bracket]`, `{{curly}}`, `<angle>` text, TBD, TODO, XXX or ___). Only email drafts are scanned: a file with no header (another manager's memo or outline) and a draft whose `to:` is the owner (the word owner, me, you, or an address or name in settings) are skipped |
| E4 | The send guard. A draft marked approved or sent needs a red `Owner approved draft <file>` row with the owner's words. A draft marked sent also needs a red `Sent reply to <person>, <file>` row with Evidence `found in Sent at HH:MM` (which needs sending on and a red `Sending turned on` row), or `Owner task: sent <file>` when the owner sent it. Settings with `sending: on` need the red `Sending turned on` row and the owner's words in settings. The draft file alone never counts as sent. Any approved, sent or dropped draft also needs a `runs/<day>/05_send.md`. Tests: `python3 -B email-manager/tests/test_send_guard.py` |
| E5 | No password, key or token in any `email-manager/_shared/` file |
| E6 | Every decision log row has 8 columns, a tier of T1, T2 or T3, a Result of done, pending, parked or no, no repeated L number, owner's words on every red row marked done, `review: pass` on every yellow row marked done, anything that sends, forwards, books or unsubscribes logged as red, and no row with a Time earlier than the row above it |
| E7 | `handoffs/schedule-items.md` has a header that says `from: email-manager` and a 5 column table, and every status is new, placed or skipped |
| E8 | Sorted equals the rows in the first table of today's `02_triage.md` (`#` is 1, 2, 3 or E1, E2, E3, one style). Needs you equals the rows in Waiting on you and the Your call plus Reply drafted rows. Every bucket is one of the five. Every Reply drafted row names a draft file that exists (a bare file name or the full `handoffs/drafts/<file>` path). A draft that is sent or dropped is not in a Reply drafted row, in Waiting on you, or in The important one (after a send or a drop the thread moves to Waiting on them, `stages/05_send` step B2). Waiting since is `YYYY-MM-DD HH:MM` and the table is oldest first. A settings VIP is never in a Clutter row. If the status is ok, New today plus the optional `Carried: N` bullet equals Sorted. A failed report shows 0, 0, 0 |
| E9 | Every earlier day folder in `email-manager/runs/` that has `01_collect.md` also has `06_log.md`, and no `06_log.md` says PENDING |

A row whose Decision starts with `corrects L4` replaces row L4 for E6. That is how you fix a mistake without editing the log.

**Today and the time zone.** The checks use today's date in the owner's time zone, read from the profile or settings file. Add `--today YYYY-MM-DD` to test as if it were another day. A row marked `Owner task:` fails if its Evidence says the AI sent it. The action words that must be T3 include send, forward, pay, invite, cancel and ordered anywhere in the Decision. The neutral wording "forward draft", "send stopped", "did not send", "did not forward" and "Sent not checked" is ignored first, so a stopped send or a forward draft logs cleanly. Accept, renew, subscribe, charge and share count only as the first word, so "Sorted 14 threads, plan renews Nov 24" passes. Rows that send, approve or switch (`Sending turned on`, `Owner approved draft`, `Sent reply`, `Owner decided`) must be T3. An `Owner task:` row with an action word passes at T1 only as `Owner task: sent <draft file>`.
