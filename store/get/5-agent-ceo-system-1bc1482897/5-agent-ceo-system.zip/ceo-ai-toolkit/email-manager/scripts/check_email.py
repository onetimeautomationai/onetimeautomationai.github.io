#!/usr/bin/env python3
"""Hard checks the Email Manager runs before it calls a run done.

Usage (from the ceo-ai-toolkit folder, works from any folder):
    python3 email-manager/scripts/check_email.py
    python3 email-manager/scripts/check_email.py --today 2026-11-20   (test with a made-up date)

Exit code 0 = all checks pass. 1 = at least one check failed (each failure is printed).
Standard library only. Reads files, never changes them.

Checks:
  E1  Setup is done: settings have no {{ placeholders, say setup_done: yes, and the sending line is on or off.
  E2  The report exists, has the header, is dated today, and has the three sections (and no other section) and the Counts line.
  E3  Every email draft file has to, subject and a valid status, a dated file name, and no placeholder text
      (any [bracket], {{curly}}, <angle> text, TBD, TODO, XXX, ___). Only email drafts are scanned: a file with
      no header, or a draft whose to: is the owner, is skipped.
  E4  Send guard. Every draft marked approved or sent has a red "Owner approved draft <file>" row with the
      owner's words. A draft marked sent also needs a "Sent reply to" row with Sent proof (which needs
      sending on and a red "Sending turned on" row), or an "Owner task: sent <file>" row. Sending on in the
      settings needs a red "Sending turned on" row with the owner's words. A draft file alone never counts as sent.
  E5  No secrets in the shared files.
  E6  Decision log rows have 8 columns, a tier, a result, owner's words on red rows marked done,
      unique row numbers, review: pass on yellow rows marked done, and sends or approvals logged as red.
  E7  schedule-items.md has the header and a 5 column table with a valid status on every row.
  E8  Counts agree: Sorted equals the sort table rows (the first table in 02_triage.md, `#` is 1, 2, 3 or E1, E2, E3,
      one style only), Needs you equals the Waiting on you rows and the
      Your call plus Reply drafted rows, every Reply drafted row names a draft file that exists.
      A draft cell may be a bare file name or a full path (handoffs/drafts/x.md). A draft that is sent or dropped
      may not stay in a Reply drafted row, in Waiting on you, or in The important one (the counts were not updated).
  E9  Every day folder before today has 06_log.md, and no 06_log.md says PENDING (write it after the check ran).
  (0.1.6) E4 also needs a runs/<day>/05_send.md once any draft is approved, sent or dropped.
  E6 also fails a log row whose Time is earlier than the row above it.
  E8 also fails a Waiting since that is not YYYY-MM-DD HH:MM, a Waiting on you table that is not oldest first,
      and a settings VIP in a Clutter row of the sort table. Counts may carry an optional "Carried: N." bullet,
      then New today plus Carried equals Sorted.
  (0.1.8) E8 also fails a "By bucket:" line under Counts whose five numbers differ from the sort table rows per bucket.

E6 action words: "forward draft", "send stopped" and "did not send" are neutral wording and do not count.

A row whose Decision starts with "corrects L<n>" replaces every row numbered L<n> for the log checks.
"""
import datetime
import re
import sys
from pathlib import Path

try:
    from zoneinfo import ZoneInfo
except ImportError:  # very old Python
    ZoneInfo = None


def owner_today(override, profile_files):
    """Today's date in the owner's time zone. override is YYYY-MM-DD (tests).
    The zone is read from the first profile file that names one (a line like 'Time zone: America/Chicago').
    With no zone found, the computer's date is used."""
    if override:
        return datetime.date.fromisoformat(override)
    if ZoneInfo:
        for p in profile_files:
            try:
                text = Path(p).read_text(encoding="utf-8")
            except OSError:
                continue
            m = re.search(r"^-?\s*Time zone[^:\n]*:[^\n]*?([A-Za-z]+/[A-Za-z_]+(?:/[A-Za-z_]+)?)", text, re.M | re.I)
            if m:
                try:
                    return datetime.datetime.now(ZoneInfo(m.group(1))).date()
                except Exception:
                    pass
    return datetime.date.today()


def arg_today():
    """The value after --today on the command line, or empty."""
    if "--today" in sys.argv:
        i = sys.argv.index("--today")
        if i + 1 < len(sys.argv):
            return sys.argv[i + 1]
    return ""

HERE = Path(__file__).resolve().parent.parent  # the email-manager folder
HANDOFFS = HERE.parent / "handoffs"
TZ_FILES = [HERE.parent / "chief-of-staff" / "_shared" / "owner-profile.md", HERE / "_shared" / "email-settings.md"]
FAILS = []

RESULTS = {"done", "pending", "parked", "no"}
DRAFT_STATUS = {"waiting for owner", "approved", "sent", "dropped"}
CLOSED_DRAFT = {"sent", "dropped"}  # a thread whose draft is sent or dropped no longer needs the owner
REPORT_STATUS = {"ok", "partial", "failed"}
ITEM_STATUS = {"new", "placed", "skipped"}
BUCKETS = {"your call", "reply drafted", "waiting on them", "fyi", "clutter"}
EMPTY_WORDS = {"", "-", "--", "n/a", "na", "none", "tbd", "?"}
ACTION = re.compile(
    r"\b(send|sends|sent|email to|reply to|forward|forwarded|forwards|post|posts|posted|publish|published|"
    r"pay|pays|paid|buy|buys|bought|purchase|purchased|invoice|refund|"
    r"delete|deletes|deleted|book|books|booked|schedule a call with|confirm a time|"
    r"sign a contract|sign the contract|signed|unsubscribe|invite|invites|invited|cancel|cancels|cancelled|"
    r"ordered|place an order|confirm with|confirmed with|confirms with)\b",
    re.I,
)
# Ambiguous words. They only count when they are the first word of the Decision, so a plain row like
# "Sorted 14 threads, CloudBooks plan renews Nov 24, no action" does not fail (LR-D11).
ACTION_START = re.compile(
    r"^\W*(accept|accepts|accepted|renew|renews|renewed|subscribe|subscribes|subscribed|"
    r"charge|charges|charged|share|shares|shared)\b",
    re.I,
)
# Wording that names an action without doing it (R2-D2). Removed before the action words are searched, so
# "Wrote 1 forward draft" and "Dropped draft X, send stopped at condition 5" pass, while "sent it" still fails.
NEUTRAL = re.compile(
    r"\b(forward|forwarding|send|sending|reply) drafts?\b|\bsend (was |is )?(stopped|dropped|blocked)\b|"
    r"\b(stopped|dropped|blocked) (the )?send\b|"
    r"\b(did not|didn't|do not|don't|never|not|no|nothing|without) (been )?(sent|send|forward|forwarded|forwarding)\b|"
    r"\bsent (folder )?not (checked|visible|pasted|read)\b|\bsent back once\b",
    re.I,
)
OWNER_TASK = re.compile(r"^\s*owner task\s*:", re.I)
# An "Owner task:" row says the owner did it. If its Evidence says the AI sent it, the row is mislabeled.
AI_SENT = re.compile(r"\b(ai sent|i sent|done by me|sent by (the )?(ai|agent|assistant|manager|email manager|me)|(the )?(ai|agent|assistant|email manager) (has )?sent)\b", re.I)
REVIEW_PASS = re.compile(r"review:\s*pass", re.I)
CORRECTS = re.compile(r"^\s*corrects\s+(L\d+)", re.I)
SECRET = re.compile(r"(api[_-]?key|secret|password|passwd|token)\s*[:=]\s*\S{8,}", re.I)
DRAFT_NAME = re.compile(r"^\d{4}-\d{2}-\d{2}-.+\.md$")
COUNTS = re.compile(r"New today:\s*(\d+)\.\s*Sorted:\s*(\d+)\.\s*Needs you:\s*(\d+)\.")
DAY_DIR = re.compile(r"^\d{4}-\d{2}-\d{2}$")
BY_BUCKET = re.compile(
    r"By bucket:\s*your call\s*(\d+),\s*reply drafted\s*(\d+),\s*waiting on them\s*(\d+),\s*FYI\s*(\d+),\s*clutter\s*(\d+)", re.I
)
CARRIED = re.compile(r"\bCarried:\s*(\d+)", re.I)
SINCE = re.compile(r"^\d{4}-\d{2}-\d{2} \d{2}:\d{2}$")
LOG_TIME = re.compile(r"^\d{4}-\d{2}-\d{2} \d{2}:\d{2}$")
# Any text in a draft that is a blank to fill in (LR-D12).
PLACEHOLDER = re.compile(
    r"\[[^\]\n]*\](?!\()|\{\{|\}\}|<[^<>@:/\n]{2,}>|\b(TBD|TODO|XXX+)\b|_{3,}",
    re.I,
)
# Rows that must be red (T3) whatever else they say.
GUARD_START = re.compile(
    r"^(sending turned o(n|ff)|labels turned o(n|ff)|owner approved draft|sent reply|owner decided)\b", re.I
)
# Owner words that are not a yes.
WEAK_WORDS = re.compile(r"^\W*(maybe|perhaps|not sure|unsure|i guess|probably|hmm+|idk|dunno)\b", re.I)
OWNER_SENT = re.compile(r"^\s*owner task\s*:\s*sent\b", re.I)
SENT_REPLY = re.compile(r"^sent reply\b", re.I)
SENT_PROOF = re.compile(r"found in sent\b.*\d{1,2}:\d{2}", re.I)


def fail(code, msg):
    FAILS.append(f"{code} FAIL: {msg}")


def table_rows(text):
    rows = []
    for line in text.splitlines():
        s = line.strip()
        if not s.startswith("|") or set(s) <= set("|-: "):
            continue
        rows.append([c.strip() for c in s.strip("|").split("|")])
    return rows


def first_table_rows(text):
    """Rows of the first table only (the sort table). Later tables, such as Scheduling asks, are ignored."""
    block, started = [], False
    for line in text.splitlines():
        if line.strip().startswith("|"):
            started = True
            block.append(line)
        elif started:
            break
    return table_rows("\n".join(block))


def strong_words(words):
    """True when the owner's words are a real answer, not empty, not 'maybe'."""
    w = words.strip()
    return w.lower() not in EMPTY_WORDS and not WEAK_WORDS.match(w) and bool(re.search(r"[A-Za-z]", w))


def clean_decision(decision):
    """The Decision text without a leading 'corrects L#'. A corrects row for a guard row restates the wording."""
    return re.sub(r"^[\s:,.\-]+", "", CORRECTS.sub("", decision, count=1))


def front_matter(text):
    m = re.match(r"^---\s*\n(.*?)\n---\s*(\n|$)", text, re.S)
    if not m:
        return None
    out = {}
    for line in m.group(1).splitlines():
        if ":" in line:
            k, v = line.split(":", 1)
            out[k.strip().lower()] = v.strip()
    return out


def section(text, heading):
    m = re.search(r"^##\s+" + re.escape(heading) + r"\s*$(.*?)(?=^##\s|\Z)", text, re.S | re.M)
    return m.group(1) if m else None


def check_setup():
    p = HERE / "_shared" / "email-settings.md"
    if not p.exists():
        fail("E1", "email-manager/_shared/email-settings.md is missing. Run setup.")
        return
    text = p.read_text(encoding="utf-8")
    left = len(re.findall(r"\{\{", text))
    if left:
        fail("E1", f"settings still have {left} unanswered setup question(s). Finish setup.")
    if not re.search(r"^setup_done:\s*yes\s*$", text, re.M):
        fail("E1", "settings do not say setup_done: yes.")
    if not re.search(r"^- sending:\s*(on|off)\s*$", text, re.M):
        fail("E1", "the 'sending:' line in settings must say on or off.")


def load_report():
    p = HANDOFFS / "email-manager-report.md"
    if not p.exists():
        fail("E2", "handoffs/email-manager-report.md is missing.")
        return None
    text = p.read_text(encoding="utf-8")
    fm = front_matter(text)
    if not fm or fm.get("from") != "email-manager":
        fail("E2", "report header must start with --- and say from: email-manager.")
        return None
    if fm.get("status", "") not in REPORT_STATUS:
        fail("E2", f"report status '{fm.get('status', '')}' is not ok, partial or failed.")
    today = owner_today(arg_today(), TZ_FILES).isoformat()
    if not fm.get("updated", "").startswith(today):
        fail("E2", f"report is dated '{fm.get('updated', '')}', not today ({today}). Run the check again.")
    for h in ("The important one", "Waiting on you", "Counts"):
        if section(text, h) is None:
            fail("E2", f"report is missing the section '## {h}'.")
    for h in re.findall(r"^##\s+(.+?)\s*$", text, re.M):
        if h not in ("The important one", "Waiting on you", "Counts"):
            fail("E2", f"report has an extra section '## {h}'. The report has exactly three sections and no others.")
    if not COUNTS.search(text):
        fail("E2", "report Counts must read 'New today: N. Sorted: N. Needs you: N.'")
    return text, fm


def is_owner_to(to):
    """True when a draft's to: is the owner: the word owner, me, myself, you, or an address or name in settings."""
    t = to.strip().strip("<>").lower()
    if not t:
        return False
    if t in ("owner", "the owner", "me", "myself", "you", "self"):
        return True
    p = HERE / "_shared" / "email-settings.md"
    text = p.read_text(encoding="utf-8") if p.exists() else ""
    for key in ("Your email address or addresses", "Name the Email Manager should use"):
        m = re.search(rf"^- {key}[^:\n]*:[ \t]*(.*)$", text, re.M)
        if m:
            for v in re.split(r"[,;]| and ", m.group(1).lower()):
                v = v.strip()
                if len(v) >= 4 and "{{" not in v and v in t:
                    return True
    return False


def check_drafts():
    d = HANDOFFS / "drafts"
    out = {}
    if not d.exists():
        return out
    for p in sorted(d.glob("*.md")):
        if p.name.lower() == "readme.md":
            continue
        text = p.read_text(encoding="utf-8")
        fm = front_matter(text)
        if fm is None:
            continue  # a file with no header is a work product of another manager (a memo, an outline), not an email draft
        if is_owner_to(fm.get("to", "")):
            continue  # a draft addressed to the owner is the owner's own copy, not a reply to a person
        if not fm.get("to") or not fm.get("subject"):
            fail("E3", f"drafts/{p.name} needs a header with to: and subject:.")
            continue
        status = fm.get("status", "")
        if status not in DRAFT_STATUS:
            fail("E3", f"drafts/{p.name} status '{status}' is not one of: waiting for owner, approved, sent, dropped.")
        if not DRAFT_NAME.match(p.name):
            fail("E3", f"drafts/{p.name} should be named YYYY-MM-DD-person-subject.md.")
        body = re.sub(r"^---\s*\n.*?\n---\s*(\n|$)", "", text, count=1, flags=re.S).split("## Notes for the owner")[0]
        if PLACEHOLDER.search(body) or PLACEHOLDER.search(fm.get("to", "")) or PLACEHOLDER.search(fm.get("subject", "")):
            fail("E3", f"drafts/{p.name} has placeholder text (a [bracket], {{{{curly}}}}, <angle> text, TBD, TODO or ___). Move the thread to Your call instead.")
        out[p.name] = status
    return out


def load_log():
    p = HERE / "_shared" / "decision-log.md"
    if not p.exists():
        fail("E6", "email-manager/_shared/decision-log.md is missing.")
        return []
    rows = table_rows(p.read_text(encoding="utf-8"))[1:]
    good = []
    for cells in rows:
        if len(cells) != 8:
            fail("E6", f"row has {len(cells)} columns, needs 8. A pipe character in the text splits it: {' | '.join(cells)[:80]}")
            continue
        good.append(cells)
    return good


def check_log(good, drafts):
    corrected = set()
    last_time, last_num = "", ""
    for cells in good:
        t = cells[1].strip()
        if LOG_TIME.match(t):
            if last_time and t < last_time:
                fail("E6", f"{cells[0]}: time {t} is earlier than {last_num} ({last_time}). A row is never earlier than the row above it. Add a 'corrects {cells[0]}' row with the right time.")
            else:
                last_time, last_num = t, cells[0]
    for cells in good:
        m = CORRECTS.match(cells[2])
        if m:
            corrected.add(m.group(1).upper())
    seen = set()
    live = []
    for cells in good:
        num, _t, decision, tier, _w, evidence, words, result = cells
        key = num.upper()
        is_dup = key in seen
        seen.add(key)
        if key in corrected:
            continue
        live.append(cells)
        if is_dup:
            fail("E6", f"{num} appears twice. Use the next number for a new row, or add a 'corrects {num}' row.")
        if tier not in ("T1", "T2", "T3"):
            fail("E6", f"{num}: tier '{tier}' is not T1, T2 or T3. Add a 'corrects {num}' row.")
        if result.lower() not in RESULTS:
            fail("E6", f"{num}: Result '{result}' is not done, pending, parked or no. Add a 'corrects {num}' row.")
        text = CORRECTS.sub("", decision)
        names_draft = any(n in text or n[:-3] in text for n in drafts)
        owner_sent_ok = bool(OWNER_SENT.match(clean_decision(decision))) and names_draft
        plain = NEUTRAL.sub(" ", text)
        has_action = bool(ACTION.search(plain) or ACTION_START.match(plain.lstrip(" :.,-")))
        if has_action and tier != "T3" and not owner_sent_ok:
            fail("E6", f"{num}: '{text[:60]}' reaches another person or the owner's mailbox, so it must be T3, not {tier}. The only green exception is 'Owner task: sent <draft file>'. Add a 'corrects {num}' row.")
        if GUARD_START.match(clean_decision(decision)) and tier != "T3":
            fail("E6", f"{num}: '{clean_decision(decision)[:60]}' is a send, an approval or a switch, so it must be T3, not {tier}. Add a 'corrects {num}' row.")
        if OWNER_TASK.match(text) and AI_SENT.search(evidence):
            fail("E6", f"{num}: marked 'Owner task:' but Evidence says the AI sent it. Remove 'Owner task:' and set the tier to T3. Add a 'corrects {num}' row.")
        if tier == "T3" and result.lower() == "done" and words.strip().lower() in EMPTY_WORDS:
            fail("E6", f"{num}: red row marked done without the owner's words. Ask the owner, or add a 'corrects {num}' row with Result pending. A send that never happened: 'corrects {num}: did not send, row logged in error' (T1, Evidence 'not in Sent, checked HH:MM', Result no).")
        if tier == "T2" and result.lower() == "done" and not REVIEW_PASS.search(evidence):
            fail("E6", f"{num}: yellow work marked done without 'review: pass' in Evidence. Run the review, then add a 'corrects {num}' row.")
    return live


def read_settings():
    p = HERE / "_shared" / "email-settings.md"
    text = p.read_text(encoding="utf-8") if p.exists() else ""
    m = re.search(r"^- sending:\s*(on|off)\s*$", text, re.M)
    w = re.search(r"^- owner's words when changed:[ \t]*(.*)$", text, re.M | re.I)
    return (m.group(1) if m else ""), (w.group(1).strip() if w else "")


def names(decision, name):
    stem = name[:-3] if name.endswith(".md") else name
    return name in decision or stem in decision


def check_send_guard(drafts, live):
    """The send guard (E4). Nothing counts as approved, sent or turned on without a red row with the owner's words."""
    sending, setting_words = read_settings()
    ok_rows = {"on": [], "off": [], "approved": [], "sent_reply": [], "owner_sent": []}
    for cells in live:
        _n, _t, decision, tier, _w, evidence, words, result = cells
        d = clean_decision(decision)
        done = result.lower() == "done"
        if re.match(r"sending turned on\b", d, re.I) and tier == "T3" and done and strong_words(words):
            ok_rows["on"].append(cells)
        elif re.match(r"sending turned off\b", d, re.I) and tier == "T3" and done and strong_words(words):
            ok_rows["off"].append(cells)
        elif re.match(r"owner approved draft\b", d, re.I) and tier == "T3" and done and strong_words(words):
            ok_rows["approved"].append(cells)
        elif SENT_REPLY.match(d) and tier == "T3" and done and strong_words(words) and SENT_PROOF.search(evidence):
            ok_rows["sent_reply"].append(cells)
        elif OWNER_SENT.match(d) and done and not AI_SENT.search(evidence):
            ok_rows["owner_sent"].append(cells)

    if sending == "on":
        if not ok_rows["on"]:
            fail("E4", "settings say sending: on but the decision log has no red 'Sending turned on' row (T3, done) with the owner's words.")
        if not strong_words(setting_words):
            fail("E1", "settings say sending: on but 'owner's words when changed:' is empty or not a clear yes.")
    elif ok_rows["on"] and not ok_rows["off"]:
        fail("E4", "the log says sending was turned on, no 'Sending turned off' row follows, and settings say sending: off. Log the change or fix the settings.")

    for name, status in drafts.items():
        if status not in ("approved", "sent"):
            continue
        if not any(names(c[2], name) for c in ok_rows["approved"]):
            fail("E4", f"drafts/{name} is '{status}' but the log has no red row 'Owner approved draft {name}' (T3, done) with the owner's words.")
        if status != "sent":
            continue
        by_owner = any(names(c[2], name) for c in ok_rows["owner_sent"])
        by_send = any(names(c[2], name) for c in ok_rows["sent_reply"])
        if by_send and sending == "off" and not ok_rows["off"]:
            by_send = False
        if by_send and not ok_rows["on"]:
            by_send = False
        if not by_owner and not by_send:
            fail("E4", f"drafts/{name} is 'sent' but there is no proof. A send needs 'Sending turned on' (red) and a red 'Sent reply to <person>, {name}' row with Evidence 'found in Sent at HH:MM'. A draft the owner sent needs 'Owner task: sent {name}'. The draft file alone never counts.")

    if any(st in ("approved", "sent", "dropped") for st in drafts.values()):
        runs = HERE / "runs"
        if not (runs.exists() and any(runs.glob("*/05_send.md"))):
            fail("E4", "a draft is approved, sent or dropped but there is no runs/<day>/05_send.md. Write it the same turn (stages/05_send, Output).")

    for cells in live:
        d = clean_decision(cells[2])
        if SENT_REPLY.match(d) and cells[7].lower() == "done":
            if not any(names(d, n) and st == "sent" for n, st in drafts.items()):
                fail("E4", f"{cells[0]}: '{d[:60]}' logs a send but no draft file named in it has status sent.")


def check_secrets():
    for p in (HERE / "_shared").glob("*.md"):
        for i, line in enumerate(p.read_text(encoding="utf-8").splitlines(), 1):
            if SECRET.search(line):
                fail("E5", f"_shared/{p.name} line {i} looks like a secret. Remove it. Secrets never go in these files.")


def check_schedule():
    p = HANDOFFS / "schedule-items.md"
    if not p.exists():
        return  # no scheduling asks yet is fine
    text = p.read_text(encoding="utf-8")
    fm = front_matter(text)
    if not fm or fm.get("from") != "email-manager":
        fail("E7", "schedule-items.md header must say from: email-manager.")
    rows = table_rows(text)
    if not rows:
        fail("E7", "schedule-items.md has no table.")
        return
    for cells in rows[1:]:
        if len(cells) != 5:
            fail("E7", f"schedule-items.md row has {len(cells)} columns, needs 5: {' | '.join(cells)[:80]}")
            continue
        if cells[4].lower() not in ITEM_STATUS:
            fail("E7", f"schedule-items.md status '{cells[4]}' is not new, placed or skipped.")


def settings_vips():
    """VIP names from the settings VIP line, lowercase, at least 3 letters. 'anyone from ...' phrases never match a name."""
    p = HERE / "_shared" / "email-settings.md"
    text = p.read_text(encoding="utf-8") if p.exists() else ""
    m = re.search(r"^- [^\n]*\(VIPs\):\s*(.*)$", text, re.M)
    if not m:
        return []
    parts = re.split(r",|;|\band\b|\bor\b", m.group(1).lower())
    return [x.strip() for x in parts if len(x.strip()) >= 3 and not x.strip().startswith("anyone") and "{{" not in x]


def draft_cell(cell):
    """The draft file name in a Draft cell. A full path like handoffs/drafts/x.md counts as x.md (R3-EA3)."""
    cell = cell.strip().strip("`").strip()
    return cell.replace("\\", "/").rsplit("/", 1)[-1] if cell else ""


def check_counts(report, fm, drafts):
    text = report
    m = COUNTS.search(text)
    if not m:
        return
    new_n, sorted_n, needs_n = (int(x) for x in m.groups())
    wait = section(text, "Waiting on you") or ""
    wrows = [r for r in table_rows(wait)[1:] if r and r[0] and r[0].lower() != "none"]
    if len(wrows) != needs_n:
        fail("E8", f"report says Needs you: {needs_n} but the Waiting on you table has {len(wrows)} row(s).")
    since = [r[2].strip() if len(r) > 2 else "" for r in wrows]
    for r, v in zip(wrows, since):
        if not SINCE.match(v):
            fail("E8", f"Waiting on you row '{r[0]}' has Waiting since '{v}', not YYYY-MM-DD HH:MM (24 hour clock).")
    good_since = [v for v in since if SINCE.match(v)]
    if good_since != sorted(good_since):
        fail("E8", "Waiting on you is not oldest first. Sort the rows by Waiting since, oldest at the top.")
    for r in wrows:
        cell = draft_cell(r[-1])
        if cell and cell.lower() != "none" and cell not in drafts:
            fail("E8", f"Waiting on you names draft '{cell}' but no such file is in handoffs/drafts/.")
        elif drafts.get(cell) in CLOSED_DRAFT:
            fail("E8", f"Waiting on you still lists draft '{cell}', which is '{drafts[cell]}'. After a send or a drop, take the thread out of Waiting on you and lower Needs you (stages/05_send).")
    important = section(text, "The important one") or ""
    for name, status in drafts.items():
        if status in CLOSED_DRAFT and names(important, name):
            fail("E8", f"The important one names draft '{name}', which is '{status}'. Pick the next thread by buckets.md, or write 'none today'.")
    if fm.get("status") == "failed":
        if (new_n, sorted_n, needs_n) != (0, 0, 0):
            fail("E8", "a failed report must show 0 for New today, Sorted and Needs you.")
        return
    day = HERE / "runs" / owner_today(arg_today(), TZ_FILES).isoformat() / "02_triage.md"
    if not day.exists():
        fail("E8", "no runs/<today>/02_triage.md to match the report against.")
        return
    trows = [r for r in first_table_rows(day.read_text(encoding="utf-8"))[1:] if r and re.fullmatch(r"E?\d+", r[0], re.I)]
    if len({r[0][:1].upper() == "E" for r in trows}) > 1:
        fail("E8", "02_triage.md mixes E-numbers (E1) and plain numbers (1) in the # column. Use one style.")
    if len(trows) != sorted_n:
        fail("E8", f"report says Sorted: {sorted_n} but 02_triage.md has {len(trows)} row(s).")
    cm = CARRIED.search(text)
    carried = int(cm.group(1)) if cm else 0
    if fm.get("status") == "ok" and new_n + carried != sorted_n:
        fail("E8", f"status is ok but New today ({new_n}) plus Carried ({carried}) is not Sorted ({sorted_n}). Use status partial, or sort the rest.")
    needs = 0
    vips = settings_vips()
    for r in trows:
        if len(r) < 7:
            fail("E8", f"02_triage.md row {r[0]} has {len(r)} columns, needs 7.")
            continue
        bucket = r[3].lower()
        if bucket not in BUCKETS:
            fail("E8", f"02_triage.md row {r[0]} bucket '{r[3]}' is not one of the five buckets.")
        if bucket == "clutter":
            for v in vips:
                if v in r[1].lower():
                    fail("E8", f"02_triage.md row {r[0]} puts VIP '{v}' in Clutter. A VIP is never Clutter (settings VIP line).")
        if bucket in ("your call", "reply drafted"):
            needs += 1
        if bucket == "reply drafted":
            cell = draft_cell(r[5])
            if not cell or cell.lower() == "none" or cell not in drafts:
                fail("E8", f"02_triage.md row {r[0]} is Reply drafted but its draft file '{cell}' is not in handoffs/drafts/.")
            elif drafts[cell] in CLOSED_DRAFT:
                fail("E8", f"02_triage.md row {r[0]} is Reply drafted but its draft '{cell}' is '{drafts[cell]}'. Move the row to Waiting on them and lower the counts (stages/05_send).")
    bm = BY_BUCKET.search(text)
    if bm:
        said = [int(x) for x in bm.groups()]
        order = ["your call", "reply drafted", "waiting on them", "fyi", "clutter"]
        real = [sum(1 for r in trows if len(r) > 3 and r[3].lower() == b) for b in order]
        if said != real:
            fail("E8", "report By bucket line says " + ", ".join(f"{b} {n}" for b, n in zip(order, said)) + " but the sort table has " + ", ".join(f"{b} {n}" for b, n in zip(order, real)) + ". Count the table rows again.")
    if needs != needs_n:
        fail("E8", f"report says Needs you: {needs_n} but the sort table has {needs} Your call and Reply drafted row(s).")


def check_runs():
    runs = HERE / "runs"
    if not runs.exists():
        return
    today = owner_today(arg_today(), TZ_FILES).isoformat()
    for d in sorted(runs.iterdir()):
        if not d.is_dir() or not DAY_DIR.match(d.name) or d.name == today:
            continue
        if (d / "01_collect.md").exists() and not (d / "06_log.md").exists():
            fail("E9", f"runs/{d.name} has no 06_log.md. Close it with stages/06_log.")
    for d in sorted(runs.iterdir()):
        log6 = d / "06_log.md"
        if d.is_dir() and log6.exists() and re.search(r"\bPENDING\b", log6.read_text(encoding="utf-8")):
            fail("E9", f"runs/{d.name}/06_log.md says PENDING. Write it after the check has run and copy the check's last line (stages/06_log).")


def main():
    check_setup()
    loaded = load_report()
    drafts = check_drafts()
    log = load_log()
    live = check_log(log, drafts)
    check_send_guard(drafts, live)
    check_secrets()
    check_schedule()
    if loaded:
        check_counts(loaded[0], loaded[1], drafts)
    check_runs()
    if FAILS:
        print("\n".join(FAILS))
        print(f"\n{len(FAILS)} check(s) failed.")
        return 1
    print("All checks passed (E1 to E9).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
