# Setup questions

Ask one per turn, in this order. The default is in brackets. Write each answer into `email-manager/_shared/email-settings.md` the moment you get it. "Required" means there is no default. Under the Chief of Staff, skip a question when its answer is already in `chief-of-staff/_shared/owner-profile.md` (marked "skip under the Chief of Staff").

1. What should I call you, and which email address or addresses are yours? [required] (Under the Chief of Staff, ask only for the addresses.)
2. Can your AI agent read your email, or will you paste emails to me? If it can, which email tool is it? [paste] (Under the Chief of Staff, when its profile says email is connected and names the tool: skip this question, write `connected` and that tool in settings. When the profile says connected and names no tool: ask only "Which email tool does your AI agent use to read your email?" and write `connected` plus the answer. Never write `paste` when the profile says connected.)
3. What is your number one goal right now, and which people should always get your attention first (customers, prospects, partners, family)? Is there anyone you always answer yourself, so I should never write a draft? Anyone or anything I must never mention? [goal: not given, people: none] (If the owner answers only part, write the default for the rest and move on. Do not ask again.) (Under the Chief of Staff, ask only for the VIPs and the never-draft list.)
4. Where can I read your real writing to learn how you sound? Best is the last 50 replies you wrote yourself in your sent mail. Or paste 3 to 5 replies you are happy with right in your answer. [sent mail] (Skip under the Chief of Staff when its voice profile is built.)
5. What city are you in (I store it as a time zone like America/Los_Angeles), and when should I run your daily inbox check? [the time zone your computer shows, first session of the day] (Skip all of question 5 under the Chief of Staff: the time zone is in its profile, and `check_time` gets its default, first session of the day, because the Chief of Staff starts the daily run.)

Under the Chief of Staff the most you ask is three: the addresses (question 1), the email tool only if the profile names none (question 2), and the VIPs and never-draft list (question 3).

Sending is not a setup question. It starts off. The owner turns it on by saying "turn on sending" (`email-manager/stages/05_send/CONTEXT.md`).
