# 02_sort: one bucket per thread, with a reason

One job: put every new thread in exactly one of the five buckets, check the live thread state first, and name the important one. Paths start from the `ceo-ai-toolkit` folder.

## Inputs
- Working: `01_collect.md` in the run folder
- Reference: `email-manager/_shared/buckets.md`, `email-manager/_shared/email-settings.md`, `email-manager/_shared/people.md`, the lessons files
- Template: `email-manager/_templates/outputs/02_triage.md`

## Process
1. Read `buckets.md`. Know the order of checks.
2. **Re-check the live thread** for every thread that is not obviously Clutter. Connected mode: read the full thread now, including the Sent folder. Find out whether the owner replied after the other side's latest message, whether the other side's last message is only a thank you, and whether the outcome is already confirmed. Paste mode with sent replies pasted: check those. Paste mode without them: you cannot see Sent. Write "Sent not checked" in Thread check, and ask the owner once in the summary: "Did you already reply to any of these?"
3. Apply the order of checks in `buckets.md` to each thread. Write the bucket and a one-line Why. Put "closed" or "suspicious" in Why where it applies.
4. Pick the important one (`buckets.md`, "The important one"), or "none today".
5. List scheduling asks for stage 04. Add them to the Why of the thread, for example "scheduling: Friday 10 AM".
6. If `labels: on`, add one label per bucket to each thread: `Email Manager: Your call`, `Email Manager: Reply drafted`, `Email Manager: Waiting on them`, `Email Manager: FYI`, `Email Manager: Clutter`. Labels only. Never archive, mark read, star, move or delete.
7. Write the sort table with the thread number in `#`: 1, 2, 3 or E1, E2, E3 (one style). Count the rows. The count is the "Sorted" number for the report.
8. Add a decision log row: `Sorted N threads`, T1, Result done.
9. **Threads that clash.** When two threads cannot both be answered as asked (two people want the same time, or one thread's answer changes another's), write "clashes with <person>" in the Why of both rows. Stage 04 names the clash in the summary.
10. A thread you cannot place with confidence goes in the safer bucket (Clutter to FYI, FYI to Your call) and the Why says so.

## Output
- `02_triage.md` in the run folder: the table (`#` is the thread number, either plain numbers 1, 2, 3 or E-numbers E1, E2, E3, one style in the whole table, and `check_email.py` counts both. Then From, Subject, Bucket, Why, Draft, Thread check), the important one, the scheduling asks, the counts by bucket.
- One decision log row.

## Human check
None. The owner can correct any bucket, and the correction becomes a lesson.
