# 03_draft: write the reply the owner would send, then check it at the pass

One job: for every Reply drafted thread, write one reviewed draft in the owner's voice that does not promise anything new. Paths start from the `ceo-ai-toolkit` folder.

## Inputs
- Working: `02_triage.md` in the run folder (rows marked Reply drafted), `01_collect.md`
- Reference: `email-manager/_shared/draft-rules.md`, the voice profile, `email-manager/_shared/people.md`, `email-manager/_shared/review-rubric.md`, `email-manager/_shared/email-settings.md`, the lessons files
- Template: `email-manager/_templates/outputs/03_drafts.md`, `email-manager/_templates/outputs/draft.md`

## Process
1. Read `draft-rules.md` and the voice profile. No voice profile built: draft short and plain, write "voice not built" in the notes, and ask the owner for writing samples once.
2. For each Reply drafted row: **re-read the live thread right now** (ER14). If the owner replied since stage 02, or the other side's last message is a pure thank you, change the bucket in `02_triage.md` (Waiting on them or FYI), say why in Thread check, and write no draft.
3. Write the draft file in `handoffs/drafts/` as `draft-rules.md` says. One live draft per thread: update an existing `waiting for owner` file instead of adding a second.
4. A thread the owner just decided ("yes to Priya, 10% for 12 months"): draft it now. The owner's words are the only source for the new commitment. Quote them in the notes. Log a red row: `Owner decided <what, in a few words>`, T3, the owner's exact words, Result done. If the owner says "later" or "not yet", log Result parked and write no draft.
5. Add the draft file name to the Draft column of `02_triage.md`. A Your call row the owner just decided (step 4) moves to Reply drafted in the same table, with the Why changed to the decision. Then update the report in the same turn: the row stays in Waiting on you with its draft file, Needs you does not change, and a `By bucket` line moves one from your call to reply drafted.
6. **Check at the pass (yellow).** Send the batch to the reviewer (`review-rubric.md`) with the files it lists. Pass: continue. Fail: fix exactly what it listed and review again. A second fail makes that draft red: keep the file, add "Reviewer concerns:" with the notes, and set `status: partial` for the report.
7. Add a decision log row: `Wrote 1 reply draft` for one draft, `Wrote N reply drafts` for two or more, T2, Evidence `review: pass` (`review: pass (self)` when the same agent reviewed, `review-rubric.md` "Who reviews"), Result done. Do not log a pass that did not happen. A first review that fails is logged before the fix, exactly `Draft for <person> failed review, sent back once: <file>`, T2, Evidence `review: fail, round 1`, Result pending. A pass after a fix adds `Re-reviewed draft <file> after fix`, T2, `review: pass` (fresh helper, `review: pass (self)` when the reviewer is resumed or is the same agent), Result done (never a second `Wrote N reply drafts` row). A draft that ended red (step 6) gets its own row, exactly `Draft for <person> failed review twice, file kept: <file>`, T2, Evidence `review: fail, 2 rounds`, Result pending. A run with no Reply drafted thread logs exactly `Wrote 0 reply drafts, no thread needed one`, T1, Evidence `02_triage.md`, Result done (nothing was shown as finished, so no review). A run that re-applies a new style lesson to waiting drafts follows `draft-rules.md`, "A new style lesson and the drafts already waiting".
8. At every run that re-reads a waiting draft's thread, update its `Thread re-checked` line to the new time. A draft that changes after an owner decision or a fix: update its line in `03_drafts.md` and the Why in `02_triage.md` the same turn, so no stale note (such as "no discount named") stays.
9. Write `03_drafts.md`: each file, the thread it answers, the reviewer result.

## Output
- Draft files in `handoffs/drafts/`, all `status: waiting for owner`.
- `03_drafts.md` in the run folder.
- One decision log row.

## Human check
The reviewer, before the owner hears a draft is ready. The owner approves every send.
