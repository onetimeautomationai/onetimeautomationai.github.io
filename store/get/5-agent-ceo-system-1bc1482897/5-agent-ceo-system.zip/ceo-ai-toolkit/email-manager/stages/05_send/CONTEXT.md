# 05_send: approvals, sends, and the sending switch

Runs only when the owner approves a draft, or says "turn on sending" or "turn off sending". One job: do exactly what the owner's words cover, and prove it. Paths start from the `ceo-ai-toolkit` folder.

## Inputs
- Working: the draft file in `handoffs/drafts/`, the owner's exact words
- Reference: `email-manager/system.md` section 5, `email-manager/_shared/email-settings.md`, `email-manager/_shared/decision-tiers.md`, `email-manager/_shared/decision-log.md`
- Template: `email-manager/_templates/outputs/05_send.md`

## A. The owner approves a draft ("send it", "send the Priya one", "approved")

0. Not shown yet? Show the draft text first (or say "show Elena" to the owner and wait). Words given before the text was shown do not count.
1. Find the draft the words cover. They cover a draft only if the owner has been shown its text and the words name the person or the subject, or say "all of the drafts you just showed me" (those drafts only). "Yes" alone after you showed one draft covers that one. If it is unclear which, ask one question and wait.
   - **"Send all of those" said again** (R3-EA4): the words cover only drafts shown since the owner's last approval that are still `waiting for owner`. Drafts already `approved`, `sent` or `dropped` are never covered again. A draft written or shown before that last approval is not covered. If that leaves none, say "Nothing new to send. Every draft you approved is already handled." If it is unclear which drafts the words mean, list them by person and ask one question.
2. Log a red row: `Owner approved draft <file>`, T3, the owner's exact words, Result done. Set the draft's status to `approved`, and write `runs/<today>/05_send.md` now, from its template (`check_email.py` E4 fails an approved, sent or dropped draft with no `05_send.md`). This row always comes before any `Sent reply` or `Owner task: sent` row for that file.
3. Sending is **off** (the default): say "Sending is off, so I have not sent it. Copy it from `handoffs/drafts/<file>` into your email and send it yourself. Tell me when you have." Stop. When the owner says "I sent it", set the status to `sent`, log `Owner task: sent <file>`, T1, Result done, and do step B2.
4. Sending is **on**: go to B.

## B. Sending (only when sending is on)

Check all five. If any fails, do not send. Say which one failed and what you need.
1. `sending: on` is in the settings, with the owner's words and the date.
2. The draft is `approved` and the owner's words are in the log.
3. It is a reply on an existing thread, to the people already on it. No new recipient, no Bcc, no attachment added, no forward.
4. The draft text is exactly what the owner approved. Anything edited since sets the status back to `waiting for owner`, and you show the owner the new text.
5. Re-read the live thread now. The owner has not replied since the draft, and no newer message changes the ask.

Then send. Read the Sent folder and find the message. Found: set the status to `sent`, log `Sent reply to <person>, <file>`, T3, the owner's exact words, Evidence "found in Sent at HH:MM", Result done. Not found, or you cannot tell: set the status to `waiting for owner`, tell the owner "I could not confirm it was sent, please check your Sent folder", and never send it a second time. A send stopped at a condition (for example the owner replied first) sets the draft to `dropped` with a note saying why, so a later "send it" cannot send an old approval. Log exactly `Dropped draft <file>, send stopped at condition N (<why>)`, T1, Evidence what you saw, Result done. Never write a `Sent reply` row for a stopped send. After a send or a drop, do step B2.

## B2. Update the sort table and the report (after every send, owner send or drop)

The check script (E8) fails a sent or dropped draft that still sits in a Reply drafted row, in Waiting on you, or in The important one. So, the same turn, for that thread:
1. In the first table of `email-manager/runs/<today>/02_triage.md`, change the row's Bucket to `Waiting on them` (sent, by you or the owner, or dropped because the owner already replied, `buckets.md` check 5). Start Why with `sent HH:MM` or `owner replied HH:MM`. Keep the file name in the Draft column. A drop because a newer message from the other side changed the ask: sort the thread again with `buckets.md` and say so in Why.
2. In `handoffs/email-manager-report.md`, remove the thread's row from Waiting on you, lower Needs you by one, and fix the by-bucket bullet. New today and Sorted do not change.
3. If The important one was this thread, pick the next one from the Your call and Reply drafted rows left, by the order in `buckets.md`, or write "none today".
4. Update the header time. Run `python3 email-manager/scripts/check_email.py`. It must pass before you tell the owner it is done.
5. **A scheduling ask the owner has settled** (a drop for condition 5 because the owner already answered, an owner send, or a send by the agent, which counts as an owner send): in `handoffs/schedule-items.md`, if the owner's own reply agrees a time, leave the thread's row `new` so the Time Manager places it, and change its Date and time cell to what the owner wrote. If the owner's reply says no meeting is needed, set the row `skipped`. If the reply confirms no time, leave the row `new` and end its What cell with `, not confirmed`. Only the Time Manager's report sets `placed`. Name the change in `05_send.md`.
6. The thread's report is from an earlier day: change only the draft status and the log. Today's run sorts it again if it is still open.

## C. Turn sending on

0. Paste mode (no connection): sending stays off. Say "You paste your emails, so I cannot send. Sending stays off." Stop.
1. Check the connection can send. If it can only create drafts, say "Your email connection cannot send, so sending stays off." Stop.
2. Explain in plain words, once: "With sending on, after you approve a specific draft I send that reply. One draft at a time. Replies on existing threads only. I re-check the thread first. I never send without your words about that draft."
3. Ask: "Turn sending on?" Only a clear yes counts.
4. Write `sending: on`, `sending_changed:` with today's date, and `owner's words when changed:` with the exact words, in the settings. Log `Sending turned on`, T3, the words, Result done. `check_email.py` fails any `sending: on` without this exact row, and any `sent` draft without a red `Owner approved draft <file>` row plus either a red `Sent reply to <person>, <file>` row with Evidence `found in Sent at HH:MM` or an `Owner task: sent <file>` row.
5. Under the Chief of Staff, the Chief of Staff asks the owner and gives you the words in your job row. Do not turn it on without them.

## D. Turn sending off

No questions. Write `sending: off`, the date and the owner's words in the settings. Log `Sending turned off`, T3, the words, Result done. Say "Sending is off." Drafts that were `approved` and not sent stay `approved`.

## E. Turn labels on or off

Same steps as C and D, for the `labels` setting. Log `Labels turned on` or `Labels turned off`.

## Standing permissions and other asks

Each refusal gets one log row: T3, Why the rule it meets, the owner's exact ask in Owner's words, Result `no`. Use the exact Decision text below (R3-EB9).
- "Send replies to Ana automatically from now on": say no. Each send needs the owner's words about that draft. Offer: "I can show you a draft and you say send it." Do not write a lesson that lowers a rule. Log exactly `Refused: standing send to <person>, each send needs the owner's words`, Evidence `no lesson written`.
- "Forward this to my accountant": you do not forward. Write a forward draft in `handoffs/drafts/` and the owner sends it. If the owner did not give the recipient, write `to: (owner adds)` and never guess one. Log exactly `Wrote 1 forward draft for <person>, waiting for owner`, T2, Evidence `review: pass`, Result done.
- "Unsubscribe me from those": you do not unsubscribe. List the senders and the owner does it. Log exactly `Refused: unsubscribe, never allowed. Listed N senders for the owner`, Evidence `nothing unsubscribed`.
- "Delete the clutter" or "Clear my inbox": you do not delete, archive or mark read. List the clutter senders and threads so the owner can do it in their email. Log exactly `Refused: delete the clutter, never allowed. Listed N clutter senders for the owner`, Evidence `nothing deleted`.

## Output
- `05_send.md` in the run folder: what was approved or sent, the owner's words, the proof.
- Updated draft status, decision log rows, sort table and report (step B2).

## Human check
The owner's words, every time.
