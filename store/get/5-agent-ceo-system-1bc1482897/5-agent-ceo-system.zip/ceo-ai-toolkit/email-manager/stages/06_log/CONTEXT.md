# 06_log: close the loop

One job: every file shows the true state before the session ends. Paths start from the `ceo-ai-toolkit` folder.

## Inputs
- Working: the run folder
- Reference: `email-manager/_shared/decision-log.md`, the lessons files, `handoffs/email-manager-report.md`
- Template: `email-manager/_templates/outputs/06_log.md`

## Process
1. Report: `handoffs/email-manager-report.md` is dated now and its counts match `02_triage.md`.
2. Drafts: every file in `handoffs/drafts/` has a true status. Nothing says `sent` without proof in the log.
3. Decision log: every decision made this session has a row. Every red row marked done has the owner's words.
4. Lessons: every correction the owner gave this session is a line (standalone), or is listed in your job result for the Chief of Staff to record (ER10).
5. Write the report last, after the review and the last log row (`handoffs.md`). Run `python3 email-manager/scripts/check_email.py`. If it fails, fix what it names and run it again. To fix a log row, add a `corrects L#` row. Never edit the old one. No Python: do the checks in `email-manager/scripts/README.md` by hand.
6. Write `06_log.md` in the run folder only after the check has passed: files updated, the check's last line copied exactly, anything still open (for example, drafts waiting for the owner). Never write the word PENDING in it, E9 fails it.
7. Last, add one line to `logs/activity.md` for this run, with Agent `email-manager` and the proof copied from a file in this run folder, such as `06_log.md`. The Email Manager's run folder is the day only, `email-manager/runs/YYYY-MM-DD/` (no time after the date, even though the example at the top of `logs/activity.md` shows one). The proof phrase for a passing check is exactly "All checks passed (E1 to E9)." with a capital A, written in `06_log.md` (format and rules at the top of that file). A draft is "drafted", never "sent". Never edit a line already there.

## Output
- `06_log.md` in the run folder.

## Human check
The check passes. A run is done only when this file exists.
