# stages: map

| Folder | One line |
|---|---|
| `01_collect/` | Read the new mail (or the pasted mail), change nothing |
| `02_sort/` | Re-check each thread, one bucket each, name the important one |
| `03_draft/` | Reviewed reply drafts in the owner's voice, predict do not promise |
| `04_handoff/` | Schedule items, the report, the summary |
| `05_send/` | Approvals, sends, and the sending and labels switches. Only on the owner's words |
| `06_log/` | Log, lessons, checks pass |
