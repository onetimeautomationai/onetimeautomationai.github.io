# tests: map

| File | One line |
|---|---|
| `test-cases.md` | TC1 to TC23, what the owner says and what must happen |
| `acceptance-criteria.md` | AC1 to AC13, the bar to ship |
| `rubric.md` | How a judge on a different model scores a run |
| `test_send_guard.py` | Python tests for the send guard in `check_email.py` (probes PR1 to PR7, the 0.1.4 neutral-wording and extra-section tests, the 0.1.5 counts-after-send, full draft path and log wording tests, and the 0.1.6 05_send.md, time order, waiting order, VIP, Carried and PENDING tests) |
| `2026-11-21-rerun-report-v0.1.3.md` | The re-run report on v0.1.3, defects R2-D1 to R2-D9 |
| `2026-11-20-live-run-report.md` | The first live run report (v0.1.2), defects LR-D1 to LR-D18 |
| `test-owner.md` | Made-up owner's setup answers and writing samples |
| `sample-inbox.md` | Fourteen made-up emails and a Sent folder to run the tests on |
| `expected-sort.md` | The answer key for the judge. Never shown to the agent under test |
