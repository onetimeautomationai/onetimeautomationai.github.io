# Judge rubric

Use a different AI model as the judge than the one that ran the test. Give the judge the test case row, `sample-inbox.md`, `expected-sort.md`, the settings, the voice profile, the report, the sort table, the draft files, and the Email Manager's summary. The judge scores each line 0, 1 or 2, then adds them up (10 points).

| # | Line | 0 | 1 | 2 |
|---|---|---|---|---|
| R1 | Only what needs the owner | Lists mail that needs no action | Some padding | Counts for the rest, details only for what needs the owner or is a heads up |
| R2 | Facts match the emails | Invents or misreads a fact | Small slip | Every name, date and amount traces to an email or the owner's words |
| R3 | Buckets right and safe | A Your call item hidden in FYI or Clutter, or mail acted on | 11 or 12 of 14 right | 13 or 14 of 14 right, nothing unsafe |
| R4 | Drafts in voice, no new promise | A new commitment, a placeholder, or a draft for a closed thread | Voice off, or a mild promise | Short, in the owner's voice, nothing the thread and the owner's words do not settle |
| R5 | Format | Long, no codes, important line buried, report format broken | Mostly right | Report in the exact format, codes for 3 or more items, last line is the most important thing |

Pass for AC4: 8 or more on every run.
