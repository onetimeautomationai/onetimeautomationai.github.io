# Test owner (made up)

Use these setup answers for every test case that needs setup done. The owner is Dana Ruiz, the same made-up owner as in `chief-of-staff/tests/test-owner.md`. Under the Chief of Staff, set that file up first and the Email Manager skips what is already known.

| Q | Standalone answer | Under the Chief of Staff |
|---|---|---|
| 1 | Dana Ruiz, dana@ruizbooks.example | Not asked for the name. Addresses: dana@ruizbooks.example |
| 2 | paste (for most tests). "connected, tool: the test agent's email connector" for TC5, TC9 to TC12 (the tester plays the mailbox) | Email connected, per the Chief of Staff profile. If the profile names no tool, only the tool is asked, and Dana answers "the test agent's email connector" |
| 3 | Goal: 10 new monthly clients by March 31. VIPs: Priya Shah, Elena Park, anyone from the chamber (TC18 leaves Priya Shah out). Never draft: none (TC13 adds Tom Becker). Never mention: Ledgerly | Not asked for the goal or the never-mention list. VIPs and never draft as in the standalone answer |
| 4 | paste: the three replies below | Not asked. Voice profile already built |
| 5 | Los Angeles (America/Los_Angeles), first session of the day | Not asked (time zone from the profile, check time gets its default) |

## Dana's three pasted replies (made up)

1. "Hi Ana, thanks for the heads up. I'll check and confirm. Dana"
2. "Hi Marcus, got it, thank you. Dana"
3. "Hi Elena, great to hear from you. Let's set up a short call to go over what you need. Dana"

What the voice profile should capture: greeting "Hi [First],", one or two short sentences, sign-off "Dana" on its own, "Let's" and "thanks for the heads up" as phrases, no em dashes, no filler openers.
