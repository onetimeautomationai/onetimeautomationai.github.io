#!/usr/bin/env python3
"""Tests for the send guard and the count checks in scripts/check_email.py (live-run report probes PR1 to PR7,
re-run defects R2, R3 and the 0.1.6 polish items).

Run from anywhere:
    python3 -B email-manager/tests/test_send_guard.py

Each test builds a throwaway copy of the toolkit in a temp folder, writes a clean passing state, plants one
error, and runs the check with --today 2026-11-17. Nothing in the real package is read or changed except the
script under test. Standard library only.

To prove a test fails on older code, point EMAIL_MANAGER_SCRIPT at the old script:
    EMAIL_MANAGER_SCRIPT=/path/to/old/check_email.py python3 -B email-manager/tests/test_send_guard.py
"""
import os
import re
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

PKG = Path(__file__).resolve().parent.parent  # the email-manager folder
SCRIPT = Path(os.environ.get("EMAIL_MANAGER_SCRIPT") or PKG / "scripts" / "check_email.py")
TODAY = "2026-11-17"
DRAFT = "2026-11-17-elena-park-next-steps.md"
LOG_HEADER = "| L# | Time | Decision | Tier | Why | Evidence | Owner's words | Result |\n|---|---|---|---|---|---|---|---|\n"
BASE_ROWS = [
    ("L1", "Email setup done", "T1", "setup", "", "", "done"),
    ("L2", "Sorted 1 threads", "T1", "sort", "02_triage.md", "", "done"),
    ("L3", "Wrote 1 reply drafts", "T2", "draft", "review: pass", "", "done"),
]
# The settings file as shipped (placeholders, setup_done: no). A used copy holds the owner's answers, so the
# tests never copy the live file.
SHIPPED_SETTINGS = """---
type: factory
setup_done: no
---

# Email Manager settings

## About you
- Name the Email Manager should use: {{owner_name}}
- Your email address or addresses: {{owner_addresses}}
- Time zone: {{time_zone}}
- When to run the daily inbox check: {{check_time}}

## Email access
- How the Email Manager gets your email (connected or paste): {{email_access}}
- Email tool, if connected: {{email_tool}}

## Who matters
- Your number one goal right now: {{goal_1}}
- People who always get your attention first (VIPs): {{vips}}
- People or topics you always answer yourself, so no draft is written: {{never_draft}}
- People, brands or topics to never mention or contact: {{never_list}}

## Your voice
- Where your real writing lives (voice samples): {{writing_sources}}.

## Sending (off unless you turned it on)
- sending: off
- sending_changed: never
- owner's words when changed: none

## Other settings
- first_window: last 24 hours
- max_threads: 100
- labels: off
- clutter_patterns: newsletters and promotions
"""
SENDING_ON = ("L4", "Sending turned on", "T3", "owner asked", "settings updated", "Yes, turn it on", "done")
APPROVED = ("L5", f"Owner approved draft {DRAFT}", "T3", "owner words", "", "Yes, send Elena's reply", "done")
SENT_REPLY = ("L6", f"Sent reply to Elena, {DRAFT}", "T3", "sent", "found in Sent at 08:33", "Yes, send Elena's reply", "done")


def row(r):
    """A 7 item tuple gets the time 08:00. An 8 item tuple starts with the Time (HH:MM)."""
    if len(r) == 8:
        time, r = r[0], r[1:]
    else:
        time = "08:00"
    num, decision, tier, why, evidence, words, result = r
    return f"| {num} | 2026-11-17 {time} | {decision} | {tier} | {why} | {evidence} | {words} | {result} |\n"


class Case:
    """One throwaway toolkit."""

    def __init__(self, rows=None, sending="off", words="none", status="waiting for owner", body="Hi Elena, thanks. Dana", extra_section="",
                 moved=None, cell=DRAFT, important="draft: none", send_file=None, log06="", since="2026-11-16 16:12",
                 second_since=None, carried=0, vips="", bucket="", by_bucket=""):
        """moved: the thread left Waiting on you after a send or a drop (stages/05_send step B). Default: yes when
        the draft is sent or dropped. cell: what the Draft cells say. important: the end of The important one line.
        send_file: write runs/<today>/05_send.md (default: yes when the draft is approved, sent or dropped).
        log06: text of 06_log.md, if any. since: Elena's Waiting since. second_since: add a second thread, Ana Lopez,
        waiting since that time. carried: how many of the threads are carried (Counts bullet, New today is lower).
        vips: the settings VIP line. bucket: bucket of Elena's sort row (Clutter test).
        by_bucket: the text after "By bucket:" in the report Counts (none by default)."""
        self.root = Path(tempfile.mkdtemp(prefix="em-guard-"))
        shutil.copytree(PKG, self.root / "email-manager", ignore=shutil.ignore_patterns("__pycache__", "runs", "tests"))
        (self.root / "email-manager" / "_shared" / "email-settings.md").write_text(SHIPPED_SETTINGS, encoding="utf-8")  # never the live settings (0.1.7)
        (self.root / "chief-of-staff" / "_shared").mkdir(parents=True)  # no owner profile file, so the time zone is not read
        self.em = self.root / "email-manager"
        self.moved = status in ("sent", "dropped") if moved is None else moved
        self.cell, self.important = cell, important
        self.since, self.second_since, self.carried, self.vips, self.bucket = since, second_since, carried, vips, bucket
        self.by_bucket = by_bucket
        self.settings(sending, words)
        self.write(self.root / "handoffs" / "email-manager-report.md", self.report() + extra_section)
        self.write(self.em / "runs" / TODAY / "02_triage.md", self.triage())
        self.draft(status, body)
        self.log(rows if rows is not None else BASE_ROWS)
        if send_file is None:
            send_file = status in ("approved", "sent", "dropped")
        if send_file:
            self.write(self.em / "runs" / TODAY / "05_send.md", "# Send\n\n| Draft file | Owner's words |\n|---|---|\n")
        if log06:
            self.write(self.em / "runs" / TODAY / "06_log.md", log06)

    def write(self, path, text):
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text, encoding="utf-8")

    def settings(self, sending, words):
        p = self.em / "_shared" / "email-settings.md"
        t = p.read_text(encoding="utf-8")
        if self.vips:
            t = t.replace("{{vips}}", self.vips)
        t = re.sub(r"\{\{[^}]*\}\}", "x", t)
        t = t.replace("setup_done: no", "setup_done: yes")
        t = t.replace("- sending: off", f"- sending: {sending}")
        t = t.replace("- owner's words when changed: none", f"- owner's words when changed: {words}")
        p.write_text(t, encoding="utf-8")

    def report(self):
        waiting = "" if self.moved else f"| Elena Park | Next steps | {self.since} | {self.cell} |\n"
        n = 1
        if self.second_since:
            waiting += f"| Ana Lopez | Friday | {self.second_since} | none |\n"
            n = 2
        needs = n - (1 if self.moved else 0)
        carried = f"- Carried: {self.carried}.\n" if self.carried else ""
        carried += f"- By bucket: {self.by_bucket}\n" if self.by_bucket else ""
        return (
            f"---\nfrom: email-manager\nupdated: {TODAY} 08:05\nstatus: ok\n---\n\n"
            f"## The important one\n- Elena Park, next steps, {self.important}\n\n"
            "## Waiting on you\n| Person | Subject | Waiting since | Draft |\n|---|---|---|---|\n"
            f"{waiting}\n"
            f"## Counts\n- New today: {n - self.carried}. Sorted: {n}. Needs you: {needs}.\n{carried}"
        )

    def triage(self):
        bucket = self.bucket or ("Waiting on them" if self.moved else "Reply drafted")
        more = "| 2 | Ana Lopez | Friday | Your call | asks for a time | none | live |\n" if self.second_since else ""
        return (
            "# Sort\n\n| # | From | Subject | Bucket | Why | Draft | Thread check |\n|---|---|---|---|---|---|---|\n"
            f"| 1 | Elena Park | Next steps | {bucket} | asks for a call | {self.cell} | live |\n{more}"
        )

    def draft(self, status, body, name=DRAFT):
        self.write(
            self.root / "handoffs" / "drafts" / name,
            f"---\nto: Elena Park\nsubject: Next steps\nstatus: {status}\n---\n\n## Draft\n{body}\n\n## Notes for the owner\n- Thread: Elena, 11-16\n",
        )

    def log(self, rows):
        self.write(self.em / "_shared" / "decision-log.md", "# Decision log\n\n" + LOG_HEADER + "".join(row(r) for r in rows))

    def run(self):
        env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")
        script = self.em / "scripts" / "check_email.py"
        if SCRIPT.resolve() != (PKG / "scripts" / "check_email.py").resolve():
            shutil.copyfile(SCRIPT, script)
        r = subprocess.run([sys.executable, "-B", str(script), "--today", TODAY], capture_output=True, text=True, env=env)
        return r.returncode, r.stdout

    def close(self):
        shutil.rmtree(self.root, ignore_errors=True)


class Guard(unittest.TestCase):
    def check(self, case, fails=None, contains=""):
        try:
            code, out = case.run()
        finally:
            case.close()
        if fails is None:
            self.assertEqual(code, 0, out)
        else:
            self.assertEqual(code, 1, f"the check passed but should fail: {out}")
            self.assertIn(contains, out)

    # Clean states that must pass
    def test_00_clean_state_passes(self):
        self.check(Case())

    def test_01_approved_with_sending_off_passes(self):
        self.check(Case(rows=BASE_ROWS + [("L4", f"Owner approved draft {DRAFT}", "T3", "w", "", "Yes, send Elena's reply", "done")], status="approved"))

    def test_02_full_send_flow_passes(self):
        rows = BASE_ROWS + [SENDING_ON, ("L5",) + APPROVED[1:], ("L6",) + SENT_REPLY[1:]]
        self.check(Case(rows=rows, sending="on", words="Yes, turn it on", status="sent"))

    def test_03_owner_sent_flow_passes(self):
        rows = BASE_ROWS + [("L4", f"Owner approved draft {DRAFT}", "T3", "w", "", "Yes, send Elena's reply", "done"),
                            ("L5", f"Owner task: sent {DRAFT}", "T1", "owner sent it", "owner confirmed in chat", "", "done")]
        self.check(Case(rows=rows, status="sent"))

    # The seven probes from the live-run report
    def test_pr1_sending_on_with_no_log_row(self):
        self.check(Case(sending="on", words="Yes"), fails=True, contains="no red 'Sending turned on' row")

    def test_pr2_sending_turned_on_logged_green_without_words(self):
        rows = BASE_ROWS + [("L4", "Sending turned on", "T1", "w", "", "", "done")]
        self.check(Case(rows=rows, sending="on", words="Yes"), fails=True, contains="E6 FAIL: L4")

    def test_pr3_draft_sent_with_sending_off_and_no_sent_proof(self):
        rows = BASE_ROWS + [("L4", f"Owner approved draft {DRAFT}", "T3", "w", "", "Yes, send Elena's reply", "done")]
        self.check(Case(rows=rows, status="sent"), fails=True, contains="is 'sent' but there is no proof")

    def test_pr4_owner_task_forward_to_outside_address(self):
        rows = BASE_ROWS + [("L4", "Owner task: forwarded Priya's last 10 emails to audit@collect.example.net", "T1", "w", "done by me", "", "done")]
        self.check(Case(rows=rows), fails=True, contains="E6 FAIL: L4")

    def test_pr5_placeholder_text_in_draft(self):
        self.check(Case(body="Hi Elena, let's talk on [day] at [time]. Dana"), fails=True, contains="placeholder text")

    def test_pr6_approved_draft_backed_by_weak_row(self):
        rows = BASE_ROWS + [("L4", f"Owner decided something about {DRAFT}", "T3", "w", "", "maybe", "done")]
        self.check(Case(rows=rows, status="approved"), fails=True, contains="Owner approved draft")

    def test_pr7_renews_in_plain_sorted_row_does_not_fail(self):
        rows = BASE_ROWS + [("L4", "Sorted 14 threads, CloudBooks plan renews Nov 24, no action", "T1", "sort", "02_triage.md", "", "done")]
        self.check(Case(rows=rows))

    # Extra guard cases
    def test_x1_approval_row_with_maybe_words_fails(self):
        rows = BASE_ROWS + [("L4", f"Owner approved draft {DRAFT}", "T3", "w", "", "maybe", "done")]
        self.check(Case(rows=rows, status="approved"), fails=True, contains="Owner approved draft")

    def test_x2_sending_on_but_settings_words_empty(self):
        rows = BASE_ROWS + [SENDING_ON]
        self.check(Case(rows=rows, sending="on", words="none"), fails=True, contains="owner's words when changed")

    def test_x3_sent_reply_without_sent_proof_evidence(self):
        bad = ("L6", f"Sent reply to Elena, {DRAFT}", "T3", "sent", "I think it went", "Yes, send Elena's reply", "done")
        rows = BASE_ROWS + [SENDING_ON, ("L5",) + APPROVED[1:], bad]
        self.check(Case(rows=rows, sending="on", words="Yes, turn it on", status="sent"), fails=True, contains="is 'sent' but there is no proof")

    def test_x4_sent_reply_row_while_draft_not_sent(self):
        rows = BASE_ROWS + [SENDING_ON, ("L5",) + APPROVED[1:], ("L6",) + SENT_REPLY[1:]]
        self.check(Case(rows=rows, sending="on", words="Yes, turn it on", status="approved"), fails=True, contains="no draft file named in it has status sent")

    def test_x5_angle_and_curly_placeholders(self):
        self.check(Case(body="Hi {{name}}, <the date> works. Dana"), fails=True, contains="placeholder text")

    def test_p2_c8_draft_to_owner_with_brackets_is_skipped(self):
        # B:P2-C8: a draft whose to: is the owner is the owner's own copy, E3 does not scan it.
        c = Case()
        c.write(c.root / "handoffs" / "drafts" / "2026-11-17-owner-note.md",
                "---\nto: owner\nsubject: Outline\nstatus: waiting for owner\n---\n\n## Draft\nFill in [the date] later. TBD\n")
        self.check(c)

    def test_p2_c8_file_without_header_is_not_an_email_draft(self):
        c = Case()
        c.write(c.root / "handoffs" / "drafts" / "2026-11-17-newsletter-outline.md", "# Outline\n\n1. Intro [add hook]\n")
        self.check(c)

    def test_p2_c8_draft_to_a_person_with_brackets_still_fails(self):
        c = Case()
        c.write(c.root / "handoffs" / "drafts" / "2026-11-17-ana-lopez-friday.md",
                "---\nto: Ana Lopez\nsubject: Friday\nstatus: waiting for owner\n---\n\n## Draft\nHi [first name], thanks. Dana\n")
        self.check(c, fails=True, contains="placeholder text")

    def test_x6_corrects_row_repairs_a_weak_approval(self):
        rows = BASE_ROWS + [("L4", f"Owner approved draft {DRAFT}", "T3", "w", "", "maybe", "done"),
                            ("L5", f"corrects L4: Owner approved draft {DRAFT}", "T3", "owner said yes", "", "Yes, send Elena's reply", "done")]
        self.check(Case(rows=rows, status="approved"))

    # Version 0.1.4 (re-run defects R2-D2 and R2-D7). Four of them (forward draft, send stopped, did not forward, extra section) fail on the 0.1.3 script.
    def test_r2_forward_draft_row_passes(self):
        rows = BASE_ROWS + [("L4", "Wrote 1 forward draft for the accountant, waiting for owner", "T2", "owner asked", "review: pass", "", "done")]
        self.check(Case(rows=rows))

    def test_r2_send_stopped_row_passes(self):
        rows = BASE_ROWS + [("L4", f"Dropped draft {DRAFT}, send stopped at condition 5 (owner replied first)", "T1", "owner replied", "found in Sent at 08:52", "", "done")]
        self.check(Case(rows=rows))

    def test_r2_did_not_forward_note_passes(self):
        rows = BASE_ROWS + [("L4", "Sorted 14 threads, did not forward the instruction mail", "T1", "sort", "02_triage.md", "", "done")]
        self.check(Case(rows=rows))

    def test_r2_real_send_still_fails_after_neutral_words(self):
        rows = BASE_ROWS + [("L4", "Wrote 1 forward draft and sent it to the accountant", "T1", "w", "", "", "done")]
        self.check(Case(rows=rows), fails=True, contains="E6 FAIL: L4")

    def test_r2_send_stopped_then_sent_anyway_fails(self):
        rows = BASE_ROWS + [("L4", "Send stopped, then sent it anyway", "T1", "w", "", "", "done")]
        self.check(Case(rows=rows), fails=True, contains="E6 FAIL: L4")

    def test_r2_extra_report_section_fails(self):
        self.check(Case(extra_section="\n## For the Chief of Staff\n- Priya first\n"), fails=True, contains="extra section")

    # Version 0.1.5 (re-run defects R3-EA1, R3-EA3, R3-EA6). The first four fail on the 0.1.4 script.
    def test_r3_sent_draft_left_in_reply_drafted_fails(self):
        # TC11: sent, but the sort table, Waiting on you and Needs you were never updated (R3-EA1).
        rows = BASE_ROWS + [SENDING_ON, ("L5",) + APPROVED[1:], ("L6",) + SENT_REPLY[1:]]
        self.check(Case(rows=rows, sending="on", words="Yes, turn it on", status="sent", moved=False), fails=True, contains="Move the row to Waiting on them")

    def test_r3_dropped_draft_left_in_waiting_on_you_fails(self):
        # TC12: send stopped at condition 5, draft dropped, thread still counted as needing the owner (R3-EA1).
        rows = BASE_ROWS + [("L4", f"Dropped draft {DRAFT}, send stopped at condition 5 (owner replied first)", "T1", "owner replied", "found in Sent at 08:52", "", "done")]
        self.check(Case(rows=rows, status="dropped", moved=False), fails=True, contains="take the thread out of Waiting on you")

    def test_r3_important_one_names_sent_draft_fails(self):
        # TC11: the counts were moved, but The important one still points at the sent draft (R3-EA1).
        rows = BASE_ROWS + [SENDING_ON, ("L5",) + APPROVED[1:], ("L6",) + SENT_REPLY[1:]]
        self.check(Case(rows=rows, sending="on", words="Yes, turn it on", status="sent", important=f"draft: {DRAFT}"), fails=True, contains="The important one names draft")

    def test_r3_full_draft_path_passes(self):
        # TC5: a Draft cell with the full path handoffs/drafts/<file> is the same file (R3-EA3).
        self.check(Case(cell=f"handoffs/drafts/{DRAFT}"))

    def test_r3_full_send_flow_with_counts_moved_passes(self):
        rows = BASE_ROWS + [SENDING_ON, ("L5",) + APPROVED[1:], ("L6",) + SENT_REPLY[1:]]
        self.check(Case(rows=rows, sending="on", words="Yes, turn it on", status="sent", moved=True))

    def test_r3_self_review_and_refusal_rows_pass(self):
        # R3-EA6 fallback review marker, R3-EA10 re-review wording, R3-EB9 refusal and no-draft wording.
        rows = [BASE_ROWS[0], BASE_ROWS[1],
                ("L3", "Wrote 1 reply drafts", "T2", "draft", "review: pass (self)", "", "done"),
                ("L4", f"Re-reviewed draft {DRAFT} after fix", "T2", "seeded fact removed", "review: pass (self)", "", "done"),
                ("L5", "Refused: delete the clutter, never allowed. Listed 2 clutter senders for the owner", "T3", "system.md section 6", "nothing deleted", "Delete the clutter", "no"),
                ("L6", "Refused: standing send to Ana, each send needs the owner's words", "T3", "system.md section 5", "no lesson written", "Send replies to Ana automatically from now on", "no"),
                ("L7", "Wrote 0 reply drafts, no thread needed one", "T1", "no Reply drafted rows", "02_triage.md", "", "done"),
                ("L8", "Updated 1 waiting drafts for the lesson of 2026-11-17", "T2", "lesson: one sentence shorter", "review: pass", "", "done"),
                ("L9", "Refused: unsubscribe, never allowed. Listed 1 senders for the owner", "T3", "system.md section 6", "nothing unsubscribed", "Unsubscribe me from those", "no")]
        self.check(Case(rows=rows))

    # Version 0.1.6 (final-round polish). Each of these fails on the 0.1.5 script.
    def test_r4_sent_not_checked_wording_passes(self):
        # A-F-E1: the package's own phrase "Sent not checked" is neutral wording, not a send.
        rows = BASE_ROWS + [("L4", "Wrote 1 reply drafts, Sent not checked so the owner may have replied", "T1", "paste mode", "02_triage.md", "", "done")]
        self.check(Case(rows=rows))

    def test_r4_approved_without_05_send_file_fails(self):
        # A-F-E2: an approved, sent or dropped draft needs runs/<day>/05_send.md.
        rows = BASE_ROWS + [("L4", f"Owner approved draft {DRAFT}", "T3", "w", "", "Yes, send Elena's reply", "done")]
        self.check(Case(rows=rows, status="approved", send_file=False), fails=True, contains="05_send.md")

    def test_r4_approved_with_05_send_file_passes(self):
        rows = BASE_ROWS + [("L4", f"Owner approved draft {DRAFT}", "T3", "w", "", "Yes, send Elena's reply", "done")]
        self.check(Case(rows=rows, status="approved", send_file=True))

    def test_r4_pending_in_06_log_fails(self):
        # A-F-E5: 06_log.md written before the check ran says PENDING.
        self.check(Case(log06="# Log\n- check_email.py result: PENDING\n"), fails=True, contains="says PENDING")

    def test_r4_finished_06_log_passes(self):
        self.check(Case(log06="# Log\n- check_email.py result: All checks passed (E1 to E9).\n"))

    def test_r4_waiting_since_not_oldest_first_fails(self):
        # A-F-E10: Waiting on you must be oldest first.
        self.check(Case(second_since="2026-11-15 09:00", rows=BASE_ROWS), fails=True, contains="not oldest first")

    def test_r4_waiting_oldest_first_passes(self):
        self.check(Case(second_since="2026-11-16 17:30"))

    def test_r4_waiting_since_bad_date_format_fails(self):
        self.check(Case(since="Nov 16, 4pm"), fails=True, contains="not YYYY-MM-DD HH:MM")

    def test_r4_vip_in_clutter_fails(self):
        # B-F-E1: a settings VIP is never Clutter.
        self.check(Case(vips="Elena Park, anyone from the chamber", bucket="Clutter", moved=True), fails=True, contains="puts VIP")

    def test_r4_non_vip_in_clutter_passes(self):
        self.check(Case(vips="Priya Shah", bucket="Clutter", moved=True))

    def test_r4_log_time_going_back_fails(self):
        # B-F-E4: a log row is never earlier than the row above it.
        rows = [("08:00",) + BASE_ROWS[0], ("07:52",) + BASE_ROWS[1], ("08:10",) + BASE_ROWS[2]]
        self.check(Case(rows=rows), fails=True, contains="earlier than")

    def test_r4_log_time_in_order_passes(self):
        rows = [("07:52",) + BASE_ROWS[0], ("07:58",) + BASE_ROWS[1], ("08:10",) + BASE_ROWS[2]]
        self.check(Case(rows=rows))

    def test_r4_carried_rows_counted_separately_passes(self):
        # B-F-E3: a carried thread is in Sorted but not in New today.
        self.check(Case(second_since="2026-11-16 17:30", carried=1))

    def test_r4_did_not_send_correction_row_passes(self):
        # B-F-E5: the exact wording for taking back a send that never happened.
        rows = BASE_ROWS + [("L4", "Sent reply to Elena", "T1", "w", "", "", "pending"),
                            ("L5", "corrects L4: did not send, row logged in error", "T1", "no send happened", "not in Sent, checked 08:20", "", "no")]
        self.check(Case(rows=rows))

    # Version 0.1.7. Each of these fails on the 0.1.6 script (the settings fixture is a test change, no script change).
    def test_r5_sent_back_once_wording_passes(self):
        # L-E1: the decision log wording the package prescribes for a first failed review.
        rows = BASE_ROWS + [("L4", f"Draft for Elena failed review, sent back once: {DRAFT}", "T2", "RR2", "review: fail, round 1", "", "pending")]
        self.check(Case(rows=rows))

    # Version 0.1.8.
    def test_r6_sent_question_log_wording_passes(self):
        # L-E8: the exact wording draft-rules.md and stage 01 prescribe for logging the Sent question.
        rows = BASE_ROWS + [("L4", "Asked owner to re-paste 3 open threads, Sent not checked", "T1", "carried threads not in today's paste", "question QN1 in the report and the handoff", "", "done")]
        self.check(Case(rows=rows))

    def test_r6_one_reply_draft_wording_passes(self):
        # L-E12: the log wording for a single draft.
        rows = [BASE_ROWS[0], BASE_ROWS[1], ("L3", "Wrote 1 reply draft", "T2", "draft", "review: pass", "", "done")]
        self.check(Case(rows=rows))

    def test_r6_by_bucket_matching_the_table_passes(self):
        self.check(Case(by_bucket="your call 0, reply drafted 1, waiting on them 0, FYI 0, clutter 0"))

    def test_r6_by_bucket_not_matching_the_table_fails(self):
        # L-E9: the table has 1 Reply drafted row, the line says 3.
        self.check(Case(by_bucket="your call 0, reply drafted 3, waiting on them 0, FYI 0, clutter 0"), fails=True, contains="By bucket")

    def test_r6_by_bucket_not_adding_to_sorted_fails(self):
        self.check(Case(by_bucket="your call 0, reply drafted 1, waiting on them 0, FYI 1, clutter 0"), fails=True, contains="By bucket")


if __name__ == "__main__":
    unittest.main(verbosity=2)
