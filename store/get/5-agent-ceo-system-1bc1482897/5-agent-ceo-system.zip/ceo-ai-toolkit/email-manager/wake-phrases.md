# What to say to your Email Manager

| Say | It does |
|---|---|
| "Start my Email Manager" | First-time setup (5 questions or fewer) |
| "Check my email" or "Triage my inbox" | Reads new mail, sorts it, drafts replies, writes the report |
| "Who is waiting on me?" | The list, oldest first |
| "Draft a reply to [person]" | One reviewed draft for that thread |
| "Yes to [person]" or "Tell [person] no" | Records your decision and writes a draft that says exactly that |
| "Send it" or "Send the [person] one" | Approves that draft. Sends it only if sending is on |
| "I sent it" | Marks a draft as sent by you |
| "Turn on sending" / "Turn off sending" | Changes the sending switch. Turning it on is explained and asked once |
| "Turn on labels" / "Turn off labels" | One label per bucket on your threads, labels only |
| "Never draft for [person]" | They go to Your call from now on |
| "[Person] is a VIP" | Always gets your attention first |
| "From now on, ..." | Saves a new rule in your lessons file |
| "Relearn my voice" | Rebuilds your voice profile from your latest writing |
| "Redo email setup" | Asks the setup questions again |
| "Stop" | Stops and lists what was in progress |
| "Uninstall the Email Manager" | Safe removal, see `UNINSTALL.md` |
