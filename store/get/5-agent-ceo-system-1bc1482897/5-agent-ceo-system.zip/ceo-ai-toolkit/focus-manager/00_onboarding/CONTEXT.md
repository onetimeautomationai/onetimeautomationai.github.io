# 00_onboarding: learn the owner once (standalone only)

Runs the first time in standalone mode, or when the owner says "redo setup". Goal: fill `focus-manager/_shared/owner-profile.md` so no stage asks these again. Paths start from the toolkit folder. Under the Chief of Staff this stage never runs, because its profile is used.

## Inputs
- `focus-manager/setup/questionnaire.md` (the five questions, in order)
- `focus-manager/_shared/owner-profile.md` (the file you fill)

## Process
1. Say one line: "I'm your Focus Manager. I'll ask you 5 short questions, one at a time, so I can pick your Top 3 against your number one goal. About 3 minutes. Say 'skip' to use the default."
2. If some answers are already filled (the owner stopped halfway last time), start at the first question whose placeholder is still there. Never re-ask a filled one. Instead of the line in step 1, say: "Welcome back. You answered N of 5 questions last time, so I'll pick up at question N+1." Then ask that question.
3. Ask the questions one per turn. Offer the default in brackets.
4. Write each answer into the profile right away, replacing its `{{placeholder}}`. If the owner stops halfway, the answers so far are saved.
5. "Skip" means use the default. For a required question (no default), ask once more in simpler words. If they skip again, write "not given" and move on. Remind them once, in the first plan, that the plan works better with that answer.
6. Fill the time zone yourself from the computer's clock and say which one you used. Write it as a zone name in the form Area/City, for example America/Los_Angeles, America/Chicago or Europe/London, never "Pacific Time" or "PST". `check_focus.py` reads that name to know the owner's date. On a Mac or Linux computer, `readlink /etc/localtime` ends with it. If you cannot find it, ask the owner their city and pick the zone name for it.
7. When no `{{` is left, set `setup_done: yes` in the profile front matter.
8. Make sure `handoffs/` exists. Create it if not.
9. Add a decision log row: "Onboarding done", T1, Result done.
10. Tell the owner in one line what you filed. Then, if it is inside the owner's work hours and not protected time, ask "What is on your mind today?" and start stage 01 (`focus-manager/stages/01_brain-dump/CONTEXT.md`). Otherwise say the first plan comes next work morning, and say "Plan my day" any time.

## Output
- `focus-manager/_shared/owner-profile.md` with no `{{` left and `setup_done: yes`.
- One decision log row.

## Human check
The owner reads the one-line summary and can correct any answer. A correction updates the profile and adds a `lessons.md` line.

## Redo setup
Copy the current profile to `focus-manager/archive/owner-profile-YYYY-MM-DD.md`. Reset every answer line to its `{{placeholder}}` and `setup_done: no`, then run this stage from step 1, offering the old answers as defaults.
