# Pipeline

Paths start from the toolkit folder. The Focus Manager runs one loop each day, plus two events during the day.

## Loop A: plan the day (morning, or when the owner says "Plan my day")

Start it with `python3 focus-manager/scripts/new_run.py`, or copy `focus-manager/_templates/run/` to `focus-manager/runs/YYYY-MM-DD/` by hand.

| # | Stage | Output in the day folder | Human check |
|---|---|---|---|
| 01 | brain dump | `01_brain-dump.md` + rows in `capture/capture.md` | none, logged the same turn |
| 02 | rank | `02_rank.md` | Owner can overrule any rank |
| 03 | Top 3 | `03_top3.md` (draft, review result) | Reviewer passes it, owner may swap |
| 04 | blocks | `04_blocks.md` | Every block result serves a Top 3 item |
| 05 | write | `handoffs/top3-today.md` + `manager-report.md` | `check_focus.py` passes |

Under the Chief of Staff the whole loop runs without questions to the owner. Standalone, the owner is asked only what the stage says.

## Event B: drift during the day

| # | Stage | When | Output |
|---|---|---|---|
| 06 | park | "Park that", or a stray idea during a block | One row in `capture/capture.md`, one line back to the owner |

## Event C: closing

| # | Stage | When | Output |
|---|---|---|---|
| 07 | close | "Block done", "Day done", "Switch block", or the Chief of Staff's close job | `05_close.md` in the day folder, carried rows in `capture/capture.md` |

**Stable every day:** everything in `focus-manager/_shared/`.
**New every day:** `focus-manager/runs/`, rows in `capture/capture.md` and in the decision log, `handoffs/top3-today.md`.

Every stage reads `focus-manager/_shared/standing-rules.md` and the lessons files first.
