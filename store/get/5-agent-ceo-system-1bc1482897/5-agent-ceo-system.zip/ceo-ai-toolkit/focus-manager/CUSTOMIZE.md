# Change how your Focus Manager works

The easy way: tell it. "From now on, make every result a number." Alone, it adds a line to `_shared/lessons.md` and follows it from then on. With a Chief of Staff, it passes the line to the Chief of Staff, which saves it for every hire.

## Safe to change

| What | File |
|---|---|
| Your goal, hours, daily actions, block rule | With a Chief of Staff, tell it or say "redo setup". Alone, `_shared/owner-profile.md` (or say "redo setup") |
| How results are worded, how short the plan is | Tell it. It saves a lesson |
| The most blocks in a day, the shortest block | Tell it ("blocks of 90 minutes or more, three at most"). It saves a lesson |
| Setup questions | `setup/questionnaire.md` |

If you set up a Chief of Staff later, its profile is used and the standalone profile is ignored.

## Change with care (your Focus Manager asks for your yes and keeps a snapshot first)

| What | Why |
|---|---|
| `_shared/decision-tiers.md` | You can add things to red any time. Moving anything down needs your direct yes. Sending, posting, publishing, paying, buying, deleting and booking with other people always stay red |
| `_shared/standing-rules.md`, `system.md` | These keep your day clean and your accounts safe. Add to them. Think twice before removing a line |
| `_shared/handoffs.md` | The Chief of Staff and the CEO Scoreboard read the Top 3 file in this exact format. Change it and they must change too |
| `scripts/check_focus.py` | The checks catch a stale file, a vague result, a block in protected time, and a skipped review or approval. Keep F2, F3 and F6 |
| `_shared/review-rubric.md` | What the reviewer checks. Add lines freely. Removing one lets more mistakes reach you |

The Top 3 stays three on purpose. Five priorities is a list, not a focus.

## Do not edit by hand

`_shared/decision-log.md` is append only. To fix a row, ask your Focus Manager to add a "corrects FL#" row.
