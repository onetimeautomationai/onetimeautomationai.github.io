# Install

Pick one path. Basic needs no terminal. Expert adds a daily rhythm.

## Basic (no terminal)

1. Download and unzip the toolkit. Put the `focus-manager` folder inside your `ceo-ai-toolkit` folder, next to `chief-of-staff`. Using it alone? Put it in any folder you made for it. That folder is your toolkit folder.
2. Load the folder that holds `focus-manager` into your favorite AI agent platform (open the agent in that folder).
3. Say: **"Start my Focus Manager."**
4. Your Chief of Staff already set up? You are done. It uses your answers and asks nothing. Using it alone? Answer 5 questions, one at a time. Say "skip" to use the default. It saves each answer as you go.
5. Say **"Plan my day"** for your first Top 3. With a Chief of Staff, say "Morning" and the Focus Manager's Top 3 is in your brief.

If your agent only has a box for a system prompt or custom instructions and cannot open folders, paste `focus-manager/INJECT-PROMPT.md` into that box instead. You get the Focus Manager without the files, so it cannot keep your parked ideas between chats.

## Expert (adds a daily rhythm)

Do Basic first, then:

1. **Install the Time Manager** so your blocks use your real calendar.
2. **Plan on a schedule**, if your agent supports scheduled tasks. Make one task that opens the folder holding `focus-manager` and says "Plan my day" at your morning brief time. Your agent follows the safe change rules below before it creates it.
3. **Turn on the scripts**, if your agent can run commands. From the toolkit folder, run `python3 focus-manager/scripts/check_focus.py`. Before you have a Top 3 for today, it fails its first checks. That is expected.

## Safe change rules

The AI follows these for any change outside the toolkit folder (scheduled tasks, your agent's settings or rules file), and for any change to the Focus Manager's rules files (`system.md`, `decision-tiers.md`, `standing-rules.md`).

1. If it cannot read and write files here, it says so and gives you manual steps instead.
2. Before changing anything, it tells you the time and lists every file and outside item it will create or change. It waits for your yes.
3. It copies each existing file it will change into `.ceo-toolkit/snapshots/focus-manager-<YYYYMMDD-HHMMSS>/`, keeping its path, and adds a row to `.ceo-toolkit/install-log.md`: time, action, snapshot, files changed, files created, notes. It creates the log with a header row if it is missing.
4. It never overwrites your agent's own rules file. It adds a block between `<!-- ceo-toolkit:focus-manager:start -->` and `<!-- ceo-toolkit:focus-manager:end -->` instead.
5. It never deletes your data, and never deletes anything in `.ceo-toolkit/`.

`.ceo-toolkit/` lives in the toolkit folder. It is your record of every change.
