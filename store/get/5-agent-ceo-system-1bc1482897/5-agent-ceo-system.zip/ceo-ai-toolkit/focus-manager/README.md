# Focus Manager

Your AI Focus Manager picks your Top 3 each morning, gives each one a result that counts as done, and gives every work block one clear result.

You are busy all day, and some days nothing that matters gets finished. The Focus Manager fixes that by ranking everything on your plate against your number one goal, then naming the three things that move it today. It keeps stray ideas out of your way so each block stays clean.

## What it does for you

| When | What you get |
|---|---|
| Morning | Your Top 3, each with a result you can check, and one result for each work block of your day |
| During the day | Say "park that" and a stray idea is saved in one line. You go straight back to your block |
| End of a block or the day | Say "block done" or "day done". It checks the result for real. What is not finished is carried to tomorrow with a reason |

## What a Top 3 looks like

> 1. Proposals for the two warm leads : both proposals written and saved in your proposals folder
> 2. Priya Shah payroll add-on reply : reply written and saved by you
> 3. Year-end checklist offer : offer post written and saved by you

A result is something you can see or check. "Work on proposals" is not a result, so it gets rewritten.

## Who it works with

| Hire | What the Focus Manager does with it |
|---|---|
| Chief of Staff | Uses your profile and board, reports to it, and the Chief of Staff shows your Top 3 in your morning brief |
| Time Manager | Reads its calendar report to find your open time for work blocks |
| CEO Scoreboard | Reads your Top 3 file at night to score your day |

Every other hire is optional. Alone, the Focus Manager asks you 5 questions once and works from your answers.

## Install in 3 steps

1. Put the `focus-manager` folder inside your `ceo-ai-toolkit` folder (or in any folder you like if you use it alone).
2. Load that folder into your favorite AI agent platform (open the agent in the folder that holds `focus-manager`).
3. Say: **"Start my Focus Manager."** If you already set up your Chief of Staff, it asks you nothing. Alone, it asks 5 questions once.

Full steps: `INSTALL.md`. What you need first: `REQUIREMENTS.md`.

## What to say

See `wake-phrases.md`. The ones you will use most:
- "Plan my day" for your Top 3 and block results.
- "Park that" when your mind drifts.
- "Block done" and "Day done" to close with a real check.

## How it earns your trust

Every piece of work gets a light. Green: small and reversible, it does it. Yellow: a new Top 3 is checked by an AI reviewer before it reaches you. Red: anything with money, other people, or no undo waits for your yes.

## What it will never do

It never sends, posts, publishes, pays, buys, deletes, or books time with another person. It does not write messages in your name. Your plans stay in this folder on your computer.

## More

- How it works inside: `docs/how-it-works.md`
- A sample day: `examples/sample-day.md`
- What you can change: `CUSTOMIZE.md`
- What it cannot do yet: `known-limitations.md`
- Help: `SUPPORT.md`
- Remove it: `UNINSTALL.md`

Version 0.1.17, 2026-11-21. Changes: `CHANGELOG.md`.
