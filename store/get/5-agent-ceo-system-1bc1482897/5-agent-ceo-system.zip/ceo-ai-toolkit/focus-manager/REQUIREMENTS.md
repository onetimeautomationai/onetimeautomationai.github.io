# What you need

## Required
- **An AI agent that can read and write files in a folder on your computer.** A chat window that cannot open files is not enough. The setup guide in the toolkit lists the agents we have tested.
- **This folder on your computer.** Your Top 3, your block results and your parked ideas live here and nowhere else.

## Better with the full team
- **Chief of Staff.** It already knows your goals and hours, so the Focus Manager asks you nothing.
- **Time Manager.** It gives the Focus Manager your real open time. Without it, the Focus Manager asks you once each day for your fixed times, or uses the block rule from setup.

## Optional
- **Python 3**, if your agent can run commands. Two small scripts use it. Without it, your agent does the same steps by hand.
- **A second AI agent for reviews.** A new Top 3 is checked before it reaches you. A separate agent does it best. Without one, your agent does a separate review pass itself.

## You do not need
- To write code.
- A subscription. You pay once and keep every file.
- Email or a calendar connected to your agent. The Focus Manager never touches them.

## Tested with

| Agent | Model | Date | Result |
|---|---|---|---|
| Claude (fresh agent in a scratch copy, helper reviewers on a second model) | Sonnet 5.5 runner, Opus reviewers | 2026-11-20 | v0.1.6: TC1 to TC19 all pass in one run. Planning cases used a replayed 8 AM clock. Not yet 3 runs per case, not yet a timed new-user walk |

Model updates can change how an agent behaves. Before you switch to a new model, run the test cases in `tests/test-cases.md` and compare.

## Before you buy, check
1. Can your AI agent open a folder and edit a file in it?
2. Are you OK with an AI choosing your Top 3 for you to change, and with it saying no to ideas that do not move your number one goal this month?
3. Do you have a number one goal with a number and a date? The Focus Manager ranks everything against it.
