# Remove the Focus Manager

## The simple way
Delete the `focus-manager` folder. Nothing else on your computer depends on it. If you have a Chief of Staff, tell it "The Focus Manager is gone." It then updates its list of installed hires and asks you for your Top 3 itself each morning. `handoffs/top3-today.md` stays where it is, and the Chief of Staff overwrites it from then on. If you did the Expert install or let it change anything outside the folder, use the next section instead.

Keep a copy of `capture/`, `runs/` and `_shared/decision-log.md` first if you want your history. `capture/capture.md` holds your open ideas and parked items.

## If your AI made changes outside the folder
Say: **"Uninstall the Focus Manager."** Your AI then:

1. Copies your data (`capture/`, `runs/`, `_shared/`) and anything it will remove into `.ceo-toolkit/removed/focus-manager-<YYYYMMDD-HHMMSS>/`.
2. Restores each file it changed from its snapshot in `.ceo-toolkit/snapshots/`.
3. In shared files, removes only the block between `<!-- ceo-toolkit:focus-manager:start -->` and `<!-- ceo-toolkit:focus-manager:end -->`. Other hires' blocks stay.
4. Lists anything outside the folder it created (scheduled tasks) and asks you before removing each one.
5. Adds a row to `.ceo-toolkit/install-log.md` and tells you what was restored, removed and kept.

Say **"Show what uninstalling would change"** to see the list without changing anything.

## What stays on your computer
Everything in `.ceo-toolkit/` stays. It is your record. Status marks the Focus Manager set on its own rows in `handoffs/jobs.md` stay as history. Your toolkit files are never sent to us, so there is nothing to delete anywhere else.
