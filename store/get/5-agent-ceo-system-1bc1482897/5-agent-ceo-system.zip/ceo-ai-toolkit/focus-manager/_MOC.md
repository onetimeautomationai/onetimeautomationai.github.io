# Focus Manager: map

Paths start from the toolkit folder.

| Path in `focus-manager/` | One line |
|---|---|
| `CLAUDE.md` | Start file for the AI: mode check, routes, rules that never bend |
| `CONTEXT.md` | The daily loop plus the park and close events |
| `system.md` | The AI's full operating rules |
| `worker.md` | The worker contract for this hire |
| `README.md` | The owner's one-page guide |
| `REQUIREMENTS.md` | What you need, tested-with record |
| `INSTALL.md` | Basic and Expert install, safe change rules |
| `UNINSTALL.md` | Safe removal and rollback |
| `CUSTOMIZE.md` | What you can change and where |
| `permissions.md` | What it can read and write |
| `known-limitations.md` | What it cannot do yet |
| `SUPPORT.md` | Help and the update promise |
| `LICENSE.md` | Use and resale terms |
| `CHANGELOG.md`, `manifest.json` | Version, file list, checksums |
| `wake-phrases.md` | What to say |
| `INJECT-PROMPT.md` | One-paste version for agents without folders |
| `00_onboarding/`, `setup/` | Standalone setup, 5 questions |
| `_shared/` | Stable files every stage reads |
| `stages/` | 01 brain dump, 02 rank, 03 Top 3, 04 blocks, 05 write, 06 park, 07 close |
| `capture/` | Live state: every open idea, note and parked item |
| `_templates/` | Day starter and output templates |
| `runs/` | One folder per planned day |
| `scripts/` | `new_run.py`, `check_focus.py` |
| `docs/` | How it works |
| `examples/` | A sample day with made-up data |
| `tests/` | Test cases, acceptance criteria, judge rubric, fixtures |
