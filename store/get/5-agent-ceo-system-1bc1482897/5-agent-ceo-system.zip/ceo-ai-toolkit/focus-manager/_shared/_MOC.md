# _shared: map

| File | One line |
|---|---|
| `owner-profile.md` | Standalone profile: name, goal 1, daily actions, hours, block rule. Filled by setup. Ignored when the Chief of Staff profile is filled in |
| `standing-rules.md` | FR1 to FR21, read by every stage |
| `decision-tiers.md` | The trust lights (green, yellow, red), the safety floor, how green is earned |
| `review-rubric.md` | How a new Top 3 is checked before it lands, and who reviews |
| `handoffs.md` | Exact format of the Top 3 file, and the files this hire reads |
| `adapters.md` | Which tool does which job |
| `lessons.md` | Owner corrections (standalone), read every run |
| `decision-log.md` | Append-only record of every decision |
