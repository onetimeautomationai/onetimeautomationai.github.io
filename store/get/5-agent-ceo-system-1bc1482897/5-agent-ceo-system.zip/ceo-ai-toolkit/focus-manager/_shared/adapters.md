---
type: factory
---

# Adapters

The Focus Manager names the job, not the vendor. It needs very little.

| Job | The owner's tool | Who uses it | Options that work |
|---|---|---|---|
| Know today's fixed times | `handoffs/time-manager-report.md` | Focus Manager reads it | The Time Manager's report. With no Time Manager, the Chief of Staff writes the same file from the owner's answers. Standalone, the owner tells you once each day |
| Keep the list of ideas, notes and parked items | `focus-manager/capture/capture.md` | Focus Manager | The file in this toolkit (default), or a notes app your agent can reach if the owner asks for it |
| Run the checks | Python 3, if your agent can run it | Focus Manager | Optional. Every script check can also be done by hand (`focus-manager/scripts/README.md`) |
| Review yellow work | A second agent with a fresh start | Focus Manager starts it | A helper agent on a different model is best. A separate pass by the same agent is the fallback |

The Focus Manager never touches email, a calendar, or any account. It reads and writes files inside the toolkit folder only.
