---
type: log
rule: append only. Never edit or delete a row.
---

# Decision log

Every decision the Focus Manager makes or records goes here before it is reported. A plain capture or park is not a decision: its row in `capture/capture.md` is the record. Rows are numbered FL1, FL2, FL3. (FC numbers are capture rows. FL numbers are log rows. They are different.) The Chief of Staff keeps its own log with its own L numbers.

- **Decision:** say what you did and refer to items by their FC number. Do not copy the item's words into this column, so a note like "send the quote" does not look like an action you took. Start with `Owner task:` when the owner will do it themselves.
- **Tier:** T1, T2 or T3 (`decision-tiers.md`). Anything that sends, posts, publishes, pays, buys, deletes or books with another person is T3.
- **Owner's words:** required for a T3 row whose Result is `done`, copied exactly. Leave it empty while you wait, and set Result to `pending`. Also use it for the owner's exact words on a T1 row, such as the Top 3 they named or a swap they asked for. The words go here, never in the Decision column.
- **One tier rule for one kind of item.** Something the owner will do themselves (post, pay, send, call) gets one row starting `Owner task:`, tier T1, Result `done`, whatever the verb is. A row is T3 only when someone other than the owner would do it, or when you are waiting for the owner's yes to let that happen (Result `pending`, owner's words empty until they answer). Never log the same kind of item at T1 one day and T3 the next.
- **Result:** one of `done`, `pending`, `parked`, `no`.
- **Evidence:** for a T2 (yellow) row marked done, write `review: pass` here (`review-rubric.md`).
- **To fix a row:** add a new row whose Decision starts with `corrects FL#` (for example "corrects FL4: owner said yes"). The check script then reads the new row instead of the old one.

`focus-manager/scripts/check_focus.py` enforces all of this.

| FL# | Time | Decision | Tier | Why | Evidence | Owner's words | Result |
|---|---|---|---|---|---|---|---|
