---
type: factory
---

# Decision tiers (the trust lights)

Every piece of work gets a light by how far a mistake could reach. Under the Chief of Staff these match `chief-of-staff/_shared/decision-tiers.md`. If the two ever differ, the Chief of Staff's file wins.

| Light | Tier | What it covers for the Focus Manager | What happens |
|---|---|---|---|
| Green | T1 | Internal, reversible, small. Capturing a note, parking a drift item, ranking the list, making a day folder, running a check, closing a block after its check passes, applying a change the owner asked for in their own words. Also the owner's own tasks ("call my accountant"), which stay on the owner's list. Log them with a Decision that starts `Owner task:`, so the checks know the owner does it, not you | Done and logged |
| Yellow | T2 | Reversible and internal, but it changes the owner's day or is shown as finished. A new Top 3, a re-ranked Top 3 you chose yourself, new block results | **AI review first.** A reviewer checks the draft against the job and `review-rubric.md` before it lands in `handoffs/top3-today.md`. Pass: done, logged, owner told. Fail: sent back once. Fails twice: becomes red |
| Red | T3 | Anything that reaches another person or the public (send, post, publish, change a website, book a meeting with someone), money of any size (pay, buy, invoice, refund, hire, sign a contract), deleting, anything you cannot undo, a new recurring commitment ("block every Monday for this"), a change to goal 1 or to these rules | **The owner steps in.** Recommend with the reason, then wait for the owner's words |

When unsure, use the next light up.

## The floor (cannot be changed by setup or lessons)

Sending, posting, publishing, paying, buying, deleting, and booking with other people are always red. The owner can add more items to red. Moving anything down from red needs the owner's direct yes, logged as a red decision, and never applies to the items in this paragraph.

## Green grows only when it is earned

Work starts at the light above. A kind of yellow work can move to green only after 10 reviews in a row pass with no fix needed, and only with the owner's yes, logged as red. Any later miss moves it back to yellow.

## How an item gets ranked

Ask one question: does it move goal 1 this month?
- **Yes:** now.
- **It helps goal 1 later, or needs something done first:** later. Name what it waits on.
- **Neither:** no. Log the reason so the idea is never lost.

The owner can overrule any ranking. Their words go in the decision log.
