---
type: factory
---

# Handoffs for the Focus Manager

The hires pass work through plain files in `handoffs/` (in the toolkit folder). Each hire overwrites only its own files. This file lists the ones the Focus Manager writes and reads. The master list is `chief-of-staff/_shared/handoffs.md`. If it is there and differs from this file, the Chief of Staff's file wins. Standalone, this file is the format.

Every report starts with this header:

```
---
from: <hire folder name>
updated: YYYY-MM-DD HH:MM (owner's time zone)
status: ok | partial | failed
---
```

Write the time zone as a short label after the time, for example `updated: 2026-11-21 08:05 PT`.

**Fresh** means `updated` is today. Two exceptions: `scoreboard-report.md` is written at night, so it is fresh if dated today or yesterday. `priorities.md` is the owner's own ranking, so you use it whenever it exists. A file that is not fresh is treated as missing, and the reader says so.

## Written by the Focus Manager

### top3-today.md (Chief of Staff and CEO Scoreboard read it)

`from` is `focus-manager`. Under the format, nothing else goes in the file. No extra sections, no notes. Put notes in `focus-manager/runs/YYYY-MM-DD/manager-report.md`.

```
## Top 3 for YYYY-MM-DD
1. <item> : result that counts as done
2. <item> : result
3. <item> : result

## One result per block
| Block | Result that counts as done |
```

Status rules, check in this order and stop at the first yes:
1. Could you not write a plan at all? Status `failed`, and write the reason in `manager-report.md`.
2. Is there no `time-manager-report.md` dated today (even if the owner says there are no fixed times)? Status `partial`.
3. Are there fewer than three items that matter today? Status `partial`.
4. Is no open block left today (after work hours, or every window already past)? Status `partial`.
5. Otherwise status `ok`.
A report this run did not need is not a missing source. No email report, no scoreboard report, no `priorities.md` and an empty capture file leave the status `ok`, and `manager-report.md` lists them as not found.

Block cells read like `Block 1, 8:00 AM to 10:00 AM`. Under the Chief of Staff with a Time Manager installed, they read `Block 1` with no time, because the Time Manager picks the times.

### handoffs/jobs.md (status of your own rows only)

```
| Job# | For | Job | Write result to | Due | Light | Status: open / done / waiting: reason |
```

The Chief of Staff writes the rows. You set the Status of the rows where For is `focus-manager`, and nothing else in the file.

## Read by the Focus Manager

### time-manager-report.md (Time Manager writes, or the Chief of Staff if no Time Manager)

```
## Today
| Start | End | Block | Fixed or movable |

## Open time today
- Total hours open, and when
```

You use it to find the open stretches for work blocks. You never change it.

### email-manager-report.md (Email Manager writes)

You read only the "The important one" section, and only when the file is dated today. It is a candidate for the Top 3, ranked like any other item. You never change the file and you never open drafts.

### scoreboard-report.md (CEO Scoreboard writes)

```
## Score for YYYY-MM-DD
- Top 3 done: N of 3
- Score: N out of 10, and one line why
- One fix for tomorrow

## Tomorrow's list
1. ...
```

You use "Tomorrow's list" as candidates in stage 01. You never change it.

### jobs.md (Chief of Staff writes)

Rows where For is `focus-manager` are your jobs. Other rows belong to other hires. A hire's routine run (sort email, block the Top 3, score the day) is never a Top 3 candidate. A job that carries real owner work (for example a reply to a client) may be a candidate, ranked like any other item.

### The board (Chief of Staff, read only)

`chief-of-staff/board/board.md`: the Job queue rows that are not done and the "Your list" rows that are not done. Candidates only.

### priorities.md (Chief of Staff writes, only when the owner has ranked their plate)

Used whenever it exists: it is the owner's own ranking. The owner ranked these items two at a time, or reviewed and approved the Chief of Staff's ranking of them. A new item placed between rankings may have been placed by the Chief of Staff and shown to the owner afterward. Treat every row the same way. You keep their order, never compare them again, and never place another candidate above them (`focus-manager/stages/02_rank/CONTEXT.md` step 3). "Size" and "Result this week" help you write today's result and the block length. Skip rows whose Status is `done` or starts with `waiting`. A "New since the ranking" row with Status `waiting: your picks` waits for the owner's pairs from the Chief of Staff, so the same item is not a candidate from any other source today either. Skip "Must do by date": the Time Manager blocks each must before its date. You never change the file.

```
## Ranked
| Rank | P# | Item | Who does it | Due | Size | Result this week | Status |

## Must do by date
| P# | Item | Who does it | Due | Status |

## New since the ranking
| P# | Item | Placed | Status |
```
