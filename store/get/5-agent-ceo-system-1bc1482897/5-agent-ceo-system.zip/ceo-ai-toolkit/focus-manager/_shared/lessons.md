---
type: factory
---

# Lessons

Every correction or "from now on" the owner gives becomes one line here, the same turn, in both modes. Every Focus Manager session reads this file, so the next plan follows it even when it runs in a fresh session.

- **Standalone:** this file is the only lessons file. Filed is `here`.
- **Under the Chief of Staff:** you never write `chief-of-staff/_shared/lessons.md`. Add the line here with Filed `waiting for the Chief of Staff`, and also list it under "Lessons to file" in your report, so the Chief of Staff copies it to its own file. Repeat it under "Lessons to file" in every later report until it is in `chief-of-staff/_shared/lessons.md`. Once that line is in `chief-of-staff/_shared/lessons.md`, both say the same thing, so nothing conflicts.
- **Goal 1 changed under the Chief of Staff:** add a line here too: "Goal 1 is now [the owner's new goal] until the Chief of Staff updates the profile." Lessons rank above the profile (`system.md` section 7), so every plan ranks against the new goal until the profile says the same.

Read this file and `chief-of-staff/_shared/lessons.md` (if it exists) before every run. Newest at the bottom.

| Date | The owner said (exact words) | What we do from now on | Filed: here / waiting for the Chief of Staff |
|---|---|---|---|
