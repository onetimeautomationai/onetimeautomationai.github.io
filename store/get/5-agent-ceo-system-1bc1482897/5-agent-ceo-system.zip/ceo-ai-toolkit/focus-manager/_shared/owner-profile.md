---
type: factory
setup_done: no
---

# Owner profile (standalone)

Used only when there is no Chief of Staff set up in this toolkit. If `chief-of-staff/_shared/owner-profile.md` is filled in, that profile is used instead and this one is ignored. Filled in by `focus-manager/00_onboarding/CONTEXT.md`. Change a line by telling your Focus Manager, or say "redo setup" to start over. A skipped answer uses its default. A skipped required answer (no default) is written as "not given".

## Who you are
- Name the team should use: {{owner_name}}
- Time zone (taken from your computer's clock, not asked, written like America/Los_Angeles): {{time_zone}}

## Your goals
- Goal 1, with a number and a date: {{goal_1}}
- Daily actions that move goal 1 most: {{leading_actions}}

## Your day
- Work hours: {{work_hours}}
- Protected time (no new questions): {{protected_hours}}
- How your work day splits into blocks: {{block_rule}}
