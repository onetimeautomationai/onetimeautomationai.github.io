---
type: factory
---

# Review rubric (yellow work)

Yellow work for this hire is a new or changed Top 3 with its block results. The reviewer sees: the job row (or the owner's request), the draft in `focus-manager/runs/YYYY-MM-DD/03_top3.md` and `04_blocks.md`, the source files the draft used (listed in `01_brain-dump.md` and `02_rank.md`, for example `handoffs/time-manager-report.md`, the board, `capture/capture.md`), the owner profile, the lessons files, and this rubric. It never sees the chat. The owner's answers reach it only through the table "Questions and the owner's answers" in `03_top3.md` and `04_blocks.md`, and the owner's words in the decision log. It scores each line pass or fail.

| # | Check | Fail when |
|---|---|---|
| RF1 | Does it do the job as written? | Not three items (and no reason for fewer), a block with no result or two results (two different end states, or two joined by "or". Steps that lead to one end state, such as "draft read and sent by you", are one result), or it did more than asked |
| RF2 | Are the facts true? | A time, a meeting, a person, a number or a job that is not in the source files or the owner's words. A place or file name (for example "your proposals folder") counts only if it appears in a source file or the owner's words. Example wording in a stage file is not a source. A fact found in a source passes. The owner's words include an answer in the "Questions and the owner's answers" table of `03_top3.md` or `04_blocks.md`. A default marked "no answer, default used" passes when the default is the one the stage offered (for example no fixed times). An "owner said" anywhere else, with no row in that table or the log, fails. A target count (for example "1 proposal written") passes when a source gives it, or when a lessons file or the profile asks for numbers and the count is the smallest true one with a QN line offering it |
| RF3 | Can every result be checked? | A result is vague ("work on", "make progress", "look at", "think about", "handle") or the owner could not tell by looking whether it happened. A block result that names a later event ("sent by you by Dec 5") instead of the end state of that block ("draft saved for your yes") cannot be checked today |
| RF4 | Is it ranked against goal 1, and do the blocks fit the day? | The Top 3 skips a now item that moves goal 1 for a lower one with no reason. A block sits inside protected hours or outside work hours. A block result serves no Top 3 item. A scoreboard suggestion is a candidate, not an override, so skipping it is fine when `02_rank.md` gives a one-line reason under "Left out of the Top 3". A Top 3 item has no block and the report does not say so |
| RF5 | Is the light right for what happens next? | The plan would send, post, pay, buy, delete or book without the owner's yes, or a result is phrased as if the Focus Manager does that. A result that names the owner as the one who writes or sends ("written and saved by you", "sent by you") is fine. A result that says someone else drafted it ("drafted for your review", "saved for your yes") fails RF2 unless a source file shows that draft |
| RF6 | Is it ready for the owner to see? | It follows the lessons and the report style, the file matches the format in `handoffs.md`, and, in a chat reply or report, the most important line is last (the Top 3 file keeps the order in `handoffs.md`) |

Status check: "no fixed times" from the owner with no calendar seen is status `partial` (`handoffs.md`). Fail a file that says `ok` there. Do not fail `ok` for a report the run did not need (no email report, no scoreboard report, no `priorities.md`, an empty capture file). Those are not missing sources (`handoffs.md`).

**Pass:** all six pass. Write `review: pass` in the decision log Evidence column, with the file that holds the reviewer's reply (`review: pass, runs/YYYY-MM-DD/review.md`).
**Fail:** list the failed lines and one fix each. The work goes back once. A second fail makes it red: the owner sees it with the reviewer's notes.
**Save the prompt and the reply.** Under "## Review N, HH:MM", first write "Helper: [name or model, or same agent]" and the prompt pasted as you sent it (copy the text, never a summary), so a reader can see the reviewer was a separate helper. Then the reviewer's reply is copied word for word into `focus-manager/runs/YYYY-MM-DD/review.md`, one section per review ("## Review 1, HH:MM", "## Review 2, HH:MM"), the same turn it comes back. Say at the top whether a separate helper or the same agent (fallback) did it. A `review: pass` with no saved reply is not proof.

## Who reviews

1. **Best:** a separate helper agent with a fresh start, on a different AI model if the owner's agent allows. Its first line: "Read focus-manager/worker.md and focus-manager/_shared/review-rubric.md before anything else. You are the reviewer."
2. **Fallback:** if the agent cannot start helpers, the same agent does a separate review pass with this rubric, reading only the files listed at the top. This is weaker, because it checks its own work. `known-limitations.md` says so.
