# _templates: map

| Path | One line |
|---|---|
| `run/01_brain-dump.md` to `run/05_close.md` | Copied into each new day folder by `new_run.py` |
| `outputs/top3-today.md` | The exact handoff format, with a header |
| `outputs/manager-report.md` | The manager report written at the end of stage 05 |
