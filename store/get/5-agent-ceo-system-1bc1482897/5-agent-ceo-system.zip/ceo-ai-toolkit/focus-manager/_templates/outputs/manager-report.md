# Focus Manager report, YYYY-MM-DD

- Job: <the job row, or what the owner asked>
- Result: Top 3 written to `handoffs/top3-today.md`, status <ok / partial / failed>. On a day the owner asked for no plan (a capture, a park, a lesson, a goal change, a close only), write exactly "Result: no plan today (<what was done>)" instead, so `check_focus.py` F2 knows no Top 3 was due
- Proof: file exists, <3> items, <N> block results, review: pass (<FL#>, `runs/YYYY-MM-DD/review.md`), `check_focus.py` output copied as printed: "<last line>" exit <0 or 1> (or "checked by hand"). Never write "check passed" without that output
- Sources used: <profile, board, jobs, capture, time manager report, scoreboard report>
- Missing: <none, or what is missing>
- Not today: <now items over three, by Cand#>
- Parked since the last plan: <N> (<FC numbers>)
- Top 3 status (filled at the close): <N of 3 done, which carried and why>
- Lessons to file (under the Chief of Staff only): <none, or the owner's exact words, also saved in `focus-manager/_shared/lessons.md` with "waiting for the Chief of Staff". Repeat every lesson still marked waiting, in every report, until it is in `chief-of-staff/_shared/lessons.md`>

## Needs the owner
- QN1: <question>. Default used: <default>.

<The most important line, usually the first block's result.>
