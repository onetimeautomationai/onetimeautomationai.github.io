---
from: focus-manager
updated: YYYY-MM-DD HH:MM (owner's time zone label, for example 2026-11-21 08:05 PT)
status: ok
---

## Top 3 for YYYY-MM-DD
1. <item> : <result that counts as done>
2. <item> : <result>
3. <item> : <result>

## One result per block
| Block | Result that counts as done |
|---|---|
| Block 1, H:MM AM to H:MM AM | <result> |
| Block 2, H:MM PM to H:MM PM | <result> |
