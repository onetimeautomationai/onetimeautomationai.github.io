---
day: {{date}}
started: {{started}}
---

# Brain dump

## Owner's words today (exact)


## Candidates (at most 10)
| Cand# | Item | Source: owner / board / jobs / capture / scoreboard / priorities (rank or must) | FC# (if on capture.md) | T3 if acted on? |
|---|---|---|---|---|

## Sources not found or not fresh
-

## Over the cap (left open on capture.md)
-
