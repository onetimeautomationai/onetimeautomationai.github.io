# Rank

Criterion (fixed for this run): Does it move goal 1 this month?

Goal 1:

| Cand# | Item | Rank: now / later / no | Reason, or what it waits on | Order among now |
|---|---|---|---|---|

## Left out of the Top 3
| Item | One-line reason |
|---|---|

## Close calls (two at a time)
| Pair | Winner | One line why |
|---|---|---|

## Owner's words (exact, if they overruled a rank)

