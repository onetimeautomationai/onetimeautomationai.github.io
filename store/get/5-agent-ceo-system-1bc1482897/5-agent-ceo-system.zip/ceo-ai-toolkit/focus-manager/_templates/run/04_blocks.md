# Blocks

Calendar source: <time-manager-report.md dated today / owner said / not seen, profile block rule used>

## Questions and the owner's answers (stage 04 step 1)
The reviewer reads this table as the owner's words (RF2). Copy the answer exactly. Never write an answer the owner did not give.
| QN# | Question asked | Default offered | Owner's answer (exact words), or "no answer, default used" |
|---|---|---|---|

## Open windows (60 minutes or more, inside work hours, outside protected hours)
| Window | Length | Kept as a block? |
|---|---|---|

## Blocks (one result each)
| Block | Result that counts as done | Serves Top 3 # |
|---|---|---|

## No block for
-
