# Close

## Blocks
| Block | Check run | Evidence, or what is missing | Done / open / switched |
|---|---|---|---|

## Top 3
| # | Result | Check run | Evidence, or what is missing | Done / carried |
|---|---|---|---|---|

## Carried to tomorrow (FC numbers)
-

## Owner's words (exact, if they corrected a result or switched a block)

