# Write

Draft of `handoffs/top3-today.md`, exactly as it would be written. Review it before it lands (stage 05 step 2).

Draft status: <ok | partial, with the reason>

```
<the full file text: header, Top 3 section, block table, nothing else>
```

## Sources given to the reviewer
-
