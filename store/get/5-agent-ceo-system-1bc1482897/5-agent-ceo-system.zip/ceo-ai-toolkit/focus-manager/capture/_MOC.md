# capture: map

| File | One line |
|---|---|
| `capture.md` | Every open idea, note and parked item, with a rank and a status. The Focus Manager's live state |
