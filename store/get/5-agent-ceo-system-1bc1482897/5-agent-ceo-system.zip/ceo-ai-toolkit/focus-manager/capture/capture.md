---
type: capture
---

# Capture

Live state. Every idea, note and parked item that is not done yet lands here. The Focus Manager reads it at the start of every plan and writes to it. Rows are never deleted. A finished or abandoned row gets a status.

- **FC#:** the row number, never reused.
- **Kind:** `idea`, `task`, `note` or `parked` (drift caught during a block).
- **Rank:** `now`, `later`, `no` or `not ranked`.
- **Waits on or reason:** what a `later` row waits on, why a `no` row is no, or which block a `parked` row interrupted.
- **Status:** `open`, `done`, `carried` (unfinished, comes back tomorrow), or `dropped` (the owner said no).

| FC# | Date | Owner's words (exact) | Kind: idea / task / note / parked | Rank: now / later / no / not ranked | Waits on or reason | Status: open / done / carried / dropped |
|---|---|---|---|---|---|---|
