# How your Focus Manager works

## The idea
Being busy is not the same as finishing what matters. Your Focus Manager decides what matters today, says what finished looks like, and protects each work block from drift.

## The flow

```
Your list  ──>  1 brain dump  ──>  2 rank  ──>  3 Top 3  ──>  4 blocks  ──>  5 write
(board, jobs,                                                                  │
 notes, you)                                                                   ▼
                                                                handoffs/top3-today.md
                                                                (Chief of Staff and
                                                                 CEO Scoreboard read it)

During the day:  "park that"  ──>  6 park  ──>  back to the block
End of a block or day:  "block done" / "day done"  ──>  7 close  ──>  done, or carried
```

## How it picks your Top 3
1. It lists everything: your message, your open ideas, the board's open jobs, your own tasks, and last night's "tomorrow" list.
2. It asks one question about each: does this move your number one goal this month? Now, later (and what it waits on), or no (and why). Nothing is deleted, so a "no" is never lost.
3. If more than three are "now", it compares two at a time. The item that wins more of its matches goes first.
4. The first three become your Top 3. Each gets a result that counts as done, something you can see or check.

## How it plans your blocks
It reads the Time Manager's report for your open time. A block is an open stretch of 60 minutes or more, inside your work hours and outside your protected hours. Each block gets one result that moves one Top 3 item. If an item has no block, it tells you so and does not invent time.

## How it keeps you on track
When your mind drifts, say "park that". The idea is saved on your list and you get one line back: "Parked: [idea]. Back to: [block result]." Parked ideas return in tomorrow's plan.

## How it closes
"Block done" and "Day done" run the check for real. A result is done only when it can be shown. What is not done is carried to tomorrow with a reason. Your Top 3 file is not rewritten at night, because the CEO Scoreboard reads it.

## Three trust lights
- **Green:** small and reversible. It does it and logs it.
- **Yellow:** it changes your day. A new Top 3 is checked by an AI reviewer first. If it fails review twice, it becomes red.
- **Red:** money, other people, deleting, anything you cannot undo. It never does these. It recommends, then waits for you.

Every decision is written to a log that is never edited, only added to. A small check script fails if a Top 3 file is old, has a vague result, puts a block in your protected hours, or if anything that sends, posts, pays, buys, deletes or books is logged as less than red.

## How it learns
When you correct it ("from now on, make every result a number"), the correction becomes one line in a lessons file, and it reads that file before every plan.

## Your files
Everything lives in the toolkit folder on your computer: your list, your plans, your decisions. Nothing is sent to us.
