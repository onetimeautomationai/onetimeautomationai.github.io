# A sample day (made-up owner, made-up data)

Owner: Dana Ruiz, runs a 6-person bookkeeping firm. Goal 1: "10 new monthly clients by March 31." Daily actions that move it: sales calls and proposals. Work hours 8 AM to 5 PM, protected 6 PM to 8 PM. Her Chief of Staff and Time Manager are installed.

## 7:58 AM, Dana says "Morning"

The Chief of Staff runs the Focus Manager. It reads the board (three tasks on Dana's list, two open jobs), yesterday's score and "Tomorrow's list", and the Time Manager's report from 7:55 (fixed: 10:00 team meeting, 12:00 lunch, 2:00 client review).

It ranks every item against goal 1:

| Item | Rank | Why |
|---|---|---|
| Write proposals for Tom Becker and Ana Lima | now | A daily action. Two of the ten new clients. Yesterday's list asked for the same thing, so the two are merged |
| Reply to Priya Shah about the payroll add-on | now | A sales conversation that is open today |
| Year-end checklist offer post | now | An offer made this week |
| Call the chamber about the January mixer | later | Helps referrals, but it needs the year-end offer to run first. Waits on the offer |
| Renew the software subscription | no | Does not move goal 1, and the renewal date is next month. It stays on Dana's list |

Three "now" items, so there is nothing to compare two at a time. The Focus Manager writes the Top 3 file, a reviewer passes it, and `check_focus.py` passes. The brief shows:

> **Top 3 today**
> 1. Proposals for the two warm leads : both proposals written and saved in your proposals folder
> 2. Priya Shah payroll add-on reply : reply written and saved by you
> 3. Year-end checklist offer : offer post written and saved by you
>
> **One result per block**
> | Block | Result that counts as done |
> |---|---|
> | Block 1, 8:00 AM to 10:00 AM | First proposal written and saved |
> | Block 2, 10:30 AM to 12:00 PM | Second proposal written and saved |
> | Block 3, 1:00 PM to 2:00 PM | Priya reply read and approved by you |
> | Block 4, 3:00 PM to 5:00 PM | Offer post read and approved by you |
>
> Start with the first proposal.

## 9:20 AM, in block 1, Dana says "Idea: a webinar for restaurant owners in January"

> Parked: webinar for restaurant owners in January. Back to: first proposal written and saved.

One row is added to the list as `parked`, "interrupted Block 1". Nothing else happens. It comes back in tomorrow's plan.

## 10:04 AM, "Block done"

The Focus Manager looks for the first proposal in the proposals folder and finds it. Block 1 is done. Evidence: the file is there.

## 12:02 PM, "Block done"

> I cannot find a second proposal in your proposals folder. Block 2 stays open. What is missing: the second proposal file.

Dana: "It's saved on my desktop as Lima-proposal." The Focus Manager finds the file there. Block 2 is done. Evidence: the file, found where Dana said.

## 5:10 PM, "Day done"

| # | Result | Done? |
|---|---|---|
| 1 | Both proposals written and saved | Done, both files found |
| 2 | Reply drafted and waiting for your yes | Done, the draft is in `handoffs/drafts/` |
| 3 | Offer post written and waiting for your yes | Carried. No draft exists. Block 4 ended with the post half written |

> 2 of 3 done. The offer post is carried to tomorrow with the reason "half written at 5 PM". The webinar idea is still parked.
>
> Tomorrow, first thing: finish the year-end offer post.

The Top 3 file is not touched, so the CEO Scoreboard scores it at night as written. Tomorrow's plan starts with the carried post and the parked webinar idea.
