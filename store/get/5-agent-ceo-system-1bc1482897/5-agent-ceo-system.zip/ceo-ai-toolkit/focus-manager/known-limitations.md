# Known limitations

- **It plans from files and what you tell it.** If the Time Manager did not run, your Top 3 file says the calendar was not seen and uses your block rule from setup. It does not guess your meetings.
- **It does not put anything on your calendar.** It names your work blocks. The Time Manager blocks the time, or you add it yourself.
- **It cannot see what you did.** At "block done" and "day done" it checks what it can look at (a file exists, a count matches). For anything else it asks you once and writes your answer down as the evidence.
- **The CEO Scoreboard does not see done marks yet.** The Top 3 file has no done column, by design, so the format stays the same for every hire. Your done marks live in `runs/YYYY-MM-DD/05_close.md` and `manager-report.md`. The night wrap asks you which Top 3 items you finished.
- **It does not run by itself unless your agent can schedule tasks.** Without that, you open your agent and say "Plan my day".
- **Your Top 3 is only as good as your goal.** Everything is ranked against goal 1. A vague goal or missing daily actions gives weaker rankings. Say "redo setup" to fix that.
- **The review is strongest with a second agent.** A new Top 3 is checked by a separate reviewer. If your agent cannot start helper agents, the same agent reviews its own work in a separate pass. That is weaker, because it is checking itself.
- **Hours checks read common time formats.** `check_focus.py` understands "6 PM to 8 PM" and "9 to 5". It skips a check it cannot read and says so.
- **One owner.** It is built for one CEO. A team can share the folder, but it treats every message as coming from the owner.
- **No phone or text alerts built in.** It talks to you inside your AI agent.
- **Long histories slow it down.** After a few months, move old `runs/` folders into `runs/archive/`.
- **Two wording rules rest on the reviewer alone.** `check_focus.py` cannot see a later event or deadline in a block result ("sent by you by Fri Nov 27") or an "approved or changed" pair that is really two end states. Both pass the script. The reviewer checks them (rubric RF3), so a review that is skipped or done by the same agent is weaker here.
- **Block times written as "Block 1" are checked only when the Time Manager report names them.** Under the Chief of Staff with a Time Manager, the Top 3 file keeps "Block N" with no time. `check_focus.py` F5 reads the times from a row of today's `time-manager-report.md` whose Block cell says "Block N". The Time Manager normally names its blocks "Top 3 #N: item", one per Top 3 item, which do not map to block numbers. F5 therefore checks those rows from a report dated today directly against the owner's work and protected hours, and still prints a note for each "Block N" it cannot place. A report not dated today is skipped with a note. Notes are not failures. Hours are also checked by the Time Manager's own K5.
