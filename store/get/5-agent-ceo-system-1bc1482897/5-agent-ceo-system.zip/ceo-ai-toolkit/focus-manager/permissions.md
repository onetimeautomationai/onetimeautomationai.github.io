# What the Focus Manager can touch

Paths start from the toolkit folder.

| Area | Read | Write | Notes |
|---|---|---|---|
| `focus-manager/` | Yes | Yes | Its own working files. Rules files change only with your yes (`INSTALL.md`, safe change rules) |
| `handoffs/top3-today.md` | Yes | Yes | Its own file. The Top 3 and the block results |
| `handoffs/jobs.md` | Yes | Only the Status of its own rows | The Chief of Staff writes the rows |
| `handoffs/time-manager-report.md`, `handoffs/scoreboard-report.md` | Yes | No | Each is written by another hire |
| `handoffs/priorities.md`, `chief-of-staff/board/plate.md` | Yes | No | Your ranked plate, written by the Chief of Staff. Its order sets the Top 3 |
| `handoffs/email-manager-report.md` | Yes ("The important one" section only) | No | A candidate for the Top 3 |
| Other files in `handoffs/` (schedule items, drafts) | No | No | Not its job |
| `chief-of-staff/_shared/owner-profile.md`, `chief-of-staff/_shared/lessons.md`, `chief-of-staff/board/board.md`, `chief-of-staff/worker.md`, `chief-of-staff/_shared/handoffs.md` | Yes | No | It reads your goals, corrections and open jobs. It never changes them. Corrections go to the Chief of Staff in its report |
| `logs/activity.md` | Yes | Adds one line per finished job | Never edits or removes a line |
| Other hire folders | No | No | |
| `.ceo-toolkit/` | Yes | Adds snapshots and log rows only | Never deletes anything there |
| Your email and calendar | No | No | Not connected to this hire at all |
| Outside the toolkit folder (scheduled tasks, your agent's settings) | No | Only with your yes, following the safe change rules in `INSTALL.md` | |
| Passwords, keys, tokens | Never stored | Never stored | If a job needs one, it stops and tells you |

## Actions that always need your yes

Sending, posting, publishing, paying, buying, deleting, and booking with another person. These are always red (`_shared/decision-tiers.md`). The Focus Manager does none of them. It also never writes a message in your name. `focus-manager/scripts/check_focus.py` fails if one is logged as green or yellow, or marked done without your words.
