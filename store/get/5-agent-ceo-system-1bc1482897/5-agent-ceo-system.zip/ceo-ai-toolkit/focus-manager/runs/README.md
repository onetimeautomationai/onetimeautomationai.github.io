# Runs

One folder per planned day, named `YYYY-MM-DD/`. Made by `python3 focus-manager/scripts/new_run.py` (from the toolkit folder) or by hand.

A day folder holds `01_brain-dump.md`, `02_rank.md`, `03_top3.md`, `04_blocks.md`, `05_close.md` and `manager-report.md`. Yesterday's plan is kept here, so the Top 3 file can be replaced each morning and nothing is lost.

Never delete a run. After a few months, move old runs into `runs/archive/`.
