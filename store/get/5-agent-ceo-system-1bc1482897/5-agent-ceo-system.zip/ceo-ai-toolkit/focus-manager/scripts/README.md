# Scripts

Two small scripts. Standard Python 3, nothing to install. They work from any folder. The docs show them run from the toolkit folder. Both are optional: if your AI agent cannot run Python, it does the same steps by hand.

| Script | What it does | By hand |
|---|---|---|
| `new_run.py` | Makes `focus-manager/runs/YYYY-MM-DD/` with the six stage files (reuses today's folder if it exists) | Copy `focus-manager/_templates/run/` to a new folder named with today's date, and fill the date and start time |
| `check_focus.py` | Runs checks F1 to F8. Exit code 0 means pass | Do each check below and write the result in `manager-report.md` |

## The checks

| # | Check |
|---|---|
| F1 | The owner profile in use has no `{{` and says `setup_done: yes`. That is `chief-of-staff/_shared/owner-profile.md` when the Chief of Staff is set up, otherwise `focus-manager/_shared/owner-profile.md` |
| F2 | `handoffs/top3-today.md` exists, its header has `from` (focus-manager), `updated` and `status` (ok, partial or failed), and `updated` is today. On a day with no plan (`focus-manager/runs/YYYY-MM-DD/manager-report.md` has the line "- Result: no plan today (...)"), a missing or older file prints "F2 note: no plan today" instead of failing. A Top 3 for a later day (a plan made ahead, "## Top 3 for" a later date) is checked for its own date with a note |
| F3 | Under `## Top 3 for YYYY-MM-DD` there are three lines like `1. item : result` (fewer only when status is partial). No result starts with "work on", "make progress", "look at", "think about", "handle", "review" or "check on". No `<` or `YYYY` template text. No other `##` section in the file |
| F4 | Under `## One result per block` the table header is `| Block | Result that counts as done |`, there is at least one block (or status is partial), each block has one result, and no block is listed twice |
| F5 | No block overlaps the protected time in the profile, and each block is inside work hours. Times come from the Block cell, or from a "Block N" row in today's `time-manager-report.md`. The Time Manager's own "Top 3 #N: item" rows in a report dated today are checked against the same hours. A block with no times is skipped with a note naming it, and a report not dated today is skipped with a note (exit stays 0). `--now HH:MM` states a replay clock and adds a note for each block already ended by then. When the work hours line names days ("Monday to Friday", "Mon, Wed, Fri", "weekdays"), a block on any other day fails |
| F6 | Every decision log row has 8 columns, a tier of T1, T2 or T3, and a Result of done, pending, parked or no. No row number (FL#) is used twice. Every T3 marked done has the owner's real words. Every T2 marked done says `review: pass`. Any decision that sends, posts, publishes, pays, buys, deletes, books, hires, signs a contract or changes a website is T3 (the owner's own tasks start with `Owner task:`) |
| F7 | Every day folder in `focus-manager/runs/` from before today has `manager-report.md` |
| F8 | No password, key or token in any `focus-manager/_shared/` file or in `capture/capture.md` |

A row whose Decision starts with `corrects FL4` replaces row FL4 for check F6. That is how you fix a mistake without editing the log. If FL4 sends, posts, pays or does any other red action, the correcting row must be T3 too, with Result `pending` or the owner's words. A T1 or T2 correction cannot clear it.

**Today and the time zone.** The checks use today's date in the owner's time zone, read from the profile's "Time zone" line. Write it as a zone name such as America/Los_Angeles. Plain US words ("Pacific Time", "Eastern") are also read. Anything else prints an "F1 note" and the computer's date is used.

**Check output in reports.** Copy the script's last line and exit code into `manager-report.md` as printed. Never write "check passed" without it.

**Tests.** `python3 focus-manager/tests/test_check_focus.py` runs the script on made-up toolkits in a temporary folder and prints PASS or FAIL per case. Add `--today YYYY-MM-DD` to test as if it were another day. A row marked `Owner task:` fails if its Evidence says the AI sent it. The action words that must be T3 include forward, accept, renew, subscribe, ordered, charge, share, invite and cancel.
