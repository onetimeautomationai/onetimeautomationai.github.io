#!/usr/bin/env python3
"""Hard checks the Focus Manager runs before it calls a day done.

Usage (from the toolkit folder, works from any folder):
    python3 focus-manager/scripts/check_focus.py
    python3 focus-manager/scripts/check_focus.py --help     (prints this text, reads and changes nothing)

Date: with no --today, "today" is the current date in the owner's time zone from the owner profile
(the computer's date, with a note, when the zone cannot be read).

Exit code 0 = all checks pass. 1 = at least one check failed (each failure is printed).
Standard library only. Reads files, never changes them. Uses the date in the owner's time zone (from the owner profile) as "today".
For tests only: add --today YYYY-MM-DD to pretend it is another day, and --now HH:MM (24 hour)
to state the clock of a replay. With --now, F5 prints a note for every block that already ended by then.

Checks:
  F1  Setup is done: the owner profile in use (the Chief of Staff's if it is set up, otherwise
      the standalone one) has no {{ placeholders and says setup_done: yes.
  F2  handoffs/top3-today.md exists, has the header (from, updated, status), and is dated today.
      On a day with no plan (today's manager-report.md has the line "- Result: no plan today"),
      a missing or older Top 3 file is not a failure: F2 to F5 for that file print a note instead.
      A Top 3 for a later day ("## Top 3 for" a date after today, a plan made ahead) is checked
      for its own date, with a note, and must not be updated after that date.
  F3  The Top 3 section follows the format: three numbered "item : result" lines (fewer only when
      status is partial), no vague results, no template text, no extra sections.
  F4  The block table follows the format: header row, at least one block, one result per block,
      no vague results, no block listed twice.
  F5  No block sits inside protected hours or outside work hours (when the times can be read).
      This covers the Top 3 file's blocks and, from a Time Manager report dated today, its
      "Top 3 #N: item" rows. A report not dated today is skipped with a note. When the work hours
      line names days ("Monday to Friday"), a block on any other day fails.
  F6  Decision log rows (FL#) have 8 columns, numbers with no gaps, a tier of T1/T2/T3 and a Result of done/pending/
      parked/no. Unique numbers. A T3 marked done has the owner's words. A T2 marked done says
      "review: pass". Anything that sends, posts, publishes, pays, buys, deletes or books is T3.
  F7  Every day folder in runs/ before today has manager-report.md.
  F8  No secrets in _shared/ files or capture/capture.md.

A row whose Decision starts with "corrects FL<n>" replaces every row numbered FL<n> for F6.
A correcting row also carries the actions of the rows it replaces: if FL<n> sends, posts, pays
and so on, the correcting row must be T3 (and a T3 marked done needs the owner's words).
"""
import datetime
import re
import sys
from pathlib import Path

if "--help" in sys.argv or "-h" in sys.argv:
    print(__doc__.strip())
    sys.exit(0)

try:
    from zoneinfo import ZoneInfo
except ImportError:  # very old Python
    ZoneInfo = None


# Plain words for the common zones, so "Pacific Time" in a profile still gives the right date.
ZONE_WORDS = [
    (r"\b(pacific|pt|pst|pdt)\b", "America/Los_Angeles"),
    (r"\b(arizona)\b", "America/Phoenix"),
    (r"\b(mountain|mt|mst|mdt)\b", "America/Denver"),
    (r"\b(central|ct|cst|cdt)\b", "America/Chicago"),
    (r"\b(eastern|et|est|edt)\b", "America/New_York"),
    (r"\b(alaska|akst|akdt)\b", "America/Anchorage"),
    (r"\b(hawaii|hst)\b", "Pacific/Honolulu"),
    (r"\b(utc|gmt)\b", "UTC"),
]


def profile_zone(path):
    """(zone, written) from the profile's 'Time zone' line. zone is a name like America/Chicago,
    or None when the line is missing or cannot be read. written is the text after the colon."""
    try:
        text = Path(path).read_text(encoding="utf-8")
    except OSError:
        return None, None
    m = re.search(r"^-?\s*Time zone[^:\n]*:\s*([^\n]*)$", text, re.M | re.I)
    if not m:
        return None, None
    written = m.group(1).strip()
    names = [n for n in re.findall(r"[A-Za-z]+/[A-Za-z_]+(?:/[A-Za-z_]+)?", written)]
    names += [zone for pat, zone in ZONE_WORDS if re.search(pat, written, re.I)]
    if ZoneInfo:
        for name in names:
            try:
                ZoneInfo(name)
                return name, written
            except Exception:
                continue
    return None, written


def owner_today(override, profile_path):
    """Today's date in the owner's time zone. override is YYYY-MM-DD (tests).
    The zone is read from the profile in use (a line like 'Time zone: America/Chicago', or plain
    words such as 'Pacific Time'). With no readable zone, the computer's date is used, and a
    finished profile gets a note saying so."""
    if override:
        return datetime.date.fromisoformat(override)
    zone, written = profile_zone(profile_path)
    if zone:
        return datetime.datetime.now(ZoneInfo(zone)).date()
    try:
        done = "{{" not in Path(profile_path).read_text(encoding="utf-8")
    except OSError:
        done = False
    if done and written:
        NOTES.append(f"F1 note: the time zone '{written[:40]}' in the profile is not a zone name the script can read, so it used the computer's date. Write a zone name such as America/Los_Angeles.")
    return datetime.date.today()


def arg_today():
    """The value after --today on the command line, or empty."""
    if "--today" in sys.argv:
        i = sys.argv.index("--today")
        if i + 1 < len(sys.argv):
            return sys.argv[i + 1]
    return ""

def arg_now():
    """Minutes since midnight from --now HH:MM, or None. A bad value stops the script with exit 2."""
    if "--now" not in sys.argv:
        return None
    i = sys.argv.index("--now")
    m = re.fullmatch(r"(\d{1,2}):(\d{2})", sys.argv[i + 1]) if i + 1 < len(sys.argv) else None
    if not m or int(m.group(1)) > 23 or int(m.group(2)) > 59:
        print("--now needs a 24 hour time like 08:00")
        sys.exit(2)
    return int(m.group(1)) * 60 + int(m.group(2))


NOW = arg_now()

HERE = Path(__file__).resolve().parent.parent  # the focus-manager folder
ROOT = HERE.parent  # the toolkit folder
FAILS = []
NOTES = []

RESULTS = {"done", "pending", "parked", "no"}
EMPTY_WORDS = {"", "-", "--", "n/a", "na", "none", "tbd", "?"}
ACTION = re.compile(
    r"\b(send|sends|sent|email to|reply to|post|posts|posted|publish|published|"
    r"pay|pays|paid|buy|buys|bought|purchase|purchased|invoice|refund|"
    r"delete|deletes|deleted|book|books|booked|schedule a call with|"
    r"sign a contract|sign the contract|signed|contract|hire|hiring|"
    r"website|wire|transfer|invite|invites|invited|cancel|cancels|cancelled|forward|forwards|forwarded|accept|accepts|accepted|renew|renews|renewed|subscribe|subscribes|subscribed|ordered|place an order|charge|charges|charged|share|shares|shared|confirm with|confirmed with|confirms with)\b",
    re.I,
)
OWNER_TASK = re.compile(r"^\s*owner task\s*:", re.I)
# An "Owner task:" row says the owner did it. If its Evidence says the AI sent it, the row is mislabeled.
AI_SENT = re.compile(r"\b(ai sent|i sent|sent by (the )?(ai|agent|assistant|manager|email manager|me)|(the )?(ai|agent|assistant|email manager) (has )?sent)\b", re.I)
REVIEW_PASS = re.compile(r"review:\s*pass", re.I)
CORRECTS = re.compile(r"^\s*corrects\s+(FL\d+)", re.I)
SECRET = re.compile(r"(api[_-]?key|secret|password|passwd|token)\s*[:=]\s*\S{8,}", re.I)
VAGUE = re.compile(
    r"^(work on|working on|work through|make progress|progress on|look at|looking at|"
    r"think about|thinking about|handle|handling|deal with|continue|keep going|do some|"
    r"try to|review|check on)\b",
    re.I,
)
TIME_RANGE = re.compile(
    r"(\d{1,2})(?::(\d{2}))?\s*([AaPp][Mm])?\s*(?:to|-)\s*(\d{1,2})(?::(\d{2}))?\s*([AaPp][Mm])?"
)
DAY_DIR = re.compile(r"^\d{4}-\d{2}-\d{2}$")


def fail(code, msg):
    FAILS.append(f"{code} FAIL: {msg}")


def table_rows(text):
    rows = []
    for line in text.splitlines():
        s = line.strip()
        if not s.startswith("|") or set(s) <= set("|-: "):
            continue
        rows.append([c.strip() for c in s.strip("|").split("|")])
    return rows


def profile_file():
    cos = ROOT / "chief-of-staff" / "_shared" / "owner-profile.md"
    own = HERE / "_shared" / "owner-profile.md"
    if cos.exists():
        text = cos.read_text(encoding="utf-8")
        if "{{" not in text and re.search(r"^setup_done:\s*yes\s*$", text, re.M):
            return cos
    return own


TODAY = owner_today(arg_today(), profile_file()).isoformat()
PLAN_DAY = TODAY  # the day the Top 3 file plans. Later than TODAY only for a plan made ahead (F-W13)

DAY_WORDS = [
    ("mon", r"mon(?:day)?"), ("tue", r"tue(?:s|sday)?"), ("wed", r"wed(?:nesday)?"), ("thu", r"thu(?:r|rs|rsday)?"),
    ("fri", r"fri(?:day)?"), ("sat", r"sat(?:urday)?"), ("sun", r"sun(?:day)?"),
]
DAY_ANY = "|".join(p for _k, p in DAY_WORDS)
DAY_NAMES = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]


def day_index(word):
    for i, (_k, p) in enumerate(DAY_WORDS):
        if re.fullmatch(p, word, re.I):
            return i
    return None


def work_days():
    """The weekdays (0 = Monday) the profile's work hours line names, or None when it names none.
    Reads 'Monday to Friday', 'Mon-Sat', 'Mon, Wed, Fri' and 'weekdays'."""
    p = profile_file()
    if not p.exists():
        return None
    days = set()
    for line in p.read_text(encoding="utf-8").splitlines():
        if not re.match(r"^-\s*Work (days and )?hours", line.strip(), re.I) or ":" not in line:
            continue
        text = line.split(":", 1)[1]
        if re.search(r"\b(every day|daily|7 days|seven days)\b", text, re.I):
            return None
        if re.search(r"\bweekdays\b", text, re.I):
            days.update(range(5))
        if re.search(r"\bweekends?\b", text, re.I):
            days.update((5, 6))
        for m in re.finditer(rf"\b({DAY_ANY})\b\s*(?:to|through|thru|-)\s*\b({DAY_ANY})\b", text, re.I):
            a, b = day_index(m.group(1)), day_index(m.group(2))
            i = a
            days.add(i)
            while i != b:
                i = (i + 1) % 7
                days.add(i)
        for m in re.finditer(rf"\b({DAY_ANY})\b", text, re.I):
            days.add(day_index(m.group(1)))
    return days or None


def off_day_fail(label, where):
    """F5 fails a block on a day the profile does not list as a work day."""
    days = work_days()
    wd = datetime.date.fromisoformat(PLAN_DAY).weekday()
    if days is not None and wd not in days:
        fail("F5", f"{where} '{label}' is on {DAY_NAMES[wd]} ({PLAN_DAY}), not a work day in the profile.")


def no_plan_today():
    """True when today's manager-report.md says the owner asked for no plan today."""
    p = HERE / "runs" / TODAY / "manager-report.md"
    if not p.exists():
        return False
    return bool(re.search(r"^\s*-?\s*Result:\s*no plan today\b", p.read_text(encoding="utf-8"), re.M | re.I))


def check_setup():
    p = profile_file()
    shown = p.relative_to(ROOT)
    if not p.exists():
        fail("F1", f"{shown} is missing. Run setup.")
        return
    text = p.read_text(encoding="utf-8")
    left = len(re.findall(r"\{\{", text))
    if left:
        fail("F1", f"{shown} still has {left} unanswered setup question(s). Finish setup.")
    if not re.search(r"^setup_done:\s*yes\s*$", text, re.M):
        fail("F1", f"{shown} does not say setup_done: yes.")


def to_minutes(h, m, ap):
    h = int(h)
    m = int(m or 0)
    if ap:
        h = h % 12 + (12 if ap.lower() == "pm" else 0)
    return h * 60 + m


def parse_ranges(text):
    """Return a list of (start, end) in minutes for every time range the text states. Skips unclear ones."""
    out = []
    for m in TIME_RANGE.finditer(text):
        h1, m1, a1, h2, m2, a2 = m.groups()
        if int(h1) > 24 or int(h2) > 24:
            continue
        if not a1 and not a2:
            if int(h1) > 12 or int(h2) > 12:
                s, e = to_minutes(h1, m1, None), to_minutes(h2, m2, None)
            elif int(h1) < 7:
                continue  # "1 to 3" with no AM or PM is too unclear to use
            else:
                s = to_minutes(h1, m1, None)
                e = to_minutes(h2, m2, None)
                if e <= s:
                    e += 12 * 60
        elif a2 and not a1:
            e = to_minutes(h2, m2, a2)
            s = to_minutes(h1, m1, a2)
            if s >= e:
                s = to_minutes(h1, m1, "am" if a2.lower() == "pm" else "pm")
        elif a1 and not a2:
            s = to_minutes(h1, m1, a1)
            e = to_minutes(h2, m2, a1)
            if e <= s:
                e = to_minutes(h2, m2, "pm" if a1.lower() == "am" else "am")
        else:
            s, e = to_minutes(h1, m1, a1), to_minutes(h2, m2, a2)
        if e > s:
            out.append((s, e))
    return out


def profile_ranges(label_pattern):
    p = profile_file()
    if not p.exists():
        return []
    ranges = []
    for line in p.read_text(encoding="utf-8").splitlines():
        if re.match(label_pattern, line.strip(), re.I):
            ranges.extend(parse_ranges(line.split(":", 1)[1] if ":" in line else line))
    return ranges


def split_header(text):
    lines = text.splitlines()
    if not lines or lines[0].strip() != "---":
        return None, text
    for i in range(1, len(lines)):
        if lines[i].strip() == "---":
            head = {}
            for l in lines[1:i]:
                if ":" in l:
                    k, v = l.split(":", 1)
                    head[k.strip().lower()] = v.strip()
            return head, "\n".join(lines[i + 1:])
    return None, text


def report_block_times(n):
    """Times for 'Block n' from today's handoffs/time-manager-report.md, or []. Matches a Today row whose Block cell says 'Block n'."""
    p = ROOT / "handoffs" / "time-manager-report.md"
    if not p.exists():
        return []
    head, body = split_header(p.read_text(encoding="utf-8"))
    if PLAN_DAY != TODAY or not head or not str(head.get("updated", "")).startswith(TODAY):
        return []  # today's calendar says nothing about a later day's blocks
    m = re.search(r"^##\s+Today\s*$(.*?)(?=^##\s|\Z)", body, re.M | re.S)
    if not m:
        return []
    for cells in table_rows(m.group(1))[1:]:
        if len(cells) >= 3 and re.search(rf"\bblock\s*{n}\b", cells[2], re.I):
            return parse_ranges(f"{cells[0]} to {cells[1]}")
    return []


def note_if_past(label, end):
    if NOW is not None and end <= NOW and PLAN_DAY == TODAY:
        NOTES.append(f"F5 note: '{label}' ended at {end // 60:02d}:{end % 60:02d}, before the stated clock {NOW // 60:02d}:{NOW % 60:02d}.")


def check_report_hours():
    """F5 for the Time Manager's own rows. Reads 'Top 3 #N: item' rows from a report dated today. 'Block N' rows are read by check_top3."""
    p = ROOT / "handoffs" / "time-manager-report.md"
    if not p.exists():
        return
    head, body = split_header(p.read_text(encoding="utf-8"))
    if not head or not str(head.get("updated", "")).startswith(TODAY):
        NOTES.append("F5 note: handoffs/time-manager-report.md is not dated today, so its Top 3 rows were not checked for hours.")
        return
    m = re.search(r"^##\s+Today\s*$(.*?)(?=^##\s|\Z)", body, re.M | re.S)
    if not m:
        return
    protected = profile_ranges(r"^-\s*Protected time")
    work = profile_ranges(r"^-\s*Work (days and )?hours")
    if not protected and not work:
        NOTES.append("F5 note: no readable work or protected hours in the profile, Time Manager rows not checked for hours.")
        return
    for cells in table_rows(m.group(1))[1:]:
        if len(cells) < 3 or not re.match(r"top\s*3\s*#\s*\d+\b", cells[2], re.I):
            continue
        off_day_fail(cells[2][:40], "Time Manager row")
        spans = parse_ranges(f"{cells[0]} to {cells[1]}")
        if not spans:
            NOTES.append(f"F5 note: '{cells[2][:40]}' in the Time Manager report has no readable times, hours not checked.")
            continue
        s, e = spans[0]
        label = cells[2][:40]
        for ps, pe in protected:
            if s < pe and ps < e:
                fail("F5", f"Time Manager row '{label}' overlaps protected time.")
        if work and not any(ws <= s and e <= we for ws, we in work):
            fail("F5", f"Time Manager row '{label}' is outside work hours.")
        note_if_past(label, e)


def check_top3():
    global PLAN_DAY
    p = ROOT / "handoffs" / "top3-today.md"
    text = p.read_text(encoding="utf-8") if p.exists() else ""
    head, body = split_header(text)
    dated_today = bool(head) and str(head.get("updated", "")).startswith(TODAY)
    hm = re.search(r"^##\s+Top 3 for (\d{4}-\d{2}-\d{2})\s*$", body, re.M)
    later = bool(head) and bool(hm) and hm.group(1) > TODAY
    if later:
        # A plan for a later day (F-W13) is checked against its own date, not today's.
        PLAN_DAY = hm.group(1)
        NOTES.append(f"F2 note: handoffs/top3-today.md holds the plan for {PLAN_DAY}, a later day than today ({TODAY}). It was checked for its own date. Today has no Top 3 in this file.")
    if not dated_today and not later and no_plan_today():
        NOTES.append(f"F2 note: no plan today. focus-manager/runs/{TODAY}/manager-report.md says 'Result: no plan today', so handoffs/top3-today.md was not checked (F2 to F5 for that file skipped).")
        return
    if not p.exists():
        fail("F2", "handoffs/top3-today.md is missing. Run stage 05_write.")
        return
    if head is None:
        fail("F2", "handoffs/top3-today.md has no header (--- from, updated, status ---).")
        return
    for key in ("from", "updated", "status"):
        if not head.get(key):
            fail("F2", f"header is missing '{key}'.")
    if head.get("from") and head["from"] not in ("focus-manager", "chief-of-staff"):
        fail("F2", f"header 'from' is '{head['from']}'. It must be focus-manager (or chief-of-staff when no Focus Manager is installed).")
    status = head.get("status", "")
    if status and status not in ("ok", "partial", "failed"):
        fail("F2", f"header status '{status}' is not ok, partial or failed.")
    day = None
    if head.get("updated"):
        m = re.match(r"(\d{4}-\d{2}-\d{2}) \d{2}:\d{2}", head["updated"])
        if not m:
            fail("F2", "header 'updated' must start with YYYY-MM-DD HH:MM.")
        else:
            day = m.group(1)
            if later:
                if day > PLAN_DAY:
                    fail("F2", f"handoffs/top3-today.md was updated {day}, after the day it plans ({PLAN_DAY}).")
            elif day != TODAY:
                fail("F2", f"handoffs/top3-today.md is dated {day}, not today ({TODAY}). It counts as missing until it is rewritten.")

    if "<" in body or "YYYY" in body:
        fail("F3", "template text (<...> or YYYY) is still in the file. Fill it in.")

    headings = re.findall(r"^##\s+(.+?)\s*$", body, re.M)
    for h in headings:
        if not (h.startswith("Top 3 for ") or h == "One result per block"):
            fail("F3", f"extra section '## {h}'. The file holds the Top 3 and the block table only. Notes go in manager-report.md.")

    m = re.search(r"^##\s+Top 3 for (\d{4}-\d{2}-\d{2})\s*$(.*?)(?=^##\s|\Z)", body, re.M | re.S)
    if not m:
        fail("F3", "missing the heading '## Top 3 for YYYY-MM-DD'.")
    else:
        if day and m.group(1) != day and not later:
            fail("F3", f"'Top 3 for {m.group(1)}' does not match the updated date {day}.")
        items = re.findall(r"^\s*(\d+)\.\s+(.*\S)\s*$", m.group(2), re.M)
        count = len(items)
        if count == 0 or count > 3 or (count < 3 and status != "partial"):
            fail("F3", f"the Top 3 has {count} item(s). It needs 3 (fewer only when status is partial, at least 1, never more than 3).")
        for i, (num, line) in enumerate(items, 1):
            if int(num) != i:
                fail("F3", f"Top 3 numbering: expected {i} but found {num}.")
            if " : " not in line:
                fail("F3", f"Top 3 item {num} must read '<item> : <result that counts as done>'.")
                continue
            item, result = [x.strip() for x in line.split(" : ", 1)]
            if not item or not result:
                fail("F3", f"Top 3 item {num} has an empty item or result.")
            elif VAGUE.match(result) or len(result.split()) < 3:
                fail("F3", f"Top 3 item {num} result '{result[:50]}' is vague. A result is something the owner can see or check.")

    m = re.search(r"^##\s+One result per block\s*$(.*?)(?=^##\s|\Z)", body, re.M | re.S)
    if not m:
        fail("F4", "missing the heading '## One result per block'.")
        return
    rows = table_rows(m.group(1))
    if not rows or [c.lower() for c in rows[0]] != ["block", "result that counts as done"]:
        fail("F4", "the block table header must be '| Block | Result that counts as done |'.")
        return
    data = rows[1:]
    if not data and status != "partial":
        fail("F4", "no block rows. Add one result per block, or set status to partial and say why in manager-report.md.")
    seen = set()
    protected = profile_ranges(r"^-\s*Protected time")
    work = profile_ranges(r"^-\s*Work (days and )?hours")
    checked_hours = False
    for cells in data:
        if len(cells) != 2:
            fail("F4", f"block row has {len(cells)} columns, needs 2: {' | '.join(cells)[:70]}")
            continue
        block, result = cells
        if not block or not result:
            fail("F4", f"block row has an empty block or result: {' | '.join(cells)[:70]}")
            continue
        if block.lower() in seen:
            fail("F4", f"'{block}' appears twice. One result per block.")
        seen.add(block.lower())
        if VAGUE.match(result) or len(result.split()) < 3:
            fail("F4", f"block '{block}' result '{result[:50]}' is vague. A result is something the owner can see or check.")
        off_day_fail(block, "block")
        spans = parse_ranges(block)
        if not spans:
            bn = re.search(r"\bblock\s*(\d+)\b", block, re.I)
            if bn:
                spans = report_block_times(bn.group(1))
        if not spans:
            NOTES.append(f"F5 note: '{block}' has no times in the Block cell and today's Time Manager report has no row named for it, so hours were not checked for this block (the Time Manager checks its own hours).")
            continue
        s, e = spans[0]
        checked_hours = True
        note_if_past(block, e)
        for ps, pe in protected:
            if s < pe and ps < e:
                fail("F5", f"block '{block}' overlaps protected time.")
        if work and not any(ws <= s and e <= we for ws, we in work):
            fail("F5", f"block '{block}' is outside work hours.")
    if data and not protected and not work:
        NOTES.append("F5 note: no readable work or protected hours in the profile, hours not checked.")
    elif data and not checked_hours:
        NOTES.append("F5 note: no block times could be read, hours not checked.")


def strip_corrects(decision):
    """The Decision text without its leading 'corrects FL<n>' and the colon after it."""
    return CORRECTS.sub("", decision).lstrip(" :.-")


def check_decision_log():
    p = HERE / "_shared" / "decision-log.md"
    if not p.exists():
        fail("F6", "focus-manager/_shared/decision-log.md is missing.")
        return
    rows = table_rows(p.read_text(encoding="utf-8"))[1:]
    good = []
    for cells in rows:
        if len(cells) != 8:
            fail("F6", f"row has {len(cells)} columns, needs 8. A pipe character in the text splits it: {' | '.join(cells)[:80]}")
            continue
        good.append(cells)

    corrected = set()
    by_num = {}
    for cells in good:
        by_num.setdefault(cells[0].upper(), []).append(cells[2])
        m = CORRECTS.match(cells[2])
        if m:
            corrected.add(m.group(1).upper())

    def replaced_text(decision, seen_nums):
        """The Decision text of every row this row replaces, followed through chains of corrections."""
        m = CORRECTS.match(decision)
        if not m:
            return ""
        target = m.group(1).upper()
        if target in seen_nums:
            return ""
        seen_nums.add(target)
        out = []
        for d in by_num.get(target, []):
            if not OWNER_TASK.match(strip_corrects(d)):
                out.append(strip_corrects(d))
            out.append(replaced_text(d, seen_nums))
        return " ".join(out)

    seen = set()
    for cells in good:
        num, _t, decision, tier, _w, evidence, words, result = cells
        key = num.upper()
        is_dup = key in seen
        seen.add(key)
        if key in corrected:
            continue
        if is_dup:
            fail("F6", f"{num} appears twice. Use the next number for a new row, or add a 'corrects {num}' row.")
        if tier not in ("T1", "T2", "T3"):
            fail("F6", f"{num}: tier '{tier}' is not T1, T2 or T3. Add a 'corrects {num}' row.")
        if result.lower() not in RESULTS:
            fail("F6", f"{num}: Result '{result}' is not done, pending, parked or no. Add a 'corrects {num}' row.")
        decision_text = strip_corrects(decision)
        if ACTION.search(decision_text) and tier != "T3" and not OWNER_TASK.match(decision_text):
            fail("F6", f"{num}: '{decision_text[:60]}' reaches another person, the public or money, so it must be T3, not {tier}. Add a 'corrects {num}' row.")
        elif tier != "T3" and not OWNER_TASK.match(decision_text):
            old = replaced_text(decision, {key})
            if ACTION.search(old):
                fail("F6", f"{num}: it corrects a row that reaches another person, the public or money ('{old.strip()[:50]}'), so it must be T3, not {tier}. A T3 marked done needs the owner's words, otherwise Result pending.")
        if OWNER_TASK.match(decision_text) and AI_SENT.search(evidence):
            fail("F6", f"{num}: marked 'Owner task:' but Evidence says the AI sent it. Remove 'Owner task:' and set the tier to T3. Add a 'corrects {num}' row.")
        if tier == "T3" and result.lower() == "done" and words.strip().lower() in EMPTY_WORDS:
            fail("F6", f"{num}: T3 marked done without the owner's words. Ask the owner, or add a 'corrects {num}' row with Result pending.")
        if tier == "T2" and result.lower() == "done" and not REVIEW_PASS.search(evidence):
            fail("F6", f"{num}: yellow (T2) work marked done without 'review: pass' in Evidence. Run the review, then add a 'corrects {num}' row.")


def check_log_numbers():
    """F6: log numbers run FL1, FL2, FL3 with none skipped, and every FL# a report cites is in the log."""
    p = HERE / "_shared" / "decision-log.md"
    if not p.exists():
        return
    nums = set()
    for cells in table_rows(p.read_text(encoding="utf-8"))[1:]:
        m = re.fullmatch(r"FL(\d+)", cells[0].strip(), re.I)
        if m:
            nums.add(int(m.group(1)))
    if nums:
        skipped = [f"FL{n}" for n in range(1, max(nums) + 1) if n not in nums]
        if skipped:
            fail("F6", f"decision log numbers skip {', '.join(skipped[:5])}. Number rows FL1, FL2, FL3 in order, with no gaps.")
    runs = HERE / "runs"
    if not runs.exists():
        return
    for d in sorted(runs.iterdir()):
        rp = d / "manager-report.md"
        if not d.is_dir() or not DAY_DIR.match(d.name) or not rp.exists():
            continue
        cited = {int(n) for n in re.findall(r"\bFL(\d+)\b", rp.read_text(encoding="utf-8"), re.I)}
        missing = [f"FL{n}" for n in sorted(cited - nums)]
        if missing:
            fail("F6", f"runs/{d.name}/manager-report.md cites {', '.join(missing[:5])}, which is not in the decision log.")


def check_runs():
    runs = HERE / "runs"
    if not runs.exists():
        return
    for d in sorted(runs.iterdir()):
        if not d.is_dir() or not DAY_DIR.match(d.name) or d.name >= TODAY:
            continue
        if not (d / "manager-report.md").exists():
            fail("F7", f"runs/{d.name} has no manager-report.md. Write it from _templates/outputs/manager-report.md.")


def check_secrets():
    files = list((HERE / "_shared").glob("*.md")) + [HERE / "capture" / "capture.md"]
    for p in files:
        if not p.exists():
            continue
        for i, line in enumerate(p.read_text(encoding="utf-8").splitlines(), 1):
            if SECRET.search(line):
                fail("F8", f"{p.relative_to(HERE)} line {i} looks like a secret. Remove it. Secrets never go in these files.")


def main():
    check_setup()
    check_top3()
    check_report_hours()
    check_decision_log()
    check_log_numbers()
    check_runs()
    check_secrets()
    for n in NOTES:
        print(n)
    if FAILS:
        print("\n".join(FAILS))
        print(f"\n{len(FAILS)} check(s) failed.")
        return 1
    print("All checks passed (F1 to F8).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
