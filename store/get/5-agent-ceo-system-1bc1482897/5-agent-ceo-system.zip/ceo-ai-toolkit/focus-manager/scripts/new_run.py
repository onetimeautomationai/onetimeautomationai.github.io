#!/usr/bin/env python3
"""Start today's day folder in focus-manager/runs/.

Usage (from the toolkit folder):
    python3 focus-manager/scripts/new_run.py [--today YYYY-MM-DD] [--now HH:MM]
    --today dates the folder on a made-up day (tests, replays). --now sets the started time (HH:MM).
    --help prints this and creates nothing.

Works from any folder. Standard library only. Makes focus-manager/runs/YYYY-MM-DD/ with the six
stage files from focus-manager/_templates/run/. If today's folder already exists it is reused and
nothing in it is overwritten.
"""
import datetime
import shutil
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent.parent  # the focus-manager folder


USAGE = "Usage: python3 focus-manager/scripts/new_run.py [--today YYYY-MM-DD] [--now HH:MM]"


def main() -> int:
    args = sys.argv[1:]
    if any(a in ("-h", "--help") for a in args):
        print(USAGE)
        return 0
    today, hhmm = "", ""
    i = 0
    while i < len(args):
        if args[i] in ("--today", "--now") and i + 1 < len(args):
            if args[i] == "--today":
                today = args[i + 1]
            else:
                hhmm = args[i + 1]
            i += 2
            continue
        print(f"STOP: {args[i]} is not a known flag or is missing its value. Nothing was made.\n{USAGE}")
        return 2
    now = datetime.datetime.now()
    try:
        if today:
            d = datetime.datetime.strptime(today, "%Y-%m-%d")
            now = now.replace(year=d.year, month=d.month, day=d.day)
        if hhmm:
            h = datetime.datetime.strptime(hhmm, "%H:%M")
            now = now.replace(hour=h.hour, minute=h.minute, second=0, microsecond=0)
    except ValueError:
        print(f"STOP: --today takes YYYY-MM-DD and --now takes HH:MM. Nothing was made.\n{USAGE}")
        return 2
    runs = HERE / "runs"
    runs.mkdir(exist_ok=True)
    target = runs / f"{now:%Y-%m-%d}"
    if target.exists():
        print(f"Using existing focus-manager/runs/{target.name}")
        return 0
    shutil.copytree(HERE / "_templates" / "run", target)
    for f in target.glob("*.md"):
        text = f.read_text(encoding="utf-8")
        text = text.replace("{{date}}", f"{now:%Y-%m-%d}")
        text = text.replace("{{started}}", f"{now:%Y-%m-%d %H:%M}")
        f.write_text(text, encoding="utf-8")
    print(f"Created focus-manager/runs/{target.name}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
