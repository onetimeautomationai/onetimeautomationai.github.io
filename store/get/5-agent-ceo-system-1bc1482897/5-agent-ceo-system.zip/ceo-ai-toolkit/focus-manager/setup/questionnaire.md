# Setup questions (standalone only)

Ask one per turn, in this order. The default is in brackets. Write each answer into `focus-manager/_shared/owner-profile.md` the moment you get it. "Required" means there is no default (see onboarding step 5). Five questions, about three minutes. Under the Chief of Staff none of these are asked, because its profile already has the answers.

1. What should I call you? [required]
2. What is your number one goal right now, with a number and a date? For example: "$10,000 in new sales by December 31." [required]
3. What daily actions move that goal the most? For example: new conversations, follow-ups, offers made. [not given, ask again in week one]
4. When do you work, and which hours are protected (no work questions)? [9 AM to 5 PM, evenings and weekends protected]
5. How should I split your work day into blocks? For example: "two blocks, morning and afternoon." [any open stretch of 60 minutes or more inside work hours, up to 4 a day]

Not asked: your time zone. Read it from the computer's clock and tell the owner what you used. Write it as a zone name such as America/Los_Angeles (`00_onboarding/CONTEXT.md` step 6).
