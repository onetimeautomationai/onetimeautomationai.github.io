# 01_brain-dump: get everything on the table

One job: every possible thing for today, from every source, is listed once, so nothing is missed and nothing is counted twice. Paths start from the toolkit folder.

## Inputs
- Working: the owner's message (if any)
- Reference: `focus-manager/_shared/standing-rules.md`, the lessons files, the owner profile (Chief of Staff's if set up, otherwise `focus-manager/_shared/owner-profile.md`)
- Sources: `focus-manager/capture/capture.md` (open and carried rows), `handoffs/scoreboard-report.md` ("Tomorrow's list", only if dated today or yesterday), `handoffs/email-manager-report.md` ("The important one" section only, only if dated today)
- Under the Chief of Staff, also: `chief-of-staff/board/board.md` (Job queue rows not done, "Your list" rows not done), `handoffs/jobs.md` (rows for you, and open rows that carry real owner work, never another hire's routine run), `handoffs/priorities.md` (the owner's ranked plate, whenever it exists: "Ranked" and "New since the ranking" rows that are open. Skip "Must do by date": the Time Manager already blocks each must before its date), `chief-of-staff/board/plate.md` (only to drop items the owner parked, put later or finished)
- Never a candidate: a "Rank your plate" or "Re-rank your plate" job, or a job that blocks time for a "Must P#"
- Template: `focus-manager/_templates/run/01_brain-dump.md`

## Process
1. Check the clock (FR13). Protected time (FR14): if the clock is inside the owner's protected hours and the owner did not say "work now", make no day folder. Capture what they said (step 5, rows in `capture.md` only), say in one line when planning comes back, and stop here.
2. Run `python3 focus-manager/scripts/new_run.py`, or copy `focus-manager/_templates/run/` to `focus-manager/runs/YYYY-MM-DD/` by hand. If today's folder already exists, use it and add a line "Updated HH:MM".
3. Standalone and the owner gave no list: ask once, "What is on your mind today?" Under the Chief of Staff, ask nothing. Use the sources.
4. Read every source in the Inputs. A source that is missing or not fresh: write it under "Sources not found" in the run file. Never guess what it would have said.
5. Split the owner's words into separate items, one idea per item. Split only separate actions. When one phrase holds two actions ("call Ana and send the quote"), split it at the joining word and keep each part of the owner's words exactly as said. When one action is for two people or things ("proposals for Tom Becker and Ana Lima"), keep it as one item with both names. Never make a row that is only a name. For each, add a row to `focus-manager/capture/capture.md` with the next FC number, the owner's exact words, Kind (`idea`, `task` or `note`), Rank `not ranked`, Status `open`. If the same idea is already a row, add the new words to that row instead.
6. List every candidate in `01_brain-dump.md`, one line each, with its source. Merge the same item from two sources into one line. Items from the board, jobs and scoreboard are listed only here. They are not copied into `capture.md`.
7. Cap the list at 10. If there are more, keep the 10 closest to goal 1 (the top open ranked items from `handoffs/priorities.md` in their order, a daily action from the profile, a date this week, a carried row, the owner's words today). Leave the rest as open `capture.md` rows and note "over the cap" in the run file.
8. Mark any candidate that would send, post, publish, pay, buy, delete or book with another person as `T3 if acted on`. You may rank it. You never act on it.
9. Go to `focus-manager/stages/02_rank/CONTEXT.md`. If the owner only wanted to dump ideas and not plan, stop after step 6, say what you captured, and write a short `manager-report.md` in the day folder with the line "- Result: no plan today (captured only)", so the day folder is complete and `check_focus.py` F2 knows no Top 3 was due. If a plan is made later today, stage 05 replaces that line.

## Output
- `01_brain-dump.md` in the day folder: the candidates, each with its source.
- New rows in `capture/capture.md`.

## Human check
None. Capture is logged the same turn. A plain capture has no decision log row, its capture row is the record.
