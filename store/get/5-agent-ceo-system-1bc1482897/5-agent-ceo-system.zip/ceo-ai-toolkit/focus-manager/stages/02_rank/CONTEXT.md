# 02_rank: now, later or no, then one order

One job: every candidate gets a rank against goal 1, and the "now" items get one clear order. Paths start from the toolkit folder.

## Inputs
- Working: `01_brain-dump.md` in the day folder
- Reference: the owner profile (goal 1, daily actions that move it), `focus-manager/_shared/standing-rules.md` (FR1, FR2), `focus-manager/_shared/decision-tiers.md`, the lessons files
- Template: `focus-manager/_templates/run/02_rank.md`

## Process
1. Write the criterion at the top of the run file and do not change it during the run: "Does it move goal 1 this month?" Copy goal 1 from the profile. If goal 1 says "not given", say so, rank by the daily actions, and ask the owner for goal 1 once (standalone) or add a QN line (under the Chief of Staff).
2. Rank each candidate:
   - **Now:** it moves goal 1 this month.
   - **Later:** it helps goal 1 later, or needs something done first. Name what it waits on.
   - **No:** neither. Give the reason, so the idea is never lost.
3. **The owner's ranking comes first.** Under the Chief of Staff, if candidates came from `handoffs/priorities.md`, the owner already ranked them two at a time, or approved the Chief of Staff's ranking of them. They are "now" and keep their order, and you do not compare them again or move anything above them. Open "New since the ranking" rows come right after the open "Ranked" rows, in the order they appear there. A row with Status `waiting: your picks` is a new item the Chief of Staff has not placed yet: skip it, and skip the same item if it also comes from the board or `handoffs/jobs.md`. It is not a candidate today and gets no QN line, because the Chief of Staff already asks the owner its pairs. Every other "now" candidate goes after the open ranked items, in its own order by the pairs below. It reaches the Top 3 only when fewer than three ranked items are open. Add one QN line to your report naming each such candidate: "Not in your ranking yet: [item]. Say 'place it' and your Chief of Staff compares it with your top 3." A candidate that is a plate item the owner parked, put later, or marked done in `chief-of-staff/board/plate.md` is not a candidate today. Neither is a plate item sorted "must": the Time Manager already blocks it before its date.
   Otherwise, put the order on the "now" items. Compare two at a time, never the whole list. For each pair ask one thing: which one moves goal 1 more this month? Count each item's wins. Most wins is first. A tie is settled by the pair of the two tied items. Three items that beat each other in a loop go to the owner as one question (QN line under the Chief of Staff) with your pick as the default.
3b. **Dates never rank.** A due date, a job's Due column or a scoreboard list order is a fact to put in the reason, never the reason for the rank. Only the pair question decides (which moves goal 1 more this month, FR2), and the owner's own ranking comes first as above. An item due today does not beat an item that moves goal 1 more. The end-state wording in stage 03 step 3b applies to result lines only and has no effect here.
4. Write down each close call (both items name a daily action, or both have a date this week) in the pair table, with one line why. With three "now" items or fewer, still ask the pairs in step 3 but skip the written pair table.
5. Update each candidate's row in `capture.md` (Rank, Waits on or reason). That includes rows captured earlier in protected time or parked during a block: once ranked, no candidate row stays `not ranked`. A row over the cap (stage 01 step 7) stays `not ranked` with "over the cap" as its reason. Candidates that came from the board, jobs or scoreboard are not in `capture.md`. Their rank lives in `02_rank.md`.
6. Standalone: show the owner the order in one short list, with the reason for any "no". They can overrule any rank. Their exact words go in the decision log as a T1 row and the new order is used.
7. **Left out, with a reason.** Under the Chief of Staff or standalone, every candidate that is not in the Top 3 gets one line in `02_rank.md` under "Left out of the Top 3": the item and one reason, for example "the Tom Becker proposal is already in the Top 3" or "ranked below three items that move goal 1 more". A scoreboard suggestion such as "Reply to Tom Becker" is a candidate, not an override: it is ranked like any other and gets its line like any other. The one exception is a `waiting: your picks` row, which gets no line.
8. Add one decision log row: "Ranked N candidates against goal 1", T1, Result done. Refer to items by Cand# or FC#, never by their words.

## Output
- `02_rank.md` in the day folder: each candidate with its rank, reason, and order among the "now" items.
- Updated rows in `capture/capture.md`.

## Human check
The owner can overrule any rank. Nothing is ever deleted: a "no" is a row with a reason.
