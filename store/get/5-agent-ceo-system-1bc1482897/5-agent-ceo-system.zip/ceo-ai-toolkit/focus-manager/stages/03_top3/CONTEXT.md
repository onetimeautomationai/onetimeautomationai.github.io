# 03_top3: three things, each with a result that counts as done

One job: pick the three things that matter most today and say, for each, what counts as done in words the owner can check. Paths start from the toolkit folder.

## Inputs
- Working: `02_rank.md` in the day folder, or the owner's own Top 3 if they named one
- Reference: the owner profile, `focus-manager/_shared/standing-rules.md` (FR1, FR3, FR4, FR12, FR16), the lessons files
- Template: `focus-manager/_templates/run/03_top3.md`

## Process
0. If the owner named their own Top 3 ("Top 3: proposals, Priya, the offer post"), use their items in their order and skip the ranking. Put their exact words in the "Owner's words" column of a T1 decision log row, and keep the Decision column generic (see `decision-log.md`). Then write the results by steps 3 to 6.
1. Otherwise take the "now" items in their order. The first three are the Top 3. Any "now" item beyond three goes under "Not today" with the reason "over three". It stays `now` and open.
2. Fewer than three "now" items: fill each empty place with one daily action from the profile that moves goal 1, then the oldest `carried` row in `capture.md`. Still short: stop at what you have. Say "fewer than three things move goal 1 today" in the run file. The file status will be `partial`. Never invent a task to reach three.
3. For each item, write the result that counts as done (FR3). It is something the owner can see or check. The shapes below show the form only. Their words and numbers are not facts about this owner, so never copy a count, a name or a place from them. Good shapes:
   - A thing exists: "[the item] written and saved as a file". Name a folder or file only if it is in a source file or the owner's words.
   - A draft from a manager that exists: "draft from [manager], read and approved by you". Use it only when a source file shows that draft (a file in `handoffs/drafts/`, a row in a report). Name the manager the source names.
   - A thing the owner will write: "reply to [person] written and saved by you". Say who does the work. Never "drafted for your review" or "saved for your yes" unless a source file shows a draft that already exists (then "reply to [person] in `handoffs/drafts/` read and approved by you").
   - A thing happened and the next step is set: "call with [person] held, next step agreed and written down".
   - A number is reached: "[N] follow-up calls made", where N comes from a source file, the owner's words, or a lesson or profile line that asks for numbers.
   - A decision is made: "pricing decision written in one sentence".
   Not results: "work on proposals", "make progress on hiring", "look at the website", "think about pricing", "handle email".
   **A singular result is a count of 1.** "Proposal written and saved by you" means one proposal. Never read it as zero or as several, and never add a number the sources do not give. **Label shortening.** A result may shorten a long item label to its key words (the person and the object, for example "Priya reply" for "reply to Priya about the discount"). It never drops the person, the number or the verb that makes it checkable, and it never adds a fact the label did not have.
   **Counts.** Put a count in a result only when a source gives it (the board says "the two warm leads", the owner says "three calls"). When a lesson or the profile asks for numbers ("make every result a number") and no source gives the count, pick the smallest count that is true when the item is done (usually 1, for example "1 proposal written and saved"), and add a QN line with that count as the default.
3b. **Result lines name today's end state.** The result line says what is true when today's work on the item is finished. It has no date and no later event in it. Good: "[the item] written and saved by you". Bad: "[the item] sent by you by Fri Nov 27". This rule is only about the words of the result line (and of the block results in stage 04). It never changes the order of the items. The order comes from stage 02, and a date or deadline is never a reason to move an item up or down.
4. A result may be something the owner does themselves ("proposal sent by you"). It is never something you do. You do not send, post, publish, pay, buy, delete or book, and you do not draft in the owner's name (FR16). If the owner asks you to do one of these, say it is red and not a Focus Manager job, hand it back ("That is a job for the Chief of Staff", or standalone, "that is an email or calendar job, which this hire does not do"), and add a T3 log row with Result `pending`.
5. If you cannot tell what the result should be, ask one short question with your best guess as the default. Standalone: ask the owner. Under the Chief of Staff: add a QN line to the report, use the default, and say you used it. **Record it.** Write every question you asked, the default you offered, and the owner's reply in their exact words in the table "Questions and the owner's answers" in `03_top3.md` (from the template), the same turn the reply comes. No reply, a "skip", or under the Chief of Staff: write "no answer, default used". Never write words the owner did not say, and never write "owner said" anywhere else. The reviewer never sees the chat, so this table is how it sees the owner's answer (RF2). Standalone, the stage 04 question ("Any fixed times today?") may go in the same message, and its answer goes in the same table in `04_blocks.md`.
6. Thinking or deciding days (FR4): only when the owner said so. The result is `Owner says it is done`.
7. **When the owner changes the Top 3** ("swap 2 for X", "make the webinar number one"): put their exact words in the "Owner's words" column of a T1 decision log row, and keep the Decision column generic. Rewrite the result for the new item by the same rules. Update `03_top3.md`, check whether `04_blocks` needs a new block result, then go to `05_write`. A change the owner named is green. A change you add on your own is yellow and goes through review.
8. Write the draft into `03_top3.md` in the day folder. It is a draft until `05_write` reviews it. Never put it in `handoffs/` yet.

## Output
- `03_top3.md` in the day folder: the three items, each with its result, why it moves goal 1, and the Cand# it came from. Plus "Not today", and every question with the owner's exact answer or "no answer, default used".

## Human check
The reviewer checks the draft in `05_write` (yellow). The owner can swap any item after (step 7).
