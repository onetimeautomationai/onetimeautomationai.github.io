# 04_blocks: one result for each work block

One job: every work block of the day has exactly one result, and each result is a step toward one Top 3 item. Paths start from the toolkit folder.

## Inputs
- Working: `03_top3.md` in the day folder
- Reference: `handoffs/time-manager-report.md`, the owner profile (work hours, protected time, block rule), `focus-manager/_shared/standing-rules.md` (FR3, FR5, FR6, FR7, FR9), the lessons files
- Template: `focus-manager/_templates/run/04_blocks.md`

## Process
1. Check the clock (FR13). Read `handoffs/time-manager-report.md`. It counts only if `updated` is today.
   - Fresh: use the "Today" table for fixed times and "Open time today" for the open stretches. Every row in the Today table is a fixed time, an evening block and lunch included. If the table has any row, "no fixed times today" is wrong, so never write it or tell the owner so.
   - Missing or not fresh, standalone: ask once, "Any fixed times today?" and use the answer. No answer means none. Write the question, the default ("none") and the owner's reply in their exact words, or "no answer, default used", in the table "Questions and the owner's answers" in `04_blocks.md`, the same turn. A fixed time the owner gave there is a source for RF2. Never write a reply the owner did not give. If the owner says there are no fixed times, the file status is `partial` (no calendar seen), the same as under the Chief of Staff. State it once in `manager-report.md`: "calendar not seen, owner says no fixed times".
   - Missing or not fresh, under the Chief of Staff: write "calendar not seen" in the run file. Use the profile's work hours and block rule, and no fixed times. The file status will be `partial`.
   Never invent a fixed time or a meeting.
2. List the open windows: stretches of 60 minutes or more, inside work hours, outside protected hours, never on top of a fixed time. Only time after the real clock (rounded up to the next 15 minutes, and a clock on a quarter hour such as 08:00 stays 08:00) counts as open today. If the owner gave a block rule ("two blocks, morning and afternoon"), keep that many, the longest first. Otherwise list up to 4 open windows, in time order. These are windows, not blocks: the blocks are one per Top 3 item (step 3), so three Top 3 items give three blocks and any window left over stays open. A stretch longer than 2 hours (for example 8 AM to 5 PM with nothing on the calendar) is split into blocks of up to 2 hours, one for each Top 3 item, with a gap of at least 15 minutes left between them.
3. Under the Chief of Staff with a Time Manager installed, write blocks as "Block N" with no time. The Time Manager picks the times, places each block on the calendar and shows the times in its own report, and the Top 3 file keeps "Block N". Otherwise give the first window to Top 3 item 1, the second to item 2, the third to item 3. One block per Top 3 item, the same as the Time Manager's TR3. If there are more windows than items, the extra windows stay open and never become a second block for an item or a fourth topic. An item that needs more time gets it from the owner or the Time Manager, not from a second block here.
4. Write one result per block (FR3, FR5). It is a step toward the item's result, small enough to finish inside the window. Examples: "proposal for [lead A] written and saved by you", "proposal for [lead B] written and saved by you", "[person] call held, notes written". A block may only name an input that exists in a source file (a draft in `handoffs/drafts/`, a file the owner named, a row in a report). Never assume a draft, file or reply that no source shows. If the input is not there, the block result is to make it, by the owner, for example "reply written and saved by you". A block with two results becomes two blocks, or one result is cut. One result is one end state the owner can check yes or no. A block result is the end state of that block, for example "draft saved by you", never a later event such as "sent by you by Dec 5" or "proposal sent by Fri Nov 27". Never join two end states with "and" or "or" ("draft sent by you or changed" is two). Steps that lead to the same end state are one result ("follow-up sent by you"). For a ranked item, shorten the "Result this week" in `handoffs/priorities.md` to the part this block finishes.
5. If a Top 3 item has no window, write it under "No block for" (FR7) and add a QN line: "No open block for #N. Want time made for it?" With a Time Manager installed (profile says so), add "That is a Time Manager job." With no Time Manager, add "You add the block yourself." and write no job row. You never book or move time yourself.
6. Check each block against protected hours and work hours once more. A block that touches either is dropped or moved to a clean window.

## Output
- `04_blocks.md` in the day folder: the open windows, the block table (Block, Result that counts as done, which Top 3 item it serves), "No block for", and the fixed times question with the owner's exact answer.

## Human check
The reviewer in `05_write` checks that every block result serves a Top 3 item and that no block sits in protected hours.
