# 05_write: review it, land it, report it

One job: the checked Top 3 and block results land in `handoffs/top3-today.md` in the exact format, with a report and proof. Paths start from the toolkit folder.

## Inputs
- Working: `03_top3.md` and `04_blocks.md` in the day folder
- Reference: `focus-manager/_shared/handoffs.md` (the exact format), `focus-manager/_shared/review-rubric.md`, `focus-manager/_shared/decision-tiers.md`, `handoffs/jobs.md`, the lessons files
- Templates: `focus-manager/_templates/outputs/top3-today.md`, `focus-manager/_templates/outputs/manager-report.md`

## Process
1. Check the clock (FR13). Build the file text from the template: header with `from: focus-manager`, the real time, and a status from the decision list in `focus-manager/_shared/handoffs.md` (calendar not seen, fewer than three items, or no open block left each make it `partial`, otherwise `ok`. A report that is simply absent and not needed leaves it `ok`). Top 3 section and block table only. No extra sections. Save the draft as `focus-manager/runs/YYYY-MM-DD/05_write.md` (template `focus-manager/_templates/run/05_write.md`) before the review.
2. **Review (yellow).** Start a reviewer with a fresh start on the draft, the source files (list them in the run file), the profile and the rubric. First line of its instructions: "Read focus-manager/worker.md and focus-manager/_shared/review-rubric.md before anything else. You are the reviewer." If your agent cannot start helpers, do a separate pass yourself with the rubric, reading only those files, and say so in the report. Write the helper's name or model and the exact prompt you sent under the same heading, then copy the reviewer's reply word for word into `focus-manager/runs/YYYY-MM-DD/review.md` the same turn ("## Review 1, HH:MM", then "## Review 2, HH:MM" if there is one), and say at the top whether a separate helper or the same agent did it.
   - Pass: write `review: pass, runs/YYYY-MM-DD/review.md` for the log. Go to step 3.
   - Fail: fix exactly what the reviewer listed and review once more. When the reviewer lists two fixes as alternatives, pick one, apply only that one, and write which you picked and why in `review.md` under the next review heading. A second fail makes it red: do not write the file. Show the owner the draft and the reviewer's notes (standalone), or put them in the report as a QN line (under the Chief of Staff), and stop. An earlier file from today, if any, stays as it was.
3. Write `handoffs/top3-today.md`. Replace the earlier file. Yesterday's Top 3 is already in yesterday's day folder, so nothing is lost.
4. Add decision log rows: the Top 3 written (T2, Evidence `review: pass`, Result done). Any `Owner task:` row for something the owner will do. If the owner overruled or swapped, their exact words in a T1 row.
5. Run `python3 focus-manager/scripts/check_focus.py`. If it fails, fix what it names and run it again. To fix a log row, add a `corrects FL#` row. No Python: do the checks in `focus-manager/scripts/README.md` by hand. Copy the script's last line and its exit code into the report exactly as printed (for example "All checks passed (F1 to F8)." exit 0). Never write "check passed" unless that output says so. If it still fails, write "check failed" with the failing lines, and the day is not done.
6. Write `manager-report.md` in the day folder from the template (an earlier "Result: no plan today" line from this morning is replaced by the plan's result): result, proof, sources used, anything missing, "Not today" items, parked count, questions (QN), lessons to file. The last line is the most important thing, usually the first block's result.
7. Under the Chief of Staff: set the status of your row in `handoffs/jobs.md` to `done`, or `waiting: [reason]`. Standalone: show the owner the Top 3, then the block results, then the last line.
8. Last, add one line to `logs/activity.md` for the Top 3 written (Agent `focus-manager`), with the proof copied from `manager-report.md` in the day folder (format and rules at the top of that file). Never edit a line already there. A plan with no later close still reaches the Scoreboard this way.

## Output
- `handoffs/top3-today.md` in the exact format.
- `manager-report.md` in the day folder.
- `review.md` in the day folder: the reviewer's replies, word for word.
- Decision log rows. Job row status (under the Chief of Staff).

## Human check
`check_focus.py` passes and the review passed. The owner reads the Top 3 and can swap an item (`03_top3` step 7).
