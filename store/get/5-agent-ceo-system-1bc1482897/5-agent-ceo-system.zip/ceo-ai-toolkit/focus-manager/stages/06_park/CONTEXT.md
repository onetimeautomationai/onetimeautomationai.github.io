# 06_park: catch it, park it, go back

One job: a stray idea or a drift request is saved in one line and the block goes on. No debate, no scoping. Paths start from the toolkit folder.

## Inputs
- Working: the owner's message ("Park that", "Note: ...", "Idea: ...", or any request unrelated to the current block's result)
- Reference: `handoffs/top3-today.md` (the block table), `focus-manager/capture/capture.md`, `focus-manager/_shared/standing-rules.md` (FR8, FR9, FR14)

## Process
1. Check the clock (FR13). Find the current block from the clock and the block table in `handoffs/top3-today.md`. Outside every block window: no block is active.
2. Add a row to `focus-manager/capture/capture.md`: the next FC number, today's date, the owner's exact words, Kind `parked` (a drift during a block) or `idea` or `note` (no block active, or the owner said "note"), Rank `not ranked`, Status `open`. For `parked`, put "interrupted Block N" under "Waits on or reason".
3. Protected time (FR14): the row is added, and you say only "Captured. It comes back at [time]." Do not ask a question or start planning.
4. Otherwise reply with exactly one line:
   - A block is active: `Parked: <item>. Back to: <that block's result>.`
   - No block is active: `Captured: <item>.`
   `<item>` is the owner's own words for the item, without the lead-in ("Idea:", "Note:", "Actually,"), shortened to at most 8 words, never reworded. `<that block's result>` is copied exactly from the block table in `handoffs/top3-today.md`. Example: owner says "Idea: new pricing page" during Block 1, reply `Parked: new pricing page. Back to: Priya call held, notes written.`
4b. Outside protected time, if today has no Top 3 and no `manager-report.md` yet, make the day folder and write `manager-report.md` with the line "- Result: no plan today (captured)". A plan made later today replaces it. In protected time, write nothing but the capture row.
5. Do not discuss the parked item, estimate it, or break it down. If it is urgent, the owner says "switch block" (FR9). Excitement alone does not switch.
6. **Switch block.** On the words "switch block": ask once for the new result and say which Top 3 item it serves. If it serves none, say so once and let the owner decide. Their words go in a T1 decision log row. Update that block's row in `handoffs/top3-today.md` (the owner's new result), run `check_focus.py`, and note the switch in `05_close.md`.
7. A request to send, post, pay, buy, delete or book is parked like any other. Acting on it is never yours (FR16).

## Output
- One new row in `capture/capture.md`. One line back to the owner.
- A plain park or capture has no decision log row, its capture row is the record. A switch has a log row.

## Human check
None. The owner sees the one-line reply. The next plan (`01_brain-dump`) picks up every open row.
