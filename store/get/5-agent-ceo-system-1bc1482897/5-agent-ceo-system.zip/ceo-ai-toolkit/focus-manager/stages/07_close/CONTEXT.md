# 07_close: run the check, mark it done or carry it

One job: a block or a day closes only when its check passes. What did not pass is carried to tomorrow with a reason. Paths start from the toolkit folder.

## Inputs
- Working: `handoffs/top3-today.md` (today's results), `05_close.md` in the day folder
- Reference: `focus-manager/capture/capture.md`, `focus-manager/_shared/standing-rules.md` (FR10, FR11, FR12), the lessons files
- Template: `focus-manager/_templates/run/05_close.md`

## Process
1. Check the clock (FR13). Which close is it?
   - **Block done:** the owner says "block done", or names a block. Use the current block if they did not name one.
   - **Day done:** the owner says "day done", or the Chief of Staff's night wrap runs the job "day done" (its stage 05 step 1).
2. **Run the check literally.** The result is the check. A file exists: look for it. If the result names no place (stage 03 never invents a file name), ask the owner once where the file is, then look there. A count: count it. A draft waiting for review: find it. If your agent cannot look (for example, a message in the owner's sent folder), ask the owner once, "Is it true that [result]?" Their answer, in their exact words, is the evidence. Never pass a result silently. A hedged answer ("I think so", "probably") is not a yes: ask once more, "Is it true that [result]? Yes or no." Still hedged means not done and carried. A result the owner said at planning they will declare done themselves passes on their words. If the owner already said it in this message ("day done, the reply went out"), their words are the answer, so ask nothing. **Protected time (FR14):** ask no question. A result that needs the owner's word and does not have it is not done. Write "not checked: needs your word, protected time" as what is missing, and it is carried like any other open item. The next plan's brain dump lists it, and the owner can say then that it was done.
3. **Pass:** mark it done in `05_close.md` and write the evidence in one line. When every block that serves a Top 3 item is done, say that item is done.
4. **Fail:** it is not done. Name exactly what is missing. The block stays open (block close) or the item is carried (day close). Never close on a feeling.
5. **Day done only:**
   - For every Top 3 item and every block, fill the table in `05_close.md`.
   - Each item done: if it has a row in `capture.md` (the item, or the parked or noted row it came from), set that row's Status to `done`. Rows of items that came only from the board, jobs or scoreboard are not in `capture.md`, so there is nothing to mark.
   - Each item not done: find its row in `capture.md` (add one if it came from the board or jobs, with the owner's exact words or the item text). Set Status `carried` and write "carried from YYYY-MM-DD: [what is missing]" under "Waits on or reason".
   - Parked rows stay open. They come back in tomorrow's brain dump.
   - Do not touch `handoffs/top3-today.md`. The CEO Scoreboard reads it at night, and tomorrow's plan is made in the morning (FR12).
   - Write the totals in `manager-report.md` under "Top 3 status": N of 3 done, which carried and why.
   - Run `python3 focus-manager/scripts/check_focus.py` and copy its last line and exit code into `manager-report.md` exactly as printed. Never write "check passed" without that output.
6. Under the Chief of Staff, set your row in `handoffs/jobs.md` to `done`, and give the totals in the report. Standalone, tell the owner in two lines: "N of 3 done." then "Tomorrow, first thing: [the first carried item or the top candidate]." Name no time and no planning session for tomorrow unless a source file gives it. In protected time this is all you say.
7. Log: a T1 row for a day close ("Closed the day, N of 3 done"). Any owner overrule in their exact words.
8. Last, add one line to `logs/activity.md` for this close, and one for the morning's Top 3 only if `logs/activity.md` has no line for today's Top 3 (stage 05 step 8 normally wrote it), using the time in the Top 3 file header, with Agent `focus-manager` and the proof copied from a file in the day folder, such as `05_close.md` (format and rules at the top of that file). Never edit a line already there.

## Output
- `05_close.md` in the day folder.
- Carried rows, and `done` rows for finished items, in `capture/capture.md`.
- "Top 3 status" in `manager-report.md`.

## Human check
The owner can correct a result. A correction updates `05_close.md` and, if it is a preference, becomes a lesson (FR20).
