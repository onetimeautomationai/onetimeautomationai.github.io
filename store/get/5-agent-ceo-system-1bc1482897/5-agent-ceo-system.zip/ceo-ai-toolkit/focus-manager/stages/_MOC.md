# stages: map

| Folder | One line |
|---|---|
| `01_brain-dump/` | Every source listed once, stray notes captured |
| `02_rank/` | Now, later or no against goal 1, then one order |
| `03_top3/` | Three items, each with a result that counts as done |
| `04_blocks/` | One result for each open work block |
| `05_write/` | Review, land `handoffs/top3-today.md`, report with proof |
| `06_park/` | Drift saved in one line, back to the block |
| `07_close/` | Check run, done or carried with a reason |
