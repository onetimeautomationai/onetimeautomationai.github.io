# tests: map

| File | One line |
|---|---|
| `test-cases.md` | TC1 to TC20, what the owner says and what must happen |
| `test_check_focus.py` | Unit tests for `check_focus.py` (no plan today, time zone, corrects rows, work days, a plan for a later day). Run `python3 focus-manager/tests/test_check_focus.py` |
| `acceptance-criteria.md` | AC1 to AC13, the bar to ship |
| `rubric.md` | How a judge on a different model scores a Top 3 |
| `test-owner.md` | The made-up owner (Dana Ruiz) and the standalone setup answers |
| `fixtures/` | Made-up handoff files and Top 3 files used by the cases |
