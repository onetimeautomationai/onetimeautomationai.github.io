# fixtures: map

Made-up data for Dana Ruiz (`tests/test-owner.md`). Copy a file into `handoffs/` (or the board path) of a scratch copy of the toolkit to run a test case. Change the `updated` line when a case needs a stale file.

| File | One line | Used by |
|---|---|---|
| `time-manager-report.md` | A calendar for 2026-11-19: three fixed times, four open windows | TC3, TC4 |
| `board-now-jobs.md` | The board's "Your list" and Job queue: five candidates (A91 to A93, J91, J92, numbered so they never clash with the Chief of Staff's own rows), with the source words that make Priya a new prospect and the offer post an offer for new clients | TC3, TC4 |
| `plan-day-standalone.md` | How to build a standalone plan day (profile, Top 3 file, day folder, capture rows FC1 to FC3, files per case) and the exact owner lines for each case | TC7, TC9, TC10 |
| `top3-seeded-tc12.md` | A stage 05 draft with exactly the two seeded errors (the 2:30 PM call with Marcus and the 6 PM to 7 PM block) | TC12 |
| `scoreboard-report.md` | Yesterday's score and a three-item "Tomorrow's list" | TC3, TC10 |
| `top3-good.md` | A Top 3 file that passes `check_focus.py` on 2026-11-19 | TC3, TC14 |
| `cos-profile-done.md` | A finished Chief of Staff profile with the line "Work days and hours" | TC19 |
| `time-manager-report-top3-rows.md` | A Time Manager report dated 2026-11-19 whose rows are named "Top 3 #N: item", one at 12:30 PM (protected) and one at 4:30 PM (after 5 PM work hours) | TC20 |
| `top3-bad.md` | A Top 3 file with a stale date, two items, vague results, a protected-hours block and an extra section | TC5, TC14 |
