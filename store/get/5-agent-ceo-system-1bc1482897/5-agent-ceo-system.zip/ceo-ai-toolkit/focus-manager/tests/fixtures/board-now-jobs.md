---
type: board
---

# Board (test fixture, made-up data for Dana Ruiz)

Only the two tables the Focus Manager reads are shown. Every fact the TC3 Top 3 needs is in these rows: the proposals serve goal 1 (A91 "Two of the ten new clients"), Priya is a new prospect and one new monthly client if she signs (J91), and the offer post is an offer made this week for new clients (J92). Goal 1 itself is in the owner profile (`10 new monthly clients by March 31`).

The rows are numbered from 91 so they never clash with rows the Chief of Staff's own setup already wrote (J1, A1 and so on). Add them below the rows already in `chief-of-staff/board/board.md` and keep their numbers. Never renumber them.

## Your list (tasks only the owner does)
| A# | Date | Task | Why it matters | Status: open / done |
|---|---|---|---|---|
| A91 | 2026-11-18 | Write proposals for the two warm leads, Tom Becker and Ana Lima | Two of the ten new clients | open |
| A92 | 2026-11-18 | Call the chamber of commerce about the January mixer | Referrals for later in the quarter | open |
| A93 | 2026-11-17 | Renew my software subscription | Renewal date is next month | open |

## Job queue
| Job# | Job | Manager | Result goes to | Due | Light | Status |
|---|---|---|---|---|---|---|
| J91 | Reply to Priya Shah about the payroll add-on pricing. Priya Shah is a new prospect (Dana: "Priya Shah is a new prospect. A 12-month monthly bookkeeping package for her would be one new monthly client."). She asked for "10% off the add-on" | Email Manager | handoffs/drafts/ | 2026-11-19 | red | open |
| J92 | Year-end checklist offer post, written. An offer made this week to bring in new clients (source words: "An offer made this week") | Chief of Staff | handoffs/drafts/ | 2026-11-20 | red | open |
