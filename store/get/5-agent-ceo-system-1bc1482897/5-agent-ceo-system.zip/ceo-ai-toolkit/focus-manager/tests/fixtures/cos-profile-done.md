---
type: factory
setup_done: yes
---

# Owner profile

Made-up finished Chief of Staff profile for Dana Ruiz. Copy it to `chief-of-staff/_shared/owner-profile.md` in a scratch toolkit. It uses the Chief of Staff wording "Work days and hours".

## Who you are
- Name the team should use: Dana
- Time zone: America/Los_Angeles

## Your goals (in order)
- Goal 1, with a number and a date: 10 new monthly clients by March 31

## Your day
- Work days and hours: Monday to Friday, 8:00 AM to 5:00 PM
- Protected time (no new questions): 12:00 PM to 1:00 PM
