# Fixture: a standalone plan day (TC7, TC9, TC10)

Made-up data for Dana Ruiz. TC7, TC9 and TC10 say "a plan exists". This file is that plan, so the runner never writes the plan or the owner's lines itself. The person setting up the case (not the runner) builds it in a scratch toolkit with no `chief-of-staff/` folder. Replace 2026-11-19 with the test day everywhere.

## Build it

1. Standalone profile: the 5 answers in `tests/test-owner.md`, `Time zone: America/Los_Angeles`, `setup_done: yes`.
2. Copy `tests/fixtures/top3-good.md` to `handoffs/top3-today.md`.
3. Make `focus-manager/runs/2026-11-19/` (copy `focus-manager/_templates/run/` by hand, since `new_run.py` uses the computer's date) and write `manager-report.md` there with the line "- Result: Top 3 written to `handoffs/top3-today.md`, status ok (fixture plan)".
4. Add these rows to `focus-manager/capture/capture.md`:

| FC# | Date | Owner's words (exact) | Kind: idea / task / note / parked | Rank: now / later / no / not ranked | Waits on or reason | Status: open / done / carried / dropped |
|---|---|---|---|---|---|---|
| FC1 | 2026-11-19 | proposals for Tom Becker and Ana Lima | task | now | two of the ten new clients | open |
| FC2 | 2026-11-19 | reply to Priya about the payroll add-on | task | now | Priya is a new prospect | open |
| FC3 | 2026-11-19 | year-end checklist offer post | task | now | an offer for new clients this week | open |

5. Files per case (the folder `proposals/` sits in the toolkit folder, the "proposals folder" the Top 3 names):

| Case | `proposals/tom-becker-proposal.md` | `proposals/ana-lima-proposal.md` | `handoffs/drafts/priya-reply.md` | Offer post file |
|---|---|---|---|---|
| TC7 | any | any | any | none |
| TC9 | exists | missing at step 1, created by the case runner before step 2 | exists | none |
| TC10 | exists | exists | exists | none |

## Owner lines, sent exactly, one message each

**TC7** (clock 08:30, inside Block 1):
1. "Idea: new pricing page"
2. "Actually, email Priya now"

Expected replies: `Parked: new pricing page. Back to: First proposal written and saved.` and `Parked: email Priya now. Back to: First proposal written and saved.`

**TC9** (Block 2 closes at clock 11:55, Block 3 at clock 13:55):
1. 11:55 "Block done" (Block 2, the second proposal file is missing)
2. Create `proposals/ana-lima-proposal.md`, then 11:58 "Block done"
3. 13:55 "Block done" (Block 3, "Priya reply read and approved by you", which the agent cannot see)
4. "I think so"
5. "Yes, I read the Priya reply and approved it."

**TC10** (clock 19:00, inside protected time 6 PM to 8 PM):
1. "Day done"
</content>
