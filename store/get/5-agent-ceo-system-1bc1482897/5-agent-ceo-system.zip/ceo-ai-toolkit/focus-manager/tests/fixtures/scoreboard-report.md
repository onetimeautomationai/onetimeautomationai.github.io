---
from: ceo-scoreboard
updated: 2026-11-18 18:10 (Pacific)
status: ok
---

## Score for 2026-11-18
- Top 3 done: 2 of 3
- Score: 7 out of 10, two of three done and the proposals started late
- One fix for tomorrow: start proposals before email

## Tomorrow's list
1. Finish the Ana Lima proposal
2. Reply to Tom Becker
3. Confirm the January mixer with the chamber of commerce
