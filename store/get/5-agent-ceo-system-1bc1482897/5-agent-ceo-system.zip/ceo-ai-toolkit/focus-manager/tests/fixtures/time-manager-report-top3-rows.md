---
from: time-manager
updated: 2026-11-19 07:55 (Pacific)
status: ok
---

## Today
| Start | End | Block | Fixed or movable |
|---|---|---|---|
| 08:00 | 09:00 | Top 3 #1: Write the two proposals | movable |
| 12:30 | 13:30 | Top 3 #2: Priya Shah reply | movable |
| 16:30 | 17:30 | Top 3 #3: Year-end offer post | movable |
