---
from: time-manager
updated: 2026-11-19 07:55 (Pacific)
status: ok
---

## Today
| Start | End | Block | Fixed or movable |
|---|---|---|---|
| 10:00 AM | 10:30 AM | Team meeting | Fixed |
| 12:00 PM | 1:00 PM | Lunch | Fixed |
| 2:00 PM | 3:00 PM | Client review | Fixed |

## Open time today
- 6.5 hours open: 8:00 AM to 10:00 AM, 10:30 AM to 12:00 PM, 1:00 PM to 2:00 PM, 3:00 PM to 5:00 PM
