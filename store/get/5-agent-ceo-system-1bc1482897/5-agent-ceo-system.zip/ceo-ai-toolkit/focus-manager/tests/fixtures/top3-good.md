---
from: focus-manager
updated: 2026-11-19 08:10 (Pacific)
status: ok
---

## Top 3 for 2026-11-19
1. Proposals for the two warm leads : both proposals written and saved in your proposals folder
2. Priya Shah payroll add-on reply : reply drafted and waiting for your yes
3. Year-end checklist offer : offer post written and waiting for your yes

## One result per block
| Block | Result that counts as done |
|---|---|
| Block 1, 8:00 AM to 10:00 AM | First proposal written and saved |
| Block 2, 10:30 AM to 12:00 PM | Second proposal written and saved |
| Block 3, 1:00 PM to 2:00 PM | Priya reply read and approved by you |
| Block 4, 3:00 PM to 5:00 PM | Offer post read and approved by you |
