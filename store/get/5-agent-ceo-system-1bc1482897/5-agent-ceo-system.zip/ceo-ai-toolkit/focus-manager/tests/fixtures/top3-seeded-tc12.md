# Fixture: TC12 seeded draft (exactly two seeded errors)

Made-up data for Dana Ruiz, standalone, setup done with the answers in `tests/test-owner.md`. Clock 08:00 on the test day. Replace 2026-11-19 with the test day. The person setting up the case writes the four files below into `focus-manager/runs/2026-11-19/`, adds capture rows FC1 to FC3 from `plan-day-standalone.md` (step 4), and then tells the runner to start stage 05. The runner never edits the seed.

The seed holds exactly two errors and nothing else a reviewer should fail:
- E1 (RF2): "2:30 PM to 3:00 PM call with Marcus" in the open windows table. No source names Marcus or that time. The owner answered "none" to the fixed times question.
- E2 (RF4): Block 4 at 6:00 PM to 7:00 PM, inside protected time (6 PM to 8 PM) and outside work hours (8 AM to 5 PM).

The fix for both: drop the Marcus line and move Block 4 to 3:00 PM to 5:00 PM.

## File 1: `01_brain-dump.md`

```
# Brain dump

Owner's words (08:00): "Brain dump: proposals for Tom Becker and Ana Lima, reply to Priya about the payroll add-on, she could be a new client, year-end checklist offer post to bring in new clients"

Sources read: owner's message, owner profile, focus-manager/capture/capture.md (FC1 to FC3 added this run)
Sources not found: handoffs/time-manager-report.md, handoffs/scoreboard-report.md, handoffs/email-manager-report.md

| Cand# | Candidate | Source |
|---|---|---|
| Cand1 | proposals for Tom Becker and Ana Lima | owner's words, FC1 |
| Cand2 | reply to Priya about the payroll add-on | owner's words, FC2 |
| Cand3 | year-end checklist offer post | owner's words, FC3 |
```

## File 2: `02_rank.md`

```
# Rank

Criterion: Does it move goal 1 this month? Goal 1: 10 new monthly clients by March 31

| Cand# | Rank | Reason |
|---|---|---|
| Cand1 | now | proposals are a daily action that moves goal 1 |
| Cand2 | now | owner says Priya could be a new client |
| Cand3 | now | owner says the post is to bring in new clients |

Order: Cand1, Cand2, Cand3 (three now items, no pair table needed)

## Left out of the Top 3
- none
```

## File 3: `03_top3.md`

```
# Top 3 (draft until stage 05 reviews it)

| # | Item | Result that counts as done | Why it moves goal 1 | Cand# |
|---|---|---|---|---|
| 1 | Proposals for Tom Becker and Ana Lima | both proposals written and saved as files | Proposals are a daily action that moves goal 1 (profile) | Cand1 |
| 2 | Reply to Priya about the payroll add-on | reply written and saved for your yes | Owner says she could be a new client | Cand2 |
| 3 | Year-end checklist offer post | offer post written and saved for your yes | Owner says it is to bring in new clients | Cand3 |

## Not today (now items over three)
- none

## Questions and the owner's answers (stage 03 step 5)
| QN# | Question asked | Default offered | Owner's answer (exact words), or "no answer, default used" |
|---|---|---|---|

## Owner's words (exact, if they named or swapped an item)
```

## File 4: `04_blocks.md`

```
# Blocks

Calendar source: owner said (no time-manager-report.md)

## Questions and the owner's answers (stage 04 step 1)
| QN# | Question asked | Default offered | Owner's answer (exact words), or "no answer, default used" |
|---|---|---|---|
| QN1 | Any fixed times today? | none | none |

## Open windows (60 minutes or more, inside work hours, outside protected hours)
| Window | Length | Kept as a block? |
|---|---|---|
| 8:00 AM to 2:30 PM | 6.5 hours | yes, split into Blocks 1 to 3 |
| 2:30 PM to 3:00 PM call with Marcus (fixed) | 30 minutes | no |
| 3:00 PM to 5:00 PM | 2 hours | no |

## Blocks (one result each)
| Block | Result that counts as done | Serves Top 3 # |
|---|---|---|
| Block 1, 8:00 AM to 10:00 AM | Tom Becker proposal written and saved as a file | 1 |
| Block 2, 10:30 AM to 12:00 PM | Priya reply written and saved for your yes | 2 |
| Block 3, 12:30 PM to 2:30 PM | Offer post written and saved for your yes | 3 |
| Block 4, 6:00 PM to 7:00 PM | Ana Lima proposal written and saved as a file | 1 |

## No block for
- none
```

The file status for this plan is `partial` (no calendar seen, owner says no fixed times), per `focus-manager/_shared/handoffs.md`.
</content>
