# Test owner (made up)

The test owner is Dana Ruiz, the same made-up owner as the Chief of Staff's tests. Under the Chief of Staff, use the 18 setup answers in `chief-of-staff/tests/test-owner.md` and nothing else. For standalone tests, use the 5 answers below. They come from the same Dana.

| Standalone Q | Answer |
|---|---|
| 1 | Dana Ruiz |
| 2 | 10 new monthly clients by March 31 |
| 3 | sales calls and proposals |
| 4 | 8 AM to 5 PM, 6 PM to 8 PM protected |
| 5 | skip (use the default: any open stretch of 60 minutes or more, up to 4 a day) |

Made-up files to copy into a scratch toolkit for the test cases are in `tests/fixtures/`. Today in the fixtures is 2026-11-19. Use the real clock in a real run, so change the dates in the fixtures to today before a live test.
