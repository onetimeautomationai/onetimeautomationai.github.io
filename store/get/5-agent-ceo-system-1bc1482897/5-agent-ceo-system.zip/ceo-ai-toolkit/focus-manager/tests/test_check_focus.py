#!/usr/bin/env python3
"""Unit tests for check_focus.py (F-F5, F-F8 and F-F9 in the 2026-11-21 final run report, and
F-W13 from the bonus final run: a Top 3 for a later day).

Usage (from the ceo-ai-toolkit folder, works from any folder):
    python3 focus-manager/tests/test_check_focus.py

Builds a made-up toolkit in a temporary folder for each case (made-up owner Dana Ruiz), runs the
check script there, and reads its output. Standard library only. Exit 0 when every case passes.
"""
import importlib.util
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent.parent  # the focus-manager folder
RESULTS = []
TEMPS = []  # temporary toolkits, removed at the end

PROFILE = """---
type: factory
setup_done: yes
---

# Owner profile (standalone)

## Who you are
- Name the team should use: Dana Ruiz
- Time zone (taken from your computer's clock, not asked): {zone}

## Your goals
- Goal 1, with a number and a date: 10 new monthly clients by March 31
- Daily actions that move goal 1 most: sales calls and proposals

## Your day
- Work hours: {work}
- Protected time (no new questions): 6 PM to 8 PM
- How your work day splits into blocks: any open stretch of 60 minutes or more, up to 4 a day
"""

TOP3 = """---
from: focus-manager
updated: {updated} 08:00 (Pacific)
status: ok
---

## Top 3 for {day}
1. Proposals for the two warm leads : {result1}
2. Priya Shah payroll add-on reply : reply drafted and waiting for your yes
3. Year-end checklist offer : offer post written and waiting for your yes

## One result per block
| Block | Result that counts as done |
|---|---|
| Block 1, 9:00 AM to 10:00 AM | First proposal written and saved |
"""


def case(name, ok, detail=""):
    RESULTS.append(ok)
    print(f"{'PASS' if ok else 'FAIL'}  {name}" + ("" if ok else f"\n      {detail}"))


def toolkit(zone="America/Los_Angeles", work="8 AM to 5 PM", shipped=False):
    """A temporary toolkit folder holding a copy of focus-manager/ with a finished profile."""
    tmp = Path(tempfile.mkdtemp(prefix="focus-check-"))
    TEMPS.append(tmp)
    shutil.copytree(HERE, tmp / "focus-manager", ignore=shutil.ignore_patterns("__pycache__", "runs", "archive"))
    (tmp / "focus-manager" / "runs").mkdir()
    (tmp / "handoffs").mkdir()
    if not shipped:
        (tmp / "focus-manager" / "_shared" / "owner-profile.md").write_text(PROFILE.format(zone=zone, work=work), encoding="utf-8")
    return tmp


def write_top3(tmp, day, result1="both proposals written and saved as files", updated=None):
    text = TOP3.format(day=day, updated=updated or day, result1=result1)
    (tmp / "handoffs" / "top3-today.md").write_text(text, encoding="utf-8")


def write_report(tmp, day, result):
    d = tmp / "focus-manager" / "runs" / day
    d.mkdir(parents=True, exist_ok=True)
    (d / "manager-report.md").write_text(f"# Focus Manager report, {day}\n\n- Job: owner message\n- Result: {result}\n", encoding="utf-8")


def add_log_rows(tmp, rows):
    p = tmp / "focus-manager" / "_shared" / "decision-log.md"
    text = p.read_text(encoding="utf-8").rstrip("\n") + "\n"
    p.write_text(text + "\n".join("| " + " | ".join(r) + " |" for r in rows) + "\n", encoding="utf-8")


def run(tmp, *args):
    r = subprocess.run([sys.executable, str(tmp / "focus-manager" / "scripts" / "check_focus.py"), *args],
                       capture_output=True, text=True, cwd=str(tmp))
    return r.returncode, r.stdout + r.stderr


def fails(out):
    return [l for l in out.splitlines() if " FAIL: " in l]


def main():
    try:
        # Baseline: the shipped, unconfigured pack fails F1 twice and F2, nothing else.
        tmp = toolkit(shipped=True)
        code, out = run(tmp)
        codes = sorted(l.split()[0] for l in fails(out))
        case("unconfigured pack fails only F1, F1, F2", code == 1 and codes == ["F1", "F1", "F2"], out)

        # F-F5: a day with no plan is not a false F2 fail.
        tmp = toolkit()
        write_report(tmp, "2026-11-24", "no plan today (captured one idea, the owner asked for no plan)")
        code, out = run(tmp, "--today", "2026-11-24")
        case("F-F5 no plan today: exit 0 with a 'no plan today' note, no F2 fail",
             code == 0 and "no plan today" in out and not fails(out), out)

        tmp = toolkit()
        write_report(tmp, "2026-11-24", "no plan today")
        write_top3(tmp, "2026-11-23")
        code, out = run(tmp, "--today", "2026-11-24")
        case("F-F5 no plan today: yesterday's Top 3 file is not a fail", code == 0 and not fails(out), out)

        tmp = toolkit()
        write_report(tmp, "2026-11-24", "Top 3 written to `handoffs/top3-today.md`, status ok")
        code, out = run(tmp, "--today", "2026-11-24")
        case("F-F5 control: a plan day with no Top 3 file still fails F2",
             code == 1 and any(l.startswith("F2 FAIL") for l in fails(out)), out)

        tmp = toolkit()
        write_report(tmp, "2026-11-24", "no plan today")
        write_top3(tmp, "2026-11-24", result1="work on proposals")
        code, out = run(tmp, "--today", "2026-11-24")
        case("F-F5 control: a Top 3 file dated today is still checked on a 'no plan' day",
             code == 1 and any(l.startswith("F3 FAIL") for l in fails(out)), out)

        # F-F8: the time zone.
        tmp = toolkit(zone="Pacific Time")
        spec = importlib.util.spec_from_file_location("check_focus_copy", tmp / "focus-manager" / "scripts" / "check_focus.py")
        mod = importlib.util.module_from_spec(spec)
        saved = sys.argv
        sys.argv = ["check_focus.py"]
        try:
            spec.loader.exec_module(mod)
            got = mod.profile_zone(tmp / "focus-manager" / "_shared" / "owner-profile.md")[0] if hasattr(mod, "profile_zone") else "no profile_zone function"
        finally:
            sys.argv = saved
        case("F-F8 'Pacific Time' is read as America/Los_Angeles", got == "America/Los_Angeles", f"got {got}")

        tmp = toolkit(zone="the moon base")
        write_report(tmp, "2026-11-24", "no plan today")
        code, out = run(tmp)
        case("F-F8 an unreadable zone prints a note instead of silently using the computer's date",
             "F1 note: the time zone" in out, out)

        tmp = toolkit(zone="America/Los_Angeles")
        code, out = run(tmp)
        case("F-F8 the zone name onboarding writes gives no zone note", "F1 note: the time zone" not in out, out)

        onboarding = (HERE / "00_onboarding" / "CONTEXT.md").read_text(encoding="utf-8")
        case("F-F8 onboarding says to write a zone name such as America/Los_Angeles", "America/Los_Angeles" in onboarding)

        # F-F9: a correcting row cannot clear a logged send at T1.
        send = ["FL1", "2026-11-24 08:00", "Send Priya the offer", "T1", "owner asked", "-", "", "done"]
        tmp = toolkit()
        write_report(tmp, "2026-11-24", "no plan today")
        add_log_rows(tmp, [send, ["FL2", "2026-11-24 08:05", "corrects FL1", "T1", "fix", "-", "", "done"]])
        code, out = run(tmp, "--today", "2026-11-24")
        case("F-F9 'corrects FL1' at T1 done does not clear a logged send",
             code == 1 and any(l.startswith("F6 FAIL: FL2") for l in fails(out)), out)

        tmp = toolkit()
        write_report(tmp, "2026-11-24", "no plan today")
        add_log_rows(tmp, [send, ["FL2", "2026-11-24 08:05", "corrects FL1", "T3", "fix", "-", "", "pending"]])
        code, out = run(tmp, "--today", "2026-11-24")
        case("F-F9 control: 'corrects FL1' at T3 pending clears it", code == 0 and not fails(out), out)

        tmp = toolkit()
        write_report(tmp, "2026-11-24", "no plan today")
        add_log_rows(tmp, [send, ["FL2", "2026-11-24 08:05", "corrects FL1", "T3", "fix", "-", "", "done"]])
        code, out = run(tmp, "--today", "2026-11-24")
        case("F-F9 control: 'corrects FL1' at T3 done with no owner's words fails",
             code == 1 and any(l.startswith("F6 FAIL: FL2") for l in fails(out)), out)

        # F-F9: F5 respects work days.
        tmp = toolkit(work="Monday to Friday, 8 AM to 5 PM")
        write_top3(tmp, "2026-11-21")  # a Saturday
        code, out = run(tmp, "--today", "2026-11-21")
        case("F-F9 a block on Saturday fails F5 when work days are Monday to Friday",
             code == 1 and any(l.startswith("F5 FAIL") and "not a work day" in l for l in fails(out)), out)

        tmp = toolkit(work="Monday to Friday, 8 AM to 5 PM")
        write_top3(tmp, "2026-11-20")  # a Friday
        code, out = run(tmp, "--today", "2026-11-20")
        case("F-F9 control: the same block on Friday passes", code == 0 and not fails(out), out)

        tmp = toolkit(work="Mon, Wed, Fri 8 AM to 5 PM")
        write_top3(tmp, "2026-11-24")  # a Tuesday
        code, out = run(tmp, "--today", "2026-11-24")
        case("F-F9 a listed-days profile fails a block on Tuesday",
             code == 1 and any("not a work day" in l for l in fails(out)), out)

        # F-W13: a Top 3 for a later day is checked for its own date.
        tmp = toolkit(work="Monday to Friday, 8 AM to 5 PM")
        write_top3(tmp, "2026-11-23", updated="2026-11-21")  # written Saturday for Monday
        code, out = run(tmp, "--today", "2026-11-21")
        case("F-W13 a plan written today for Monday passes with a 'later day' note",
             code == 0 and not fails(out) and "later day" in out, out)

        tmp = toolkit()
        write_top3(tmp, "2026-11-23")  # header and heading both say Monday
        code, out = run(tmp, "--today", "2026-11-21")
        case("F-W13 a plan dated Monday in header and heading passes on Saturday", code == 0 and not fails(out), out)

        tmp = toolkit(work="Monday to Friday, 8 AM to 5 PM")
        write_top3(tmp, "2026-11-28", updated="2026-11-24")  # a Saturday plan
        code, out = run(tmp, "--today", "2026-11-24")
        case("F-W13 a later-day plan is checked against its own weekday (Saturday fails F5)",
             code == 1 and any("not a work day" in l for l in fails(out)), out)

        tmp = toolkit()
        write_top3(tmp, "2026-11-23", result1="work on proposals", updated="2026-11-21")
        code, out = run(tmp, "--today", "2026-11-21")
        case("F-W13 control: a later-day plan with a vague result still fails F3",
             code == 1 and any(l.startswith("F3 FAIL") for l in fails(out)), out)

        tmp = toolkit()
        write_top3(tmp, "2026-11-20")
        code, out = run(tmp, "--today", "2026-11-21")
        case("F-W13 control: a plan for an earlier day still fails F2",
             code == 1 and any(l.startswith("F2 FAIL") for l in fails(out)), out)

        # F2-F3: log numbers have no gaps and a report cites only rows that exist.
        def row(n, text="Closed the day", tier="T1", result="done"):
            return [f"FL{n}", "2026-11-24 08:00", text, tier, "why", "-", "", result]

        tmp = toolkit()
        write_report(tmp, "2026-11-24", "no plan today")
        add_log_rows(tmp, [row(1), row(3)])
        code, out = run(tmp, "--today", "2026-11-24")
        case("F2-F3 a skipped log number (FL1 then FL3) fails F6",
             code == 1 and any(l.startswith("F6 FAIL") and "FL2" in l for l in fails(out)), out)

        tmp = toolkit()
        write_report(tmp, "2026-11-24", "no plan today (logged FL1 and FL2)")
        add_log_rows(tmp, [row(1), row(2)])
        code, out = run(tmp, "--today", "2026-11-24")
        case("F2-F3 control: FL1, FL2 and a report that cites both passes", code == 0 and not fails(out), out)

        tmp = toolkit()
        write_report(tmp, "2026-11-24", "no plan today (logged FL1 and FL3)")
        add_log_rows(tmp, [row(1), row(2)])
        code, out = run(tmp, "--today", "2026-11-24")
        case("F2-F3 a report that cites FL3 when the log ends at FL2 fails F6",
             code == 1 and any(l.startswith("F6 FAIL") and "FL3" in l and "manager-report.md" in l for l in fails(out)), out)

        # F2-F9: --help prints usage, states the date default, and changes nothing.
        tmp = toolkit()
        def listing():
            return sorted((str(q.relative_to(tmp)), q.stat().st_size, q.stat().st_mtime_ns) for q in tmp.rglob("*") if q.is_file())
        before = listing()
        code, out = run(tmp, "--help")
        case("F2-F9 --help prints usage and exits 0 without running the checks",
             code == 0 and "Usage" in out and "FAIL" not in out and "checks failed" not in out, out)
        case("F2-F9 --help states the date default", "no --today" in out and "time zone" in out, out)
        case("F2-F9 --help changes no file", listing() == before)

        # F-W6/L-W4: new_run.py takes --today and --now, and --help creates nothing.
        probe = Path(tempfile.mkdtemp(prefix="newrun-"))
        TEMPS.append(probe)
        shutil.copytree(HERE / "_templates", probe / "focus-manager" / "_templates")
        (probe / "focus-manager" / "scripts").mkdir(parents=True)
        shutil.copy(HERE / "scripts" / "new_run.py", probe / "focus-manager" / "scripts" / "new_run.py")
        script = str(probe / "focus-manager" / "scripts" / "new_run.py")
        r = subprocess.run([sys.executable, script, "--help"], capture_output=True, text=True, cwd=str(probe))
        case("F-W6 new_run.py --help prints usage and creates nothing",
             r.returncode == 0 and "Usage" in r.stdout and not (probe / "focus-manager" / "runs").exists(), r.stdout + r.stderr)
        r = subprocess.run([sys.executable, script, "--today", "2026-12-07", "--now", "08:30"], capture_output=True, text=True, cwd=str(probe))
        day = probe / "focus-manager" / "runs" / "2026-12-07"
        started = "2026-12-07 08:30" in "".join(f.read_text(encoding="utf-8") for f in day.glob("*.md")) if day.exists() else False
        case("F-W6 new_run.py --today and --now date the folder and the started time",
             r.returncode == 0 and day.exists() and started, r.stdout + r.stderr)
    finally:
        for t in TEMPS:
            shutil.rmtree(t, ignore_errors=True)

    print(f"\n{sum(RESULTS)} of {len(RESULTS)} passed.")
    return 0 if all(RESULTS) else 1


if __name__ == "__main__":
    sys.exit(main())
