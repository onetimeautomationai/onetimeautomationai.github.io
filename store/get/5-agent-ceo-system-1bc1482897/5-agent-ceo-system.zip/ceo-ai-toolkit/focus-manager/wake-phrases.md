# What to say to your Focus Manager

With a Chief of Staff, say "Morning" and it runs the Focus Manager for you. The phrases below also work when you talk to the Focus Manager directly.

| Say | It does |
|---|---|
| "Start my Focus Manager" | First-time setup (5 questions), or nothing to ask if your Chief of Staff is set up |
| "Plan my day" or "Top 3" | Your Top 3 with a result for each, and one result for each work block |
| "Brain dump: ..." | Splits it into items and saves each one on your list. It plans only if you ask |
| "Note: ..." or "Idea: ..." | Saves it on your list in one line |
| "Park that" | Saves the stray idea and sends you back to your block's result |
| "Swap 2 for [thing]" | Changes your Top 3 and rewrites the result for the new item |
| "Switch block" | Changes the current block's result. Only these words switch it |
| "Block done" | Checks the block's result for real, then marks it done or tells you what is missing |
| "Day done" | Checks your Top 3 results, marks them, and carries what is not done to tomorrow |
| "Where am I?" or "Show my Top 3" | Your Top 3 and your current block in three lines |
| "From now on, ..." | Saves a new rule |
| "Work now" | Plans during your protected hours, once |
| "Redo setup" | Asks the 5 setup questions again (alone only) |
| "Stop" | Stops and lists what was in progress |
| "Uninstall the Focus Manager" | Safe removal, see `UNINSTALL.md` |
