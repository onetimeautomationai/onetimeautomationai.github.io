# Handoffs

The hires pass work to each other through the files in this folder. Formats: `chief-of-staff/_shared/handoffs.md`.

| File | Written by | Read by |
|---|---|---|
| `jobs.md` | Chief of Staff (each manager sets the Status of its own rows) | Every manager |
| `email-manager-report.md` | Email Manager | Chief of Staff, Focus Manager ("The important one" only) |
| `schedule-items.md` | Email Manager (owns the Status column) | Time Manager |
| `drafts/` | Email Manager (or Chief of Staff if no Email Manager) | Chief of Staff, then the owner |
| `time-manager-report.md` | Time Manager (or Chief of Staff if no Time Manager) | Chief of Staff, Focus Manager, Email Manager |
| `top3-today.md` | Focus Manager (or Chief of Staff if no Focus Manager) | Chief of Staff, Time Manager, CEO Scoreboard |
| `scoreboard-report.md` | CEO Scoreboard | Chief of Staff, Focus Manager |
| `priorities.md` | Chief of Staff, after the owner ranks their plate | Focus Manager (sets the daily Top 3 from it) |

Each hire overwrites only its own files. The For cell in `jobs.md` is the hire's folder name, for example `time-manager`.
