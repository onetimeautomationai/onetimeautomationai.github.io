# Drafts

Reply drafts waiting for the owner. One file per draft: `YYYY-MM-DD-person-subject.md`. Nothing here is ever sent without the owner's yes.

Each draft file starts with:

```
---
to: <person>
subject: <subject>
status: waiting for owner / approved / sent / dropped
---
```
