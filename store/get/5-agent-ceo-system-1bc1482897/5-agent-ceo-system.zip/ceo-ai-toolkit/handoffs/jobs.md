---
from: chief-of-staff
---

# Jobs

| Job# | For | Job | Write result to | Due | Light: green / yellow / red | Status: open / done / waiting: reason |
|---|---|---|---|---|---|---|
