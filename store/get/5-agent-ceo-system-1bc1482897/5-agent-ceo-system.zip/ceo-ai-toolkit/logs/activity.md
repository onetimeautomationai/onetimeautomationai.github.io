# Activity log

Every agent adds one line here when it finishes a job. The CEO Scoreboard checks each line at night against its proof and counts only the jobs that pass. Paths start from the `ceo-ai-toolkit` folder.

How to write a line:
- When: the date and time the job finished, in the owner's time zone, as YYYY-MM-DD HH:MM.
- Agent: `chief-of-staff`, `email-manager`, `time-manager`, `focus-manager` or `watch-to-ai`.
- Job: what the job was, in a few words.
- Result: what came out of it. Write "drafted" for a draft. Write "sent" only when the owner or a send log says it was sent.
- Proof: the file that shows the result, then the word `contains`, then a few words copied exactly from that file in double quotes. Example: `email-manager/runs/2026-11-20/06_log.md contains "Check result: all checks passed"`. Use a file that the next run does not overwrite, such as a file in your run folder.

Rules:
- Add lines at the bottom. Never edit or delete a line, yours or another agent's.
- To fix a line, add a new line whose Job starts with `corrects AL3` (the code the Scoreboard gave the old line), then the job.
- Replace any pipe character in a cell with a slash.
- No passwords, keys or tokens.

| When | Agent | Job | Result | Proof |
|---|---|---|---|---|
