# 00_onboarding: learn the owner's time once

Runs the first time, or when the owner says "redo setup". Goal: fill `time-manager/config.json` so no stage asks these again, then build the first two weeks of the calendar. Paths start from the `ceo-ai-toolkit` folder.

## Inputs
- `time-manager/setup/questionnaire.md` (the questions, in order, at most five)
- `time-manager/config.json` (the file you fill)
- `chief-of-staff/_shared/owner-profile.md`, only if it exists and says `setup_done: yes`

## Process
1. Check the clock (SR2).
2. If the Chief of Staff's owner profile is done, copy name, time zone, work hours, protected hours and calendar choice into `config.json`. Say in one line what you copied. If it is not done, or does not exist, you are alone: ask all five questions.
3. Say one line: "I'm your Time Manager. I'll ask you [N] short questions, one at a time. Say 'skip' to use the default." N is the number you still need to ask, never more than five.
4. Read `setup_step` in `config.json`. It is the number of the last question the owner answered (0 when none). Start at the next owed question after `setup_step` (the questions skipped under the Chief of Staff, listed in step 5, are not owed). Never re-ask an answered one, even if its setting is "none" or empty.
5. Ask one question per turn. Offer the default in brackets. Write each answer into `config.json` right away, and set `setup_step` to that question's number in the same write. Under the Chief of Staff, set `setup_step` to 1 after copying the profile answers (question 1 is covered), so a stop before the focus question resumes there. Questions 1, 3 and 5 are skipped under the Chief of Staff (`questionnaire.md`), so the next one asked is 2, then 4.
6. "Skip" means use the default. For a required question (no default), ask once more in simpler words. If they skip again, write the word `not given` in the note you give the owner and go on without it. A missing name is replaced by "you".
7. Check each time you write: times are 24 hour `HH:MM`, days are `mon` to `sun`, the time zone is a name like `America/Chicago`. If the owner gives "2 PM", write `14:00`.
8. Set `"setup_done": true` only after the last question you owe has been answered or skipped (question 5 alone, question 4 under the Chief of Staff) and `owner_name`, `time_zone` and the hours are valid. Never set it earlier. `CLAUDE.md` re-enters this stage only while it is false, so an early true would skip the questions still owed.
9. Build the first two weeks. This is yellow work. Run `python3 time-manager/scripts/calendar_tools.py roll --dry-run`, show the owner the days it will add, then run it without `--dry-run`. In connected mode, read the calendar for the next `horizon_days` days into `time-manager/calendar/calendar.md` instead (stage 01 step 2). Rows built by `roll` are the starting calendar (setup rows), not blocks you placed, so they get no `added` row in `changes-log.md`. Have the result reviewed (stage 03, which says what a setup roll review checks), add a decision log row with `review: pass`.
10. Under the Chief of Staff, skip this step and the offer in step 11 to block the Top 3. The first brief runs you. Alone: write the first report (stage 05), so the report check can pass. Then run `python3 time-manager/scripts/calendar_tools.py check`. Fix anything it names.
11. Tell the owner in one line what you set up. If the owner has a Top 3 ready, offer to block it now. Otherwise say what to say next ("plan my day").

## Output
- `time-manager/config.json` with `setup_done: true`.
- `time-manager/calendar/calendar.md` covering today and the next 13 days.
- `handoffs/time-manager-report.md`, dated today.
- One decision log row for the setup and one for the first calendar build.

## Human check
The owner reads the one-line summary and the first two days, and can correct any answer. A correction updates `config.json` and adds a lessons line.

## Redo setup
Copy the current `config.json` to `time-manager/archive/config-YYYY-MM-DD.json`. Reset every setting to its starting value and `setup_done` to `false`, then run this stage from step 1, offering the old answers as defaults. Never touch `time-manager/calendar/calendar.md` during a redo. Ask before rebuilding it.
