# 00_onboarding: map

| File | One line |
|---|---|
| `CONTEXT.md` | First-run setup: fill `config.json`, build the first two weeks |
