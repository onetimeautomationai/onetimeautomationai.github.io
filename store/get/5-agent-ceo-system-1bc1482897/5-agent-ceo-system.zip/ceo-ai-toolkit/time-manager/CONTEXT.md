# Pipeline

Paths start from the `ceo-ai-toolkit` folder. The Time Manager runs two loops, and both use the same six stages.

## Loop A: one owner request

An ask such as "block Thursday morning for the proposal", "add the dentist Friday at 3", or "find me a time for a 30 minute call". Start it by copying `time-manager/_templates/run/` to `time-manager/runs/YYYY-MM-DD-short-name/`.

## Loop B: the daily run

The first session of the day, the Chief of Staff's morning job, or "plan my day". Folder name: `time-manager/runs/YYYY-MM-DD-daily/`. If the Top 3 was not ready at the first run, run again later the same day as `YYYY-MM-DD-daily-2` for "block the Top 3".

Once a week (or whenever the horizon is short), the daily run also rolls the calendar forward in stage 01.

## The six stages

| # | Stage | Output in the run folder | Human check |
|---|---|---|---|
| 01 | collect | `01_collect.md` | none, logged the same turn |
| 02 | slot | `02_slot.md` | none, unless a question is open |
| 03 | guard | `03_guard.md` | AI review for yellow work, the owner's yes for red |
| 04 | place | `04_place.md` | the owner's yes before any red item is placed |
| 05 | report | `handoffs/time-manager-report.md` (not in the run folder) | none |
| 06 | log | `06_log.md` | `calendar_tools.py check` passes |

Small asks ("what is open Thursday?") go 01, then a one-line answer, then 06. Write "lookup only" in `02_slot.md`.

**Stable every run:** everything in `time-manager/_shared/` and `time-manager/config.json`.
**New every run:** `time-manager/runs/`, the calendar files, rows in the decision log, `handoffs/time-manager-report.md`.

Every stage reads `time-manager/_shared/standing-rules.md` and the lessons file first.
