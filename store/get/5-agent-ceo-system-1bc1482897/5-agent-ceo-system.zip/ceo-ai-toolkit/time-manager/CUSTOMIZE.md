# Change how your Time Manager works

The easy way: tell it. "From now on, no calls before 10." It adds a line to `_shared/lessons.md` and follows it from then on. A new lesson never moves a fixed meeting that is already on the calendar. It flags that meeting under Warnings and leaves the decision to you.

## Safe to change

| What | Where |
|---|---|
| Work days and hours, protected time, fixed weekly times, time zone | `config.json` (or say "redo setup") |
| Your sharpest focus time | `config.json`, `focus_hours` |
| How long a Top 3 block is when nobody said | `config.json`, `default_block_minutes` (starts at 60) |
| Gap left between blocks | `config.json`, `buffer_minutes` (starts at 10) |
| When it warns you a day is too full | `config.json`, `overload_booked_percent` (starts at 80) and `min_open_minutes` (starts at 60) |
| The shortest open gap it counts as open time | `config.json`, `min_window_minutes` (starts at 15) |
| How many days ahead it keeps your calendar | `config.json`, `horizon_days` (starts at 14) |
| The tag on events it creates in Expert | `config.json`, `event_tag` (starts at `TM`) |
| Which calendar it uses | `config.json`, `calendar_mode` and `calendar_name`, or say "Connect my calendar" |

Times in `config.json` are 24 hour, like `14:30`. Days are `mon` to `sun`. A protected window or fixed weekly time looks like this:

```
{"name": "Lunch", "days": ["daily"], "start": "12:00", "end": "13:00"}
```

In `config.json`, `days` is always a list (`["daily"]`, never a string), or the check fails K1.

Add `"people": true` to a fixed weekly time that has another person on it.

## Change with care (your Time Manager asks for your yes and keeps a snapshot first)

| What | Why |
|---|---|
| `_shared/decision-tiers.md` | You can add things to red any time. Moving anything down needs your direct yes. Sending, posting, publishing, paying, buying, deleting and booking with other people always stay red |
| `_shared/time-rules.md`, `_shared/standing-rules.md`, `system.md` | These keep your calendar and accounts safe. Add to them. Think twice before removing a line |
| `_shared/handoffs.md` | The other hires read these formats. Change one and the hire that reads it must change too |
| `scripts/calendar_tools.py` | The checks catch double booking, protected time, missing approvals and skipped reviews. Keep K4, K5, K8 and K9 |
| `_shared/review-rubric.md` | What the reviewer checks. Add lines freely. Removing one lets more mistakes reach you |

## Do not edit by hand

`_shared/decision-log.md` is append only. To fix a row, ask your Time Manager to add a "corrects L#" row.

## Watch memos

The bonus Watch-to-AI Team Edition is a separate add-on in the `bonus-watch-to-ai/` folder. It lets you say "Block Friday morning for proposals" into your Apple Watch. Your Chief of Staff hands that to the Time Manager as a normal job. Nothing about the Time Manager changes. The Time Manager answers "What now?" from the calendar and the real clock when you ask.
