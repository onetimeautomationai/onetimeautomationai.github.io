# Install

Pick one path. Basic needs no terminal and no calendar connection. Expert connects your own calendar.

## Basic (no terminal)

1. Download and unzip the toolkit. Put the `ceo-ai-toolkit` folder anywhere you like, for example your Documents folder.
2. Load the `ceo-ai-toolkit` folder into your favorite AI agent platform (open the agent in that folder).
3. Say: **"Start my Time Manager."**
4. Answer the questions one at a time (five at most). Say "skip" to use the default. It saves each answer as you go. If you already set up the Chief of Staff, it asks only what your profile does not answer.
5. When it says setup is done, it has built your first two weeks in `time-manager/calendar/calendar.md`. Say **"Plan my day"** to see today.

If your agent only has a box for a system prompt or custom instructions and cannot open folders, paste `time-manager/INJECT-PROMPT.md` into that box instead. You get the Time Manager without the files, so it cannot keep a calendar between chats. It plans in the chat and you copy the result.

## Expert (your own calendar)

Do Basic first, then:

1. **Connect your calendar** in your AI agent's settings (its connectors or plugins). Only the Time Manager uses it.
2. Say: **"Connect my calendar."** Your agent follows the safe change rules below, then:
   - lists the calendars it can see, and asks which one to use,
   - sets `calendar_mode` to `connected` and `calendar_name` in `time-manager/config.json`,
   - reads the next 14 days into `time-manager/calendar/calendar.md` as a mirror,
   - creates one test event titled `TM: test, safe to delete` for tomorrow, with no attendees, reads it back, and asks you to delete it yourself. The Time Manager never deletes.
3. **Run it on a schedule**, if your agent supports scheduled tasks. Make one task that opens the `ceo-ai-toolkit` folder and says "Plan my day" at your morning time. If you use the Chief of Staff, its morning job already runs the Time Manager, so you do not need this. Your agent follows the safe change rules before it creates the task.
4. **Turn on the script**, if your agent can run commands. From the `ceo-ai-toolkit` folder, run `python3 time-manager/scripts/calendar_tools.py check`. Before setup is done, it fails its first check (K1). That is expected.

Events the Time Manager creates start with `TM:` (you can change the tag in `config.json`). It only ever moves events with that tag. It never changes an event you made.

## Safe change rules

The AI follows these for any change outside the `ceo-ai-toolkit` folder (your calendar, scheduled tasks, your agent's settings or rules file), and for any change to the Time Manager's rules files (`system.md`, `_shared/decision-tiers.md`, `_shared/time-rules.md`, `_shared/standing-rules.md`).

1. If it cannot read and write files here, it says so and gives you manual steps instead.
2. Before changing anything, it tells you the time and lists every file and outside item it will create or change. It waits for your yes.
3. It copies each existing file it will change into `.ceo-toolkit/snapshots/time-manager-<YYYYMMDD-HHMMSS>/`, keeping its path. For calendar events it will change, it writes their title, calendar, start and end into `events-before.md` in the same folder. It adds a row to `.ceo-toolkit/install-log.md`: time, action, snapshot, files changed, files created, notes. It creates the log with a header row if it is missing.
4. It never overwrites your agent's own rules file. It adds a block between `<!-- ceo-toolkit:time-manager:start -->` and `<!-- ceo-toolkit:time-manager:end -->` instead.
5. It never deletes your data, never deletes a calendar event without your yes, and never deletes anything in `.ceo-toolkit/`.

`.ceo-toolkit/` lives in the `ceo-ai-toolkit` folder. It is your record of every change.

## Switch from Expert back to Basic

Say "Switch to the plain file calendar." It sets `calendar_mode` to `plain-file`, keeps the mirror as your plan, and stops touching your connected calendar. Events it already created stay where they are. You can delete the ones tagged `TM:` yourself, or ask it to list them.
