# Time Manager

Your AI Time Manager builds your calendar and protects it. You decide what matters, and it blocks the time.

It puts time on your calendar for your Top 3, places the dates your Email Manager finds in your inbox, keeps your protected hours clear, and warns you when a day is too full. It never invites anyone, and it never deletes anything without your yes.

## What it does for you

| When | What you get |
|---|---|
| Morning | Today's calendar and your open time, with a block for each of your Top 3 |
| During the day | Say "block Thursday 9 to 10 for the proposal" and it is on your calendar. Say "find me a time" and it offers open slots |
| When email has a date in it | It places a date that is only yours (a deadline, your dentist). A meeting with another person waits for your yes |
| Any time | A warning when a day is overloaded or your protected time is at risk |

## Two ways to use it

| | Basic | Expert |
|---|---|---|
| Your calendar | A plain file in this folder that you can read, `calendar/calendar.md` | Your own connected calendar, reached through your AI agent |
| Needs | Nothing but your AI agent | Your calendar connected to your AI agent |
| Your part | Copy blocks into your own calendar if you want them there | Nothing. Blocks appear on your calendar with a `TM:` tag at the start of the title |

Start with Basic. You can switch to Expert later.

## Who it works with

| Hire | What the Time Manager does with it |
|---|---|
| Chief of Staff | Gives it jobs and reads its report. Without a Chief of Staff, you talk to the Time Manager yourself |
| Email Manager | Reads the dates it finds in email, places the ones that are only yours, and holds the rest for your yes |
| Focus Manager | Reads your Top 3 and blocks time for each item. The Focus Manager reads your open time |

Each hire is optional. The Time Manager works alone, and it tells you what it could not see.

## Install in 3 steps

1. Put the `ceo-ai-toolkit` folder anywhere on your computer. The `time-manager` folder is inside it.
2. Load the `ceo-ai-toolkit` folder into your favorite AI agent platform (open the agent in that folder).
3. Say: **"Start my Time Manager."** It asks you up to 5 questions, one at a time, and saves your answers. If you use the Chief of Staff, it asks only what your profile does not already answer.

Full steps: `INSTALL.md`. What you need first: `REQUIREMENTS.md`.

## What to say

See `wake-phrases.md`. The ones you will use most:
- "Plan my day" for today's calendar and open time.
- "Block [day] [time] for [thing]."
- "What now?" for the block you are in.

## How it earns your trust

Every piece of work gets a light. Green: small and reversible, it does it. Yellow: blocking your own time. An AI reviewer checks it before it lands. Red: anything with another person, anything in your protected time, moving something you made, or deleting. Red waits for your yes.

## What it will never do

It never sends an invite, a reply, an accept or a decline. It never puts another person on an event. It never deletes an event or schedules over your protected time without your yes. Your plans stay in this folder on your computer.

## More

- How it works inside: `docs/how-it-works.md`
- A sample day: `examples/sample-day.md`
- What you can change: `CUSTOMIZE.md`
- What it cannot do yet: `known-limitations.md`
- Help: `SUPPORT.md`
- Remove it: `UNINSTALL.md`

Version 0.1.14, 2026-11-21. Changes: `CHANGELOG.md`.
