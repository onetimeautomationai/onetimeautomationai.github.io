# What you need

## Required
- **An AI agent that can read and write files in a folder on your computer.** A chat window that cannot open files is not enough. The setup guide in the toolkit lists the agents we have tested.
- **This folder on your computer.** Your calendar plan, your settings and your decisions live here.

## Needed for Expert
- **A calendar your AI agent can reach** (through a connector or plugin). It must be able to list events, read an event, and create an event with no attendees. Without one, use Basic. The Time Manager keeps your two-week plan in a file, and you copy the blocks into your calendar yourself.

## Needed for the full team
- **The other hires are optional.** The Email Manager gives it dates from your inbox. The Focus Manager gives it your Top 3. The Chief of Staff gives it jobs. Without them, you tell the Time Manager directly.

## Optional
- **Python 3**, if your agent can run commands. One small script uses it. Without it, your agent does the same steps by hand.

## You do not need
- To write code.
- A subscription. You pay once and keep every file.
- Any other app.

## Tested with

| Agent | Model | Date | Result |
|---|---|---|---|
| Not yet tested | | | First draft. Walk tests are listed in `tests/acceptance-criteria.md` |

Model updates can change how an agent behaves. Before you switch to a new model, run the test cases in `tests/test-cases.md` and compare.

## Before you buy, check
1. Can your AI agent open a folder and edit a file in it?
2. For Expert: can it list and create events in your calendar?
3. Are you OK with your AI placing blocks of your own time without asking each time, while anything with another person waits for your yes?
