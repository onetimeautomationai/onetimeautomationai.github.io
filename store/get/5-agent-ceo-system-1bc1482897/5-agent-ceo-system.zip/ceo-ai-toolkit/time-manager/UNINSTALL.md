# Remove the Time Manager

## The simple way
Delete the `time-manager` folder. Nothing else on your computer depends on it. Your other hires keep working, but nobody keeps your calendar plan or writes `handoffs/time-manager-report.md`. If you did the Expert install or let it change anything outside the folder, use the next section instead.

Keep a copy of `calendar/`, `runs/` and `_shared/decision-log.md` first if you want your history.

## If your AI made changes outside the folder
Say: **"Uninstall the Time Manager."** Your AI then:

1. Copies your data (`calendar/`, `runs/`, `config.json`, `_shared/`) and anything it will remove into `.ceo-toolkit/removed/time-manager-<YYYYMMDD-HHMMSS>/`.
2. Restores each file it changed from its snapshot in `.ceo-toolkit/snapshots/`.
3. In shared files, removes only the block between `<!-- ceo-toolkit:time-manager:start -->` and `<!-- ceo-toolkit:time-manager:end -->`. Other hires' blocks stay.
4. Reads `calendar/changes-log.md` and lists every calendar event it created (the ones whose title starts with your `TM:` tag), plus any scheduled task it made. It asks you before touching each one. It removes an event only on your yes, one event at a time, and only events it created. It never removes an event you made.
5. Adds a row to `.ceo-toolkit/install-log.md` and tells you what was restored, removed and kept.

Say **"Show what uninstalling would change"** to see the list without changing anything.

## Roll back one change
Each snapshot folder in `.ceo-toolkit/snapshots/` holds the files as they were before that change. Say "Roll back the change from [time]" and your AI restores those files, and lists the calendar events from `events-before.md` so you can see what they looked like.

## What stays on your computer
Everything in `.ceo-toolkit/` stays. It is your record. Your toolkit files are never sent to us, so there is nothing to delete anywhere else.
