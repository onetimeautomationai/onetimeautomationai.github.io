# Time Manager: map

Paths start from the `ceo-ai-toolkit` folder.

| Path in `time-manager/` | One line |
|---|---|
| `CLAUDE.md` | Start file for the AI: first-run check, routes, rules that never bend |
| `CONTEXT.md` | The two loops and the six stages |
| `system.md` | The AI's full operating rules |
| `config.json` | The owner's settings: time zone, hours, protected time, calendar choice |
| `README.md` | The owner's one-page guide |
| `REQUIREMENTS.md` | What you need, tested-with record |
| `INSTALL.md` | Basic and Expert install, safe change rules |
| `UNINSTALL.md` | Safe removal and rollback |
| `CUSTOMIZE.md` | What you can change and where |
| `permissions.md` | What it can read and write |
| `known-limitations.md` | What it cannot do yet |
| `SUPPORT.md` | Help and the update promise |
| `LICENSE.md` | Use and resale terms |
| `CHANGELOG.md`, `manifest.json` | Version, file list, checksums |
| `wake-phrases.md` | What to say |
| `INJECT-PROMPT.md` | One-paste version for agents without folders |
| `00_onboarding/`, `setup/` | First-run setup, at most 5 questions |
| `_shared/` | Stable files every stage reads |
| `calendar/` | The plan: calendar, waiting items, ledger, changes log, archive |
| `stages/` | 01 collect, 02 slot, 03 guard, 04 place, 05 report, 06 log |
| `_templates/` | Run starter, output templates, a blank calendar day |
| `runs/` | Run history |
| `scripts/` | `calendar_tools.py` (check, day, roll) |
| `docs/` | How it works |
| `examples/` | A sample day with made-up data |
| `tests/` | Test cases, acceptance criteria, judge rubric |
