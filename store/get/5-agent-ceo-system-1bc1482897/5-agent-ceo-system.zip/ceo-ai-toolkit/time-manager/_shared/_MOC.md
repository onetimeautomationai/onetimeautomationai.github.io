# _shared: map

| File | One line |
|---|---|
| `time-rules.md` | TR1 to TR16, how the Time Manager decides when things happen |
| `standing-rules.md` | SR1 to SR14, read by every stage |
| `decision-tiers.md` | The trust lights (green, yellow, red), the safety floor, calendar examples |
| `review-rubric.md` | How yellow work is checked before it lands, and who reviews |
| `adapters.md` | Which tool does which job, and what "connected" means |
| `handoffs.md` | The file formats the Time Manager reads and writes |
| `lessons.md` | Owner corrections, read every run |
| `decision-log.md` | Append-only record of every decision |
