---
type: factory
---

# Adapters

The Time Manager names the job, not the vendor. Onboarding fills in which calendar the owner uses (`calendar_mode` and `calendar_name` in `time-manager/config.json`).

| Job | The owner's tool | Options that work |
|---|---|---|
| Calendar, Basic | The plain file `time-manager/calendar/calendar.md` | No connection needed. The owner copies blocks into their own calendar if they want them there |
| Calendar, Expert | The owner's connected calendar, reached through the owner's AI agent | Any calendar your agent can list, read and create events in. The Time Manager needs three actions: list events, read one event, create an event with no attendees |
| Settings | `time-manager/config.json` | A plain file. No tool needed |
| Top 3 and schedule items | `handoffs/top3-today.md`, `handoffs/schedule-items.md` | Files. The Focus Manager and the Email Manager write them |
| Run small scripts | Python 3, if your agent can run it | Optional. Every script step can also be done by hand (`time-manager/scripts/README.md`) |

The Time Manager never reaches email, files outside the toolkit folder, or anything else. Paths start from the `ceo-ai-toolkit` folder.

## What "connected" means here

The agent reads the owner's calendar for the next `horizon_days` days and writes it into `time-manager/calendar/calendar.md` as a mirror, so every check and report works the same in both modes. In connected mode the real calendar is the truth and the file is rebuilt from it. Events the Time Manager creates carry the `event_tag` at the start of the title (default `TM: `), and only those may be moved later.
