---
type: log
rule: append only. Never edit or delete a row.
---

# Decision log

Every decision the Time Manager makes or records goes here before it is reported. Rows are numbered L1, L2, L3. (Waiting items like P1 are in `time-manager/calendar/pending.md`. L numbers are log rows. They are different.) This is the Time Manager's own log. Under the Chief of Staff, the Chief of Staff keeps its own log for the owner's answers it records on the board.

- **Tier:** T1, T2 or T3 (`time-manager/_shared/decision-tiers.md`). Anything that sends, posts, publishes, pays, buys, deletes, cancels, invites, or puts a meeting with another person on the calendar is T3.
- **How the check reads the Decision:** a Decision that starts with `Block` is time for the owner alone, so the check looks only for calendar words (send, invite, cancel, delete, decline, meeting with, call with, attendee, pay, buy, invoice, contract). Write "Block 9:00 to 10:00 Thursday for Top 3 #1". Refer to a Top 3 item by its number only ("for Top 3 #1"), never by its words, so a task name such as "send proposals" does not trip the check. Any other Decision is checked against the full list (send, post, publish, pay, buy, delete, book, hire, contract, website, invite and so on), and a hit must be T3.
- **Owner's words:** required for a T3 row whose Result is `done`, copied exactly. Leave it empty while you wait, and set Result to `pending`.
- **Result:** one of `done`, `pending`, `parked`, `no`.
- **Decision:** start with `Owner task:` when the owner will do it themselves. If the Evidence says you found a sent message, the row is not an owner task, so the check fails it.
- **Evidence:** for a T2 (yellow) row marked done, write exactly `review: pass (separate)` when a separate reviewer passed it, or exactly `review: pass (self)` when you checked it yourself (`review-rubric.md`). Put any note after it, after a space or a comma, never inside the brackets. The check fails a bare `review: pass` or text inside the brackets, and warns on `(self)`. Also write the run folder name.
- **Time:** the date and clock time when you write the row, `YYYY-MM-DD HH:MM` in the owner's time zone (the run's clock time). It is never the date or time of the block. The check fails a Time later than the run clock.
- **Parked T3 rows:** a row with Result `parked` that waits on the owner comes back in the next report under `## Waiting on your yes` (add it to `pending.md` as a `waiting` row in stage 04 step 2 so stage 05 lists it).
- **Held asks:** a Decision that starts `Held:` that names another person is T3 with Result `pending` (SR14).
- **To fix a row:** add a new row whose Decision starts with `corrects L#` (for example "corrects L4: owner said yes"). The check script then reads the new row instead of the old one.

`time-manager/scripts/calendar_tools.py check` enforces all of this (check K8).

| L# | Time | Decision | Tier | Why | Evidence | Owner's words | Result |
|---|---|---|---|---|---|---|---|
