---
type: factory
---

# Decision tiers (the trust lights)

Every piece of work gets a light by how far a mistake could reach. Nothing leaves without being checked first. If `chief-of-staff/_shared/decision-tiers.md` exists, it is the master copy and wins on any difference. This copy lets the Time Manager work alone.

| Light | Tier | What it covers | What happens |
|---|---|---|---|
| Green | T1 | Internal, reversible, small. Reading the calendar, working out open time, writing the report, archiving past days, a changes log line. The owner's own tasks ("I will call the dentist myself") count here too. Log them with a Decision that starts `Owner task:` | Done and logged. Must pass the hard checks |
| Yellow | T2 | Reversible and internal, but it changes the owner's day. Blocking time that holds no other person (the Top 3, focus time, a personal reminder). Moving a block you placed. Building or extending the calendar when the owner asks (a setup build or a roll request). The automatic daily roll in stage 01 adds setup rows only and is green, so it needs no review | **AI review first.** A reviewer checks it against the job and `time-manager/_shared/review-rubric.md` before it lands. Pass: done, logged, owner told. Fail: sent back once. Fails twice: becomes red |
| Red | T3 | Anything that reaches another person (an invite, a reply, a meeting, an event with an attendee), anything in protected time or outside work hours, moving or changing an event the owner made, deleting, a new recurring commitment, a change to work hours or protected hours, money of any size | **The owner steps in.** Recommend with the reason, then wait for the owner's words |

When unsure, use the next light up.

## The floor (cannot be changed by setup or lessons)

Sending, posting, publishing, paying, buying, deleting, and booking with other people are always red. For the calendar this means: no invite, no reply, no accept, no decline, no attendee on any event, and no deleting, ever, without the owner's yes. The owner can add more items to red. Moving anything down from red needs the owner's direct yes, logged as a red decision, and never applies to the items in this paragraph.

## Green grows only when it is earned

Work starts at the light above. A kind of yellow work can move to green only after 10 reviews in a row pass with no fix needed, and only with the owner's yes, logged as red. Any later miss moves it back to yellow.

## Examples

| Request | Light | Why |
|---|---|---|
| "Block 9 to 10 tomorrow for the proposal" | Yellow | Only the owner is on it |
| "Put the dentist Friday at 3 on my calendar" | Yellow | Only the owner is on it |
| "Block 30 minutes to call Priya back" | Yellow | Time for the owner to make a call. No time was agreed with Priya and nobody is invited |
| "Add the call with Priya Thursday at 2" | Red | A time agreed with another person. Placed only after the owner's yes, with no invitation |
| "Block 7 PM Thursday" when 6 to 8 PM is protected | Red | Protected time |
| "Move my client review to Friday" (the owner made it) | Red | An event the owner made |
| "Cancel Tuesday's block" | Red | Deleting |
| "Make Fridays a work day" | Red | A change to the owner's rules |
