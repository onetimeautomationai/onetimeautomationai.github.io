---
type: factory
---

# Handoff formats the Time Manager uses

This is a copy of the formats the Time Manager reads and writes, so it can work alone. If `chief-of-staff/_shared/handoffs.md` exists, that file is the master and wins on any difference. Each hire overwrites only its own files. Nobody edits another hire's file.

Every report starts with this header:

```
---
from: <hire folder name>
updated: YYYY-MM-DD HH:MM (owner's time zone)
status: ok | partial | failed
---
```

**Fresh** means `updated` is today.

## time-manager-report.md (the Time Manager writes. The Chief of Staff, the Focus Manager and the Email Manager read)

The two sections below are the shared format and must stay exactly as written. The Time Manager adds extra sections after them. Readers that do not know the extra sections ignore them.

```
## Today
| Start | End | Block | Fixed or movable |

## Open time today
- Total hours open, and when
```

Header: `from: time-manager`. In the Today table, list every row of the day from the calendar file, protected windows inside the work day included. Under "Open time today" write one line in this form: `- Total: 3.5 hours open. When: 10:30 to 12:00, 13:00 to 15:00`. The command `python3 time-manager/scripts/calendar_tools.py day` prints both pieces ready to paste.

Extra sections the Time Manager adds, each only when it has something to say:

```
## Waiting on your yes
| P# | What | When | Who | My recommendation |

## Warnings
- <day>: <what is wrong and the one move recommended>

## Schedule items handled
| Found in email | What | Date and time | Result: placed / waiting / skipped | Note |

Every run carries this section when the ledger has any row handled today. It lists every `schedule-ledger.md` row handled today, from every run today, not only the latest run. Found in email is the same cell as in `schedule-items.md`. The Email Manager matches a line to its row by Found in email plus What, and reads it at its next run, from a report dated today or yesterday.

## Missing
- missing: <what>
```

## top3-today.md (the Focus Manager writes, or the Chief of Staff if no Focus Manager. The Time Manager reads it)

```
## Top 3 for YYYY-MM-DD
1. <item> : result that counts as done
2. <item> : result
3. <item> : result

## One result per block
| Block | Result that counts as done |
```

The Time Manager blocks the date in the heading, not the date of the file's `updated` line. The Time Manager picks the block times. If the "Block" column names a time, the Time Manager treats it as a preference, keeps its own block length (TR3), checks it against the calendar, and never places a block in time that has already passed.

## schedule-items.md (the Email Manager writes. The Time Manager reads it)

```
| Found in email | What | Date and time | Who | Status: new / placed / skipped |
```

The Time Manager does not edit this file. It records what it did with each row in `time-manager/calendar/schedule-ledger.md` and in the "Schedule items handled" section of its report.

## jobs.md (the Chief of Staff writes the rows. Each manager sets the status of its own rows)

```
| Job# | For | Job | Write result to | Due | Light | Status: open / done / waiting: reason |
```

The For cell is the hire's folder name, for example `time-manager`. The Time Manager changes only the Status cell of rows where For is `time-manager`.
