---
type: factory
---

# Lessons

Every correction the owner gives becomes one line here, the same turn. The Time Manager reads this file before it starts. Under the Chief of Staff, the Chief of Staff's own `chief-of-staff/_shared/lessons.md` is read too, and corrections about the whole team go there. Newest at the bottom.

| Date | The owner said (exact words) | What we do from now on |
|---|---|---|
