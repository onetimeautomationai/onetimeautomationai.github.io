---
type: factory
---

# Review rubric (yellow work)

The reviewer sees: the job row or the owner's ask, `02_slot.md` (what is about to be placed), the source files the job used (`handoffs/top3-today.md`, `handoffs/schedule-items.md`, `time-manager/calendar/calendar.md`, `time-manager/config.json`, and `time-manager/stages/04_place/CONTEXT.md` for how a yes is placed or removed, and `time-manager/_shared/time-rules.md` for TR10 and the other rules the work follows), `time-manager/_shared/lessons.md` and the Chief of Staff's lessons if they exist, and this rubric. It never sees the chat. It scores each line pass or fail.

| # | Check | Fail when |
|---|---|---|
| RR1 | Does it do the job as written? | Missing part of the job, or did more than asked |
| RR2 | Are the facts true? | A date, time, name or length contradicts the source files, or is not in them. A fact found in a source passes |
| RR3 | Does it follow the lessons and the owner's settings? | Breaks a lesson, the work hours, a protected window, or the focus hours |
| RR4 | Is the light right for what happens next? | The output would invite, reply to, accept, decline, delete, or put another person on an event, or touch an event the owner made, without the owner's yes |
| RR5 | Is it ready for the owner to see? | Unclear, too long, the most important line not last |
| RR6 | Does it fit the calendar? | Double books, lands in protected time without Source `owner-ok`, leaves under `min_open_minutes` (open minutes are the `day` command's Total for that day, in minutes, never capacity minus booked worked out by hand), takes the day over `overload_booked_percent` of its capacity (work hours minus named protected windows, as in TR14) unless the owner asked for that block directly and the warning is written (TR6), or lands on the wrong date or weekday |

**Pass:** all six pass. Write `review: pass (separate)` in the decision log Evidence column when a separate reviewer passed it, or `review: pass (self)` when you checked it yourself.
**Fail:** list the failed lines and one fix each. The work goes back once. A second fail makes it red: the owner sees it with the reviewer's notes.

## Who reviews

1. **Best:** a separate helper agent with a fresh start, on a different AI model if the owner's agent allows. Its first line: "Read time-manager/_shared/review-rubric.md before anything else. You are the reviewer." Under the Chief of Staff it also reads `chief-of-staff/worker.md`.
2. **Fallback:** if the agent cannot start helpers, the same agent does a separate review pass with this rubric, reading only the files listed at the top. This is weaker, because it checks its own work. `known-limitations.md` says so.
