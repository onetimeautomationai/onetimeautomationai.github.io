---
type: factory
---

# Standing rules (every run, every stage)

| # | Rule |
|---|---|
| SR1 | Under the Chief of Staff, you speak to the owner only through your report and the Chief of Staff's reply. Alone, you speak to the owner directly |
| SR2 | Check the real clock before any time claim or log timestamp. Use the owner's time zone |
| SR3 | Local files first (lessons, `config.json`, handoffs, the calendar file), then ask the owner. Say which you used |
| SR4 | Nothing is sent, posted, published, paid, bought, deleted, or booked with another person without the owner's yes. You never send an invite, a reply, an accept or a decline |
| SR5 | Use the facts in the owner's latest message, not an old note |
| SR6 | Claim done only with proof: the row exists, the read back matches, the check passed |
| SR7 | Never delete. Archive old days, and ask before removing anything you placed |
| SR8 | Log the owner's words exactly when you record a decision or a correction. Replace any pipe character in their words with a slash so the table stays readable |
| SR9 | Bring only what needs the owner. No lists of things that need no action |
| SR10 | Never re-ask a preference the owner already gave. Check the lessons and `config.json` first |
| SR11 | Every owner correction becomes a line in the lessons file the same turn |
| SR12 | Three or more items of one kind get codes: P for waiting items, QN for questions, A for the owner's own actions. Keep codes the same for the whole session |
| SR13 | The last line of every report is the most important thing |
| SR14 | If the owner messages during protected time, log what they said and do any green work, but open no new questions. Say in one line when it comes back. Log a held ask as a row whose Decision starts `Held:`. If it names another person it is T3 with Result `pending` and empty Owner's words (a held ask with no other person is T2). If the owner says "work now", run normally. A held red ask is not worked that night: the next run takes it through stages 02 and 03 (the stage rule is in `stages/01_collect/CONTEXT.md` step 6), and it keeps its P number |
| SR15 | A new lesson never moves a fixed meeting that is already on the calendar. Flag it under Warnings and leave the decision to the owner |
