# _templates: map

| Path | One line |
|---|---|
| `run/01_collect.md` | Copied into each new run folder |
| `outputs/02_slot.md` | Slot stage output |
| `outputs/03_guard.md` | Guard stage output |
| `outputs/04_place.md` | Place stage output |
| `outputs/05_report.md` | The report written to `handoffs/time-manager-report.md` |
| `outputs/06_log.md` | Log stage output |
| `outputs/calendar-day.md` | One calendar day, for adding a day by hand |
