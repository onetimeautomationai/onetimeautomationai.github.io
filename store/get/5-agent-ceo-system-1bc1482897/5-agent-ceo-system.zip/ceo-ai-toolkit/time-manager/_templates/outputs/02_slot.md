# Slot

Placement table: yellow and green items only. A red item never goes in this table.

| C# | Item | Day | Start | End | Type | Fixed or movable | Source | Light | Why this slot |
|---|---|---|---|---|---|---|---|---|---|

## Proposals for pending.md (red, not placed)
| P# | Date and time | What | Who | Why red |
|---|---|---|---|---|

lookup only: yes / no

## Questions for the owner
- QN1:
