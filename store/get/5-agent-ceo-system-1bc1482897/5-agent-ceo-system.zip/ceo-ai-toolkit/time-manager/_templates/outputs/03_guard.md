# Guard

| C# | Light | Review: pass / fail / not needed | Fix made | Result: pass / fixed after review / red / missing |
|---|---|---|---|---|

## Hand checks
- No overlap:
- Inside work hours, outside protected windows:
- Dates and weekdays match the source:
- Open time kept, day not overloaded:
- No other person on a yellow row:

## Reviewer notes
- Write the reviewer's notes here, or `none`:

## Warnings
- <day>: <what is wrong>, one recommended move
