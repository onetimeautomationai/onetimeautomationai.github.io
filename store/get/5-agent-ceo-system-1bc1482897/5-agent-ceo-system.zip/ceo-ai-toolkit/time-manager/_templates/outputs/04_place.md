# Place

## Placed
| C# | Day | Start | End | Block | Where: plain file / calendar name | Proof |
|---|---|---|---|---|---|---|

## Waiting on the owner
- P1:

## Owner answers handled
| P# | Owner's words (exact) | Placed | Log L# |
|---|---|---|---|

## Check
- calendar_tools.py check result:
- Read back of connected events (Expert):
