---
from: time-manager
updated: {{YYYY-MM-DD HH:MM}}
status: ok
---

## Today
| Start | End | Block | Fixed or movable |
|---|---|---|---|

## Open time today
- Total: 0 hours open. When: none

<!-- Delete every section below this line that has nothing in it, and this note. Only Today and Open time today always stay. -->

## Waiting on your yes
| P# | What | When | Who | My recommendation |
|---|---|---|---|---|

## Warnings
- <one line per warning>

## Schedule items handled
| Found in email | What | Date and time | Result: placed / waiting / skipped | Note |
|---|---|---|---|---|

## Missing
- <one line per missing item>

<The most important line, usually the one thing for the owner to do first.>
