## YYYY-MM-DD Weekday

| Start | End | Block | Type | Fixed or movable | Source |
|---|---|---|---|---|---|
| 09:00 | 10:00 | Top 3 #1: example item | focus | movable | top3 |

A day with nothing placed has this line instead of the table:

No blocks placed.
