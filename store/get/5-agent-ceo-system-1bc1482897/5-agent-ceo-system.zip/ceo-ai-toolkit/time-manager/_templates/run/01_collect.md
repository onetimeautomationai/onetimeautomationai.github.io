---
run: {{run_name}}
started: {{YYYY-MM-DD HH:MM}}
---

# Collect

## Calendar brought up to date
- Mode: plain file / connected
- Roll or read result:
- Owner edits found and logged:

## Top 3
- Fresh today: yes / no
- missing:

## Things that need time
| C# | Source: top3 / email / owner / job / waiting | What | Date and time wanted | Who else | Size |
|---|---|---|---|---|---|
