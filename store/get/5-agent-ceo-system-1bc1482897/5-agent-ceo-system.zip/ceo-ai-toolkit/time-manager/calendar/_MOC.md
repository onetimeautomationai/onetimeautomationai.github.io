# calendar: map

| File | One line |
|---|---|
| `calendar.md` | The plan, one section per day. The plain-file calendar (Basic) or a mirror of the connected one (Expert) |
| `pending.md` | Red items waiting on the owner's yes. Nothing here is on the calendar |
| `schedule-ledger.md` | What was done with each row from the Email Manager |
| `changes-log.md` | Every move, and every edit the owner made |
| `archive/` | Past days, one file per month, made by `calendar_tools.py roll`. Created on first use |
