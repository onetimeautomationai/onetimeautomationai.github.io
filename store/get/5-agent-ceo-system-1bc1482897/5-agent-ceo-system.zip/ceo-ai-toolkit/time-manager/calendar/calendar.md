# Calendar

The plan the Time Manager keeps. Basic: this file is your calendar. Expert: this file is a mirror of your connected calendar, rebuilt from it on every run.

One section per day, one row per block. Times are 24 hour, in your time zone. Fill-in rules are in `time-manager/stages/04_place/CONTEXT.md`. The script `calendar_tools.py roll` adds new days and archives past ones.

| Column | Values |
|---|---|
| Type | `focus` (a Top 3 or focus block), `fixed` (a commitment at a set time), `meeting` (another person is involved), `protected` (your protected window), `personal` |
| Fixed or movable | `fixed` or `movable` |
| Source | `setup` (from your setup answers), `top3`, `email`, `owner` (you asked), `job` (a Chief of Staff job), `owner-ok` (you said yes to using protected time), `connected` (read from your connected calendar) |

Your own edits are never reverted. Edit any row by hand, and the Time Manager takes your version and logs it.
