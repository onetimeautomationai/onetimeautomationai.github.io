---
type: log
rule: append only. Never edit or delete a row.
---

# Changes log

Every change to a block after it was placed, and every edit the owner made. Uninstalling reads this file to find what the Time Manager created.

Time is the date and clock time when you write the row, `YYYY-MM-DD HH:MM` in the owner's time zone (the run's clock time), never the time of the block. Day is the day of the block. The check fails a Time later than the run clock.

Change is one of: `added`, `moved`, `edited by owner`, `removed with yes`, `corrects`. A misnamed row is fixed with a new `corrects` row (Block is the right name, From the wrong name, Why `corrects the row above`). K12 counts it as the `added` row for that Block. Where is `plain file` or the connected calendar's name.

| Time | Day | Block | Where | Change | From | To | Why |
|---|---|---|---|---|---|---|---|
