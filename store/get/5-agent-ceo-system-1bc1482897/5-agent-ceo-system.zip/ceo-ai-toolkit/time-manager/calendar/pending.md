---
type: board
---

# Waiting on your yes

Red items the Time Manager has prepared and will not place until you say yes. Anything with another person, anything in protected time, moving your own events, and deleting wait here. Nothing in this table is on your calendar.

Status: `waiting`, `yes` (done after your yes: placed, removed, or left to you), `no`, `expired` (the date passed), or `placed` (a yellow ask you made in protected time, put on the calendar at the next work time). A row whose Why starts with `held:` is an ask made in protected time that has not been reviewed yet. If it turns out to be red, it still waits for your yes like any other. Never delete a row. Change its status.

| P# | Date and time | What | Who | Why red | Source | Status |
|---|---|---|---|---|---|---|
