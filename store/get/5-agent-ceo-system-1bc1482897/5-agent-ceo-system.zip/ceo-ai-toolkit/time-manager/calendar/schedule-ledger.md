---
type: log
rule: append only. One row per item the Email Manager found.
---

# Schedule ledger

What the Time Manager did with each row of `handoffs/schedule-items.md`. The Time Manager does not edit that file, so this ledger is how it avoids handling the same row twice. A row is the same row when `What` and `Date and time` match.

| Handled | Found in email | What | Date and time | Who | Result: placed / waiting / skipped | Note |
|---|---|---|---|---|---|---|
