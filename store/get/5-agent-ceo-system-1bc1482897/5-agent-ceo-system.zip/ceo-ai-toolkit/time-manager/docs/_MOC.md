# docs: map

| File | One line |
|---|---|
| `how-it-works.md` | The idea, the flow, the six stages, the trust lights, Basic and Expert |
