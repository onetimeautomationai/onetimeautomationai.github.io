# How your Time Manager works

## The idea
You are the CEO. A CEO decides what matters, and does not drag blocks around a calendar. Your Time Manager takes what you decided matters, finds the time, and puts it on your calendar. It keeps your protected hours clear and tells you when a day is too full.

## The flow

```
Focus Manager ──> handoffs/top3-today.md ──┐
Email Manager ──> handoffs/schedule-items.md ──┤
You ("block Thursday for the proposal") ──────┤
                                              v
                                       Time Manager
                           collect > slot > guard > place > report > log
                                              │
                    ┌─────────────────────────┼──────────────────────────┐
                    v                         v                          v
        your calendar (file or       calendar/pending.md        handoffs/time-manager-report.md
        connected, blocks tagged)    (red items, your yes)      (Chief of Staff and Focus Manager read it)
```

The Time Manager never talks to the Email Manager or the Focus Manager directly. They write short files into the `handoffs/` folder, and the Time Manager reads them.

## Six stages
1. **Collect.** Bring the calendar up to date, then list the Top 3, the dates from email, and what you asked for.
2. **Slot.** One slot and one light for each item. The Top 3 go in your sharpest hours, with a gap between blocks.
3. **Guard.** Check for double booking, protected time and overload. Yellow work gets an AI review.
4. **Place.** Put the reviewed blocks on the calendar. Hold red items for your yes. Prove they are there.
5. **Report.** Write `handoffs/time-manager-report.md` so the rest of the team sees today.
6. **Log.** Record the decisions and run the check.

## Three trust lights
- **Green:** small and reversible. It does it and logs it.
- **Yellow:** blocking time that holds only you. An AI reviewer checks it first. If it fails review twice, it becomes red.
- **Red:** anything with another person, anything in your protected time, moving something you made, deleting. It recommends, then waits for you.

A meeting from your email waits for your yes. After the yes, it goes on your calendar as your own event. It never sends the invitation, and never replies for you. That stays with you or the Email Manager.

Every decision is written to a log that is never edited, only added to. A check script fails if anything that sends, invites, cancels or deletes is logged as less than red, or if something it placed sits in your protected time.

## Basic and Expert
- **Basic:** your calendar is the file `calendar/calendar.md`. One section per day, one row per block, in plain text you can read and edit. Edit it and the Time Manager takes your version.
- **Expert:** your connected calendar is the truth, and the file becomes a mirror. The Time Manager creates events with a `TM:` tag and no attendees, reads each one back to check it, and only ever moves events with that tag.

## How it learns
When you correct it ("from now on, no calls before 10"), it writes one line in a lessons file and follows it. When you edit a block it placed, it keeps your version and writes the change in a log.

## Your files
Everything lives in the toolkit folder on your computer: your settings, your calendar plan, your decisions, your history. Nothing is sent to us.
