# A sample day (made-up owner, made-up data)

Owner: Dana Ruiz, runs a 6-person bookkeeping firm. Works Monday to Friday, 8 AM to 5 PM. Sharpest focus time 8 to 11 AM. Protected: lunch 12 to 12:30 and 6 to 8 PM. Fixed weekly: team meeting Monday 10:00 to 10:30, sales calls Tuesday 1 to 3 PM. Calendar: plain file (Basic).

Today is Tuesday, 2026-11-24.

## 7:58 AM, the Chief of Staff's morning job reaches the Time Manager

**What the Time Manager reads**

`handoffs/top3-today.md` (fresh, from the Focus Manager):
1. Send proposals to the two warm leads : both proposals drafted for review
2. Call Priya Shah back about the payroll add-on : call held, next step agreed
3. Draft the year-end checklist offer post : post drafted for review

`handoffs/schedule-items.md` (from the Email Manager):

| Found in email | What | Date and time | Who | Status |
|---|---|---|---|---|
| Dentist office, "Appointment reminder" | Dentist cleaning | 2026-11-27 15:00 | Dana only | new |
| Tom Becker, "Thursday?" | Call with Tom Becker | 2026-11-26 14:00 | Tom Becker | new |
| Software vendor, "Demo" | Product demo | sometime next week | the vendor | new |

**What it decides** (stage 02, checked in stage 03)

| Item | Slot | Light | Why |
|---|---|---|---|
| Top 3 #1 proposals | 08:00 to 09:00 | Yellow | Sharpest hours, first item first |
| Top 3 #3 offer post | 09:10 to 10:10 | Yellow | Next focus slot, 10 minute gap after #1 |
| Top 3 #2 call Priya back | 15:10 to 16:10 | Yellow | Time for Dana to make a call goes after the focus hours, 60 minutes by default, 10 minutes clear of Lunch and the Sales calls. No time was agreed with Priya, so nobody is invited |
| Dentist cleaning | Friday 15:00 to 16:00 | Yellow | Only Dana is on it. No length given, so the 60 minute default |
| Call with Tom Becker | Thursday 14:00 | Red | Another person. Held for Dana's yes |
| Product demo | not placed | none | No exact time. Asked, not guessed |

A separate reviewer checks the yellow blocks against the rubric. They pass. The decision log gets yellow rows with `review: pass (separate)`, and a red row for Tom's call with Result `pending`.

**The calendar for today** (`time-manager/calendar/calendar.md`):

| Start | End | Block | Type | Fixed or movable | Source |
|---|---|---|---|---|---|
| 08:00 | 09:00 | Top 3 #1: Send proposals to the two warm leads | focus | movable | top3 |
| 09:10 | 10:10 | Top 3 #3: Draft the year-end checklist offer post | focus | movable | top3 |
| 12:00 | 12:30 | Lunch | protected | fixed | setup |
| 13:00 | 15:00 | Sales calls | meeting | fixed | setup |
| 15:10 | 16:10 | Top 3 #2: Call Priya Shah back about payroll add-on | focus | movable | top3 |
| 18:00 | 20:00 | Evening protected | protected | fixed | setup |

**The report** (`handoffs/time-manager-report.md`):

```
---
from: time-manager
updated: 2026-11-24 07:58 (Pacific)
status: ok
---

## Today
| Start | End | Block | Fixed or movable |
|---|---|---|---|
| 08:00 | 09:00 | Top 3 #1: Send proposals to the two warm leads | movable |
| 09:10 | 10:10 | Top 3 #3: Draft the year-end checklist offer post | movable |
| 12:00 | 12:30 | Lunch | fixed |
| 13:00 | 15:00 | Sales calls | fixed |
| 15:10 | 16:10 | Top 3 #2: Call Priya Shah back about payroll add-on | movable |
| 18:00 | 20:00 | Evening protected | fixed |

## Open time today
- Total: 3.2 hours open. When: 10:10 to 12:00, 12:30 to 13:00, 16:10 to 17:00

## Waiting on your yes
| P# | What | When | Who | My recommendation |
|---|---|---|---|---|
| P1 | Call with Tom Becker | Thu 2026-11-26 14:00 | Tom Becker | Yes. Thursday is open and it does not touch protected time. I will not send an invitation. Reply to Tom yourself or through the Email Manager |

## Schedule items handled
| Found in email | What | Date and time | Result | Note |
|---|---|---|---|---|
| 2026-11-20 | Dentist cleaning | 2026-11-27 15:00 | placed | Friday 15:00 to 16:00 |
| 2026-11-20 | Call with Tom Becker | 2026-11-26 14:00 | waiting | P1 |
| 2026-11-21 | Product demo | sometime next week | waiting | Needs an exact time |

## Missing
- missing: exact time for the product demo
```

**What Dana sees from the Chief of Staff (Calendar line)**

> **Calendar:** C1 proposals 8:00, C2 offer post 9:10, lunch, sales calls 1:00 to 3:00, C3 Priya call 3:10. Open: 3.2 hours. Dentist placed Friday 3:00. Decisions: P1, Tom Becker call Thursday 2:00, I recommend yes. QN1: what time is the product demo?

## 8:10 AM, Dana answers

Dana: "Yes to P1. The demo is Wednesday the 2nd at 11."

- The Time Manager adds a new decision log row, `corrects L#`, with Dana's exact words "Yes to P1" and Result done. The old row is not edited.
- Call with Tom Becker goes on Thursday 14:00 to 15:00 as Dana's own event. No attendee, no invitation. The report's "Waiting on you" section is now empty.
- The demo is a meeting with another person, so it is a new red item (P2) with the time now given. Dana's yes to P1 is not a yes to P2. It asks once.

## 7:05 PM, Dana messages during protected time

Dana: "Block Friday 10 to 11 for the quarterly report."

The Time Manager logs the ask and says in one line: "Noted, I will put this on your calendar at 8 AM tomorrow." It opens no new questions. At 8 AM it blocks Friday 10:00 to 11:00 (yellow, reviewed, logged).
