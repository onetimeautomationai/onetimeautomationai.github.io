# Known limitations

- **It only knows what is in its files, your calendar, and the other hires' reports.** If the Focus Manager did not run today, it says "Top 3 not run today" and does not guess. If a date in email is vague, it asks you for the exact time.
- **It does not run by itself unless your agent can schedule tasks.** Without that, you open your agent and say "Plan my day".
- **No alerts.** It does not text or ping you when a block is about to end. It tells you when you ask ("What now?") or when you open your agent.
- **It never sends an invite or a reply.** If a meeting needs an invitation or an answer, it tells you, and the Email Manager or you send it. This is on purpose.
- **Basic does not talk to your real calendar.** The plain file is your plan. You copy blocks into your own calendar yourself, and edits you make there do not come back unless you edit the file too.
- **Expert depends on your AI agent's calendar connector.** If the connector cannot list, read, or create events with no attendees, use Basic. A connector that adds an attendee or sends an invite on its own is not safe to use. Check what yours does with the test event at install.
- **It cannot see a meeting you never put on a calendar or in email.** A clash it cannot see is a clash it cannot warn about.
- **It plans in one time zone.** If you travel, tell it your new time zone (say "redo setup") before it plans.
- **One calendar.** It plans for one calendar at a time. Recurring series are not created. It places individual blocks for the next two weeks and adds days as it goes.
- **Rule following depends on your AI agent and model.** Stronger agents follow the rules more closely. The checks in `time-manager/scripts/calendar_tools.py` catch the most important misses (double booking, protected time, a missing approval, a skipped review) when your agent can run Python.
- **The review is strongest with a second agent.** Yellow work is checked by a separate reviewer. If your agent cannot start helper agents, the same agent reviews its own work in a separate pass. That is weaker, because it is checking itself.
- **One owner.** It is built for one CEO. A team can share the folder, but it treats every message as coming from the owner.
- **Long histories slow it down.** Past days are archived by month. After a few months, move old `runs/` folders into `runs/archive/`.
