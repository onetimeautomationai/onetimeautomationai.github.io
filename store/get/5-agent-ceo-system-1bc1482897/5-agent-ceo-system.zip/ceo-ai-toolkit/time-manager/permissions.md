# What the Time Manager can touch

Paths start from the `ceo-ai-toolkit` folder.

| Area | Read | Write | Notes |
|---|---|---|---|
| `time-manager/` | Yes | Yes | Its own working files. Rules files change only with your yes (`INSTALL.md`, safe change rules) |
| `handoffs/time-manager-report.md` | Yes | Yes | It writes this report every run |
| `handoffs/top3-today.md`, `handoffs/schedule-items.md` | Yes | No | The Focus Manager and the Email Manager write these. It never edits them |
| `handoffs/jobs.md` | Yes | Only the Status cell of rows where For is `time-manager` | |
| Other files in `handoffs/` and other hire folders | Only `chief-of-staff/_shared/owner-profile.md`, `chief-of-staff/_shared/lessons.md`, `chief-of-staff/worker.md` and `chief-of-staff/_shared/handoffs.md`, and only when they exist | No | |
| `logs/activity.md` | Yes | Adds one line per finished run | Never edits or removes a line |
| `.ceo-toolkit/` | Yes | Adds snapshots and log rows only | Never deletes anything there |
| Your connected calendar (Expert) | Yes, the days it plans | Creates events with no attendees, and moves only the events it created (title starts with the tag) | Never changes an event you made. Never adds anyone. Removes an event it created only on your yes, one at a time. Needs your yes before the first change (`INSTALL.md`) |
| Your email | No | No | Only the Email Manager reaches email |
| Outside the toolkit folder (scheduled tasks, your agent's settings) | No | Only with your yes, following the safe change rules in `INSTALL.md` | |
| Passwords, keys, tokens | Never stored | Never stored | If a job needs one, it stops and tells you |

## Actions that always need your yes

Sending, posting, publishing, paying, buying, deleting, and booking with another person. For your calendar that means no invite, no reply, no accept, no decline, no attendee on any event, and no deleting. Also anything in your protected time, and moving an event you made. These are always red (`_shared/decision-tiers.md`). `time-manager/scripts/calendar_tools.py check` fails if one is logged as green or yellow, marked done without your words, or placed in protected time without your yes.
