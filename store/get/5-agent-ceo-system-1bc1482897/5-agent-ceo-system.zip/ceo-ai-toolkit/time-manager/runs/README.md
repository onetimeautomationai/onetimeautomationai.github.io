# Runs

One folder per run, named `YYYY-MM-DD-short-name/`. The daily run is `YYYY-MM-DD-daily/`, and a second pass the same day is `YYYY-MM-DD-daily-2/`. Start one by copying `time-manager/_templates/run/01_collect.md` into it. Each later stage copies its own template from `time-manager/_templates/outputs/`.

A run folder holds `01_collect.md`, `02_slot.md`, `03_guard.md`, `04_place.md` and `06_log.md`. The report is not in the run folder. It is `handoffs/time-manager-report.md`.

Never delete a run. After a few months, move old runs into `runs/archive/`.
