# runs: map

| Path | One line |
|---|---|
| `README.md` | How run folders are named and what each holds |
| `YYYY-MM-DD-daily/` | Created by the daily run, one per day, not shipped |
