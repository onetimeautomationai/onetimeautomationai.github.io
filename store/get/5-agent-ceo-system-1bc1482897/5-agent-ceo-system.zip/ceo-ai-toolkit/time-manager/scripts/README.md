# Scripts

One small script, `calendar_tools.py`. Standard Python 3, nothing to install. It works from any folder. The docs show it run from the `ceo-ai-toolkit` folder. It is optional: if your AI agent cannot run Python, it does the same steps by hand.

| Command | What it does | By hand |
|---|---|---|
| `python3 time-manager/scripts/calendar_tools.py roll` (add `--dry-run` to preview) | Plain file only. Moves past days to `time-manager/calendar/archive/YYYY-MM.md`, adds a section for every missing day through today plus `horizon_days` minus 1, filled with the protected windows (work days only, because other days are protected all day) and fixed weekly times from `config.json`. Never changes a day that already exists | See "Roll by hand" below |
| `python3 time-manager/scripts/calendar_tools.py day [YYYY-MM-DD]` | Prints that day's table and the open time line, ready to paste into the report. For today it leaves out time before the real clock, rounded up to the next 15 minutes | List the day's rows in time order, then work out open time by hand (below) |
| `python3 time-manager/scripts/calendar_tools.py check` | Runs checks K1 to K12. Exit code 0 means pass. WARN lines do not fail it | Do each check below and write the result in `06_log.md` |

Add `--today YYYY-MM-DD` to any command to test as if it were another day. Add `--now HH:MM` to `day` to test as if the clock said that time today. `--now` alone means that time on the real today. To test a simulated day at a given time, give both: `--today YYYY-MM-DD --now HH:MM`. Without `--today` the open line is worked out for the real today, not the day you meant.

## The checks

| # | Check |
|---|---|
| K1 | `time-manager/config.json` says `"setup_done": true`, has a name, a real time zone, valid work days and hours, and whole-number limits |
| K2 | `calendar/calendar.md` is well formed: real dates, the weekday name matches the date, 24 hour times with the end after the start, a known Type, Fixed or movable and Source on every row, six columns |
| K3 | The calendar has a section for every day from today through today plus `horizon_days` minus 1 |
| K4 | No two blocks overlap. FAIL if the Time Manager placed one of them (Source `top3`, `email`, `owner` or `job`). WARN if both are the owner's. Also a FAIL when a block the Time Manager placed is closer than `buffer_minutes` to a fixed row (TR5) |
| K5 | Nothing the Time Manager placed sits in protected time or outside work hours unless its Source is `owner-ok`. A Top 3 block (a call block excepted) must end by the end of `focus_hours` (TR3) |
| K6 | Overload, WARN only: a work day over `overload_booked_percent` booked, under `min_open_minutes` open, or three or more tight gaps |
| K7 | `calendar/pending.md` rows have 7 columns and a Status of waiting, yes, no, expired or placed. A waiting row whose date has passed is a WARN |
| K8 | Decision log: 8 columns, a tier of T1, T2 or T3, a Result of done, pending, parked or no. Sends, invites, cancels, deletes and meetings with another person are T3. A T3 marked done has the owner's real words. A T2 marked done says `review: pass (separate)` or `review: pass (self)` (self is a WARN). A `Held:` row that names another person is T3 with Result pending. No L number is used twice. Evidence is exactly `review: pass (separate)` or `(self)`, then nothing, a space or a comma. A Time later than the run clock (`--now HH:MM` or the real clock, or the date when `--today` is given) fails. |
| K9 | `handoffs/time-manager-report.md` has both required sections, a header from `time-manager`, and a Today table that matches the calendar for the report's date |
| K10 | No password, key or token in `config.json`, `_shared/` or `calendar/` |
| K11 | Every run folder from before today has `06_log.md` |
| K12 | A block you placed, today on, has an `added` row in `changes-log.md` (WARN only). A changes log Time later than the run clock is also a WARN |

A row whose Decision starts with `corrects L4` replaces row L4 for check K8. That is how you fix a mistake without editing the log.

## Roll by hand

1. Open `time-manager/calendar/calendar.md`. Cut every day section dated before today and paste it into `time-manager/calendar/archive/YYYY-MM.md` (make the file if it is missing, one file per month).
2. Add one section for each missing day through today plus 13 days, using `time-manager/_templates/outputs/calendar-day.md`. Heading format: `## 2026-11-20 Friday`, with the right weekday.
3. In each new day, add a row for every fixed weekly time in `config.json` that applies to that weekday, and for every protected window if the day is a work day. Protected windows are Type `protected`, fixed times are Type `fixed` (or `meeting` if another person is on it), Fixed or movable `fixed`, Source `setup`. A day with no rows gets the line `No blocks placed.`

## Open time by hand

Take the work hours for that day. Remove every row that day and every protected window inside the work hours. For today, also remove everything before the real clock, rounded up to the next 15 minutes. What is left, in windows of time, is the open time. Add the windows up for the total.
