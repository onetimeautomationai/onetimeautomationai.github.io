# scripts: map

| File | One line |
|---|---|
| `calendar_tools.py` | `check` (K1 to K12), `day`, `roll`. Standard Python 3, optional |
| `README.md` | What each command does, the checks, and the by-hand version of every step |
