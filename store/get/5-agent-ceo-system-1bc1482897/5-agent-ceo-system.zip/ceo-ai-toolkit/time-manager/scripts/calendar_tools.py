#!/usr/bin/env python3
"""Calendar tools for the Time Manager. Standard library only.

Run from the ceo-ai-toolkit folder (it also works from any other folder):

    python3 time-manager/scripts/calendar_tools.py check [--today YYYY-MM-DD]
    python3 time-manager/scripts/calendar_tools.py day [YYYY-MM-DD] [--today YYYY-MM-DD] [--now HH:MM]
    python3 time-manager/scripts/calendar_tools.py roll [--dry-run] [--today YYYY-MM-DD]

check  Runs the hard checks K1 to K12. Exit code 0 = pass, 1 = at least one FAIL.
       WARN lines (overload, expired waiting items, owner-made clashes) do not fail the check.
       They go into the "Warnings" section of the report. Reads files, never changes them.
day    Prints one day from the calendar file in the report format, plus the open time.
       For today, time before the real clock (rounded up to the next 15 minutes) is not counted as open.
roll   Plain-file calendar only. Moves past days to calendar/archive/YYYY-MM.md (never deletes),
       then adds a section for every missing day through today + horizon_days minus 1,
       filled with the protected windows and fixed weekly times from config.json.
       Days that already exist are never changed: their text is kept exactly, including a note the owner typed under a day.

All settings come from time-manager/config.json. Nothing is hard coded here.

Checks:
  K1  Setup is done and config.json is complete and valid.
  K2  calendar/calendar.md is well formed: dates, weekdays, times, types, sources.
  K3  The calendar covers today through today + horizon_days minus 1.
  K4  No double booking (FAIL if the Time Manager placed one of the two, WARN if both are the owner's). A block the Time Manager placed also FAILs if it is closer than buffer_minutes to a fixed row.
      A Top 3 block (not a call) FAILs if it ends after the end of focus_hours (K5).
  K5  Nothing the Time Manager placed sits in protected time without the owner's yes (Source owner-ok or setup).
  K6  Overload warnings (WARN only): too full, too little open time, too many back to back blocks.
  K7  calendar/pending.md is well formed. Old waiting items are a WARN.
  K8  Decision log: 8 columns, tiers, results, sends and invites are T3 (a Decision starting with Block is read for calendar words only), T3 done has the owner's words,
      T2 done has "review: pass (separate)" or "review: pass (self)" (self is a WARN), followed by nothing, a space or a comma. A "Held:" row naming another person is T3 pending.
      A Time later than the run clock FAILs (decision log) or WARNs (changes log). The run clock is --now, else the real clock, else only the date is compared when --today is given.
  K9  handoffs/time-manager-report.md exists, has both required sections, and its Today table matches the calendar.
  K10 No password, key or token in the Time Manager's settings, shared files or calendar files.
  K11 Every run folder from before today has 06_log.md.
  K12 A block the Time Manager placed (today on) with no `added` or `corrects` row in changes-log.md is a WARN.
"""
import argparse
import datetime as dt
import json
import re
import sys
from pathlib import Path

try:
    from zoneinfo import ZoneInfo
except ImportError:  # very old Python
    ZoneInfo = None

HERE = Path(__file__).resolve().parent.parent  # the time-manager folder
TOOLKIT = HERE.parent  # the ceo-ai-toolkit folder
CONFIG = HERE / "config.json"
CAL = HERE / "calendar" / "calendar.md"
PENDING = HERE / "calendar" / "pending.md"
CHANGES = HERE / "calendar" / "changes-log.md"
LOG = HERE / "_shared" / "decision-log.md"
REPORT = TOOLKIT / "handoffs" / "time-manager-report.md"

DAYS = ["mon", "tue", "wed", "thu", "fri", "sat", "sun"]
TYPES = {"focus", "fixed", "meeting", "protected", "personal"}
FIXED_OR_MOVABLE = {"fixed", "movable"}
SOURCES = {"setup", "top3", "email", "owner", "job", "owner-ok", "connected"}
TM_SOURCES = {"top3", "email", "owner", "job"}  # rows the Time Manager placed itself
PENDING_STATUS = {"waiting", "yes", "no", "expired", "placed"}
RESULTS = {"done", "pending", "parked", "no"}
EMPTY_WORDS = {"", "-", "--", "n/a", "na", "none", "tbd", "?"}
ACTION = re.compile(
    r"\b(send|sends|sent|email to|reply to|post|posts|posted|publish|published|"
    r"pay|pays|paid|buy|buys|bought|purchase|purchased|invoice|refund|"
    r"delete|deletes|deleted|cancel|cancels|cancelled|decline|declines|declined|"
    r"invite|invites|invited|attendee|attendees|meeting with|call with|"
    r"book|books|booked|schedule a call with|"
    r"sign a contract|sign the contract|signed|contract|hire|hiring|"
    r"website|wire|transfer|"
    r"forward(?:s|ed)?\s+(?:the|it|this|that|an?|my|all|these|those)|forward(?:s|ed)?\s+to\s+(?-i:[A-Z][a-z]+)|accept|accepts|accepted|renew|renews|renewed|"
    r"subscribe|subscribes|subscribed|ordered|place an order|charge|charges|charged|"
    r"share|shares|shared|confirm with|confirmed with|confirms with)\b",
    re.I,
)
# A decision that starts with "Block" is time for the owner alone, so the name of the task inside it
# (for example "the offer post") must not trigger the full list. Only these calendar words do.
STRONG = re.compile(
    r"\b(send|sends|sent|invite|invites|invited|attendee|attendees|cancel|cancels|cancelled|"
    r"decline|declines|declined|delete|deletes|deleted|meeting with|call with|"
    r"pay|buy|invoice|contract)\b",
    re.I,
)
BLOCK_ONLY = re.compile(r"^\s*block\b", re.I)
OWNER_TASK = re.compile(r"^\s*owner task\s*:", re.I)
# An "Owner task:" row says the owner did it. If its Evidence says the AI sent it, the row is mislabeled.
AI_SENT = re.compile(r"\b(ai sent|i sent|sent by (the )?(ai|agent|assistant|manager|email manager|me)|(the )?(ai|agent|assistant|email manager) (has )?sent)\b", re.I)
REVIEW_PASS = re.compile(r"review:\s*pass\s*\((separate|self)\)(?=$|[\s,])", re.I)
LOG_TIME = re.compile(r"^(\d{4}-\d{2}-\d{2})[ T]([01]\d|2[0-3]):([0-5]\d)$")
REVIEW_SELF = re.compile(r"review:\s*pass\s*\(self\)(?=$|[\s,])", re.I)
HELD = re.compile(r"^\s*held\s*:", re.I)
OTHER_PERSON = re.compile(r"\b(with|to|for|from)\s+(?!Top\b|Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday|January|February|March|April|May|June|July|August|September|October|November|December)[A-Z][a-z]+")
CALL_WORD = re.compile(r"\bcalls?\b", re.I)
CORRECTS = re.compile(r"^\s*corrects\s+(L\d+)", re.I)
SECRET = re.compile(r"(api[_-]?key|secret|password|passwd|token)\s*[:=]\s*\S{8,}", re.I)
TIME_RE = re.compile(r"^([01]\d|2[0-3]):[0-5]\d$")
DAY_HEAD = re.compile(r"^##\s+(\d{4}-\d{2}-\d{2})\s*(\w*)\s*$")
CAL_HEADER = ["Start", "End", "Block", "Type", "Fixed or movable", "Source"]
PENDING_HEADER = ["P#", "Date and time", "What", "Who", "Why red", "Source", "Status"]

FAILS = []
WARNS = []


def fail(code, msg):
    FAILS.append(f"{code} FAIL: {msg}")


def warn(code, msg):
    WARNS.append(f"{code} WARN: {msg}")


# ---------- small helpers ----------

def to_min(hhmm):
    h, m = hhmm.split(":")
    return int(h) * 60 + int(m)


def to_hhmm(minutes):
    return f"{minutes // 60:02d}:{minutes % 60:02d}"


def union(intervals):
    """Merge overlapping (start, end) minute intervals."""
    out = []
    for s, e in sorted(i for i in intervals if i[1] > i[0]):
        if out and s <= out[-1][1]:
            out[-1] = (out[-1][0], max(out[-1][1], e))
        else:
            out.append((s, e))
    return out


def total(intervals):
    return sum(e - s for s, e in union(intervals))


def subtract(window, blocked):
    """The parts of window (start, end) not covered by the blocked intervals."""
    out, cur = [], window[0]
    for s, e in union(blocked):
        if e <= cur or s >= window[1]:
            continue
        if s > cur:
            out.append((cur, min(s, window[1])))
        cur = max(cur, e)
    if cur < window[1]:
        out.append((cur, window[1]))
    return out


def table_rows(text):
    rows = []
    for line in text.splitlines():
        s = line.strip()
        if not s.startswith("|") or set(s) <= set("|-: "):
            continue
        rows.append([c.strip() for c in s.strip("|").split("|")])
    return rows


def load_config():
    if not CONFIG.exists():
        return None
    try:
        return json.loads(CONFIG.read_text(encoding="utf-8"))
    except ValueError as e:
        fail("K1", f"config.json is not valid JSON: {e}")
        return None


def get_today(cfg, override):
    if override:
        return dt.date.fromisoformat(override)
    tz = None
    if cfg and cfg.get("time_zone") and ZoneInfo:
        try:
            tz = ZoneInfo(cfg["time_zone"])
        except Exception:
            tz = None
    return dt.datetime.now(tz).date() if tz else dt.date.today()


def now_minutes(cfg, override, raw=False):
    """Minutes since midnight now in the owner's zone, rounded up to the next 15 (raw=True: not rounded). override is HH:MM (tests)."""
    if override:
        m = to_min(override)
    else:
        tz = None
        if cfg and cfg.get("time_zone") and ZoneInfo:
            try:
                tz = ZoneInfo(cfg["time_zone"])
            except Exception:
                tz = None
        n = dt.datetime.now(tz) if tz else dt.datetime.now()
        m = n.hour * 60 + n.minute
    return m if raw else min(1440, -(-m // 15) * 15)


def day_key(d):
    return DAYS[d.weekday()]


def work_window(cfg, d):
    """(start, end) minutes of the work day, or None on a non-work day."""
    if day_key(d) not in cfg["work_days"]:
        return None
    return to_min(cfg["work_hours"]["start"]), to_min(cfg["work_hours"]["end"])


def window_days(item_days):
    if not item_days or "daily" in item_days:
        return set(DAYS)
    return set(item_days)


def protected_intervals(cfg, d):
    """Named protected windows for this weekday, plus everything outside work time."""
    out = []
    for p in cfg.get("protected", []):
        if day_key(d) in window_days(p.get("days")):
            out.append((to_min(p["start"]), to_min(p["end"])))
    if cfg.get("protected_outside_work", True):
        ww = work_window(cfg, d)
        if ww is None:
            out.append((0, 1440))
        else:
            out.append((0, ww[0]))
            out.append((ww[1], 1440))
    return union(out)


# ---------- calendar file ----------

def parse_calendar(path, errors=True):
    """Returns (days, preamble). days maps date -> list of row dicts."""
    days, preamble, cur = {}, [], None
    if not path.exists():
        return days, ""
    seen_first = False
    in_table_header_seen = False
    for n, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        m = DAY_HEAD.match(line)
        if m:
            seen_first = True
            try:
                d = dt.date.fromisoformat(m.group(1))
            except ValueError:
                if errors:
                    fail("K2", f"calendar.md line {n}: '{m.group(1)}' is not a real date.")
                cur = None
                continue
            name = m.group(2)
            if errors and name and name.lower() != d.strftime("%A").lower():
                fail("K2", f"calendar.md line {n}: {d.isoformat()} is a {d.strftime('%A')}, not '{name}'.")
            if d in days and errors:
                fail("K2", f"calendar.md line {n}: {d.isoformat()} appears twice.")
            days.setdefault(d, [])
            cur = d
            in_table_header_seen = False
            continue
        if not seen_first:
            preamble.append(line)
            continue
        s = line.strip()
        if cur is None or not s.startswith("|") or set(s) <= set("|-: "):
            continue
        cells = [c.strip() for c in s.strip("|").split("|")]
        if not in_table_header_seen:
            in_table_header_seen = True
            if cells != CAL_HEADER and errors:
                fail("K2", f"calendar.md line {n}: table header must be {' | '.join(CAL_HEADER)}.")
            continue
        if len(cells) != 6:
            if errors:
                fail("K2", f"calendar.md line {n}: row has {len(cells)} columns, needs 6. A pipe character in the text splits it.")
            continue
        start, end, block, typ, fm, src = cells
        ok = True
        if not TIME_RE.match(start) or not TIME_RE.match(end):
            if errors:
                fail("K2", f"calendar.md line {n}: times must be 24 hour HH:MM, got '{start}' and '{end}'.")
            ok = False
        elif to_min(end) <= to_min(start):
            if errors:
                fail("K2", f"calendar.md line {n}: end {end} is not after start {start}.")
            ok = False
        if typ not in TYPES:
            if errors:
                fail("K2", f"calendar.md line {n}: Type '{typ}' is not one of {', '.join(sorted(TYPES))}.")
            ok = False
        if fm not in FIXED_OR_MOVABLE:
            if errors:
                fail("K2", f"calendar.md line {n}: 'Fixed or movable' must be fixed or movable, got '{fm}'.")
            ok = False
        if src not in SOURCES:
            if errors:
                fail("K2", f"calendar.md line {n}: Source '{src}' is not one of {', '.join(sorted(SOURCES))}.")
            ok = False
        if not block:
            if errors:
                fail("K2", f"calendar.md line {n}: Block name is empty.")
            ok = False
        if ok:
            days[cur].append({"start": to_min(start), "end": to_min(end), "block": block,
                              "type": typ, "fm": fm, "source": src, "line": n})
    for rows in days.values():
        rows.sort(key=lambda r: (r["start"], r["end"]))
    return days, "\n".join(preamble).rstrip() + "\n"


def render_day(d, rows):
    out = [f"## {d.isoformat()} {d.strftime('%A')}", ""]
    if not rows:
        out.append("No blocks placed.")
        out.append("")
        return "\n".join(out)
    out.append("| " + " | ".join(CAL_HEADER) + " |")
    out.append("|---|---|---|---|---|---|")
    for r in sorted(rows, key=lambda r: (r["start"], r["end"])):
        out.append(f"| {to_hhmm(r['start'])} | {to_hhmm(r['end'])} | {r['block']} | {r['type']} | {r['fm']} | {r['source']} |")
    out.append("")
    return "\n".join(out)


# ---------- the checks ----------

def check_setup(cfg):
    if cfg is None:
        if not CONFIG.exists():
            fail("K1", "time-manager/config.json is missing.")
        return False
    if cfg.get("setup_done") is not True:
        fail("K1", "config.json does not say setup_done: true. Run setup (time-manager/00_onboarding/CONTEXT.md).")
        return False
    ok = True
    for key in ("owner_name", "time_zone", "calendar_mode"):
        if not cfg.get(key):
            fail("K1", f"config.json: '{key}' is empty.")
            ok = False
    if cfg.get("time_zone") and ZoneInfo:
        try:
            ZoneInfo(cfg["time_zone"])
        except Exception:
            fail("K1", f"config.json: time_zone '{cfg['time_zone']}' is not a real time zone name (example: America/Chicago).")
            ok = False
    if cfg.get("calendar_mode") not in ("plain-file", "connected"):
        fail("K1", "config.json: calendar_mode must be plain-file or connected.")
        ok = False
    days = cfg.get("work_days")
    if not days or any(x not in DAYS for x in days):
        fail("K1", f"config.json: work_days must be a list using {', '.join(DAYS)}.")
        ok = False
    wh = cfg.get("work_hours") or {}
    if not (TIME_RE.match(str(wh.get("start"))) and TIME_RE.match(str(wh.get("end")))) or (
        TIME_RE.match(str(wh.get("start"))) and TIME_RE.match(str(wh.get("end"))) and to_min(wh["end"]) <= to_min(wh["start"])
    ):
        fail("K1", "config.json: work_hours needs a start and an end as HH:MM, with the end after the start.")
        ok = False
    for group in ("protected", "fixed_weekly"):
        for i, p in enumerate(cfg.get(group) or []):
            if not (p.get("name") and TIME_RE.match(str(p.get("start"))) and TIME_RE.match(str(p.get("end")))
                    and to_min(p["end"]) > to_min(p["start"])):
                fail("K1", f"config.json: {group} item {i + 1} needs a name, a start and an end as HH:MM.")
                ok = False
            elif any(x not in DAYS + ["daily"] for x in (p.get("days") or [])):
                fail("K1", f"config.json: {group} item {i + 1} has a day that is not one of {', '.join(DAYS)} or daily.")
                ok = False
    for key in ("horizon_days", "default_block_minutes", "buffer_minutes", "overload_booked_percent", "min_open_minutes", "min_window_minutes"):
        if not isinstance(cfg.get(key), int) or cfg[key] < 0:
            fail("K1", f"config.json: '{key}' must be a whole number.")
            ok = False
    return ok


def check_calendar(cfg, today):
    days, _ = parse_calendar(CAL)
    horizon = [today + dt.timedelta(days=i) for i in range(cfg["horizon_days"])]
    missing = [d for d in horizon if d not in days]
    if missing:
        fail("K3", f"calendar.md has no section for {len(missing)} day(s) starting {missing[0].isoformat()}. Run: python3 time-manager/scripts/calendar_tools.py roll")
    for d in sorted(days):
        rows = days[d]
        prot = protected_intervals(cfg, d)
        # K4 double booking
        live = [r for r in rows if r["type"] != "protected"]
        for i in range(len(live)):
            for j in range(i + 1, len(live)):
                a, b = live[i], live[j]
                if a["start"] < b["end"] and b["start"] < a["end"]:
                    msg = (f"{d.isoformat()}: '{a['block']}' ({to_hhmm(a['start'])} to {to_hhmm(a['end'])}) overlaps "
                           f"'{b['block']}' ({to_hhmm(b['start'])} to {to_hhmm(b['end'])}).")
                    if a["source"] in TM_SOURCES or b["source"] in TM_SOURCES:
                        fail("K4", msg + " The Time Manager must not double book.")
                    else:
                        warn("K4", msg + " Both are the owner's. Tell the owner.")
        # K4 a block the Time Manager placed never touches a fixed row of the owner's (TR5)
        fixed_rows = [r for r in live if r["fm"] == "fixed" and r["source"] not in TM_SOURCES]
        for a in live:
            if a["source"] not in TM_SOURCES:
                continue
            for f in fixed_rows:
                if a["start"] < f["end"] and f["start"] < a["end"]:
                    continue  # overlap is reported above
                gap = f["start"] - a["end"] if f["start"] >= a["end"] else a["start"] - f["end"]
                if gap < cfg["buffer_minutes"]:
                    fail("K4", f"{d.isoformat()}: '{a['block']}' ({to_hhmm(a['start'])} to {to_hhmm(a['end'])}) is {gap} minutes from the fixed row "
                               f"'{f['block']}' ({to_hhmm(f['start'])} to {to_hhmm(f['end'])}). Leave at least {cfg['buffer_minutes']} (TR5).")
        # K5 a Top 3 block ends by the focus end (TR3). A call block is placed after focus time (TR4).
        fh = cfg.get("focus_hours") or {}
        if fh.get("end") and TIME_RE.match(fh["end"]) and work_window(cfg, d) is not None:
            for r in live:
                if r["source"] == "top3" and r["type"] == "focus" and not CALL_WORD.search(r["block"]) and r["end"] > to_min(fh["end"]):
                    fail("K5", f"{d.isoformat()}: Top 3 block '{r['block']}' ends {to_hhmm(r['end'])}, after the focus end {fh['end']}. "
                               "Do not place it. Name it under Warnings with one recommended move (TR3).")
        # K5 protected time
        for r in live:
            if r["source"] in TM_SOURCES:
                for ps, pe in prot:
                    if r["start"] < pe and ps < r["end"]:
                        fail("K5", f"{d.isoformat()}: '{r['block']}' ({to_hhmm(r['start'])} to {to_hhmm(r['end'])}) is in protected time. "
                                   "Needs the owner's yes, then Source owner-ok.")
                        break
        # K6 overload (work days from today on)
        if d < today or d >= today + dt.timedelta(days=cfg["horizon_days"]):
            continue
        ww = work_window(cfg, d)
        if ww is None:
            continue
        named = [(s, e) for s, e in prot if ww[0] < e and s < ww[1]]
        capacity_parts = subtract(ww, named)
        capacity = sum(e - s for s, e in capacity_parts)
        if capacity <= 0:
            continue
        # minutes of booked time that fall inside capacity parts
        booked_in = 0
        for s, e in union([(max(r["start"], ww[0]), min(r["end"], ww[1])) for r in live if r["start"] < ww[1] and ww[0] < r["end"]]):
            for cs, ce in capacity_parts:
                booked_in += max(0, min(e, ce) - max(s, cs))
        pct = round(100 * booked_in / capacity)
        open_min = capacity - booked_in
        if pct > cfg["overload_booked_percent"]:
            warn("K6", f"{d.isoformat()}: {pct}% of work time is booked (limit {cfg['overload_booked_percent']}%).")
        elif open_min < cfg["min_open_minutes"]:
            warn("K6", f"{d.isoformat()}: only {open_min} minutes open (minimum {cfg['min_open_minutes']}).")
        merged = union([(r["start"], r["end"]) for r in live])
        tight = sum(1 for k in range(len(merged) - 1) if 0 <= merged[k + 1][0] - merged[k][1] < cfg["buffer_minutes"])
        if tight >= 3:
            warn("K6", f"{d.isoformat()}: {tight + 1} blocks in a row with less than {cfg['buffer_minutes']} minutes between them.")
    # K12 every block the Time Manager placed from today on has an `added` row in changes-log.md
    added = set()
    if CHANGES.exists():
        for line in CHANGES.read_text(encoding="utf-8").splitlines():
            cells = [c.strip() for c in line.strip().strip("|").split("|")]
            if len(cells) >= 5 and cells[4].lower() in ("added", "corrects"):
                added.add((cells[1][:10], cells[2]))
    for d in sorted(days):
        if d < today:
            continue
        for r in days[d]:
            if r["source"] in TM_SOURCES and (d.isoformat(), r["block"]) not in added:
                warn("K12", f"{d.isoformat()}: '{r['block']}' has no `added` row in changes-log.md. Add one.")
    return days


def check_changes_times(today, clock):
    """WARN when a changes-log Time is later than the run clock (the log is append only, so never a FAIL)."""
    if not CHANGES.exists():
        return
    for line in CHANGES.read_text(encoding="utf-8").splitlines():
        cells = [c.strip() for c in line.strip().strip("|").split("|")]
        if cells and time_after_clock(cells[0], today, clock):
            warn("K12", f"changes-log Time '{cells[0]}' is later than the run clock. Time is when the row is written, not the time of the block.")


def check_pending(today):
    if not PENDING.exists():
        fail("K7", "calendar/pending.md is missing.")
        return
    rows = table_rows(PENDING.read_text(encoding="utf-8"))[1:]
    seen = set()
    for cells in rows:
        if len(cells) != 7:
            fail("K7", f"pending.md row has {len(cells)} columns, needs 7: {' | '.join(cells)[:80]}")
            continue
        pid, when, _what, _who, _why, _src, status = cells
        if pid in seen:
            fail("K7", f"pending.md: {pid} appears twice.")
        seen.add(pid)
        if status.lower() not in PENDING_STATUS:
            fail("K7", f"pending.md {pid}: Status '{status}' is not waiting, yes, no, expired or placed.")
        elif status.lower() == "waiting":
            m = re.match(r"(\d{4}-\d{2}-\d{2})", when)
            if m and dt.date.fromisoformat(m.group(1)) < today:
                warn("K7", f"pending.md {pid}: still waiting but the date {m.group(1)} has passed. Mark it expired and tell the owner.")


def time_after_clock(value, today, clock):
    """True when a log Time (YYYY-MM-DD HH:MM) is later than the run clock. clock is minutes or None (date only)."""
    m = LOG_TIME.match(value.strip())
    if not m:
        return False
    d = dt.date.fromisoformat(m.group(1))
    if d != today:
        return d > today
    return clock is not None and int(m.group(2)) * 60 + int(m.group(3)) > clock


def check_decision_log(today=None, clock=None):
    if not LOG.exists():
        fail("K8", "_shared/decision-log.md is missing.")
        return
    rows = table_rows(LOG.read_text(encoding="utf-8"))[1:]
    good = []
    for cells in rows:
        if len(cells) != 8:
            fail("K8", f"log row has {len(cells)} columns, needs 8. A pipe character in the text splits it: {' | '.join(cells)[:80]}")
            continue
        good.append(cells)
    corrected = set()
    for cells in good:
        m = CORRECTS.match(cells[2])
        if m:
            corrected.add(m.group(1).upper())
    seen = set()
    for cells in good:
        num, _t, decision, tier, _w, evidence, words, result = cells
        key = num.upper()
        is_dup = key in seen
        seen.add(key)
        if key in corrected:
            continue
        if today and time_after_clock(_t, today, clock):
            fail("K8", f"{num}: Time '{_t}' is later than the run clock. Time is when the row is written, not the time of the block. Add a 'corrects {num}' row.")
        if is_dup:
            fail("K8", f"{num} appears twice. Use the next number, or add a 'corrects {num}' row.")
        if tier not in ("T1", "T2", "T3"):
            fail("K8", f"{num}: tier '{tier}' is not T1, T2 or T3. Add a 'corrects {num}' row.")
        if result.lower() not in RESULTS:
            fail("K8", f"{num}: Result '{result}' is not done, pending, parked or no. Add a 'corrects {num}' row.")
        text = CORRECTS.sub("", decision)
        pattern = STRONG if BLOCK_ONLY.match(text) else ACTION
        if HELD.match(text):
            held_text = HELD.sub("", text)
            if (ACTION.search(held_text) or OTHER_PERSON.search(held_text)) and tier != "T3":
                fail("K8", f"{num}: a held ask that names another person must be T3 with Result pending, not {tier}. Add a 'corrects {num}' row.")
            elif tier == "T3" and result.lower() != "pending":
                fail("K8", f"{num}: a held T3 ask waits, so Result must be pending, not {result}. Add a 'corrects {num}' row.")
        elif pattern.search(text) and tier != "T3" and not OWNER_TASK.match(text):
            fail("K8", f"{num}: '{text[:60]}' reaches another person, the public, money or deletes something, so it must be T3, not {tier}. Add a 'corrects {num}' row.")
        if OWNER_TASK.match(text) and AI_SENT.search(evidence):
            fail("K8", f"{num}: marked 'Owner task:' but Evidence says the AI sent it. Remove 'Owner task:' and set the tier. Add a 'corrects {num}' row.")
        if tier == "T3" and result.lower() == "done" and words.strip().lower() in EMPTY_WORDS:
            fail("K8", f"{num}: T3 marked done without the owner's words. Ask the owner, or add a 'corrects {num}' row with Result pending.")
        if tier == "T2" and result.lower() == "done" and not REVIEW_PASS.search(evidence):
            fail("K8", f"{num}: yellow (T2) work marked done without 'review: pass (separate)' or 'review: pass (self)' in Evidence. Run the review, then add a 'corrects {num}' row.")
        elif tier == "T2" and result.lower() == "done" and REVIEW_SELF.search(evidence):
            warn("K8", f"{num}: reviewed by yourself, not by a separate reviewer. Use a separate reviewer when one is available.")


def check_report(cfg, today, days, now=None, pretend=False):
    if not REPORT.exists():
        prof = TOOLKIT / "chief-of-staff" / "_shared" / "owner-profile.md"
        if prof.exists() and re.search(r"^setup_done:\s*yes\s*$", prof.read_text(encoding="utf-8"), re.M):
            # Under the Chief of Staff the first brief writes the first report (LR-D7).
            warn("K9", "handoffs/time-manager-report.md does not exist yet. The Chief of Staff's first brief runs stage 05.")
        else:
            fail("K9", "handoffs/time-manager-report.md is missing. Run stage 05.")
        return
    text = REPORT.read_text(encoding="utf-8")
    head = re.match(r"---\s*\n(.*?)\n---", text, re.S)
    meta = {}
    if head:
        for line in head.group(1).splitlines():
            if ":" in line:
                k, v = line.split(":", 1)
                meta[k.strip()] = v.strip()
    if meta.get("from") != "time-manager":
        warn("K9", f"the report says from: {meta.get('from', 'nothing')}. It is not the Time Manager's own report, so it was not compared.")
        return
    if meta.get("status") not in ("ok", "partial", "failed"):
        fail("K9", "report header status must be ok, partial or failed.")
    m = re.match(r"(\d{4}-\d{2}-\d{2}) \d{2}:\d{2}", meta.get("updated", ""))
    if not m:
        fail("K9", "report header 'updated' must look like YYYY-MM-DD HH:MM.")
        return
    if "## Today" not in text or "## Open time today" not in text:
        fail("K9", "report must have the sections '## Today' and '## Open time today' exactly.")
        return
    if m.group(1) != today.isoformat():
        warn("K9", f"report was updated {m.group(1)}, not today. Readers treat it as not fresh.")
        return
    today_part = text.split("## Today", 1)[1].split("\n## ", 1)[0]
    rows = table_rows(today_part)[1:]
    got = sorted((r[0], r[1], r[2]) for r in rows if len(r) >= 4)
    want = sorted((to_hhmm(r["start"]), to_hhmm(r["end"]), r["block"]) for r in (days or {}).get(today, []))
    if got != want:
        fail("K9", f"the report's Today table does not match calendar.md for {today.isoformat()} "
                   f"({len(got)} rows in the report, {len(want)} in the calendar). Rebuild it with the 'day' command.")
        return
    # The open line is worked out again at the report's own clock (--now, else the header time), so a line
    # left from an earlier run, or from before a block was added, fails.
    ww = work_window(cfg, today)
    open_part = text.split("## Open time today", 1)[1].split("\n## ", 1)[0]
    line = next((l.strip() for l in open_part.splitlines() if l.strip().startswith("- Total:")), "")
    if ww is not None and line:
        hhmm = re.search(r"(\d{2}:\d{2})", meta.get("updated", "")).group(1)
        want_line = open_line(cfg, today, (days or {}).get(today, []), ww, None if pretend else now_minutes(cfg, now or hhmm))
        if line != want_line:
            fail("K9", f"the report's open line is stale. It says '{line}', the 'day' command at {'no clock' if pretend else (now or hhmm)} says '{want_line}'. Run 'day' again and paste its line.")


def check_secrets():
    files = [CONFIG] + list((HERE / "_shared").glob("*.md")) + list((HERE / "calendar").glob("*.md"))
    for p in files:
        if not p.exists():
            continue
        for i, line in enumerate(p.read_text(encoding="utf-8").splitlines(), 1):
            if SECRET.search(line):
                fail("K10", f"{p.relative_to(HERE)} line {i} looks like a secret. Remove it. Secrets never go in these files.")


def check_runs(today):
    runs = HERE / "runs"
    if not runs.exists():
        return
    for d in sorted(runs.iterdir()):
        if not d.is_dir() or d.name == "archive" or d.name >= today.isoformat():
            continue
        if not (d / "06_log.md").exists():
            fail("K11", f"runs/{d.name} has no 06_log.md. Close it with stages/06_log.")


def cmd_check(args):
    cfg = load_config()
    ready = check_setup(cfg)
    today = get_today(cfg if ready else None, args.today)
    days = None
    if ready:
        days = check_calendar(cfg, today)
        check_report(cfg, today, days, args.now, bool(args.today and not args.now))
    check_pending(today)
    # run clock: --now, else the real clock when no --today was given, else date only (a pretend day)
    clock = now_minutes(cfg if ready else None, args.now, raw=True) if (args.now or not args.today) else None
    check_decision_log(today, clock)
    check_changes_times(today, clock)
    check_secrets()
    check_runs(today)
    for w in WARNS:
        print(w)
    if FAILS:
        print("\n".join(FAILS))
        print(f"\n{len(FAILS)} check(s) failed.")
        return 1
    print("All checks passed (K1 to K12)." + (f" {len(WARNS)} warning(s)." if WARNS else ""))
    return 0


# ---------- day ----------

def open_line(cfg, d, rows, ww, clock=None):
    """The 'Total' line of the report for day d. clock: minutes (already rounded up to 15) before which nothing is open, or None."""
    blocked = [(r["start"], r["end"]) for r in rows] + protected_intervals(cfg, d)
    if clock is not None:
        blocked.append((0, clock))
    free = [(s, e) for s, e in subtract(ww, blocked) if e - s >= cfg["min_window_minutes"]]
    mins = sum(e - s for s, e in free)
    hours = int(mins / 6 + 0.5) / 10  # one decimal, halves round up
    hours_text = str(int(hours)) if hours == int(hours) else str(hours)
    when = ", ".join(f"{to_hhmm(s)} to {to_hhmm(e)}" for s, e in free) or "none"
    return f"- Total: {hours_text} hours open. When: {when}"


def cmd_day(args):
    cfg = load_config()
    if not check_setup(cfg):
        print("\n".join(FAILS))
        return 2
    today = get_today(cfg, args.today)
    d = dt.date.fromisoformat(args.date) if args.date else today
    days, _ = parse_calendar(CAL)
    if FAILS:
        print("\n".join(FAILS))
        return 2
    rows = days.get(d)
    if rows is None:
        print(f"No section for {d.isoformat()} in calendar.md. Run the roll command first.")
        return 2
    print("| Start | End | Block | Fixed or movable |")
    print("|---|---|---|---|")
    for r in rows:
        print(f"| {to_hhmm(r['start'])} | {to_hhmm(r['end'])} | {r['block']} | {r['fm']} |")
    ww = work_window(cfg, d)
    print()
    if ww is None:
        print(f"- Total: 0 hours open. {d.strftime('%A')} is not a work day.")
        return 0
    # Today only: time before the real clock (rounded up to 15 minutes) is not open.
    # With --today and no --now the day is a pretend day, so the real clock is not used.
    clock = now_minutes(cfg, args.now) if d == today and (args.now or not args.today) else None
    print(open_line(cfg, d, rows, ww, clock))
    return 0


# ---------- roll ----------

def default_rows(cfg, d):
    rows = []
    for p in cfg.get("protected", []):
        # Non-work days are protected all day, so no separate rows are written for them.
        if work_window(cfg, d) is not None and day_key(d) in window_days(p.get("days")):
            rows.append({"start": to_min(p["start"]), "end": to_min(p["end"]), "block": p["name"],
                         "type": "protected", "fm": "fixed", "source": "setup"})
    for p in cfg.get("fixed_weekly", []):
        if day_key(d) in window_days(p.get("days")):
            rows.append({"start": to_min(p["start"]), "end": to_min(p["end"]), "block": p["name"],
                         "type": "meeting" if p.get("people") else "fixed", "fm": "fixed", "source": "setup"})
    return rows


def split_raw_days(text):
    """Splits the calendar text into (preamble, {date: raw section text}). Every section keeps its own
    characters exactly, including any note the owner typed that is not a table row."""
    lines = text.splitlines(keepends=True)
    heads = []
    for i, line in enumerate(lines):
        m = DAY_HEAD.match(line.rstrip("\r\n"))
        if m:
            try:
                heads.append((i, dt.date.fromisoformat(m.group(1))))
            except ValueError:
                pass
    if not heads:
        return text, {}
    preamble = "".join(lines[:heads[0][0]])
    raw = {}
    for k, (i, d) in enumerate(heads):
        end = heads[k + 1][0] if k + 1 < len(heads) else len(lines)
        raw[d] = "".join(lines[i:end])
    return preamble, raw


def cmd_roll(args):
    cfg = load_config()
    if not check_setup(cfg):
        print("\n".join(FAILS))
        return 2
    if cfg["calendar_mode"] != "plain-file":
        print("calendar_mode is connected. The plain file is a mirror of your calendar, so it is rebuilt by your agent, not rolled. Nothing changed.")
        return 0
    today = get_today(cfg, args.today)
    days, preamble = parse_calendar(CAL)
    if FAILS:
        print("\n".join(FAILS))
        print("Fix calendar.md first. Nothing changed.")
        return 2
    if not preamble.strip():
        preamble = "# Calendar\n\nThe plan the Time Manager keeps when there is no connected calendar. Times are 24 hour, in the owner's time zone.\n"
    # LR-D1: existing days keep their raw text, so a note the owner typed under a day is never lost.
    _pre, raw = split_raw_days(CAL.read_text(encoding="utf-8")) if CAL.exists() else ("", {})
    past = {d: rows for d, rows in days.items() if d < today}
    keep = {d: rows for d, rows in days.items() if d >= today}
    new_days = {}
    added = []
    for i in range(cfg["horizon_days"]):
        d = today + dt.timedelta(days=i)
        if d not in keep:
            new_days[d] = render_day(d, default_rows(cfg, d))
            keep[d] = None
            added.append(d)
    def section(d):
        return raw[d].rstrip() + "\n\n" if d in raw else new_days[d].rstrip() + "\n\n"
    archived = []
    by_month = {}
    for d in sorted(past):
        by_month.setdefault(d.strftime("%Y-%m"), []).append(d)
    for month, ds in by_month.items():
        ap = HERE / "calendar" / "archive" / f"{month}.md"
        have = set(parse_calendar(ap, errors=False)[0]) if ap.exists() else set()
        text = ap.read_text(encoding="utf-8") if ap.exists() else f"# Calendar archive {month}\n\nPast days moved here by the roll. Never deleted.\n\n"
        for d in ds:
            if d not in have:
                text = text.rstrip() + "\n\n" + (raw[d].rstrip() if d in raw else render_day(d, past[d]).rstrip()) + "\n"
                archived.append(d)
        if not args.dry_run:
            ap.parent.mkdir(exist_ok=True)
            ap.write_text(text.rstrip() + "\n", encoding="utf-8")
    body = "".join(section(d) for d in sorted(keep))
    if not args.dry_run and (past or added):
        CAL.write_text(preamble.rstrip() + "\n\n" + body.rstrip() + "\n", encoding="utf-8")
    tag = "DRY RUN. " if args.dry_run else ""
    print(f"{tag}Archived {len(past)} past day(s). Added {len(added)} day(s)"
          + (f": {added[0].isoformat()} to {added[-1].isoformat()}." if added else "."))
    print(f"{tag}The calendar now covers {today.isoformat()} to {(today + dt.timedelta(days=cfg['horizon_days'] - 1)).isoformat()}.")
    return 0


def main():
    ap = argparse.ArgumentParser(description="Time Manager calendar tools")
    sub = ap.add_subparsers(dest="cmd", required=True)
    c = sub.add_parser("check")
    c.add_argument("--today")
    c.add_argument("--now", help="HH:MM, tests only: the run clock for the log Time check")
    d = sub.add_parser("day")
    d.add_argument("date", nargs="?")
    d.add_argument("--today")
    d.add_argument("--now", help="HH:MM, tests only: pretend the clock says this time today")
    r = sub.add_parser("roll")
    r.add_argument("--dry-run", action="store_true")
    r.add_argument("--today")
    args = ap.parse_args()
    return {"check": cmd_check, "day": cmd_day, "roll": cmd_roll}[args.cmd](args)


if __name__ == "__main__":
    sys.exit(main())
