# setup: map

| File | One line |
|---|---|
| `questionnaire.md` | The five setup questions and where each answer lands in `config.json` |
