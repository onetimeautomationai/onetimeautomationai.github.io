# Setup questions

At most five. Ask one per turn, in this order, and only the ones the owner has not already answered. The default is in brackets. Write each answer into `time-manager/config.json` the moment you get it. "Required" means there is no default.

**Under the Chief of Staff,** ask question 2 as "When is your sharpest focus time, and do you want lunch or other breaks protected?" and ask question 4. Those are the only two. Skip questions 1, 3 and 5.

**Before asking anything,** check for `chief-of-staff/_shared/owner-profile.md` with `setup_done: yes`. If it exists, copy these answers from it and do not ask them again: name (its question 1), time zone (5), work hours and protected hours (10), calendar tool (9). Tell the owner in one line what you copied. If the profile gives hours but no days, use Monday to Friday and say so. If the profile has no protected hours at all, ask question 3 too.

1. What should I call you, and what time zone are you in? [name: required. Time zone: the one your computer shows]
2. When do you work, which days, and when is your sharpest focus time? [Monday to Friday, 9 AM to 5 PM, focus time is your first three work hours]
3. What time is protected, so I never schedule over it? Think lunch, family, health, evenings and weekends. [lunch 12 to 1, everything outside your work hours]
4. Which times are fixed every week, such as team meetings, standing calls or classes? Skip this if you use a connected calendar, because I read them from there. [none]
5. Which calendar do you use? Say "connected" if your AI agent can reach it, or "plain file" and I keep your calendar in a file you can read. [plain file]

## How answers land in `config.json`

| Answer | Setting |
|---|---|
| Name | `owner_name` |
| Time zone | `time_zone`, as a name like `America/Chicago` |
| Work days and hours | `work_days` (three letter lowercase days), `work_hours` |
| Sharpest focus time | `focus_hours` |
| Protected time inside the work day | `protected` rows: name, days, start, end. Anything outside work hours is protected automatically (`protected_outside_work`) |
| Fixed weekly times | `fixed_weekly` rows: name, days, start, end, and `"people": true` if another person is on it |
| Calendar | `calendar_mode` (`plain-file` or `connected`) and `calendar_name` |

Use 24 hour `HH:MM` times in the file. Leave every other setting at its starting value unless the owner asks.
