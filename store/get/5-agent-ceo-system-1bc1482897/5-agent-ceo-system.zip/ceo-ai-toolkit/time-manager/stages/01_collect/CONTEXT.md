# 01_collect: gather everything that needs time

One job: list everything that needs a place on the calendar today, so nothing is missed and nothing is guessed. Paths start from the `ceo-ai-toolkit` folder.

## Inputs
- Working: the owner's message or the job row
- Handoffs: `handoffs/top3-today.md`, `handoffs/schedule-items.md`, `handoffs/jobs.md`
- Reference: `time-manager/config.json`, `time-manager/_shared/standing-rules.md`, the lessons file, `time-manager/calendar/pending.md`, `time-manager/calendar/schedule-ledger.md`, `time-manager/calendar/calendar.md`
- Template: `time-manager/_templates/run/01_collect.md`

## Process
1. Check the clock (SR2). Start the run folder: make `time-manager/runs/YYYY-MM-DD-daily/` (or `-short-name/` for a request) and copy `time-manager/_templates/run/01_collect.md` into it. Each later stage names its own template in `time-manager/_templates/outputs/`. If the folder exists, reuse it.
2. **Bring the calendar up to date.**
   - Plain file, first, before any roll: compare each row you placed (listed in the last run's `04_place.md`) with `calendar.md` as it is now. If the owner changed one by hand, keep their version and log an `edited by owner` row in `time-manager/calendar/changes-log.md` the same way (TR11). Say so in `01_collect.md`, so stage 03 does not need the archive.
   - Plain file, then: run `python3 time-manager/scripts/calendar_tools.py roll`. This automatic daily roll is green: it adds setup rows only and needs no review. It archives past days and adds missing days through today plus `horizon_days` minus 1. No Python: do the by-hand steps in `time-manager/scripts/README.md`.
   - Connected: read the owner's calendar for the same days through the owner's agent and rewrite `time-manager/calendar/calendar.md` from it, keeping the lunch, evening and other protected rows from `config.json` in each day because the connected calendar does not hold them (Source `connected` for the owner's events, Type `meeting` if the event has other people, `fixed` otherwise, Fixed or movable `fixed`). If the owner's version of a row you placed differs from the file, take the owner's version and add an `edited by owner` row to `time-manager/calendar/changes-log.md`.
3. **Top 3.** Open `handoffs/top3-today.md`. Fresh (`updated` is today): list each item with its result and the date in its heading. Not fresh or missing: write `missing: Top 3 not run today` in the run file. Alone or with no Focus Manager, ask the owner once for the 1 to 3 things that need time today, and list their answer.
4. **Schedule items.** Open `handoffs/schedule-items.md`. For each row with Status `new` that is not already in `time-manager/calendar/schedule-ledger.md`, list it. A row whose What and Date and time already match a ledger row is the same row. Skip it.
5. **Owner's asks and jobs.** Add anything the owner just asked for, and any row for the Time Manager with status `open` in `handoffs/jobs.md`.
6. **Waiting items.** List every `waiting` row in `time-manager/calendar/pending.md`. A `held:` row is an ask made in protected time, so it goes to stage 02 as a new ask (conversion on a yes: stage 04 step 1). A held ask that is red (it names another person) gets stages 02 and 03 at the next run, the first one after the protected time ends, and waits for the owner's yes in `## Waiting on your yes`. Nothing is placed before the yes. If the owner just answered one, go to `time-manager/stages/04_place/CONTEXT.md` step 1 first.
7. **Protected time (SR14).** If it is the owner's protected time now and they just messaged, add the ask to `time-manager/calendar/pending.md` as a `waiting` row whose Why starts with `held:` (asked in protected time), do green work only, and say in one line when it comes back. Skip this step if the owner said "work now".
8. Number each thing C1, C2, C3 and write the file.

## Output
- `01_collect.md` in the run folder: a table `C# | Source | What | Date and time wanted | Who else | Size`, plus every `missing:` line.

## Human check
None. Collecting is logged the same turn.
