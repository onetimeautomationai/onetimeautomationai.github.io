# 02_slot: decide where each item goes

One job: give every collected item one slot and one light, or one clear question. Paths start from the `ceo-ai-toolkit` folder.

## Inputs
- Working: `01_collect.md` in the run folder
- Reference: `time-manager/_shared/time-rules.md`, `time-manager/_shared/decision-tiers.md`, `time-manager/config.json`, `time-manager/calendar/calendar.md`, the lessons file
- Template: `time-manager/_templates/outputs/02_slot.md`

## Process
1. For each item, read the day it wants from the calendar. Get the open windows with `python3 time-manager/scripts/calendar_tools.py day YYYY-MM-DD`, or work them out from the rows by hand.
2. **Top 3 items** (TR3): one block each, in order, in the focus hours. Length is the length the owner or the item names in words (for example "90 minute"), else `default_block_minutes`. Leave `buffer_minutes` between blocks. An item that is a call (the owner phoning someone, no time agreed with them) goes after the focus hours instead (TR4). Block name: `Top 3 #N: <item>`. Type `focus`, Fixed or movable `movable`, Source `top3`. If the "One result per block" table names a time, treat it as a preference only. You pick the times (TR3), and only time after the real clock (rounded up to the next 15 minutes) counts as open today. If an item does not fit today or no open time is left, the recommended move is the earliest open window that fits, today first and then the next work day (TR3). Moves recommended in the same run never overlap each other: count a window already given to an earlier item as taken.
3. **Schedule items from email** (TR8, TR9):
   - No date, no time, or a vague time: write `missing: exact time`, add a question to the owner's list, and do not place it. Ledger result `waiting`.
   - Date already past: ledger result `skipped`, with the reason.
   - Length: `default_block_minutes` unless the email item names a length in words (TR3).
   - Only the owner on it (a deadline, a reminder, an appointment for them alone): yellow, Type `fixed`, Fixed or movable `fixed`, Source `email`.
   - Another person must attend with the owner (a meeting or a call), not just a business the owner visits, such as a dentist or a bank: red. It will not be placed yet. Slot it as a proposal in `pending.md` (stage 04).
4. **Owner's asks:** "block", "add", "put" for the owner alone is yellow, Source `owner`. "Find me a time" is read only: offer up to three open windows that fit, after the focus hours if the thing is a call, and stop. A move of something the owner made, a delete, or anything in protected time is red.
5. **Fit check** (TR6, TR14): for Top 3 items and dates from email, if the day would go over `overload_booked_percent` or under `min_open_minutes` open, place only what fits in order, name what did not fit, and recommend one move. When the owner directly asked for the block, place it and warn with one recommended move. Never use protected time to make things fit.
6. **Protected time and outside work hours** (TR2): a slot there is red. Show the owner two nearby slots that are not.
7. Give each item its light (`time-manager/_shared/decision-tiers.md`). When unsure, use the next light up. A lesson never moves a fixed meeting, it flags it under Warnings (SR15).
8. One question at a time, with your best guess as the default. If the owner does not answer, use the default and log it.

## Output
- `02_slot.md` in the run folder: the placement table `C# | Item | Day | Start | End | Type | Fixed or movable | Source | Light | Why this slot` for yellow and green items only, then a separate table of red proposals for `pending.md` (a red item is never a row in the placement table), then `lookup only`, and last the questions. A roll request ("extend my calendar") is one row that fills C#, Item and Why this slot, with Light `yellow`, and puts `n/a` in Day, Start, End, Type, Fixed or movable and Source, because it places no block.

## Human check
Only when a question is open. Otherwise stage 03 checks it.
