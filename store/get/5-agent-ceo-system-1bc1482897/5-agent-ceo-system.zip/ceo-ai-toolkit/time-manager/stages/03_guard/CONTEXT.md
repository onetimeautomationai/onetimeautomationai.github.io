# 03_guard: check it before it lands

One job: nothing lands on the calendar that double books, breaks protected time, overloads the day, or needs a yes you do not have. Paths start from the `ceo-ai-toolkit` folder.

## Inputs
- Working: `02_slot.md` in the run folder
- Reference: `time-manager/_shared/review-rubric.md`, `time-manager/_shared/time-rules.md`, `time-manager/_shared/decision-tiers.md`, `time-manager/stages/04_place/CONTEXT.md`, `time-manager/config.json`, `time-manager/calendar/calendar.md`, `handoffs/top3-today.md`, `handoffs/schedule-items.md`
- Template: `time-manager/_templates/outputs/03_guard.md`

## Process
No archive read is needed. The reviewer may read the latest month file `calendar/archive/YYYY-MM.md` only to confirm an owner edit named in `01_collect.md` was kept. Stage 01 compares the owner's edits before the roll, so an owner edit is already in `changes-log.md` and in `01_collect.md`.
**A setup roll or a roll request** (onboarding step 9, "extend my calendar") places no block, so the reviewer applies RR1 and RR2 with TR10 to the rolled days: the days added reach `horizon_days`, work days carry the protected rows from `config.json`, and weekend days carry none because `daily` protection covers them (TR10). A weekend day with no protected rows is a pass, not a fail.
1. For every slot in `02_slot.md`, confirm by hand:
   - It does not overlap another row that day.
   - It is inside work hours and outside every protected window, unless the row is red and waiting for a yes.
   - The date and weekday match the source (Top 3 heading date, schedule item date).
   - The day keeps at least `min_open_minutes` open and stays under `overload_booked_percent`.
   - No row has another person on it unless it is red.
2. **Check by light:**
   - Green: done.
   - Yellow: send the ask, `02_slot.md` and the source files to the reviewer (`review-rubric.md`). Pass: continue. Fail: back to stage 02 once with the reviewer's fixes. Second fail: treat the item as red and show the owner the work with the reviewer's notes.
   - Red: not placed. Written as a proposal for `pending.md` in stage 04, reviewed like yellow so the owner sees something correct.
3. Add `Warnings` for any day that is overloaded or has too many tight blocks (TR14), each with one recommended move.
4. **Save the reviewer's reply word for word.** Whatever the reviewer returns (pass, fail, fixes), paste it unchanged into `03_guard.md` under the item, with the reviewer named. Do not summarize or tidy it. A second review after a fix is saved the same way, under the first.
5. Write the result for each item: `pass`, `fixed after review`, `red`, or `missing`.

## Output
- `03_guard.md` in the run folder: `C# | Light | Review: pass / fail / not needed | Fix made | Result`, then the warnings.

## Human check
Yellow: the AI review. Red: the owner's yes, asked once, in stage 04. A yes to a decision is not a yes to place it with an invitation. No invitation is ever sent.
