# 05_report: tell the team what the calendar looks like

One job: write `handoffs/time-manager-report.md` so the Chief of Staff and the Focus Manager see today's calendar and open time, and so the owner hears what needs them. Paths start from the `ceo-ai-toolkit` folder.

## Inputs
- Working: the run folder, `time-manager/calendar/calendar.md`, `time-manager/calendar/pending.md`
- Reference: `time-manager/_shared/handoffs.md` (the format), `time-manager/config.json`
- Template: `time-manager/_templates/outputs/05_report.md` (the shape of `handoffs/time-manager-report.md`. No file goes in the run folder)

## Process
1. Check the clock (SR2). Get today's table and the open time line: `python3 time-manager/scripts/calendar_tools.py day`. No Python: list today's rows from the calendar file in time order, and work out the open time inside the work hours, leaving out every row and every protected window.
2. Before you overwrite, if the old report has a `## Waiting on your yes` section, copy the whole old report to `time-manager/calendar/archive/report-YYYY-MM-DD-HHMM.md` (create the folder if it is missing) (its old `updated:` date and time), so the report that showed a P number stays readable after the owner's yes. Then write `handoffs/time-manager-report.md`. Overwrite it. The header is `from: time-manager`, `updated:` the real time in the owner's time zone, and `status:` `ok`, `partial` (something is missing or a tool failed) or `failed`.
3. Sections in this order: `## Today`, `## Open time today` (both exactly as in `handoffs.md`), then only the extras that have content (the report ends on a final plain line with the most important thing, usually the first thing for the owner to do, after the last section): `## Waiting on your yes` (every `waiting` row in `pending.md` except the yellow ones whose Why starts with `held:` (stage 04 step 1 says how a held row converts, and a red held row has `held:` replaced and is listed), with your recommendation), `## Warnings`, `## Schedule items handled` (every `schedule-ledger.md` row handled today, from every run today, not only this run, so the second run of the day does not drop it. Copy the ledger's Found in email cell into the first column, because the Email Manager matches on Found in email plus What), `## Missing`.
4. If a Top 3 block was not placed because the Top 3 was not fresh, say it under `## Missing`: `missing: Top 3 not run today`, and set `status:` to `partial`. A schedule item from email with `missing: exact time` under `## Missing` also sets `status:` to `partial`. If a Top 3 item did not fit, say which one and why under `## Warnings`. If `handoffs/schedule-items.md` has no new rows, add the line `no new dates from email` under `## Schedule items handled`.
5. If you have a row in `handoffs/jobs.md`, set the Status cell of your own row to `done`, or `waiting: [reason]`. A missing Top 3 leaves the job open: write `waiting: Top 3 not run today`, never `done`. Never touch other rows.
6. Run `python3 time-manager/scripts/calendar_tools.py check`. K9 compares the Today table with the calendar. Fix any mismatch.
7. Tell the owner (alone) or hand the report to the Chief of Staff (under it). Alone, the message to the owner is one short list: what is blocked today, what is open, what waits on their yes by P number, and the one thing to do first as the last line. In that message the placed blocks are listed with their C codes from `02_slot.md` (C1, C2, C3) and their times. Three or more waiting items or questions still get P and QN codes.

## Output
- `handoffs/time-manager-report.md`, dated today.

## Human check
None. The Chief of Staff or the owner reads it. Answers to waiting items go to stage 04 step 1.
