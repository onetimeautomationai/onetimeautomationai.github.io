# 06_log: close the loop

One job: every file shows the true state before the session ends. Paths start from the `ceo-ai-toolkit` folder.

## Inputs
- Working: the run folder
- Reference: `time-manager/_shared/decision-log.md`, the lessons file, `time-manager/calendar/pending.md`, `time-manager/calendar/changes-log.md`
- Template: `time-manager/_templates/outputs/06_log.md`

## Process
1. Calendar: every placed row is in the calendar file (and in the connected calendar in Expert), and every waiting item is in `pending.md`.
2. Decision log: every decision made this session has a row. Any T3 marked done has the owner's words. Any T2 marked done says `review: pass (separate)` or `review: pass (self)`.
3. Lessons: every correction the owner gave this session is a line (SR11).
4. Changes log: every move and every owner edit has a row.
5. Run `python3 time-manager/scripts/calendar_tools.py check`. If it fails, fix what it names and run it again. To fix a log row, add a `corrects L#` row. Never edit the old one. No Python: do the checks in `time-manager/scripts/README.md` by hand.
6. Write `06_log.md` in the run folder: files updated, check result, anything still open. Fill each line from what really happened. Write `Calendar updated: no` when nothing changed. Paste the check output line under `calendar_tools.py check result`. Under Still open, list each waiting P number, or write none.
7. Last, and only after `calendar_tools.py check` exits 0, add one line to `logs/activity.md` for this run, with Agent `time-manager` and the proof copied from a file in this run folder that the next run does not overwrite, such as the check output line in `06_log.md` ("All checks passed" from `calendar_tools.py check`, never a sentence you wrote yourself, such as "Calendar updated: yes"). Format and rules are at the top of that file. A block held for the owner's yes is "waiting", never "placed". Never edit a line already there. To fix a wrong line, add a new one that says `corrects the line at <When>` in its note.

## Output
- `06_log.md` in the run folder.

## Human check
The check passes. A run is done only when this file exists.
