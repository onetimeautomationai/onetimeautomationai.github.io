# stages: map

| Folder | One line |
|---|---|
| `01_collect/` | Bring the calendar up to date, then list the Top 3, email dates and asks that need time |
| `02_slot/` | One slot and one light for each item, or one clear question |
| `03_guard/` | Check for clashes, protected time and overload. AI review for yellow |
| `04_place/` | Place yellow rows, hold red ones for the owner's yes, prove it is there |
| `05_report/` | Write `handoffs/time-manager-report.md` |
| `06_log/` | Log, lessons, checks pass |
