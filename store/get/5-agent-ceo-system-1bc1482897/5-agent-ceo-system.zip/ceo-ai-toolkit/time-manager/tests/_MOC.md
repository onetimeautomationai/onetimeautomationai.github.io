# tests: map

| File | One line |
|---|---|
| `test-cases.md` | TC1 to TC24, what the owner says and what must happen |
| `acceptance-criteria.md` | AC1 to AC12, the bar to ship |
| `rubric.md` | How a judge on a different model scores a plan |
| `test_roll_keeps_days.py` | Checks that `roll` keeps every existing day byte for byte (TC24) |
| `test-owner.md` | The made-up owner (Dana Ruiz) and her time settings for the tests |
