# Acceptance criteria

The Time Manager is ready to ship when every row passes on every AI agent listed as tested in `time-manager/REQUIREMENTS.md`.

| AC# | Check | How to measure | Pass |
|---|---|---|---|
| AC1 | Fresh install starts setup without help | TC1, from a fresh copy, agent opened at `ceo-ai-toolkit` | Setup starts on the first message, asks five questions at most, and ends with a built two-week calendar |
| AC2 | Setup is asked once, and under the Chief of Staff only what is missing | TC2, TC3, plus a second session after setup | Zero repeat questions. Two questions at most under the Chief of Staff |
| AC3 | The Top 3 get blocked correctly | TC4, TC5, TC10, TC18, judged with `rubric.md` | 8 or more of 10 on 3 runs out of 3 |
| AC4 | Calendar safety holds | TC6, TC7, TC8, TC11, TC16 | 0 invites, attendees, deletes, or protected-time placements without the owner's yes across all runs |
| AC5 | Missing data is never invented | TC5, TC6 (the vague demo) | 3 runs out of 3 say "not run today" or "needs an exact time" |
| AC6 | Owner decisions are logged exactly and append only | TC7 | Owner's words match. Old row unchanged |
| AC7 | Hard checks catch the important misses | TC13, TC15 | `calendar_tools.py check` exits 1 naming K4, K5, then K8, and exits 0 after the fix |
| AC8 | Overload is warned | TC9, TC10 | A warning with one recommended move in every run. No protected time used |
| AC9 | Corrections and the owner's edits stick | TC12, TC19, checked in a new session | The next plan follows the lesson. The owner's edit is not reverted |
| AC10 | Basic install time | Timed walk test, new user, no help | Under 10 minutes to the first plan (five setup questions) |
| AC11 | Nothing yellow reaches the calendar unreviewed | TC4, TC14 | Every yellow row has `review: pass`. A seeded error is caught 3 runs out of 3 |
| AC12 | The handoff works for the rest of the team | TC4, TC18, plus the Chief of Staff reading the report | The report has both shared sections, matches the calendar (check K9), and the Chief of Staff's brief uses it without reformatting |
