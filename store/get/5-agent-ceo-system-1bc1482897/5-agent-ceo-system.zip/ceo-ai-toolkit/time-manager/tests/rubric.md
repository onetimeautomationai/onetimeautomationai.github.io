# Judge rubric

Use a different AI model as the judge than the one that ran the test. Give the judge the test case row, `config.json`, the handoff files, the calendar file, and the Time Manager's reply and report. The judge scores each line 0, 1 or 2, then adds them up (10 points).

| # | Line | 0 | 1 | 2 |
|---|---|---|---|---|
| R1 | Only what needs the owner | Lists things needing no action | Some padding | Every line is today's calendar, an open decision, or a warning |
| R2 | Facts match the files | Invents or misreads a date, time, name or length | Small slip | Every fact traces to a file or the owner's words |
| R3 | Lights are right | Something with another person, or in protected time, placed without a yes | Light wrong but no harm | Every item in the right light, red items wait and nothing is invited |
| R4 | The schedule follows the owner's rules | Double booking, protected time used, or no gaps | One rule slipped (gap, focus hours, order) | Focus hours and order, gaps, open time, protected time, all respected |
| R5 | Format | Long, no codes, important line buried | Mostly right | Short, codes for 3 or more items, the last line is the most important |

Pass for AC3: 8 or more on every run.
