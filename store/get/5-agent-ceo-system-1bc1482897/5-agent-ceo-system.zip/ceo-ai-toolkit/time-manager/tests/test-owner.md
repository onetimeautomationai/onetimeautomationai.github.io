# Test owner (made up)

The test owner is Dana Ruiz, the same made-up owner as in `chief-of-staff/tests/test-owner.md`. Use these answers for every test case that needs setup done. Run each case in a fresh copy of the toolkit.

## When the Time Manager runs under the Chief of Staff

The Chief of Staff's profile is done with the answers in `chief-of-staff/tests/test-owner.md` (name Dana Ruiz, Pacific time, 8 AM to 5 PM, 6 PM to 8 PM protected, calendar plain file). The Time Manager copies those and asks only these two questions:

| Q | Answer |
|---|---|
| Sharpest focus time | 8 to 11 AM |
| Fixed weekly times, and lunch | Team meeting Mondays 10:00 to 10:30 with other people. Sales calls Tuesdays 1 to 3 PM with other people. Lunch 12 to 12:30 every day |

## When the Time Manager runs alone

| Q | Answer |
|---|---|
| 1 | Dana Ruiz, Pacific |
| 2 | Monday to Friday, 8 AM to 5 PM, sharpest focus 8 to 11 AM |
| 3 | Lunch 12 to 12:30 every day, evenings 6 to 8 PM, weekends |
| 4 | Team meeting Mondays 10:00 to 10:30 with other people. Sales calls Tuesdays 1 to 3 PM with other people |
| 5 | plain file |

## Settings these answers make in `config.json`

`owner_name` Dana Ruiz, `time_zone` America/Los_Angeles, `work_days` mon to fri, `work_hours` 08:00 to 17:00, `focus_hours` 08:00 to 11:00, `protected` Lunch 12:00 to 12:30 daily and Evening protected 18:00 to 20:00 daily, `fixed_weekly` Team meeting Monday 10:00 to 10:30 with people and Sales calls Tuesday 13:00 to 15:00 with people, `calendar_mode` plain-file.

## Test files to use

The test day is Tuesday 2026-11-24. Run the script with `--today 2026-11-24` so the calendar and the dates in `examples/sample-day.md` line up. The Top 3 file, the schedule items and the expected calendar are in `examples/sample-day.md`.
