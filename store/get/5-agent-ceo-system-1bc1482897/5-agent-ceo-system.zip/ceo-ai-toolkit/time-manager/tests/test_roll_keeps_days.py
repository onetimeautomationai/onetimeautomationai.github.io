#!/usr/bin/env python3
"""TC24: `roll` never changes a day that already exists (LR-D1 in the 2026-11-20 live run report).

Usage (from the ceo-ai-toolkit folder, works from any folder):
    python3 time-manager/tests/test_roll_keeps_days.py

Builds a made-up toolkit in a temporary folder (made-up owner), puts a note the owner typed under
two days, runs `roll`, and checks that every day that stays is byte for byte the same text.
Standard library only. Never touches the real calendar.
"""
import datetime as dt
import json
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent.parent  # the time-manager folder
RESULTS = []


def case(name, ok, detail=""):
    RESULTS.append(ok)
    print(f"{'PASS' if ok else 'FAIL'}  {name}" + ("" if ok else f"  ({detail})"))


def sections(text):
    """{date string: section text} split on '## YYYY-MM-DD' headings."""
    parts = re.split(r"(?m)^(?=## \d{4}-\d{2}-\d{2})", text)
    out = {}
    for part in parts:
        m = re.match(r"## (\d{4}-\d{2}-\d{2})", part)
        if m:
            out[m.group(1)] = part
    return out


def main():
    tmp = Path(tempfile.mkdtemp(prefix="time-roll-"))
    try:
        shutil.copytree(HERE, tmp / "time-manager", ignore=shutil.ignore_patterns("__pycache__", "runs", "archive"))
        cfg_path = tmp / "time-manager" / "config.json"
        cfg = json.loads(cfg_path.read_text(encoding="utf-8"))
        cfg.update({"setup_done": True, "owner_name": "Dana Ruiz", "time_zone": "America/Los_Angeles",
                    "work_hours": {"start": "08:00", "end": "17:00"}, "focus_hours": {"start": "08:00", "end": "11:00"},
                    "protected": [{"name": "Lunch", "start": "12:00", "end": "12:30", "days": ["daily"]}]})
        cfg_path.write_text(json.dumps(cfg, indent=2), encoding="utf-8")
        cal = tmp / "time-manager" / "calendar" / "calendar.md"
        start = dt.date(2026, 11, 24)
        text = "# Calendar\n\nMade-up preamble.\n\n"
        for i in range(14):
            d = start + dt.timedelta(days=i)
            text += f"## {d.isoformat()} {d.strftime('%A')}\n\n| Start | End | Block | Type | Fixed or movable | Source |\n|---|---|---|---|---|---|\n"
            if d.weekday() < 5:
                text += "| 12:00 | 12:30 | Lunch | protected | fixed | setup |\n"
            if d.isoformat() == "2026-11-27":
                text += "\nNote: Dana is traveling, keep it light.\nSecond note line with a | pipe.\n"
            if d.isoformat() == "2026-11-24":
                text += "\nNote on the day that will be archived.\n"
            text += "\n"
        cal.write_text(text, encoding="utf-8")
        before = sections(text)

        r = subprocess.run([sys.executable, str(tmp / "time-manager" / "scripts" / "calendar_tools.py"), "roll", "--today", "2026-11-26"],
                           cwd=tmp, capture_output=True, text=True)
        case("roll exits 0", r.returncode == 0, r.stdout + r.stderr)
        after_text = cal.read_text(encoding="utf-8")
        after = sections(after_text)
        stay = [d for d in before if d >= "2026-11-26"]
        same = [d for d in stay if after.get(d, "").rstrip() == before[d].rstrip()]
        case("every existing day that stays is byte for byte the same", len(stay) == len(same) and len(stay) > 0, [d for d in stay if d not in same])
        case("the owner's note under 2026-11-27 is still there", "Note: Dana is traveling, keep it light." in after_text and "Second note line with a | pipe." in after_text)
        case("days were added at the end through today plus 13", "2026-12-09" in after and "2026-12-10" not in after, sorted(after)[-2:])
        case("past days are out of the calendar", "2026-11-24" not in after and "2026-11-25" not in after)
        arch = tmp / "time-manager" / "calendar" / "archive" / "2026-11.md"
        arch_text = arch.read_text(encoding="utf-8") if arch.exists() else ""
        case("past days are in the archive with the owner's note kept", "2026-11-24" in arch_text and "Note on the day that will be archived." in arch_text)
        r2 = subprocess.run([sys.executable, str(tmp / "time-manager" / "scripts" / "calendar_tools.py"), "roll", "--today", "2026-11-26"],
                            cwd=tmp, capture_output=True, text=True)
        case("a second roll changes nothing", cal.read_text(encoding="utf-8") == after_text and r2.returncode == 0, r2.stdout)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    passed = sum(RESULTS)
    print(f"\n{passed} passed, {len(RESULTS) - passed} failed.")
    return 0 if all(RESULTS) else 1


if __name__ == "__main__":
    sys.exit(main())
