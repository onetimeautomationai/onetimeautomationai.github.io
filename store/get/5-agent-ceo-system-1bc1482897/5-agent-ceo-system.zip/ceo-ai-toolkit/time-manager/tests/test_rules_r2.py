#!/usr/bin/env python3
"""Checks added in 0.1.5 (R2-D1, R2-D3, R2-D4 in the 2026-11-21 rerun report).

Usage (works from any folder):
    python3 time-manager/tests/test_rules_r2.py

Builds a made-up toolkit in a temporary folder (made-up owner), writes calendar and log rows,
runs `calendar_tools.py check`, and looks for the K number in the output.
Standard library only. Never touches the real calendar.
"""
import datetime as dt
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent.parent  # the time-manager folder
RESULTS = []
TODAY = "2026-11-24"


def case(name, ok, detail=""):
    RESULTS.append(ok)
    print(f"{'PASS' if ok else 'FAIL'}  {name}" + ("" if ok else f"  ({detail})"))


def build(tmp, rows_today, log_rows=""):
    shutil.copytree(HERE, tmp / "time-manager", ignore=shutil.ignore_patterns("__pycache__", "runs", "archive"))
    tm = tmp / "time-manager"
    cfg_path = tm / "config.json"
    cfg = json.loads(cfg_path.read_text(encoding="utf-8"))
    cfg.update({"setup_done": True, "owner_name": "Dana Ruiz", "time_zone": "America/Los_Angeles",
                "work_hours": {"start": "08:00", "end": "17:00"}, "focus_hours": {"start": "08:00", "end": "11:00"},
                "protected": [{"name": "Lunch", "start": "12:00", "end": "12:30", "days": ["daily"]}]})
    cfg_path.write_text(json.dumps(cfg, indent=2), encoding="utf-8")
    text = "# Calendar\n\n"
    start = dt.date(2026, 11, 24)
    for i in range(14):
        d = start + dt.timedelta(days=i)
        text += f"## {d.isoformat()} {d.strftime('%A')}\n\n| Start | End | Block | Type | Fixed or movable | Source |\n|---|---|---|---|---|---|\n"
        if d.weekday() < 5:
            text += "| 12:00 | 12:30 | Lunch | protected | fixed | setup |\n"
        if d.isoformat() == TODAY:
            text += rows_today
        text += "\n"
    (tm / "calendar" / "calendar.md").write_text(text, encoding="utf-8")
    if log_rows:
        log = tm / "_shared" / "decision-log.md"
        base = log.read_text(encoding="utf-8")
        log.write_text(base.rstrip() + "\n" + log_rows, encoding="utf-8")
    return tm


def run_check(tmp, tm, extra=()):
    r = subprocess.run([sys.executable, str(tm / "scripts" / "calendar_tools.py"), "check", "--today", TODAY, *extra],
                       cwd=tmp, capture_output=True, text=True)
    return r.returncode, r.stdout + r.stderr


def scenario(rows_today="", log_rows="", extra=()):
    tmp = Path(tempfile.mkdtemp(prefix="time-r2-"))
    try:
        tm = build(tmp, rows_today, log_rows)
        return run_check(tmp, tm, extra)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def has(out, code, what):
    return any(line.startswith(code) and what in line for line in out.splitlines())


def main():
    # R2-D1: a held ask that names another person is T3 pending
    row = "| L1 | 2026-11-23 19:00 | Held: set up time with Priya on Friday | {t} | held during protected time | none | | {r} |\n"
    _, out = scenario(log_rows=row.format(t="T1", r="pending"))
    case("held ask naming a person logged T1 fails K8", has(out, "K8", "held ask that names another person"), out)
    _, out = scenario(log_rows=row.format(t="T3", r="pending"))
    case("held ask naming a person logged T3 pending passes K8", "K8 FAIL" not in out, out)
    _, out = scenario(log_rows=row.format(t="T3", r="done"))
    case("held T3 ask with Result done fails K8", has(out, "K8", "held T3 ask waits"), out)
    own = "| L1 | 2026-11-23 19:00 | Held: Block Friday 10:00 to 11:00 for Top 3 #1 | T2 | held | none | | pending |\n"
    _, out = scenario(log_rows=own)
    case("held owner-only block is not forced to T3", "K8 FAIL" not in out, out)

    # R2-D3: review evidence says separate or self
    rev = "| L1 | 2026-11-24 08:00 | Block 08:00 to 09:00 for Top 3 #1 | T2 | top 3 | {e} | | done |\n"
    _, out = scenario(log_rows=rev.format(e="review: pass, run 2026-11-24-daily"))
    case("bare 'review: pass' fails K8", has(out, "K8", "yellow (T2)"), out)
    _, out = scenario(log_rows=rev.format(e="review: pass (separate), run 2026-11-24-daily"))
    case("'review: pass (separate)' passes K8", "K8 FAIL" not in out, out)
    _, out = scenario(log_rows=rev.format(e="review: pass (self), run 2026-11-24-daily"))
    case("'review: pass (self)' passes K8 with a WARN", has(out, "K8 WARN", "yourself") and "K8 FAIL" not in out, out)

    # R2-D4: Top 3 block never runs past the focus end, never touches a fixed row
    hdr = "| 08:00 | 09:00 | Top 3 #1: proposal | focus | movable | top3 |\n"
    late = hdr + "| 10:55 | 11:55 | Top 3 #3: report | focus | movable | top3 |\n"
    _, out = scenario(rows_today=late)
    case("Top 3 block past the focus end fails K5", has(out, "K5 FAIL", "focus end"), out)
    ok = hdr + "| 09:10 | 10:10 | Top 3 #3: report | focus | movable | top3 |\n| 11:00 | 12:00 | Top 3 #2: call Tom | focus | movable | top3 |\n"
    _, out = scenario(rows_today=ok)
    case("Top 3 blocks inside focus and a call after it pass K4 and K5", not any(l.startswith(("K4 FAIL", "K5 FAIL")) for l in out.splitlines()), out)
    touch = "| 13:00 | 15:00 | Sales calls | fixed | fixed | setup |\n| 15:00 | 16:00 | Top 3 #2: call Tom | focus | movable | top3 |\n"
    _, out = scenario(rows_today=touch)
    case("a placed block touching a fixed row fails K4", has(out, "K4 FAIL", "fixed row"), out)
    gap = "| 13:00 | 15:00 | Sales calls | fixed | fixed | setup |\n| 15:10 | 16:10 | Top 3 #2: call Tom | focus | movable | top3 |\n"
    _, out = scenario(rows_today=gap)
    case("a placed block with the buffer to a fixed row passes", not any(l.startswith("K4 FAIL") for l in out.splitlines()), out)

    # R4-T8: a placed block with no `added` row warns K12 (WARN only, exit code unchanged)
    blk = "| 08:00 | 09:00 | Top 3 #1: proposal | focus | movable | top3 |\n"
    _, out = scenario(rows_today=blk)
    case("placed block with no `added` row warns K12", has(out, "K12 WARN", "no `added` row"), out)
    tmp = Path(tempfile.mkdtemp(prefix="time-r2-"))
    try:
        tm = build(tmp, blk)
        log = tm / "calendar" / "changes-log.md"
        log.write_text(log.read_text(encoding="utf-8").rstrip() + "\n| 2026-11-24 07:50 | 2026-11-24 | Top 3 #1: proposal | plain file | added | | 08:00 to 09:00 | placed |\n", encoding="utf-8")
        _, out = run_check(tmp, tm)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    case("block with its `added` row passes K12", "K12" not in out, out)

    # F-T3: "Roll the calendar forward" is not an email forward
    roll = "| L1 | 2026-11-24 08:00 | Roll the calendar forward to 2026-12-07 | T1 | keep 14 days | none | | done |\n"
    _, out = scenario(log_rows=roll)
    case("'Roll the calendar forward' is not read as a T3 action", "K8 FAIL" not in out, out)
    fwd = "| L1 | 2026-11-24 08:00 | Forward the email to Priya | T1 | owner asked | none | | done |\n"
    _, out = scenario(log_rows=fwd)
    case("'Forward the email' still fails K8 as T3", has(out, "K8 FAIL", "must be T3"), out)

    # F-T4: the log Time is the run clock, never later than it
    tm_row = "| L1 | {t} | Block 08:00 to 09:00 for Top 3 #1 | T2 | top 3 | review: pass (separate) | | done |\n"
    _, out = scenario(log_rows=tm_row.format(t="2026-11-25 08:00"))
    case("a log Time on a later day fails K8", has(out, "K8 FAIL", "later than the run clock"), out)
    _, out = scenario(log_rows=tm_row.format(t="2026-11-24 10:00"), extra=("--now", "09:00"))
    case("a log Time later than --now on the same day fails K8", has(out, "K8 FAIL", "later than the run clock"), out)
    _, out = scenario(log_rows=tm_row.format(t="2026-11-24 08:30"), extra=("--now", "09:00"))
    case("a log Time before --now passes K8", "K8 FAIL" not in out, out)
    fix = tm_row.format(t="2026-11-25 08:00") + "| L2 | 2026-11-24 09:00 | corrects L1: Time was the block's | T2 | fix | review: pass (separate) | | done |\n"
    _, out = scenario(log_rows=fix, extra=("--now", "09:30"))
    case("a corrects row replaces a log row with a bad Time", "K8 FAIL" not in out, out)

    # F-T5: the exact review string, then optional text after a space or a comma
    for ev, ok in (("review: pass (separate) second review", True), ("review: pass (separate), run 2026-11-24-daily", True),
                   ("review: pass (self)", True), ("review: pass (separate, second review)", False),
                   ("review: pass (separate)second", False)):
        _, out = scenario(log_rows=rev.format(e=ev))
        case(f"Evidence '{ev}' {'passes' if ok else 'fails'} K8", ("K8 FAIL" not in out) == ok, out)

    # F2-T5: a `corrects` row in the changes log counts as the `added` row for its Block
    tmp = Path(tempfile.mkdtemp(prefix="time-r2-"))
    try:
        tm = build(tmp, blk)
        log = tm / "calendar" / "changes-log.md"
        log.write_text(log.read_text(encoding="utf-8").rstrip() + "\n| 2026-11-24 07:50 | 2026-11-24 | Top 3 #1 proposal | plain file | added | | 08:00 to 09:00 | placed |\n| 2026-11-24 07:55 | 2026-11-24 | Top 3 #1: proposal | plain file | corrects | Top 3 #1 proposal | 08:00 to 09:00 | corrects the row above |\n", encoding="utf-8")
        _, out = run_check(tmp, tm)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    case("a `corrects` changes row satisfies K12 for the right block name", "K12" not in out, out)

    # 0.1.10: Source `job` (a Chief of Staff job) is a valid value
    tmp = Path(tempfile.mkdtemp(prefix="time-r2-"))
    try:
        tm = build(tmp, "| 09:00 | 10:00 | Must P3: contract | focus | movable | job |\n")
        _, out = run_check(tmp, tm)
        _tm2 = build(tmp / "x", "| 09:00 | 10:00 | Bad | focus | movable | bogus |\n") if (tmp / "x").mkdir() is None else tm
        _, out2 = run_check(tmp / "x", _tm2)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    case("Source `job` passes K2", "K2 FAIL" not in out, out)
    case("an unknown Source still fails K2", "K2 FAIL" in out2, out2)

    # 0.1.11 L-T3: K9 works out the open line again, so a stale line fails
    blk = "| 08:00 | 09:00 | Top 3 #1: proposal | focus | movable | top3 |\n"
    tmp = Path(tempfile.mkdtemp(prefix="time-r2-"))
    try:
        tm = build(tmp, blk)
        day = subprocess.run([sys.executable, str(tm / "scripts" / "calendar_tools.py"), "day", "--today", TODAY, "--now", "09:10"],
                             cwd=tmp, capture_output=True, text=True).stdout.strip().splitlines()
        table, total = day[:-2], day[-1]
        head = "---\nfrom: time-manager\nupdated: 2026-11-24 09:10\nstatus: ok\n---\n\n## Today\n" + "\n".join(table) + "\n\n## Open time today\n"
        (tmp / "handoffs").mkdir(exist_ok=True)
        rep = tmp / "handoffs" / "time-manager-report.md"
        rep.write_text(head + total + "\n\nDo the proposal first.\n", encoding="utf-8")
        _, fresh = run_check(tmp, tm, ("--now", "09:10"))
        rep.write_text(head + total.replace("Total: ", "Total: 9 ", 1) + "\n\nDo the proposal first.\n", encoding="utf-8")
        _, stale = run_check(tmp, tm, ("--now", "09:10"))
        rep.write_text(head + "- Total: 7.5 hours open. When: 09:00 to 12:00, 12:30 to 17:00\n\nDo the proposal first.\n", encoding="utf-8")
        _, stale2 = run_check(tmp, tm, ("--now", "09:10"))
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    case("a report whose open line matches the day command passes K9", "K9" not in fresh, fresh)
    case("a report with a wrong open line fails K9", has(stale, "K9 FAIL", "open line is stale"), stale)
    case("a report open line left from an earlier clock fails K9", has(stale2, "K9 FAIL", "open line is stale"), stale2)

    passed = sum(RESULTS)
    print(f"\n{passed} passed, {len(RESULTS) - passed} failed.")
    return 0 if all(RESULTS) else 1


if __name__ == "__main__":
    sys.exit(main())
