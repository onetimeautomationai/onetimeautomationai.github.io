# What to say to your Time Manager

| Say | It does |
|---|---|
| "Start my Time Manager" | First-time setup (five questions at most), then builds your first two weeks |
| "Plan my day" or "Morning" | Today's calendar, your open time, and a block for each of your Top 3 |
| "Block [day] [time] for [thing]" | Puts time on your calendar for you alone |
| "Add [thing] on [day] at [time]" | Same, for a date that is only yours (your dentist, a deadline) |
| "Find me a time for [thing]" | Offers up to three open slots. Changes nothing |
| "What's open [day]?" | Your open time for that day |
| "What now?" | The block you are in, when it ends, and the result it is for |
| "Show my week" | The next seven days from your calendar |
| "Yes to P1" / "No to P1" / "Later" | Answers a waiting item (a meeting, protected time, a move). Yes places it, with no invitation sent |
| "What needs me?" | Only the items waiting on your yes |
| "Extend my calendar" | Adds days so you are covered two weeks ahead |
| "Connect my calendar" | Expert setup, see `INSTALL.md` |
| "From now on, ..." | Saves a new rule in your lessons file |
| "Redo setup" | Asks the setup questions again |
| "Stop" | Stops all jobs and lists what was in progress |
| "Uninstall the Time Manager" | Safe removal, see `UNINSTALL.md` |
