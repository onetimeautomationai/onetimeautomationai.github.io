# Setup questionnaire

Ask these a few at a time. Write the answers into `../_shared/owner-profile.md` and `../_shared/roster.md`, replacing every `{{placeholder}}`. Then delete nothing. Keep this file for re-setup.

## Goals
1. What is your #1 goal, with a number and a deadline? What comes after it (your goal stack, in order)?
2. What daily actions move that goal most? These become your leading metrics (for example: new conversations, follow-ups, offers made, pages published).
3. What results prove it is working? These become your lagging metrics (for example: calls booked, sales, cash collected, recurring revenue).

## Roles
4. Do you want persona names for the CEO and Orchestrator? (Optional. Some people like a name and a voice. Default: "CEO" and "Orchestrator".)
5. First show the owner the example roster in the layer folder at the pack root (`real-estate-team-leader/roster.md`) and offer to copy the roles they want. Then ask: what other specialist roles do you need? Start with 0 to 3 (for example: writer, researcher, sales desk, bookkeeper, builder). Add more only when a job has no owner twice.
6. Who reviews work before you see it: a QA role every time, or only when you ask?

## Approval and limits
7. What must never happen without your approval? (Default: sending anything to another person, posting, paying, deleting, changing an external system.)
8. Any people, brands or topics the team must never mention or contact?
9. Which tools can the team use (email, calendar, CRM, notes, task manager)? Which account is which? For the calendar, give the calendar IDs for work, personal and appointments. If you have no Google Calendar or connector, answer "local file" and the time manager keeps a plain markdown calendar.

## SOPs
10. Where do your SOPs live? Default: the `sops/` folder in this folder, with `sops/INDEX.md` as the index. Write the path into the `sop_index` field of the owner profile. If you already keep SOPs somewhere else, give that path or index instead.

## Style
11. How do you want reports: length, format, rated drafts, codes for lists?
