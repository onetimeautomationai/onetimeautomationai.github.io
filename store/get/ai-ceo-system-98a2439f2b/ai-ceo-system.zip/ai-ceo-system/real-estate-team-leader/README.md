# Real estate team leader layer

This folder sits on top of `ai-leadership-team/` and `ai-time-manager/`. It gives you a starting point for a real estate team so you do not begin from a blank page.

Everything here is an example. Nothing in it is a result, a statistic or an income claim. Replace the names, goals and times with your own during setup.

## What is inside

- `roster.md`: five team roles (lead agent, ISA, transaction coordinator, listing coordinator, marketing) written so you can paste them into `ai-leadership-team/_shared/roster.md` as specialist roles.
- `example-week.md`: an example week for a team leader, written as a blueprint you can edit and copy into the time manager.
- `example-ideas.md`: eight example ideas run through the decision tiers, so you can see what the CEO decides alone and what comes to you.

## How to use it

1. Run setup from the pack root. The agent shows `roster.md` before it asks for your specialist roles.
2. Keep the roles you actually have. Delete the rest.
3. The agent copies the kept roles into the specialist table in `ai-leadership-team/_shared/roster.md`. The columns match.
4. Read `example-week.md`, then tell the agent to build your own blueprint from it.
5. Read `example-ideas.md` once. It shows how an idea is ranked against goal 1 and who decides it.

## Rules that stay true for a real estate team

- Nothing goes to a client, a lead or another agent without your approval.
- Anything about fair housing, advertising rules, contracts or fees goes to you and to your broker. The agent does not decide those.
- The agent drafts. You and your people send.
