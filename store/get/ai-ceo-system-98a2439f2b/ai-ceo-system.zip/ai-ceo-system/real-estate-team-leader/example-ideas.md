# Example ideas run through the decision tiers

These show the method. Assume an example goal 1 of "close more transactions with the current team this year." Your goal will differ, so your rankings will too. No result is claimed for any idea here.

How the tiers work: T1 is reversible and internal, so the role doing the job decides. T2 is reversible and moderate, so the CEO decides and tells you in the report. T3 involves money, anyone outside the team, or something hard to undo, so it comes to you with a recommendation first.

| # | Idea | Tier | Rank | Who decides | Why |
|---|---|---|---|---|---|
| 1 | Reorder the daily call list so the newest leads come first | T1 | Now | The ISA support role | Internal, reversible, inside the existing job |
| 2 | Move the Friday review from 3:00 to 2:30 | T2 | Now | CEO, told to you in the report | A calendar change that you can undo in one step |
| 3 | Create a closing checklist for every new accepted offer | T2 | Now | CEO, told to you in the report | Internal, helps goal 1, easy to remove |
| 4 | Send a past-client email about a market change | T3 | Now | You | Goes to people outside the team. The agent drafts it and you approve |
| 5 | Add a new paid lead source | T3 | Later | You | It costs money. Needs a baseline of current lead numbers first |
| 6 | Hire a second transaction coordinator | T3 | Later | You | A new recurring commitment. Wait until the current coordinator's workload is measured |
| 7 | Post a listing video on social media | T3 | Now | You | Public and tied to advertising rules. The agent drafts and you and your broker approve |
| 8 | Redesign the team logo | T3 | No | You, with the reason logged | Does not move goal 1 this month. Logged so it is not lost |

## How to read the table

- Rank "Now" means it moves goal 1 this month. "Later" means it helps goal 1 but needs something built first, and the dependency is named. "No" means it is logged with a reason.
- When the agent is unsure, it treats the idea as one tier higher.
- Each T3 item becomes a pending question on the board with the recommendation first. You answer once and the agent does not ask again.
