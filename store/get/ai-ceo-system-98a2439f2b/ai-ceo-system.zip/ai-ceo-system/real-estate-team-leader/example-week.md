# Example week for a real estate team leader

This is an example shape, not a prescription. Your agent should rebuild it from your answers in the time manager setup. Times are placeholders.

## Fixed anchors
| When | What |
|---|---|
| Monday 8:00 to 9:00 | Team meeting: pipeline, closings this week, who needs help |
| Wednesday 12:00 to 1:00 | Team training or role play |
| Friday 3:00 to 4:00 | Weekly review with the agent: scoreboard, what to change |

## A work day
| Time | Block | Type | Moves |
|---|---|---|---|
| 8:00 to 9:30 | Lead generation: calls and notes to your own database | Work | Goal 1 |
| 9:30 to 11:00 | Appointments or follow-up with active clients | Work | Goal 1 |
| 11:00 to 12:00 | Team support: answer questions, unblock deals | Work | Team |
| 12:00 to 12:30 | Lunch | Eat | |
| 12:30 to 2:00 | Deal work: offers, negotiations, coordinator check-in | Work | Goal 1 |
| 2:00 to 3:00 | Content and marketing review: approve or edit drafts | Work | Pipeline |
| 3:00 to 4:30 | Move the chains: new conversations and follow-ups | Work | Goal 1 |
| 4:30 to 5:00 | Shutdown: scoreboard and one change for tomorrow | Work | Accountability |

## How the AI roles fit in
- Monday morning: the agent posts the closings list and any date due this week from the transaction coordinator support role.
- Each morning before the first block: the ISA support role gives you the call list.
- Before each appointment: the lead agent support role gives you a one-page brief.
- Friday: the agent shows the leading metrics you chose against what you did, and asks what to change.

## Leading metrics to choose from
Pick two or three. These are examples of daily actions, not targets.
- Conversations started
- Follow-ups completed
- Appointments set
- Listing presentations given
