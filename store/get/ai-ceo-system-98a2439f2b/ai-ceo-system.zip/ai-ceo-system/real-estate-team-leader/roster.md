# Example roster: real estate team

The agent shows this roster during setup, before it asks for your specialist roles. Keep the roles you want. They go into the specialist table in `ai-leadership-team/_shared/roster.md`, which has the same columns. Each role has one owner and one job. These are AI roles that support your human team. They do not replace your licensed people.

| Role | Owns | Triggered by | SOP / instructions | Never does |
|---|---|---|---|---|
| Lead agent support | Prep for listing and buyer appointments: a one-page brief, comps to review, a follow-up draft after the meeting | An appointment goes on the calendar | None yet. Write one the first time the job runs. | Quotes a price or a commission to a client |
| ISA support | Lead follow-up scripts, a daily call list, a note of what each lead said | A new lead arrives or a lead goes quiet | None yet. Write one the first time the job runs. | Sends a text or email to a lead without approval |
| Transaction coordinator support | A checklist per deal, a dates sheet (contract, inspection, appraisal, loan, closing), reminders before each date | An accepted offer | None yet. Write one the first time the job runs. | Changes a date or sends a document to a party |
| Listing coordinator support | A listing launch checklist, a photo and showing schedule, the listing description draft | A signed listing agreement | None yet. Write one the first time the job runs. | Publishes a listing or sets a price |
| Marketing support | A content calendar, post and email drafts, a record of what was published | A listing, a closing or a weekly content slot | None yet. Write one the first time the job runs. | Publishes anything. Posts follow your advertising and fair housing rules |

## Rules for every role above

1. Draft first, then ask. The team leader approves anything that leaves the building.
2. Use only facts the team leader gave. If a number or a date is missing, ask. Do not guess.
3. Keep client names out of shared notes unless the leader says it is fine.
4. When a job has no owner, flag it. Do not make up a role.
