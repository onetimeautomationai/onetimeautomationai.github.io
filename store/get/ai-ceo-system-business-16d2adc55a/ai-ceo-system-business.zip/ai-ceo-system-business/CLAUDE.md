# AI CEO System: pack root

Start here. Two folders live next to this file. Each has its own `CLAUDE.md`.

| Folder | What it is |
|---|---|
| `ai-leadership-team/` | The leadership team. Its `CLAUDE.md` runs the seven stages. |
| `ai-time-manager/` | The time manager. Its `CLAUDE.md` runs the calendar stages. |
| `business-layer/` | Example roster, example week and example ideas. |

Also in this pack: `session-clock/`, an optional hook.

## When the owner says "run setup"

Run ONE combined setup. Do not send the owner to two separate setups. Ask a few questions at a time. Never ask the same thing twice.

1. Check `ai-leadership-team/_shared/owner-profile.md`. If it still has `{{` placeholders, run step 2. If not, skip to step 3.
2. Leadership team questions first. Follow `ai-leadership-team/setup/questionnaire.md` in order. Before question 5 (specialist roles), show the example roster in `business-layer/roster.md` and offer to copy the roles the owner wants. Also ask for the calendar IDs (or "local file") in question 9, and the SOP index path in question 10.
3. Time manager questions second. Follow `ai-time-manager/setup/questionnaire.md`. Skip the goal stack, because `ai-time-manager/_shared/owner-profile.md` points to the leadership owner profile for goals. Ask only for the daily actions if the leadership profile lacks them. Copy the calendar IDs (or "local file") from the first part into the Calendars table. Ask nothing about them again.
4. Build the blueprint (time manager stage 01) and get the owner's approval. Then run stage 02.
5. Tell the owner what was filled in and what is still open.

## Calendar fallback

If the owner has no Google Calendar and no calendar connector, set every calendar to "local file". Stages 02 and 03 then write the plan to `ai-time-manager/calendar/calendar.md`. Never stop setup because Google is missing. `ai-time-manager/scripts/calendar_roll.py` is optional and needs Google.

## After setup

- An idea, ask or brain dump: use `ai-leadership-team/CLAUDE.md`.
- A task to schedule, "what's ahead", shutdown, or weekly review: use `ai-time-manager/CLAUDE.md`.
- The two teams share one owner profile for goals. Do not copy goals into the time manager.

## Rules that never bend

1. Nothing goes to another person or an external system without the owner's approval.
2. Check the real clock before any time claim.
