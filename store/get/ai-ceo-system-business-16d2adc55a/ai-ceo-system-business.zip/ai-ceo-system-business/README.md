# AI CEO System: Business Edition

This folder gives your AI agent a leadership team, a two-week calendar and a clock.

## What is inside

| Folder | What it does |
|---|---|
| `CLAUDE.md` | The start file at the pack root. It runs one combined setup. |
| `ai-leadership-team/` | A leadership team with seven working stages: intake, decide, plan jobs, prepare, review, report and log. It has standing rules, decision tiers, a roster, an owner profile, a board, an SOP index in `sops/` and a setup questionnaire. |
| `ai-time-manager/` | A time manager with a two-week rolling calendar, slotting, edit learning, a road ahead view, a shutdown scoreboard, a session rating and a weekly review. It works with Google Calendar or with a plain markdown calendar file. |
| `session-clock/` | A Claude Code hook that shows the real time and your current and previous calendar block when a session starts and on each prompt. |
| `business-layer/` | A business layer: an example roster (operations, sales, marketing, finance, admin), an example owner week and 8 example ideas run through the decision tiers. |

## Setup

1. Unzip the download. Copy all the folders and `CLAUDE.md` into your agent workspace.
2. Start your agent from the pack root, the folder that holds this README and `CLAUDE.md`. Do not start it inside a subfolder.
3. Say "run setup" once. The agent runs one combined setup. It asks the leadership team questions first, then the time manager questions. It never asks for the same goal twice.
4. When the agent reaches the specialist roles, it shows the example roster in `business-layer/roster.md` first. Say which roles you want. Then it asks for any others.
5. When the agent asks about your calendar, give your calendar IDs. No Google Calendar? Say "local file". Your plan is then kept in `ai-time-manager/calendar/calendar.md` and nothing else is needed.
6. Optional: install the session clock hook. Follow `session-clock/README.md`. It takes about five minutes and uses only Python.

## Optional: Google Calendar

Skip this section if you said "local file". The agent works without it.

1. Install the Google client libraries first. Run this line in your terminal: `pip install google-api-python-client google-auth`
2. Create the OAuth token file. `ai-time-manager/scripts/README.md` has the steps.
3. Copy `ai-time-manager/scripts/config.example.json` to `config.json` and fill in your calendar IDs.
4. Test with `python3 ai-time-manager/scripts/calendar_roll.py --config ai-time-manager/scripts/config.json --dry-run`.
5. Schedule `calendar_roll.py` weekly. `ai-time-manager/scripts/README.md` has the steps.

## What you need

- Claude Code or another AI agent that can read and write files in a folder.
- Python 3.9 or newer for the optional session clock and the optional Google roll.
- Optional: a Google Calendar. Without it, the plan lives in a markdown file.

## Good to know

- Your agent works from plain markdown files. You can read and edit all of them.
- Nothing goes to another person or to an outside system without your approval.
- The examples in `business-layer/` are examples. They contain no results and no income claims.
