# Pipeline definition

**Repeating unit:** one owner request (an idea, an ask, a decision, a brain dump). One run = one request, from intake to log.

| # | Stage | Lead role | Output (in `runs/{run}/`) | Human gate |
|---|---|---|---|---|
| 01 | intake | Orchestrator | `01_intake.md` | none, logged the same turn |
| 02 | decide | CEO | `02_decide.md` | Owner + CEO decide (skip if owner already decided) |
| 03 | plan-jobs | Orchestrator | `03_jobs.md` | Owner only for T3 items (`_shared/decision-tiers.md`) |
| 04 | prepare | Specialist roles | `04_prepared.md` + drafts | none |
| 05 | review | QA Reviewer | `05_review.md` | QA pass |
| 06 | report | CEO / Orchestrator | `06_report.md` | Owner approves any send or external write |
| 07 | log | Orchestrator + Accountability Coach | `07_log.md` | Scoreboard check |

**Small asks** (a lookup, a status check) go 01, then 06, then 07. Write `03_jobs.md` with the single line "lookup only" so status stays derivable.

**Factory (stable every run):** everything in `_shared/`.
**Product (new every run):** everything in `runs/`, plus rows on `board/board.md`.

Every stage reads `_shared/standing-rules.md`.
