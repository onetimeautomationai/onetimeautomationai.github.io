# AI Leadership Team: an exportable ICM

A folder you drop into your AI operating system (Claude Code, Cursor, Codex, or any agent that reads files). It turns your AI into a small leadership team:

- **CEO (AI):** ranks every idea against your goals, decides what is now, later, or no, and owns your calendar if you also install the AI Time Manager ICM.
- **Orchestrator:** breaks decisions into jobs, hands each to the right role, checks the work, and reports back.
- **Behind them:** a QA Reviewer, an Accountability Coach, and any specialist roles you add. You never manage them directly.

You talk to two roles. They manage everyone else.

## Install (5 minutes)
1. Copy this folder into your AI workspace.
2. Point your agent at `CLAUDE.md`. Rename it `AGENTS.md` if your tool expects that name.
3. Say "run setup". The agent walks `setup/questionnaire.md` and fills `_shared/owner-profile.md` and `_shared/roster.md`.
4. Share your first idea. The agent starts a run in `runs/`.

No folder support? Paste `INJECT-PROMPT.md` into your AI's system prompt or custom instructions instead. You lose the file trail but keep the operating model.

## What one run looks like
1. You: "I want to run a webinar for my audience."
2. **Intake:** logged verbatim on the board as IN1.
3. **Decide:** the CEO checks it against your goal stack and recommends "yes, after the offer is done, because a webinar needs something to sell." You answer.
4. **Plan jobs:** the Orchestrator splits it into jobs with an owner role each, and schedules your part on the calendar.
5. **Prepare:** roles do the work or draft it.
6. **Review:** QA checks every draft and claim.
7. **Report:** one short report. You approve anything that leaves the building.
8. **Log:** the board, the scoreboard and the lessons file are updated. At session end you get a rating of how much the session moved your goal.

## Files
- `CLAUDE.md`: entry file and routing, read first.
- `CONTEXT.md`: the 7-stage pipeline.
- `_shared/`: your profile, roster, decision tiers, standing rules, lessons.
- `board/board.md`: inbox, decisions, job queue, wins.
- `stages/0N_*/CONTEXT.md`: one contract per stage.
- `INJECT-PROMPT.md`: a single-prompt version.

Method: Interpretable Context Methodology (Van Clief & McDermott, arXiv:2603.16021). Pairs with the **AI Time Manager** ICM.
