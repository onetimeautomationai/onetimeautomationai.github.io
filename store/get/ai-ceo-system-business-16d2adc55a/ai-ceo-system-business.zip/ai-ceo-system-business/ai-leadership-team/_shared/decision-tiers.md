---
type: factory
---

# Decision tiers

| Tier | What it covers | Who decides | Logged where |
|---|---|---|---|
| T1 | Reversible, internal, inside existing rules (file a note, fix a typo, re-run a check) | The role doing the job | `07_log.md` |
| T2 | Reversible, moderate impact, internal (reorder priorities, move a calendar block, pick between two drafts) | CEO, then tells the owner in the report | Board, Decided |
| T3 | Money, anything external, anything irreversible, a new recurring commitment, a new role, a change to the goal stack | The owner, with the CEO's recommendation first | Board, Pending then Decided |

When unsure, treat it as one tier higher.

**How the CEO ranks an idea:** does it move goal 1 this month? Yes = now. Helps goal 1 later or needs something built first = later, with the dependency named. Neither = no, logged with the reason so it is never lost.
