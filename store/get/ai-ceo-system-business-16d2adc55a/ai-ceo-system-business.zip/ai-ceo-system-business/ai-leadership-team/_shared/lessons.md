---
type: factory
---

# Lessons (owner corrections become rules)

Add one row the same turn the owner corrects the team. Read before 02_decide and 04_prepare.

| Date | Owner's words (verbatim) | Rule from now on | Applies to stage |
|---|---|---|---|
