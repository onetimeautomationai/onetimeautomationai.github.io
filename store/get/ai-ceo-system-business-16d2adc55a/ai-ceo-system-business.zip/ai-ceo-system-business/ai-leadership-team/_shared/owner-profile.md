---
type: factory
filled_by: setup/questionnaire.md
---

# Owner profile

- **Owner name:** {{owner name}}
- **Time zone:** {{time zone}}
- **sop_index:** {{path to your SOP index, default `sops/INDEX.md`}}

## Goal stack (ranked, every decision is checked against #1 first)
1. {{goal 1, number + deadline}}
2. {{goal 2}}
3. {{goal 3}}

## Leading metrics (daily actions that move goal 1)
| Metric | Daily target |
|---|---|
| {{e.g. new conversations}} | {{2}} |
| {{e.g. follow-ups}} | {{3}} |

## Lagging metrics (proof it works)
- {{e.g. calls booked, sales, cash collected, recurring revenue}}

## Needs owner approval
- {{default: any message to another person, any post, any payment, any delete, any write to an external system}}

## Never mention or contact
- {{people, brands, topics}}

## Tools and accounts
| Tool | Account | Used for |
|---|---|---|
| {{calendar}} | {{account}} | {{work blocks}} |

## Report style
- {{length, format, rated drafts, codes for 3+ items}}
