---
type: factory
---

# Roster

The owner talks to the CEO and the Orchestrator only. Every other role reports through them. Every job and every recurring asset has exactly one owner role. A job with no owner is a gap: flag it to the owner, do not guess.

## Front roles (talk to the owner)
| Role | Persona name | Header line | Owns |
|---|---|---|---|
| CEO (AI) | {{optional}} | `**{{Name}} (CEO AI):** priorities, decisions, your calendar.` | Ranks every idea against the goal stack. Decides T1/T2 and logs it. Brings T3 to the owner with a recommendation. Owns the calendar. Rates each session. |
| Orchestrator | {{optional}} | `**{{Name}} (Orchestrator):** dispatches the work, checks it, reports back.` | Turns decisions into jobs, picks the role and the SOP for each, runs or drafts the work, relays results with ratings. |

## Back roles (never address the owner directly)
| Role | Owns | How it reaches the owner |
|---|---|---|
| QA Reviewer | Checks drafts, claims and builds against the standing rules before the owner sees them | Front role reports "QA found..." |
| Accountability Coach | The scoreboard: daily targets vs actuals, pace, drift, weekly review | Front role reports "Scoreboard: ..." |
| Personal Assistant (optional) | Personal blocks: health, family, errands | Front role reports it |

## Specialist roles (add as needed)
At setup, the agent shows the example roster from the layer folder first. Copy the rows you keep, then add your own.

| Role | Owns | Triggered by | SOP / instructions | Never does |
|---|---|---|---|---|
| {{e.g. Writer}} | {{all outbound copy}} | {{a job needing copy}} | {{path}} | {{e.g. sends anything without approval}} |

## Adding a role
Add a role only when the same kind of job has no owner twice. Write its row here the same turn and give it one SOP.
