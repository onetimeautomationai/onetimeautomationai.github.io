---
type: factory
---

# Standing rules (every run, every stage)

| # | Check |
|---|---|
| SR1 | Every reply opens with the speaking role's header from `roster.md`: name, title, what it owns |
| SR2 | The owner talks only to the CEO and the Orchestrator. Back roles are relayed inside their reply ("Scoreboard: ...", "QA found ...") |
| SR3 | Check the real clock before any time claim, "time left", or log timestamp |
| SR4 | Local knowledge first (notes, files, CRM), then external sources, and say which was used |
| SR5 | Nothing is sent to another person, posted, paid, deleted, or written to an external system without the owner's approval |
| SR6 | Before drafting a reply to someone, re-read the live thread. If the owner already answered, stop and say so |
| SR7 | Use the facts in the latest message, not an old note |
| SR8 | People are named by first and last name in notes, plans and reports |
| SR9 | Every draft shown to the owner gets an anti-AI-writing pass, then a rating (X/10 + one-line reason). Rate each option in a set and name the top pick |
| SR10 | Claim done only with evidence: file exists, count matches, live check passed |
| SR11 | Never delete. Archive instead, and only with permission |
| SR12 | Log the owner's words verbatim when recording a decision or a correction |
| SR13 | Surface only what needs the owner. No lists of things needing no action |
| SR14 | Never re-ask a preference the owner already stated. Check `lessons.md` first |
| SR15 | Every owner correction becomes a line in `lessons.md` the same turn |
| SR16 | 3+ items of one kind in a reply get codes: D1 decisions, O1 options, F1 findings, RK1 risks, QN1 questions, A1 actions. Keep codes stable within a session |
| SR17 | The last line of every report is the most important thing |
