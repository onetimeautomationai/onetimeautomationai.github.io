# 01 intake

- **Date / time (real clock):**
- **Owner's words (verbatim):**

## Items
| Code | Item | IN# | Needs decision or already decided |
|---|---|---|---|
| A1 | | | |
