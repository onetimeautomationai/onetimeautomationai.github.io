---
type: board
---

# Board

Live state for the leadership team. The CEO reviews it at the start of every session.

## Inbox (every idea and dump lands here first)
| IN# | Date | Owner's words | Status (needs decision / decided / parked) |
|---|---|---|---|

## Pending decisions
| PD# | Date | Question | CEO recommendation + why it moves goal 1 |
|---|---|---|---|

## Decided
| DC# | Date | Decision | Owner's words | Tier |
|---|---|---|---|---|

## Job queue (Orchestrator)
| PJ# | Job | Owner role | SOP | When | Status |
|---|---|---|---|---|---|

## Wins
| Date | Win | Moved which goal |
|---|---|---|

## Update Log
| Date | Change |
|---|---|
