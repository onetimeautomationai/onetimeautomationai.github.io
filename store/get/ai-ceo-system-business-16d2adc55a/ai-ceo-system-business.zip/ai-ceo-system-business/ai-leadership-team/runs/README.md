# runs

One folder per owner request: `YYYY-MM-DD-short-slug/`. Start each by copying `../_templates/run/`.
Status of a run = its highest numbered file. A run is done when `07_log.md` exists.
