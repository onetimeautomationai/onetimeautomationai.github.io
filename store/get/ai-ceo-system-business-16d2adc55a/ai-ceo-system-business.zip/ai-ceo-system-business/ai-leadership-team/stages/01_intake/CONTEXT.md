# 01_intake: catch the idea the same turn

**Lead role:** Orchestrator. One job: record what the owner asked, in their words, before anything else happens.

## Inputs
- Working: the owner's message
- Reference: `../../_shared/standing-rules.md` (SR3, SR12), `../../board/board.md` (Inbox)

Do NOT load: other runs, stage contracts past this one.

## Process
1. Check the clock (SR3). Copy `../../_templates/run/` to `../../runs/YYYY-MM-DD-slug/`.
2. Quote the owner verbatim. Split a multi-part message into items A1, A2...
3. Add one Inbox row (IN#) per item on the board. Mark each: needs decision, or already decided.

## Output
- `runs/{run}/01_intake.md`

## Human check
None. The owner sees it on the board.
