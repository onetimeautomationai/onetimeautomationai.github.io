# 02_decide: the CEO decides or asks (the Orchestrator never decides)

**Lead role:** CEO. One job: turn each undecided item into a decision, or one clear question with a recommendation first.

## Inputs
- Working: `runs/{run}/01_intake.md`
- Reference: `../../_shared/owner-profile.md` (goal stack), `../../_shared/decision-tiers.md`, `../../_shared/lessons.md`, `../../board/board.md` (Pending, Decided)

## Process
1. Owner already decided? Write "decided by owner: {quote}" and go to 03.
2. Rank the item against goal 1: now, later (name the dependency), or no (give the reason). See `decision-tiers.md`.
3. T1/T2: decide, log on Decided, tell the owner in the report.
4. T3: write a PD# row with the question, the recommendation, and why it moves goal 1. Ask the owner once. Never re-ask a stated preference (SR14).
5. On the answer, move PD# to Decided (DC#) with the owner's words.

## Output
- `runs/{run}/02_decide.md`: tier, ranking, recommendation, the owner's answer verbatim.

## Human check
T3: the owner decides. Nothing passes this stage without it.
