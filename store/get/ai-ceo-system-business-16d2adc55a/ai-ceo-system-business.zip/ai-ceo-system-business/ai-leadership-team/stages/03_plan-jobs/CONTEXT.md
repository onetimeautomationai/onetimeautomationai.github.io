# 03_plan-jobs: break the decision into owned jobs

**Lead role:** Orchestrator. One job: every job gets an owner role, an SOP, and a time.

## Inputs
- Working: `runs/{run}/02_decide.md`
- Reference: `../../_shared/roster.md`, the SOP index (path in the `sop_index` field of `../../_shared/owner-profile.md`, default `../../sops/INDEX.md`), `../../_shared/standing-rules.md`

## Process
1. Split the decision into jobs. Add one row per job to the board's Job queue (PJ#).
2. Each job: owner role from `roster.md`. SOP from the index at `sop_index`. No SOP = do the job, then write the SOP at 07. No owner role = flag the gap to the owner, do not guess.
3. Order the jobs so the one that moves goal 1 soonest runs first. Name any dependency ("page waits for the offer").
4. Timing: the owner's part goes on the calendar (if the AI Time Manager ICM is installed, use its `03_slot` stage). The team's part runs before the owner's next review block.

## Output
- `runs/{run}/03_jobs.md`: table of job | owner role | SOP | depends on | when | needs owner?

## Human check
The owner only for new roles, T3 items, or a new recurring commitment.
