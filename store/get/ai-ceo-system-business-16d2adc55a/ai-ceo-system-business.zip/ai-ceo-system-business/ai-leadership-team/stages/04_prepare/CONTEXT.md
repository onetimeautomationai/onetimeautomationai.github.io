# 04_prepare: do the work or draft it

**Lead role:** each job's owner role. One job: execute per the SOP, or draft for approval.

## Inputs
- Working: `runs/{run}/03_jobs.md`
- Reference: each job's SOP (found through the `sop_index` field in `../../_shared/owner-profile.md`), `../../_shared/standing-rules.md` (SR4 to SR11), `../../_shared/lessons.md`

Do NOT load: other runs, unrelated SOPs.

## Process
1. Local knowledge first (SR4).
2. Anything addressed to a person: re-read the live thread (SR6), use the latest facts (SR7), draft, run the anti-AI-writing pass, rate it (SR9).
3. Internal work (files, notes, automations): do it, then prove it (SR10).
4. Nothing is sent or written externally here (SR5).
5. Long or parallel jobs can run as background agents. The Orchestrator waits for their results and never predicts them.

## Output
- `runs/{run}/04_prepared.md`: per job, what was done, evidence, draft paths, ratings.

## Human check
None. QA is next.
