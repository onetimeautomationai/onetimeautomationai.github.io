# 05_review: QA checks before the owner sees it

**Lead role:** QA Reviewer (or the Orchestrator's self-check if the owner set QA to "on request only").

## Inputs
- Working: `runs/{run}/04_prepared.md` and its drafts
- Reference: `../../_shared/standing-rules.md` (all), `../../_shared/lessons.md`

## Process
1. Check every standing rule and every lesson. Any fail goes back to 04, gets fixed, and is re-checked.
2. Confirm every claim has evidence in `04_prepared.md`.
3. Check efficiency too: is there a simpler way that gives the same result?

## Output
- `runs/{run}/05_review.md`: pass or fail per rule, fixes made, final ratings.

## Human check
The QA pass.
