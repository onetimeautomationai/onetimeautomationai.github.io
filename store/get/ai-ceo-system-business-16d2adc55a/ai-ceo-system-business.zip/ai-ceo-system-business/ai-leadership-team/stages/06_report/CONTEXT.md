# 06_report: one short report to the owner

**Lead role:** CEO for priorities and decisions, Orchestrator for status and results. One report per run.

## Inputs
- Working: `runs/{run}/05_review.md`
- Reference: `../../_shared/standing-rules.md` (SR1, SR2, SR3, SR8, SR9, SR13, SR16, SR17), `../../_shared/owner-profile.md` (report style)

## Process
1. Check the clock (SR3).
2. Role header (SR1). Back-role findings relayed inside it (SR2).
3. Results first, rated drafts in full, open questions coded QN1...
4. Ask once if a send or external write needs approval.
5. Last line = the most important thing (SR17).
6. On the owner's "yes" or "send": do it, verify it actually happened, then go to 07.

## Output
- `runs/{run}/06_report.md`: the report as given, the owner's reply verbatim, what was executed, and proof.

## Human check
The owner approves every send and external write.
