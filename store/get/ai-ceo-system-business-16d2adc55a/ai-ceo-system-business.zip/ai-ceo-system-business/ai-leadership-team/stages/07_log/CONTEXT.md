# 07_log: close the loop

**Lead roles:** Orchestrator, with the Accountability Coach. One job: every tracker shows the true state, the same turn.

## Inputs
- Working: `runs/{run}/06_report.md`
- Reference: `../../board/board.md`, `../../_shared/lessons.md`, `../../_shared/owner-profile.md` (metrics, `sop_index`)

## Process
1. Board: job status, Decided row, Wins row if something shipped, closed or got paid, Update Log row (owner's words, real time).
2. Scoreboard: update any metric that moved (if the AI Time Manager ICM is installed, its `logs/scoreboard.md`).
3. New SOP if 03 found none: write it, then add a row to the index at `sop_index` (`../../_shared/owner-profile.md`). New recurring job = owner role in `roster.md`.
4. Owner correction = a `lessons.md` row (SR15).
5. **Session end, or "how did we do?":** the CEO rates how much the session moved goal 1. If the AI Time Manager ICM is installed, run its `06_session-rating`. Otherwise score each area worked on 1 to 10, give an overall score, and name one fix for next session.

## Output
- `runs/{run}/07_log.md`: files and trackers updated, what changed.

## Human check
The Accountability Coach's scoreboard check (daily shutdown, weekly review).
