# Workspace definition

**Repeating units:** a day (stages 03 to 06) and a week (stage 07). Setup (01, 02) runs once and again whenever the blueprint changes a lot.

| # | Stage | Cadence | Output | Human gate |
|---|---|---|---|---|
| 01 | build-blueprint | once | `blueprint/weekly-blueprint.md` | Owner approves the blueprint |
| 02 | book-calendar | once, then the weekly roll | Tagged recurring series on the calendar, 2 weeks ahead | Owner looks at the calendar |
| 03 | slot | every dump or appointment | Calendar event + `logs/slotting-log.md` row | Owner approves anything that moves a fixed anchor |
| 04 | road-ahead | start of day, or on request | `logs/road-ahead.md` (latest only) | none |
| 05 | shutdown | end of each work day | `logs/scoreboard.md` row | Owner fills in anything only they know |
| 06 | session-rating | end of each session | `logs/session-ratings.md` row | none |
| 07 | weekly-review | weekly | Blueprint changes proposed, horizon rolled | Owner approves blueprint changes |

**Factory:** `_shared/`, `blueprint/`, `scripts/`. **Product:** `logs/` and the calendar itself.

Pairs with the **AI Leadership Team** ICM: there, the CEO role owns this workspace and runs stage 06 at the end of each run.
