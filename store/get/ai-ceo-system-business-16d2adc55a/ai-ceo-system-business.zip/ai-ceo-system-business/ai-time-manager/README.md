# AI Time Manager: an exportable ICM

A folder you drop into your AI operating system. Your AI takes over your calendar:

- You build an ideal week once (the **blueprint**) from your real constraints: sleep, meals, health, family, fixed meetings, and when your best work happens.
- The AI books it on your calendar, always exactly **2 weeks ahead**, and rolls it forward weekly.
- You **dump** everything you want to do. The AI decides when, based on what moves your #1 goal, and books it.
- When you move or delete a block, the AI **learns** from it instead of fighting you, and proposes blueprint changes weekly.
- Every day ends with a **scoreboard** (did you move the chains?), and every work session ends with a **rating** and one fix for next time.

## Install
1. Copy this folder into your AI workspace. Point your agent at `CLAUDE.md` (rename it `AGENTS.md` if your tool expects that).
2. Say "run setup". The agent walks `setup/questionnaire.md`, then builds your blueprint (stage 01) for your approval.
3. Give your agent calendar access, or say "local file" in setup. With no calendar connector or Google setup, stages 02 and 03 write the plan to `calendar/calendar.md` instead of creating events. Use separate calendars for work blocks and personal blocks so you can show or hide each.
4. Optional: schedule `scripts/calendar_roll.py` weekly (cron, launchd or Task Scheduler) so the 2-week horizon rolls without you. See `scripts/README.md`.

No folder support? Paste `INJECT-PROMPT.md` into your AI's custom instructions.

## Why a blueprint plus a rolling horizon
- A fixed week takes decisions off your plate, so you spend willpower on the work, not on planning.
- Two weeks ahead is far enough to see the road and protect it, and close enough that the plan is still real.
- Tagging the AI's events means it never touches your own recurring events.
- Treating your edits as signal means the plan gets closer to how you actually live every week.

Method: Interpretable Context Methodology (Van Clief & McDermott, arXiv:2603.16021). Pairs with the **AI Leadership Team** ICM.
