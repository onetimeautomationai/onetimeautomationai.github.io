---
type: factory
filled_by: setup/questionnaire.md
---

# Owner profile (time)

Goals and the owner name live in `../../ai-leadership-team/_shared/owner-profile.md`. Read them there. Do not copy them here. If you use this folder alone, fill the two lines below.

- **Owner name:** {{name}}
- **Time zone:** {{time zone}}
- **Goal stack:** see the leadership owner profile (standalone only: 1. {{goal 1, number + deadline}} 2. {{goal 2}} 3. {{goal 3}})
- **Work days:** {{e.g. 7}} | **Minimum on travel/event days:** {{e.g. 2 hours}}
- **Wake / bed:** {{6:00 / 10:00}}
- **Meal rules:** {{e.g. lunch 12:00, dinner by 6:00, walk after each meal}}
- **Sharpest focus:** {{e.g. 8:30 to 12:00}}
- **When contacts answer:** {{e.g. 3:30 to 5:30}}
- **Shutdown time:** {{e.g. 7:30 PM}} | **Weekly review day:** {{e.g. Sunday}}
- **Push style:** {{facts / motivation / both}}

## Calendars
Put a calendar ID in each row, or write "local file" in all rows if you have no Google Calendar or connector. Local file mode keeps the plan in `../calendar/calendar.md`.

| Label | Calendar ID | Holds |
|---|---|---|
| Work | {{id or "local file"}} | AI-managed work blocks |
| Personal | {{id or "local file"}} | AI-managed personal blocks |
| Appointments | {{id or "local file"}} | Confirmed meetings with other people |

## Never touch
- {{the owner's own recurring events}}
