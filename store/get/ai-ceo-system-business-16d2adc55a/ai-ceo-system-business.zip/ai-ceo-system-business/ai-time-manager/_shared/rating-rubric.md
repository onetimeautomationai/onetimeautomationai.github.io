---
type: factory
---

# Session rating rubric

Rate only the areas the session actually touched. Score each 1 to 10, then give the overall score, the pattern, and one fix.

| Area | 9 to 10 | 6 to 8 | 3 to 5 | 1 to 2 |
|---|---|---|---|---|
| Conversations (leading) | Targets hit and replies came back | Targets partly hit, some sends out | Touches sent, no new conversations | None |
| Pipeline | New people or leads added that will produce conversations | Pipeline protected (retention, follow-up) | Pipeline only reviewed | Nothing |
| Asset or offer | Something sellable shipped | A stage of it finished and approved | Drafted, not approved | Talked about only |
| Systems | Saves time every week and was needed now | Useful, but not the bottleneck | Nice to have | Busywork |
| Results (lagging) | Cash or booked calls | Offer made | A real "yes, tell me more" | Nothing yet |

**Overall:** weight results and conversations highest. A session full of systems work with zero conversations cannot score above 6.

**Always end with:** the pattern in one sentence, and one fix with a time ("Tomorrow, 2 new conversations in the 3:30 block before any build work").
