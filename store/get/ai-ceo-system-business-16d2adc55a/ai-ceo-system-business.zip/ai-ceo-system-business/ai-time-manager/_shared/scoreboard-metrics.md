---
type: factory
---

# Scoreboard metrics

"Moving the chains" means making progress you can count, not just being busy. Leading metrics are actions the owner controls today. Lagging metrics are results that prove the actions work.

## Leading (daily targets)
| Code | Metric | Target | Counts when |
|---|---|---|---|
| M1 | {{New conversations}} | {{2}} | {{the other person replies, not when you send}} |
| M2 | {{Follow-ups}} | {{3}} | {{sent to someone already in a conversation}} |
| M3 | {{Assets shipped}} | {{1}} | {{something a buyer can see is live}} |

## Lagging (results)
| Code | Metric | Period target |
|---|---|---|
| L1 | {{Calls booked}} | {{per week}} |
| L2 | {{Offers made}} | {{per week}} |
| L3 | {{Cash collected}} | {{goal 1 number}} |

## Scoreboard row format
`YYYY-MM-DD | M1 x/target | M2 x/target | M3 x/target | L1 | L2 | L3 period-to-date / goal`
