---
type: factory
---

# Time rules

| # | Rule |
|---|---|
| TR1 | The AI owns the calendar. The owner dumps, the AI slots. Fixed anchors move only with the owner's OK |
| TR2 | Rank every slot by what moves goal 1 soonest. Revenue-making or goal-making work gets the best hours |
| TR3 | Deep work (making something you can show or sell) goes in the owner's sharpest focus hours. Calls and conversations go when contacts answer |
| TR4 | Health, meals, sleep and family are booked first. Work fills around them, never over them |
| TR5 | A walk or movement after each meal is part of the work day, not lost time (if the owner set that rule) |
| TR6 | No zero-work days on work days. Travel or event days still get the minimum |
| TR7 | A disrupted block moves within the same day first, then to the next day. Never silently dropped |
| TR8 | Confirmed appointments from email or messages are booked the same turn. Unconfirmed ones are not |
| TR9 | Build exactly 2 weeks ahead. Roll weekly, the day before the week starts |
| TR10 | Every AI-made recurring series carries a private tag (for example an extended property `ai_blueprint=1`). Only tagged series are ever rolled or bulk-edited. Before any bulk move, filter to tagged events and check the list |
| TR11 | Owner edits are never reverted. They are logged and learned from (stage 07) |
| TR12 | Every day closes with the shutdown: scoreboard plus one change that makes tomorrow better |
| TR13 | Check the real clock before any time claim, "time left", or "what now" answer |
| TR14 | When showing the plan, tie each block to the goal with its reason (what it moves) |
