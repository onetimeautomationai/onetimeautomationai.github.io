---
type: blueprint
status: draft
approved:
---

# Weekly blueprint

Example structure. Stage 01 replaces every time and block with the owner's answers. Block types: Health, Mind, Eat, Work, Family, Rest, Sleep.

## Fixed anchors
| When | What |
|---|---|
| {{Mon 8:00 to 9:30}} | {{weekly team meeting}} |

## Work day (example)
| Time | Block | Type | Moves |
|---|---|---|---|
| 6:00 to 6:30 | Meditation and stretching | Health | Energy |
| 6:30 to 7:30 | Exercise, breakfast | Health / Eat | Energy |
| 7:30 to 8:00 | Shower and reset | Health | |
| 8:00 to 10:00 | **Deep work 1:** make an offer or asset someone can buy | Work | Goal 1 |
| 10:00 to 12:00 | **Calls:** clients, prospects, partners | Work | Goal 1 |
| 12:00 to 12:30 | Lunch | Eat | |
| 12:30 to 12:50 | Walk | Health | Focus after lunch |
| 1:00 to 2:30 | **Deep work 2:** build or review systems | Work | Goal 2 |
| 2:30 to 3:30 | **Brand:** content, email, publishing | Work | Pipeline |
| 3:30 to 5:30 | **Move the chains:** new conversations and follow-ups | Work | Goal 1 |
| 5:30 to 6:00 | Dinner | Eat | |
| 6:00 to 7:30 | Walk, family | Family | |
| 7:30 to 8:00 | **Shutdown:** scoreboard, one change for tomorrow | Work | Accountability |
| 8:00 to 9:00 | Relax, family | Rest | |
| 9:00 to 10:00 | Journal, reflection, reading | Mind | |
| 10:00 | Lights out | Sleep | |

## Day exceptions
- {{e.g. Wednesday: deep work 1 runs longer because of an 11:00 anchor}}

## Weekend
| Time | Block |
|---|---|
| {{ }} | {{ }} |

## Update Log
| Date | Change | Why (owner's words or edit pattern) |
|---|---|---|
