# Local calendar

Used only when there is no calendar connector or Google setup. Stage 02 fills this file. Stage 03 adds rows. Stage 07 rolls it forward each week. Keep 14 days ahead.

## YYYY-MM-DD (weekday)

| Time | Block | Calendar | Goal it moves |
|---|---|---|---|
| {{08:30 to 12:00}} | {{Deep work}} | {{Work}} | {{goal 1}} |
