# Owner calendar edits

Written by `scripts/calendar_roll.py`. Read at the weekly review. Edits are signal, never reverted.
