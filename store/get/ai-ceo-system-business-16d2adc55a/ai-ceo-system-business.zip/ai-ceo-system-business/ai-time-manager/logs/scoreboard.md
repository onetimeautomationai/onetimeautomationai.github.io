# Scoreboard

Format: `_shared/scoreboard-metrics.md`. One row per work day, written at shutdown.

| Row | Did the chains move? | DW1 finished on line (yes/no) | Depth ratio (DW15) | Change for tomorrow |
|---|---|---|---|---|
