# Session ratings

Rubric: `_shared/rating-rubric.md`.

| Date | Window | Area scores | Overall | Pattern | Fix |
|---|---|---|---|---|---|
