# Slotting log

| Date | Item | Slot | Why this slot |
|---|---|---|---|
