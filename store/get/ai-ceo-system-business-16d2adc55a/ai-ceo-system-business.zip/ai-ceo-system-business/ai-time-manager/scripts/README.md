# scripts

`calendar_roll.py` is the weekly roll from stage 07 (reference implementation).

- Optional. Skip it if you use the local calendar file.
- Needs Python 3.9+ and Google's Python client. Run `pip install google-api-python-client google-auth` first.
- It reads an OAuth token file for your Google account. Create one in the Google Cloud console (enable the Calendar API, make an OAuth desktop client, run the consent flow once, save the authorized user JSON). Put its path in `token_file`. Relative paths in the config (such as `edits_log`) resolve against the config file's folder.
- Copy `config.example.json` to `config.json` and fill in your time zone and calendar IDs. Your primary calendar ID is your email address. Other calendars show their ID in Google Calendar under Settings for that calendar. Use the same tag your AI puts on every blueprint series when booking (stage 02).
- On another calendar system, rewrite only `list_events()` and `patch_recurrence()`.
- Run `python3 calendar_roll.py --config config.json --dry-run` first. It should list only your blueprint series. If it lists your own events, your tag is wrong. Stop and fix it.
- Schedule it weekly, the day before your week starts: cron `50 15 * * 0`, a macOS launchd agent, or Windows Task Scheduler. Send its log somewhere you will see failures.
- Exit code 1 = at least one series failed to extend. Have your AI notify you.
