#!/usr/bin/env python3
"""calendar_roll.py: keep the AI-managed blueprint booked exactly N days ahead.

1. Logs the owner's edits (moved, retitled, re-timed or deleted instances of
   tagged blueprint series in the last 7 days) to the edits log for the weekly review.
2. Sets UNTIL = today + horizon_days (end of day, owner's time zone) on every
   recurring series that carries the private tag. Untagged series are never touched.

Relative paths in the config (edits_log, token_file) resolve against the config file's folder.

Usage:  python3 calendar_roll.py --config config.json [--dry-run]
Backend: the Google Calendar API v3 through google-api-python-client, using an
OAuth token file (see README.md). To use another calendar system, replace
list_events() and patch_recurrence() only.
"""
import argparse, json, os, re, sys, datetime as dt
from zoneinfo import ZoneInfo

_SERVICE = None


def service(cfg):
    global _SERVICE
    if _SERVICE is None:
        from google.oauth2.credentials import Credentials
        from googleapiclient.discovery import build
        creds = Credentials.from_authorized_user_file(cfg["token_file"])
        _SERVICE = build("calendar", "v3", credentials=creds, cache_discovery=False)
    return _SERVICE


def list_events(cfg, env, params):
    """All events for params, following pagination."""
    items, token = [], None
    while True:
        p = dict(params, maxResults=250)
        if token:
            p["pageToken"] = token
        d = service(cfg).events().list(**p).execute()
        items += d.get("items", [])
        token = d.get("nextPageToken")
        if not token:
            return items


def patch_recurrence(cfg, env, cal, event_id, recurrence):
    service(cfg).events().patch(calendarId=cal, eventId=event_id, sendUpdates="none",
                                body={"recurrence": recurrence}).execute()


def detect_edits(cfg, env, tz, tag):
    now = dt.datetime.now(tz)
    lo, hi = (now - dt.timedelta(days=7)).isoformat(), now.isoformat()
    rows = []
    for name, cal in cfg["calendars"].items():
        series = {e["id"]: e for e in list_events(cfg, env, {"calendarId": cal, "singleEvents": False, "privateExtendedProperty": tag}) if e.get("recurrence")}
        for i in list_events(cfg, env, {"calendarId": cal, "singleEvents": True, "showDeleted": True, "timeMin": lo, "timeMax": hi}):
            base = series.get(i.get("recurringEventId"))
            if not base:
                continue
            orig = i.get("originalStartTime", {}).get("dateTime", "")
            what = []
            if i.get("status") == "cancelled":
                what.append("deleted")
            else:
                start = i.get("start", {}).get("dateTime", "")
                if start[:16] != orig[:16]:
                    what.append(f"moved to {start[:16]}")
                if i.get("summary") != base.get("summary"):
                    what.append(f"retitled '{i.get('summary')}'")
                if not any(w.startswith("moved") for w in what) and i.get("end", {}).get("dateTime", "")[11:16] != base.get("end", {}).get("dateTime", "")[11:16]:
                    what.append(f"end changed to {i['end']['dateTime'][11:16]}")
            if what:
                rows.append(f"| {orig[:16]} | {name} | {base.get('summary', '')[:50]} | {'; '.join(what)} |")
    if rows and not cfg.get("_dry"):
        with open(cfg["edits_log"], "a") as f:
            f.write(f"\n## Run {now:%Y-%m-%d %H:%M}\n\n| Planned start | Calendar | Block | Owner's edit |\n|---|---|---|---|\n" + "\n".join(rows) + "\n")
    print(f"edits detected {len(rows)}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    ap.add_argument("--dry-run", action="store_true")
    a = ap.parse_args()
    cfg_path = os.path.abspath(a.config)
    cfg = json.load(open(cfg_path))
    base = os.path.dirname(cfg_path)
    for key in ("edits_log", "token_file"):
        if key in cfg:
            path = os.path.expanduser(cfg[key])
            cfg[key] = path if os.path.isabs(path) else os.path.normpath(os.path.join(base, path))
    cfg["_dry"] = a.dry_run
    env = dict(os.environ, **cfg.get("env", {}))
    tz = ZoneInfo(cfg["timezone"])
    tag = f'{cfg["tag_key"]}={cfg["tag_value"]}'
    detect_edits(cfg, env, tz, tag)
    end = dt.datetime.combine(dt.datetime.now(tz).date() + dt.timedelta(days=cfg.get("horizon_days", 14)), dt.time(23, 59, 59), tz)
    until = end.astimezone(dt.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    changed = fails = 0
    for cal in cfg["calendars"].values():
        for e in list_events(cfg, env, {"calendarId": cal, "singleEvents": False, "privateExtendedProperty": tag}):
            rec = e.get("recurrence")
            if not rec or e.get("status") == "cancelled" or any(f"UNTIL={until}" in x for x in rec):
                continue
            new = []
            for line in rec:
                if line.startswith("RRULE:"):
                    parts = [x for x in line[6:].split(";") if not re.match(r"(UNTIL|COUNT)=", x)]
                    line = "RRULE:" + ";".join(parts + [f"UNTIL={until}"])
                new.append(line)
            print(("DRY " if a.dry_run else "") + f"{e.get('summary', '')[:50]} -> UNTIL {until}")
            if a.dry_run:
                continue
            try:
                patch_recurrence(cfg, env, cal, e["id"], new)
                changed += 1
            except Exception as ex:
                fails += 1
                print("FAIL", e.get("summary"), ex, file=sys.stderr)
    print(f"series updated {changed}, failed {fails}, horizon {end.date()}")
    sys.exit(1 if fails else 0)


if __name__ == "__main__":
    main()
