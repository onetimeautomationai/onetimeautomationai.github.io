# Setup questionnaire

Ask a few at a time. Write the answers into `../_shared/owner-profile.md`. Stage 01 turns them into the blueprint. In the combined setup (see the `CLAUDE.md` at the pack root) the leadership team questions run first, so skip any goal question already answered there.

## Goal
Goals live in `../../ai-leadership-team/_shared/owner-profile.md`. Do not ask for the goal stack again. Only ask the one question below if it is missing there.
1. Which daily actions move goal 1 most, and how many of each per day? (These become the scoreboard.)

## Shape of the day
3. Wake time and bedtime. How much sleep do you need?
4. Morning routine you will not give up (meditation, exercise, reading, and how long each takes)?
5. Meal times and any rules (for example: lunch at noon, dinner by 6, a walk after every meal).
6. When is your focus sharpest? When do the people you contact usually answer?
7. Fixed anchors: weekly meetings, school runs, classes, sports, family time.
8. How many days a week do you work? What is the minimum on a travel or event day?

## Calendar
9. Which calendar app and account? Give the calendar ID for work blocks, personal blocks and appointments (your primary calendar ID is your email address). If you have no Google Calendar or calendar connector, answer "local file". Then stages 02 and 03 write the plan to `calendar/calendar.md` instead of creating events.
10. Which existing recurring events must never be touched?

## Accountability
11. When should the day close (shutdown time)? Which weekday is your weekly review?
12. How do you want to be pushed: plain facts, motivation tied to the goal, or both?
