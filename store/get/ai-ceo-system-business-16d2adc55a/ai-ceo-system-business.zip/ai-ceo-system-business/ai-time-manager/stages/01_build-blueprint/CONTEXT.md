# 01_build-blueprint: design the ideal week

One job: turn the owner's answers into a weekly blueprint they approve.

## Inputs
- Working: `../../_shared/owner-profile.md` (filled by setup)
- Reference: `../../_shared/time-rules.md`, `../../blueprint/weekly-blueprint.md` (example structure)

## Process
1. Place sleep, health, meals and family first (TR4). Then fixed anchors.
2. Put deep work in the sharpest focus hours and conversations when contacts answer (TR3).
3. Fill the rest by goal impact (TR2). Add a shutdown block (TR12) and a weekly review slot.
4. Write day exceptions (anchor days) and the weekend.
5. Total the work hours per day and state them.

## Output
- `blueprint/weekly-blueprint.md` with `status: draft`.

## Human check
The owner reads it and edits in place. On approval: `status: approved`, date in `approved:`, an Update Log row.
