# 02_book-calendar: put the blueprint on the calendar

One job: put every blueprint block on the calendar, exactly 2 weeks ahead. Use Google events if a calendar connector or Google setup exists. If neither exists, write a local markdown calendar instead.

## Inputs
- Working: `../../blueprint/weekly-blueprint.md` (approved)
- Reference: `../../_shared/owner-profile.md` (calendar IDs or "local file", never-touch list), `../../_shared/time-rules.md` (TR9, TR10)

## Pick the mode first
1. Read the Calendars table in `../../_shared/owner-profile.md`.
2. If it holds real calendar IDs and you can reach a calendar connector, use **calendar mode**.
3. If it says "local file", or no connector or Google setup exists, use **local file mode**. Do not stop and do not ask the owner to set up Google.

## Process: calendar mode
1. Work blocks go on the Work calendar, personal blocks on the Personal calendar.
2. One recurring series per block, with `UNTIL` = today + 14 days, end of day local time.
3. Tag every series (TR10). Untagged series are never touched.
4. Check for clashes with existing events and the never-touch list. Report clashes, do not delete.
5. Verify: count the series created vs blueprint blocks, and list the next 2 days back from the calendar.
6. Optional: schedule `../../scripts/calendar_roll.py` weekly, the day before the week starts. It needs Google setup. Without it, run stage 07 by hand each week.

## Process: local file mode
1. Write the plan to `../../calendar/calendar.md`. Create the file if it is missing.
2. Use one dated table per day, for today + 14 days. Columns: Time | Block | Calendar (Work or Personal) | Goal it moves.
3. Skip anything on the never-touch list. Note clashes in a line under the day.
4. Verify: count the blocks written vs the blueprint blocks for each day, and show the next 2 days to the owner.
5. Each week, stage 07 drops past days and adds new days so the file always shows 14 days ahead.

## Output
- An Update Log row in the blueprint: block count or series count, horizon date, mode used, roll schedule.

## Human check
The owner looks at the next 2 days and confirms.
