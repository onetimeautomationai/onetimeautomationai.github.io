# 03_slot: decide when each dumped item happens

One job: every item the owner dumps, and every confirmed appointment, gets a time on the calendar, the same turn. In local file mode, "the calendar" is `../../calendar/calendar.md`.

## Inputs
- Working: the owner's message, or a confirmed appointment from email or messages
- Reference: `../../_shared/time-rules.md`, `../../blueprint/weekly-blueprint.md`, the live calendar for the next 14 days (or `../../calendar/calendar.md` in local file mode)

## Process
1. Check the clock (TR13). Classify each item: work or personal, how much it moves goal 1, size in minutes, deadline.
2. Fit it into the matching blueprint block (a call goes in Calls, a build in Deep work). Highest goal impact gets the earliest slot (TR2).
3. No room? Bump the lowest-impact item, and say what moved and why.
4. Appointment with another person: book it only if confirmed (TR8), on the Appointments calendar. In local file mode, add a row to that day's table with Calendar = Appointments.
5. Moving a fixed anchor needs the owner's OK (TR1).
6. If the owner has no calendar connector or Google setup, do not create events. Add the row to `../../calendar/calendar.md` instead.

## Output
- A calendar event (or a row in `calendar/calendar.md`), plus a `logs/slotting-log.md` row: date | item | slot | why this slot.

## Human check
Only when a fixed anchor moves.
