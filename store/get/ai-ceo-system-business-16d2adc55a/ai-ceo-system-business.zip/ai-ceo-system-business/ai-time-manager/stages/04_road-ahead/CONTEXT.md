# 04_road-ahead: show the owner the next week

One job: show the plan far enough ahead to see the road, with the reason for each block.

## Inputs
- Working: the live calendar for the next 7 days (or `../../calendar/calendar.md` in local file mode)
- Reference: `../../_shared/owner-profile.md` (goal stack, push style), `../../_shared/time-rules.md` (TR14), last row of `../../logs/scoreboard.md`

## Process
1. Check the clock. Read the next 7 days from the calendar (or the local calendar file), not from the blueprint.
2. Per day: the key work blocks and what each moves (goal 1, pipeline, assets).
3. Flag clashes, overloaded days and missing shutdowns.
4. Close in the owner's push style: where the scoreboard stands vs goal 1, and what today has to deliver.

## Output
- `logs/road-ahead.md` (overwritten each time), plus the message to the owner.

## Human check
None.
