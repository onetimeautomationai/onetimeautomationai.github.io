# 05_shutdown: close the day

One job: score the day and make tomorrow better than today.

## Inputs
- Working: today's calendar, today's work log or chat, the owner's answers to anything only they know
- Reference: `../../_shared/scoreboard-metrics.md`

## Process
1. Count each metric with evidence (sent messages, replies, assets live, cash received). Unknown = ask the owner, never guess.
2. Answer "Did the chains move today?" with yes or no and the reason.
3. Name one change that makes tomorrow better (TR12) and the top 3 for tomorrow.

## Output
- One row in `logs/scoreboard.md` in the format from `scoreboard-metrics.md`, plus tomorrow's change and top 3.

## Human check
The owner confirms the counts.
