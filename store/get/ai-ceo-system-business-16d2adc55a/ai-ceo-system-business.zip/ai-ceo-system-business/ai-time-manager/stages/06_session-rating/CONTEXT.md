# 06_session-rating: how effective was this session?

One job: an honest score of how much the session moved goal 1, and one fix.

## Inputs
- Working: what happened this session (chat, work log, run logs), with real start and end times
- Reference: `../../_shared/rating-rubric.md`, `../../_shared/scoreboard-metrics.md`

## Process
1. Check the clock. State the session window.
2. List what was done per area. Each item needs evidence.
3. Score each area touched (1 to 10) and give an overall score per the rubric. Results and conversations are weighted highest.
4. Name the pattern in one sentence, and one fix with a time.
5. Say how many minutes are left in the current calendar block and what fits in them.

## Output
- One row in `logs/session-ratings.md`: date | window | area scores | overall | pattern | fix.

## Human check
None. The owner can dispute a score, and the dispute goes in the row.
