# 07_weekly-review: learn and roll forward

One job: make next week's plan fit how the owner actually lives and works, and keep the horizon at 2 weeks.

## Inputs
- Working: `../../logs/edits-log.md`, `../../logs/scoreboard.md` and `../../logs/session-ratings.md` (last 7 days)
- Reference: `../../blueprint/weekly-blueprint.md`, `../../_shared/time-rules.md` (TR9, TR11)

## Process
1. With Google: run `../../scripts/calendar_roll.py` (or confirm the scheduled run worked). It logs the owner's edits, then extends tagged series to today + 14 days. Without Google: open `../../calendar/calendar.md`, note any rows the owner changed in `logs/edits-log.md`, drop past days, and add days until it shows today + 14 days.
2. Read the edits. The same block moved 2 or more times the same way = propose a blueprint change. Deleted 2 or more times = propose a cut. Never revert an edit (TR11).
3. Read the week's scoreboard and ratings: which metric missed most, and which block produced it.
4. Propose at most 3 changes: one habit to fix, one block to cut or move, one to protect.

## Output
- Proposed changes in the blueprint Update Log, marked "proposed".

## Human check
The owner approves each change. Approved changes are applied to the blueprint, then to the calendar via stage 02.
