# Example ideas run through the decision tiers

These show the method. Assume an example goal 1 of "bring in more paying customers this quarter." Your goal will differ, so your rankings will too. No result is claimed for any idea here.

How the tiers work: T1 is reversible and internal, so the role doing the job decides. T2 is reversible and moderate, so the CEO decides and tells you in the report. T3 involves money, anyone outside the business, or something hard to undo, so it comes to you with a recommendation first.

| # | Idea | Tier | Rank | Who decides | Why |
|---|---|---|---|---|---|
| 1 | Sort the follow-up list by how long since last contact | T1 | Now | The sales role | Internal, reversible, inside the existing job |
| 2 | Move the weekly review from Friday to Thursday | T2 | Now | CEO, told to you in the report | A calendar change that you can undo in one step |
| 3 | Write a checklist for onboarding a new customer | T2 | Now | CEO, told to you in the report | Internal, helps goal 1, easy to change |
| 4 | Email past customers about a new offer | T3 | Now | You | Goes to people outside the business. The agent drafts and you approve |
| 5 | Run a paid ad campaign | T3 | Later | You | It costs money. Needs a clear offer and a way to count leads first |
| 6 | Hire a part-time assistant | T3 | Later | You | A new recurring commitment. Wait until the weekly admin hours are counted |
| 7 | Raise prices on one service | T3 | Now | You | Customers see it and it is hard to undo. The agent lays out the options and you choose |
| 8 | Rebuild the company website | T3 | No | You, with the reason logged | Does not move goal 1 this quarter. Logged so it is not lost |

## How to read the table

- Rank "Now" means it moves goal 1 this period. "Later" means it helps goal 1 but needs something built first, and the dependency is named. "No" means it is logged with a reason.
- When the agent is unsure, it treats the idea as one tier higher.
- Each T3 item becomes a pending question on the board with the recommendation first. You answer once and the agent does not ask again.
