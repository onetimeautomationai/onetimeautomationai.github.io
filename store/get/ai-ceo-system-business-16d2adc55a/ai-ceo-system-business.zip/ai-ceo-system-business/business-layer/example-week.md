# Example week for a small business owner

This is an example shape, not a prescription. Your agent should rebuild it from your answers in the time manager setup. Times are placeholders.

## Fixed anchors
| When | What |
|---|---|
| Monday 8:30 to 9:30 | Plan the week: top three results, open jobs, money due |
| Wednesday 2:00 to 3:00 | Team check-in or customer review |
| Friday 3:30 to 4:30 | Weekly review with the agent: scoreboard, what to change |

## A work day
| Time | Block | Type | Moves |
|---|---|---|---|
| 8:30 to 10:30 | Deep work: the one task that moves goal 1 | Work | Goal 1 |
| 10:30 to 12:00 | Customers and sales: calls, quotes, follow-ups | Work | Goal 1 |
| 12:00 to 12:30 | Lunch | Eat | |
| 12:30 to 1:30 | Operations: open jobs, unblock the team | Work | Delivery |
| 1:30 to 2:30 | Marketing: approve or edit drafts | Work | Pipeline |
| 2:30 to 3:30 | Finance and admin: invoices, bills, renewals | Work | Cash |
| 3:30 to 4:30 | Move the chains: new conversations and follow-ups | Work | Goal 1 |
| 4:30 to 5:00 | Shutdown: scoreboard and one change for tomorrow | Work | Accountability |

## How the AI roles fit in
- Monday morning: the agent lists open jobs, invoices due and deadlines this week.
- Each morning before the first block: the sales role gives you the follow-up list.
- Wednesday: the agent prepares a short agenda from the board.
- Friday: the agent shows the leading metrics you chose against what you did, and asks what to change.

## Leading metrics to choose from
Pick two or three. These are examples of daily actions, not targets.
- New conversations started
- Follow-ups completed
- Quotes sent
- Pieces of content approved
