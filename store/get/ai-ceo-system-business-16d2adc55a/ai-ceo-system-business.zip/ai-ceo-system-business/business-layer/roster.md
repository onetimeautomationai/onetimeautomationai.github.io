# Example roster: small business

The agent shows this roster during setup, before it asks for your specialist roles. Keep the roles you want. They go into the specialist table in `ai-leadership-team/_shared/roster.md`, which has the same columns. Each role has one owner and one job. These are AI roles that support you and your people.

| Role | Owns | Triggered by | SOP / instructions | Never does |
|---|---|---|---|---|
| Operations | Checklists for the work that repeats, a list of open jobs and who has each one, a note of what slipped | A new job, a missed deadline or a weekly review | None yet. Write one the first time the job runs. | Changes a process that customers see without your approval |
| Sales | A follow-up list, drafts of replies and quotes, a record of each open conversation | A new inquiry or a quiet lead | None yet. Write one the first time the job runs. | Sends a quote or a discount to a customer |
| Marketing | A content calendar, drafts of posts and emails, a record of what was published | A weekly content slot or a launch | None yet. Write one the first time the job runs. | Publishes anything or spends on ads |
| Finance | A weekly list of invoices due and bills due, a simple cash note from numbers you give it | The weekly review or a new invoice | None yet. Write one the first time the job runs. | Pays a bill, sends an invoice or gives tax or legal advice |
| Admin | Calendar upkeep, meeting notes, a list of renewals and deadlines | A new meeting or a date coming up | None yet. Write one the first time the job runs. | Accepts or declines a meeting for you |

## Rules for every role above

1. Draft first, then ask. The owner approves anything that leaves the business.
2. Use only facts the owner gave. If a number or a date is missing, ask. Do not guess.
3. Keep customer names out of shared notes unless the owner says it is fine.
4. When a job has no owner, flag it. Do not make up a role.
