# Session clock

A small Claude Code hook. On every session start and every prompt, it gives your agent the real time from your computer's clock, the calendar block you are in now, the block before it, and the next one. On session start it also adds one row to a log file so you can see what was scheduled against what got done.

It needs only Python 3.9 or newer. It uses no other tools and no private services.

## 1. Set up the config

1. Copy `config.example.json` to `config.json` in this folder.
2. Set `timezone` to your own time zone name, for example `America/Chicago`.
3. Under `calendars`, give each calendar a name and an address. An address is one of two things.
   - A web link to an .ics feed. In Google Calendar, open Settings, pick the calendar, and copy "Secret address in iCal format". Treat that link like a password.
   - A path to an .ics file on your computer.
4. Set `primary_calendar` to the name of the calendar whose block should win when two blocks overlap.
5. Set `log_file` to where the log should live. The folder is created for you.

## 2. Test it

Run this from the folder.

    python3 session_clock.py session

You should see one line of JSON that includes the real time and your current block. If the calendar cannot be read, the hook still prints the real time and says the calendar was unreadable.

## 3. Add it to Claude Code hooks

Open your Claude Code settings file (`~/.claude/settings.json` for all projects, or `.claude/settings.json` inside one project). Add this, with the full path to your copy of `session_clock.py`.

    {
      "hooks": {
        "SessionStart": [
          {
            "hooks": [
              { "type": "command", "command": "python3 /full/path/to/session-clock/session_clock.py session" }
            ]
          }
        ],
        "UserPromptSubmit": [
          {
            "hooks": [
              { "type": "command", "command": "python3 /full/path/to/session-clock/session_clock.py prompt" }
            ]
          }
        ]
      }
    }

Restart Claude Code. Your agent now sees the real time on every prompt.

## How it reads your calendar

- Session start always reads the calendar fresh.
- Each prompt uses a saved copy that is at most `cache_minutes` old, so prompts stay fast.
- It handles one-off events and repeating events that run daily or weekly, including skipped dates and moved instances. All-day events are ignored because they are not time blocks.
- More complex repeat rules (monthly, yearly) are not expanded. Put those on a calendar as plain events if you need them here.

## The log file

Each interactive session start adds one row with the time, the block you were in, and the block before it. Starting several sessions inside one block updates a single row and its minute count. Your agent fills in "Worked on" and "Accomplished" as the work gets done.
