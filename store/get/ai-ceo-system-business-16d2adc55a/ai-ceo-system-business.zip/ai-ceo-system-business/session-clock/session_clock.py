#!/usr/bin/env python3
"""session_clock.py: show the real time and the current and previous calendar block.

Run as a Claude Code hook:
  python3 session_clock.py session   (SessionStart hook)
  python3 session_clock.py prompt    (UserPromptSubmit hook)

It reads session-clock/config.json (or the path in SESSION_CLOCK_CONFIG).
Each calendar entry is an .ics address: either a web URL (for Google Calendar use the
"Secret address in iCal format") or a path to a local .ics file. No other tools are needed.
It fails open: if the calendar cannot be read, it still prints the real clock.
"""
import datetime as dt
import json
import os
import re
import sys
import time
import urllib.request
from zoneinfo import ZoneInfo

HERE = os.path.dirname(os.path.abspath(__file__))
CONFIG = os.environ.get("SESSION_CLOCK_CONFIG", os.path.join(HERE, "config.json"))
MODE = sys.argv[1] if len(sys.argv) > 1 else "prompt"
DAYS = ["MO", "TU", "WE", "TH", "FR", "SA", "SU"]


def load_config():
    with open(CONFIG) as f:
        return json.load(f)


def read_source(src):
    if src.startswith(("http://", "https://")):
        with urllib.request.urlopen(src, timeout=10) as r:
            return r.read().decode("utf-8", "replace")
    with open(os.path.expanduser(src), encoding="utf-8") as f:
        return f.read()


def unfold(text):
    return re.sub(r"\r?\n[ \t]", "", text).splitlines()


def parse_dt(value, params, tz):
    if re.fullmatch(r"\d{8}", value):
        return None  # all-day events are not time blocks
    z = value.endswith("Z")
    d = dt.datetime.strptime(value.rstrip("Z"), "%Y%m%dT%H%M%S")
    if z:
        return d.replace(tzinfo=dt.timezone.utc).astimezone(tz)
    m = re.search(r"TZID=([^;:]+)", params)
    zone = ZoneInfo(m.group(1)) if m else tz
    return d.replace(tzinfo=zone).astimezone(tz)


def parse_ics(text, tz):
    events, cur = [], None
    for line in unfold(text):
        if line == "BEGIN:VEVENT":
            cur = {"exdates": []}
        elif line == "END:VEVENT" and cur is not None:
            events.append(cur)
            cur = None
        elif cur is not None and ":" in line:
            head, value = line.split(":", 1)
            name = head.split(";", 1)[0].upper()
            params = head[len(name):]
            if name == "DTSTART":
                cur["start"] = parse_dt(value, params, tz)
            elif name == "DTEND":
                cur["end"] = parse_dt(value, params, tz)
            elif name == "SUMMARY":
                cur["title"] = value.replace("\\,", ",").replace("\\;", ";")
            elif name == "RRULE":
                cur["rrule"] = dict(p.split("=", 1) for p in value.split(";") if "=" in p)
            elif name == "EXDATE":
                for v in value.split(","):
                    d = parse_dt(v, params, tz)
                    if d:
                        cur["exdates"].append(d)
            elif name == "RECURRENCE-ID":
                cur["recurrence_id"] = parse_dt(value, params, tz)
            elif name == "STATUS":
                cur["status"] = value.upper()
            elif name == "UID":
                cur["uid"] = value
    return events


def expand(ev, day0, day1, tz):
    """Instances of one event that overlap [day0, day1). Handles DAILY and WEEKLY rules."""
    s, e = ev.get("start"), ev.get("end")
    if not s or not e or ev.get("status") == "CANCELLED":
        return []
    length = e - s
    rule = ev.get("rrule")
    if not rule:
        return [(s, e)] if s < day1 and e > day0 else []
    freq = rule.get("FREQ")
    interval = int(rule.get("INTERVAL", "1"))
    until = None
    if "UNTIL" in rule:
        u = rule["UNTIL"]
        until = parse_dt(u if "T" in u else u + "T235959", "", tz)
    out, d = [], day0.date() - dt.timedelta(days=1)
    for _ in range(3):
        cand = dt.datetime.combine(d, s.astimezone(tz).timetz()).replace(tzinfo=tz)
        d += dt.timedelta(days=1)
        if cand < s or (until and cand > until):
            continue
        days_since = (cand.date() - s.astimezone(tz).date()).days
        if freq == "DAILY" and days_since % interval == 0:
            ok = True
        elif freq == "WEEKLY":
            wanted = rule.get("BYDAY", DAYS[s.astimezone(tz).weekday()]).split(",")
            wanted = [re.sub(r"^[+-]?\d*", "", w) for w in wanted]
            weeks = days_since // 7
            ok = DAYS[cand.weekday()] in wanted and weeks % interval == 0
        else:
            ok = False
        if ok and not any(abs((cand - x).total_seconds()) < 60 for x in ev["exdates"]):
            if cand < day1 and cand + length > day0:
                out.append((cand, cand + length))
    return out


def fetch(now, cfg, tz):
    day0 = now.replace(hour=0, minute=0, second=0, microsecond=0)
    day1 = day0 + dt.timedelta(days=1)
    result = []
    for name, src in cfg["calendars"].items():
        events = parse_ics(read_source(src), tz)
        replaced = {(x.get("uid"), x["recurrence_id"]) for x in events if x.get("recurrence_id")}
        for ev in events:
            if "recurrence_id" in ev:
                pairs = expand(ev, day0, day1, tz)
            else:
                pairs = [p for p in expand(ev, day0, day1, tz)
                         if (ev.get("uid"), p[0]) not in replaced]
            for s, e in pairs:
                result.append({"cal": name, "s": s.isoformat(), "e": e.isoformat(),
                               "t": ev.get("title", "(untitled)")})
    return sorted(result, key=lambda x: x["s"])


def blocks(now, cfg, tz, refresh):
    cache = os.path.expanduser(cfg.get("cache_file", "~/.cache/session-clock.json"))
    ttl = cfg.get("cache_minutes", 10) * 60
    try:
        with open(cache) as f:
            c = json.load(f)
        if not refresh and c["day"] == now.date().isoformat() and time.time() - c["at"] < ttl:
            return c["ev"]
    except Exception:
        pass
    ev = fetch(now, cfg, tz)
    try:
        os.makedirs(os.path.dirname(cache), exist_ok=True)
        with open(cache, "w") as f:
            json.dump({"day": now.date().isoformat(), "at": time.time(), "ev": ev}, f)
    except Exception:
        pass
    return ev


def hm(iso, tz):
    return dt.datetime.fromisoformat(iso).astimezone(tz).strftime("%-I:%M %p")


HEADER = ("# Session clock log\n\nOne row is written each time an interactive session starts. "
          "Repeated starts inside one block update one row. The agent fills in "
          "'Worked on' and 'Accomplished'.\n\n"
          "| Time | Scheduled now | Previous block | Worked on | Accomplished | Actual min |\n"
          "|---|---|---|---|---|---|\n")


def log_row(now, cfg, cur_s, prev_s):
    path = os.path.expanduser(cfg.get("log_file", "~/session-clock/session-clock-log.md"))
    os.makedirs(os.path.dirname(path), exist_ok=True)
    if not os.path.exists(path):
        with open(path, "w") as f:
            f.write(HEADER)
    with open(path) as f:
        lines = f.read().split("\n")
    for i in range(len(lines) - 1, -1, -1):
        if lines[i].startswith(f"| {now:%Y-%m-%d} "):
            c = [x.strip() for x in lines[i].strip().strip("|").split("|")]
            if len(c) >= 3 and c[1] == cur_s:
                first = dt.datetime.strptime(c[0], "%Y-%m-%d %H:%M").replace(tzinfo=now.tzinfo)
                c += [""] * (6 - len(c))
                c[5] = str(max(0, int((now - first).total_seconds() // 60)))
                lines[i] = "| " + " | ".join(c[:6]) + " |"
                with open(path, "w") as f:
                    f.write("\n".join(lines))
                return
            break
    with open(path, "a") as f:
        f.write(f"| {now:%Y-%m-%d %H:%M} | {cur_s} | {prev_s} | | | |\n")


def main():
    cfg = load_config()
    tz = ZoneInfo(cfg["timezone"])
    now = dt.datetime.now(tz)  # the real system clock
    clock = now.strftime("%a %b %-d %Y, %-I:%M %p %Z")
    cur = prev = nxt = None
    err = ""
    try:
        primary = cfg.get("primary_calendar")
        for x in blocks(now, cfg, tz, MODE == "session"):
            s, e = dt.datetime.fromisoformat(x["s"]), dt.datetime.fromisoformat(x["e"])
            if s <= now < e and (cur is None or x["cal"] == primary):
                cur = x
            elif e <= now:
                prev = x
            elif s > now and nxt is None:
                nxt = x
    except Exception as ex:
        err = f" (calendar unreadable: {str(ex)[:80]})"

    def fmt(x):
        return f"{x['t']} {hm(x['s'], tz)}-{hm(x['e'], tz)} [{x['cal']}]" if x else "none"

    line = (f"REAL CLOCK (read from the system, not a guess): {clock}. "
            f"Scheduled now: {fmt(cur)}. Previous: {fmt(prev)}. Next: {fmt(nxt)}.{err}")
    if MODE == "session":
        try:
            log_row(now, cfg, fmt(cur), fmt(prev))
        except Exception:
            pass
        msg = (line + " SESSION START: open your first reply by showing this real time and the scheduled "
               "block. Say whether the work in this session matches that block. As work completes, fill "
               "'Worked on' and 'Accomplished' on this session's row in the session clock log. "
               "Never state a time that did not come from this line or the system clock.")
    else:
        msg = (line + " Use this time for any time claim. If the request is off the scheduled block, "
               "say so in one line.")
    event = "SessionStart" if MODE == "session" else "UserPromptSubmit"
    print(json.dumps({"hookSpecificOutput": {"hookEventName": event, "additionalContext": msg}}))


if __name__ == "__main__":
    try:
        main()
    except Exception as ex:
        print(json.dumps({"hookSpecificOutput": {"hookEventName": "UserPromptSubmit",
              "additionalContext": f"REAL CLOCK: {dt.datetime.now():%c} (session clock error: {str(ex)[:80]})"}}))
