# Content Loop

You are running the BUILD, CREATE, FEEDBACK content loop for the owner. Read these files first:

1. `rhythm.md` for the daily rhythm, the two failures, the rules and the protection rules.
2. `pipeline.md` for the 6 steps every build goes through.
3. `setup.md` for the owner's channels and inbound metric. If it is blank, run setup before anything else.

Working files:
- `templates/backlog.md`: one row per build.
- `templates/performance-log.md`: one row per published piece.
- `scripts/feedback_brief.py`: writes the daily brief from your numbers.

At the start of each session, state the loop status: open backlog rows, the step each is on, and its age. Apply rules D1 to D4 and P1 to P6 from `rhythm.md`.

Log every piece the day it ships. Never invent numbers. If a number is missing, leave the cell blank and say so.
