# Content Loop

A daily rhythm that turns what you build into content that brings in new people, and a brief that tells you what worked.

What is inside:

- `CLAUDE.md`: the entry file your agent reads first.
- `rhythm.md`: BUILD, CREATE, FEEDBACK, the two failures it prevents, and the rules.
- `pipeline.md`: the 6 steps every build goes through.
- `setup.md`: a short form you fill in once.
- `templates/backlog.md` and `templates/performance-log.md`: blank tables.
- `scripts/feedback_brief.py` plus example config and CSV files: an optional daily brief.

## Setup

1. Copy this folder into your agent workspace.
2. Open `setup.md` and fill in your channels and your inbound metric.
3. Tell your agent: "Read CLAUDE.md in the content-loop folder and run my day by it."
4. Add a row to `templates/backlog.md` for each thing you build. Add a row to the performance log for each piece you publish.

## Optional: the daily brief

The script needs Python 3.9 or newer and nothing else. It makes no network calls and needs no keys.

1. Copy `scripts/config.example.json` to `scripts/config.json`. Set your time zone, for example `America/New_York`.
2. Copy `scripts/stats.example.csv` to `scripts/stats.csv`. Add one row per published piece with its rates. Copy `scripts/inbound.example.csv` to `scripts/inbound.csv` and add one row per day with new followers.
3. Run `python3 scripts/feedback_brief.py --config scripts/config.json`. Add `--dry-run` to preview without writing.
4. To run it daily, add it to your scheduler (cron on Mac or Linux, Task Scheduler on Windows) a little before your FEEDBACK block.

The brief scores each piece against your own median over 30 days, flags WIN, PAR or MISS, updates the auto columns in the log, and raises an inbound alarm after 7 days with no new followers.
