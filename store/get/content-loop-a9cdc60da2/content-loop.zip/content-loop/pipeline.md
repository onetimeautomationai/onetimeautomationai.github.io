# The 6-Step Per-Build Pipeline

Run this once for every build.

| # | Step | Output | Deadline |
|---|---|---|---|
| 1 | Idea: what to build | A backlog row in your own words | Same turn |
| 2 | Why you built it | The problem, in your own words, on the backlog row | Same turn |
| 3 | Build it and put it to work | A working build used for real at least once | Per your plan |
| 4 | Make a shareable asset (prompt, folder, template), with private details removed | A file someone else can use | Within 24 hours of step 3 |
| 5 | Write the post or email: what you did, the instructions you gave (quoted), what you learned, how it works, and the asset as the call to action | A draft you review and approve | Draft within 24 hours of step 3 |
| 6 | Make a presentation or video | Slides or a recording | Your next long-form content block |

Result metric: new followers or members gained, measured 7 days after step 5 goes out. Write it on the backlog row.

## Each step-5 post covers

1. The idea and the problem, in your words.
2. Why you built it.
3. What you built and how you put it to work. Quote the actual instructions you gave.
4. What you learned, mistakes included.
5. How it works, so the reader can copy it.
6. The free asset, with your join link as the call to action.

Never name clients, prospects, friends, revenue, loans or family details.
