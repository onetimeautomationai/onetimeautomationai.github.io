# The Daily Rhythm: BUILD, CREATE, FEEDBACK

Every work day runs all three parts.

| Part | What happens |
|---|---|
| 1. BUILD | Make the offer, asset or system. Note what you built and what you learned. |
| 2. FEEDBACK | Read the daily brief. Answer: what worked and why, what we repeat today, what we drop. Write it on the performance log. |
| 3. CREATE | Make one piece from today's build or learning. Topic is today. Format follows your rotation. Apply the repeat from FEEDBACK. The call to action is your free asset. |

Run FEEDBACK right before CREATE. Yesterday's result then shapes today's piece in the same sitting.

## The two failures it prevents

- **F1: what you build stays with you.** You build something useful and never share it, so nobody learns it exists.
- **F2: you wait too long, and it is forgotten.** The details fade, the moment passes, and nothing gets published.

## Rules

- **D1, ship daily.** A CREATE block that ends with nothing shipped or queued is a miss.
- **D2, log every piece.** Every piece gets a row in the performance log the day it ships, so FEEDBACK has data.
- **D3, inbound is the score.** Count new followers or members per week, not opens. If you get 0 new in 7 days, the next piece goes on a channel that reaches new people, not only your existing list.
- **D4, repeat winners.** Reuse a WIN's hook, topic shape or call to action within 7 days. Do not reuse a MISS's pattern until a lesson explains it.

## Protection rules

- **P1, no silent builds.** When a build finishes, name the shareable asset and the email or post that goes with it, and book your review time. Add the backlog row the same day.
- **P2, status check.** State the loop status at the start and end of each day: open rows, the step each is on, and its age.
- **P3, stall alarm.** A row older than 3 days with no step-5 draft is the first thing you handle next. Older than 7 days with no approved step 5: take the next content slot for it.
- **P4, the content comes to you.** Never start from a blank page. The agent drafts steps 4 and 5 from the session record. You edit, record or approve.
- **P5, never "later".** "Later" means a calendar slot with a date, said in the same reply.
- **P6, weekly check.** Each week, count builds against closed loops. If builds are ahead, make one fix for next week.
