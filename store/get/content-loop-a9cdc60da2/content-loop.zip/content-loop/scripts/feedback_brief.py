#!/usr/bin/env python3
"""Daily feedback brief for the BUILD, CREATE, FEEDBACK loop.

Reads two small CSV files you fill in or export from your channels, scores each piece
against your own median, updates the performance log and writes today's brief.
It never calls an outside service and never needs a key.

Usage:
  python3 feedback_brief.py --config config.json
  python3 feedback_brief.py --config config.json --dry-run

Files (paths come from the config file, relative to the config file's folder):
  stats_file   one row per published piece. Columns:
               date,channel,piece,piece_id,audience,primary_rate,secondary_rate,negative_count
               Rates are fractions below 1 (0.42) or percents of 1 and above (42). Primary is your main reaction
               rate (for example opens or views). Secondary is your action rate (clicks or replies).
  inbound_file one row per day. Columns: date,new_followers
  log_file     the performance log. Auto columns are updated. Lesson and Repeat/drop are never touched.
"""
import argparse
import csv
import datetime as dt
import json
import os
import re
import statistics
import sys
from zoneinfo import ZoneInfo


def load_config(path):
    with open(path) as f:
        cfg = json.load(f)
    base = os.path.dirname(os.path.abspath(path))
    for k in ("log_file", "stats_file", "inbound_file", "brief_dir"):
        cfg[k] = os.path.join(base, cfg[k])
    return cfg


def rate(x):
    try:
        v = float(x)
    except (TypeError, ValueError):
        return 0.0
    return v / 100 if v >= 1 else v


def pct(x):
    return f"{x * 100:.1f}%"


def read_rows(path):
    if not os.path.exists(path):
        return []
    with open(path, newline="") as f:
        return list(csv.DictReader(f))


def verdict(p, s, mp, ms, win, miss):
    if (mp and p >= mp * win) or (ms and s >= ms * win):
        return "WIN"
    if (not mp or p <= mp * miss) and (not ms or s <= ms * miss):
        return "MISS"
    return "PAR"


HEADER = """# Performance Log

One row per published piece. Verdict: WIN is the win ratio or more of your median on either rate.
MISS is the miss ratio or less on both. Everything else is PAR.
Lesson is one sentence on why. Repeat / drop is what you do next time.

| Date | Channel | Piece | Piece ID | Audience | Primary rate | Secondary rate | Negative | Verdict | Lesson | Repeat / drop |
|---|---|---|---|---|---|---|---|---|---|---|
"""


def upsert_log(path, rows, dry):
    text = open(path).read() if os.path.exists(path) else HEADER
    lines = text.rstrip("\n").split("\n")
    index = {}
    for i, ln in enumerate(lines):
        cells = [c.strip() for c in ln.split("|")]
        if len(cells) > 5 and re.match(r"\d{4}-\d{2}-\d{2}$", cells[1]):
            index[(cells[1], cells[4])] = i
    hdr = next(i for i, ln in enumerate(lines) if ln.startswith("|---"))
    for r in rows:
        auto = (f"| {r['date']} | {r['channel']} | {r['piece'][:70].replace('|', '/')} | {r['piece_id']} | "
                f"{r['audience']} | {pct(r['p'])} | {pct(r['s'])} | {r['neg']} | {r['verdict']} |")
        key = (r["date"], r["piece_id"])
        if key in index:
            i = index[key]
            cells = lines[i].split("|")
            tail = "|".join(cells[10:]) if len(cells) > 10 else "  |  |"
            lines[i] = auto + tail
        else:
            lines.insert(hdr + 1, auto + "  |  |")
    if not dry:
        with open(path, "w") as f:
            f.write("\n".join(lines) + "\n")
    return [ln for ln in lines if ln.startswith("| 20") and not re.search(r"\|\s*\|\s*\|\s*$", ln)]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    ap.add_argument("--dry-run", action="store_true")
    a = ap.parse_args()
    cfg = load_config(a.config)
    tz = ZoneInfo(cfg["timezone"])
    today = dt.datetime.now(tz).date()
    since = today - dt.timedelta(days=cfg["window_days"])

    rows = []
    for r in read_rows(cfg["stats_file"]):
        try:
            d = dt.date.fromisoformat(r["date"])
        except (KeyError, ValueError):
            continue
        if d >= since:
            rows.append({"date": r["date"], "channel": r.get("channel", ""), "piece": r.get("piece", ""),
                         "piece_id": r.get("piece_id", ""), "audience": r.get("audience", "0"),
                         "p": rate(r.get("primary_rate")), "s": rate(r.get("secondary_rate")),
                         "neg": r.get("negative_count", "0")})
    mp = statistics.median([r["p"] for r in rows]) if rows else 0
    ms = statistics.median([r["s"] for r in rows]) if rows else 0
    for r in rows:
        r["verdict"] = verdict(r["p"], r["s"], mp, ms, cfg["win_ratio"], cfg["miss_ratio"])
    lessons = upsert_log(cfg["log_file"], rows, a.dry_run)

    inbound = read_rows(cfg["inbound_file"])
    def new_between(start, end):
        total = 0
        for r in inbound:
            try:
                d = dt.date.fromisoformat(r["date"])
                if start <= d <= end:
                    total += int(float(r["new_followers"]))
            except (KeyError, ValueError):
                pass
        return total
    y = new_between(today - dt.timedelta(days=1), today - dt.timedelta(days=1))
    w = new_between(today - dt.timedelta(days=7), today)

    recent = [r for r in rows if r["date"] >= (today - dt.timedelta(days=7)).isoformat()]
    wins = sorted([r for r in rows if r["verdict"] == "WIN"], key=lambda r: (r["s"], r["p"]), reverse=True)[:3]
    misses = [r for r in rows if r["verdict"] == "MISS"][:3]

    def line(r):
        return f"- {r['date']} {r['channel']} \"{r['piece']}\": {pct(r['p'])} / {pct(r['s'])} ({r['verdict']})"

    alarm = ""
    if w == 0:
        alarm = ("**Inbound alarm:** 0 new followers in 7 days. Your pieces reach the people you already have "
                 "but bring no one new. Today's CREATE piece goes on a channel that reaches new people.\n\n")
    nl = "\n"
    body = f"""# Feedback Brief, {today.isoformat()}

Read this in the FEEDBACK block, then answer the 3 questions at the bottom.

{alarm}## Audience growth
- Yesterday: {y} new.
- Last 7 days: {w} new.

## Last 7 days of pieces
{nl.join(line(r) for r in recent) or '- Nothing shipped in the last 7 days. That is the first fix.'}

## Baseline
- {len(rows)} pieces in {cfg['window_days']} days. Median primary {pct(mp)}, median secondary {pct(ms)}.

## What worked (repeat these)
{nl.join(line(r) for r in wins) or '- No WIN yet.'}

## What did not (drop or fix these)
{nl.join(line(r) for r in misses) or '- No MISS yet.'}

## Lessons already logged
{nl.join(lessons[-5:]) or '- None yet. Today starts the habit.'}

## Answer these 3, then write them on the log row
1. What worked, and why? One sentence, goes in the Lesson column.
2. What do we repeat in today's piece? Hook, topic, format or call to action.
3. What do we drop?
"""
    if a.dry_run:
        print(body)
        return
    os.makedirs(cfg["brief_dir"], exist_ok=True)
    out = os.path.join(cfg["brief_dir"], f"{today.isoformat()}-feedback-brief.md")
    with open(out, "w") as f:
        f.write(body)
    print(f"wrote {out}: {len(rows)} pieces, {w} new in 7 days")


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"Feedback brief failed: {type(e).__name__}: {e}", file=sys.stderr)
        sys.exit(1)
