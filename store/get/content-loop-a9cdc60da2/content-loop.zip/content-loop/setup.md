# Setup

Fill this in once. The agent reads it every session.

- My channels (where I publish): 
- My main inbound metric (for example new email subscribers or new community members per week): 
- Where the metric is counted: 
- My daily BUILD time: 
- My daily FEEDBACK time: 
- My daily CREATE time: 
- My free asset and where people get it: 
- My content rotation (which format on which day): 
