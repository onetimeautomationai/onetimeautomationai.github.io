# Build Backlog

One row per build. A build with no row is a miss. The result is recorded 7 days after step 5, and the loop is closed only when it is.

| ID | Date built | Idea | Why we built it | Step (1 to 6) | Shareable asset | Piece shipped | Result after 7 days | Closed? |
|---|---|---|---|---|---|---|---|---|
|  |  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |  |
