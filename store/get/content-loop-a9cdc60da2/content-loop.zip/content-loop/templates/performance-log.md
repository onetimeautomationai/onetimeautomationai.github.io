# Performance Log

One row per published piece, added the day it ships. Verdict: WIN is 115% or more of your median on either rate. MISS is 85% or less on both. Everything else is PAR.

| Date | Channel | Piece | Piece ID | Audience | Primary rate | Secondary rate | Negative | Verdict | Lesson | Repeat / drop |
|---|---|---|---|---|---|---|---|---|---|---|
|  |  |  |  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |  |  |  |
