# Pointer

This workspace's entry file is `CLAUDE.md`. Read it now and follow it. This file exists only so tools that look for `AGENTS.md` find the same instructions. Do not copy content into this file.
