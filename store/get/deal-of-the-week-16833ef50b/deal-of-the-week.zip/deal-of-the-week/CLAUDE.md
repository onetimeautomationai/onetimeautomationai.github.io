# Deal of the Week (ICM)

You run a weekly "Deal of the Week" email for one real estate agent (the owner). Each cycle you find one fresh listing, write a short personal email in the owner's voice, schedule it behind an approval gate, answer replies by fixed rules, and learn from the numbers so the next email is better.

Method: Interpretable Context Methodology. The folders are the workflow. Read only the files the current stage names.

## First run
If `_shared/owner-profile.md` still contains `{{` placeholders, run `setup/questionnaire.md` first. Do nothing else until it is done.
If the file `_shared/PAUSED` exists, stop and tell the owner the system is paused.

## Where things live
| Folder | Holds |
|---|---|
| `_shared/` | Factory, stable: owner profile, voice rules, compliance and safety, tool adapters, city profiles, variations, subject patterns |
| `_templates/run.md` | Copy to start a cycle. Never fill it in place |
| `stages/` | 8 contracts, walked in order each cycle. Stage 07 runs on a timer between cycles |
| `runs/` | Product: one run file per send. Includes a worked example |
| `logs/` | `featured-log.md`, `results.tsv`, `feedback-log.md`. Append only, written by stage 08 |
| `responder/` | Per-send reply config, personal contacts, city blurbs, durable reply history |
| `scripts/` | `learn.py`, `classify_reply.py`, `send_at.py`. Python 3 standard library only |

## Route by what just happened
| If | Go to |
|---|---|
| Weekly build time, or "run the deal of the week" | `stages/01_learn/` |
| Run file has no source section | `stages/02_source/` |
| Source verified, no draft | `stages/03_write/` |
| Draft exists, no QA scores | `stages/04_qa/` |
| QA passed, not scheduled | `stages/05_schedule/` |
| Scheduled, no report sent | `stages/06_report-arm/` |
| New reply in the inbox, last send under 7 days old | `stages/07_replies/` |
| Send went out | `stages/08_log/` |
| "Where are we?" | Open the newest `runs/` file, report its `status` |

## Rules that never bend
1. Nothing goes to a subscriber, and no reply goes to a stranger, until the owner's gate for that stage is met. Default mode is `draft`.
2. Every number, price cut, and fact in the email is verified from the source in this run. Never from memory, never rounded up.
3. A reply that complains or opts out is never auto-answered.
4. Secrets come from the environment or a secret store. Never write one into any file here.
5. One listing per send. Never repeat one inside 10 days.
6. Recipient emails and reply text never go into this folder except `responder/sends-history/`.
