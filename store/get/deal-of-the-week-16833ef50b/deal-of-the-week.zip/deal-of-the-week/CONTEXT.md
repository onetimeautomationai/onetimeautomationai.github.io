# Workspace definition

**Repeating unit:** a run. One run = one listing, one email, one scheduled broadcast, one reply window, one row of learning.

| # | Stage | Output | Human gate |
|---|---|---|---|
| 01 | learn | `## Learn` in the run file: levers read, decision note started | None, owner can read it |
| 02 | source | `## Source`: one verified listing, slot and city logged | Owner may veto the pick |
| 03 | write | `## Draft`: subject options, body, CTA keyword | None yet |
| 04 | qa | `## QA`: scores, lint result, fact check | Subject and email must clear the score floors in `_shared/owner-profile.md` |
| 05 | schedule | `## Schedule`: broadcast created, send time set, status verified | **Owner approves before the broadcast is scheduled live** (mode `draft`) |
| 06 | report-arm | Confirmation report sent, `responder/active-send.json` written | Owner can abort until send time |
| 07 | replies | Rows in `responder/sends-history/<send_id>.json`, replies sent or flagged | Owner reviews the first batch before `auto_send` is allowed |
| 08 | log | Rows in `logs/featured-log.md` and `logs/results.tsv` | None |

**Factory:** `_shared/`, `_templates/`, `scripts/`. **Product:** `runs/`, `logs/`, `responder/sends-history/`.

**Status is in the files.** No `## Source` means stage 02. No `## Draft` means 03. No `## QA` scores means 04. No `## Schedule` with `verified: yes` means 05. No `## Report` means 06. No featured-log row means 08.

**Loop:** stage 08 writes results, stage 01 of the next cycle reads them through `scripts/learn.py`. One send's replies become the next send's decision input.

Pairs well with an AI Time Manager ICM (build time and send time become calendar blocks) and an AI Leadership Team ICM (the orchestrator dispatches this run weekly).
