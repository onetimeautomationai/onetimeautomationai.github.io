# Deal of the Week: an exportable ICM

A folder you drop into any AI agent platform. Your AI runs a weekly "Deal of the Week" email for your real estate database:

- Finds one fresh listing in your markets, in a fixed rotation (newly listed, off-market, new construction, price reduction).
- Writes a short, personal email in your voice and checks it against your rules and a compliance list.
- Schedules it as a broadcast behind your approval, with an abort window.
- Answers replies by fixed rules (the keyword reply gets the photos and details, a city reply gets a custom-alert offer, complaints and personal contacts are never auto-answered).
- Records every reply and every result, ranks what is working, and uses that ranking to write the next one.

## Install
1. Copy this folder into your AI workspace. Point your agent at `CLAUDE.md`. Tools that look for `AGENTS.md` find a pointer to it. For other tools, copy the pointer under the name that tool expects (for example `GEMINI.md` or a rules file).
2. Say "run setup". The agent walks `setup/questionnaire.md` and fills `_shared/owner-profile.md`, `_shared/city-profiles.md`, your signature, and your first city blurbs.
3. Map your tools in `_shared/adapters.md`. You need five capabilities: a listing source, an email platform that can schedule a broadcast and report stats, a mailbox the agent can read and send from, a scheduler, and a notifier. Any vendor works. Examples are listed.
4. Say "run the deal of the week" for a first cycle in `draft` mode. Nothing leaves until you approve each gate.
5. Optional: schedule the weekly build and the 10-minute reply check with your scheduler (cron, launchd, Task Scheduler, a cloud routine).

No folder support in your AI tool? Paste `INJECT-PROMPT.md` into its custom instructions. It is the condensed version and works in a plain chat. You then paste in listings and replies by hand.

## What is portable and what is not
- Portable: every stage contract, the voice and compliance rules, the variation library, the learning loop, and three standard-library Python scripts (`learn.py`, `classify_reply.py`, `send_at.py`).
- Yours to supply: listing access, email platform account, mailbox access, scheduler. Vendor notes and known API gotchas are in `_shared/adapters.md`.
- Not shipped: any subscriber data, results, API keys, or third-party training material.

## Why these design choices
- Default mode is `draft`. Auto-send of broadcasts and replies is a switch you flip after you have watched the first batch work.
- The reply classifier is plain code, not a model. A model can be talked into replying to a complaint. The code cannot.
- Learning ranks on reply rate with open rate as the gate, because opens measure subject lines and replies measure interest.
- Every send re-writes `responder/active-send.json` from the content that actually went out, so the reply matcher never works from a stale subject or keyword.

Method: Interpretable Context Methodology (Van Clief & McDermott, arXiv:2603.16021).
