# Tool adapters (capabilities, not vendors)

Stages name capabilities. The owner maps each to a real tool once, here. If your agent platform has a native connector, use it. If not, a short script or a manual paste step works, and the stage still passes.

| Capability | Stage | Minimum contract | Example tools |
|---|---|---|---|
| **Listing search** | 02 | Filter by city, status, days on market, price. Return address, price, beds, baths, sqft, year, lot, status, days on market, listing id, and a detail call with the full remarks. | An MLS or IDX API, a CRM's listing API, a licensed data feed |
| **Portal fallback** | 02 | Read a city page for off-market, coming-soon, new construction, and price-drop badges. Cheap, one call per cycle. | A scraper or browser tool pointed at a listing portal, a builder directory for new construction |
| **Email platform** | 05, 08 | Create a broadcast to a named segment, set a send time, read back status, delete a broadcast, report delivered, open rate, click rate, unsubscribes per broadcast. | Kit, Mailchimp, ActiveCampaign, Constant Contact, a CRM's bulk email |
| **Mailbox** | 06, 07 | Search and read replies to the broadcast, send an HTML reply into the same thread, save a draft, apply a label, check a thread for a newer sent reply. | Gmail, Outlook, any IMAP/SMTP account |
| **Scheduler** | all | Run a command weekly (build) and every 10 minutes (replies) on the owner's machine or a cloud runner. | cron, launchd, Windows Task Scheduler, a cloud routine |
| **Notifier** | 05, 06 | Reach the owner immediately with a short message on failure. | iMessage, SMS, Slack, email to a second address |
| **Secret store** | all | Hold API keys. Never a file inside this folder. | Environment variables, OS keychain, a password manager CLI |

## Owner's mapping (fill during setup)
| Capability | Tool | How the agent calls it | Account or segment id |
|---|---|---|---|
| Listing search | {{tool}} | {{CLI, API, connector}} | {{id}} |
| Portal fallback | {{tool}} | {{ }} | n/a |
| Email platform | {{tool}} | {{ }} | {{segment id, template id}} |
| Mailbox | {{tool}} | {{ }} | {{account}} |
| Scheduler | {{tool}} | {{ }} | n/a |
| Notifier | {{tool}} | {{ }} | {{ }} |

## Gotchas learned the hard way (examples, check your own tools for the equivalent)
- **Filters nested wrongly are silently ignored.** One listing API ignored flat top-level filters and returned the whole state. Always check the result count is small and every returned row is in your city before trusting a search.
- **Search payloads often have no description.** Fetch the detail record for the full remarks. The detail call is usually free. Read it before writing.
- **Portals that block a plain fetch need a real browser tool.** Budget one source call and one detail call per cycle, rotate one city, and never sweep a whole portal. Credits and time are finite.
- **A created broadcast is a draft.** One email platform ignored `send_at` on create. Create, then update with the send time, then read back `status: scheduled`.
- **Template ids differ between the API and the editor URL.** Use the API id.
- **Segment, not tag, for audience** if your platform has both. A stale tag once sent to the wrong audience. Name the segment id in the mapping above.
- **Convert send time with the real time zone.** A hard-coded UTC offset is wrong for half the year. Use `scripts/send_at.py`.
- **Scheduled jobs on a locked-down laptop** may be blocked from reading folders such as Documents. If a job exits with a permission error, run the scheduler's entry command from a folder it is allowed to read and log outside protected folders.
- **Inline `font-size` overrides the email template's type.** Leave size to the template.
