# City price profiles

Used at stage 03 to classify a listing's price tier and frame it. Fill during setup. Refresh every quarter, or when the owner says the market moved. The agent can compute medians from the listing source, so ask it to.

| City | Median price | Entry ceiling | Luxury floor | Notes (HOA norms, school-zone talk to avoid, landmarks) | Last refreshed |
|---|---|---|---|---|---|
| {{city 1}} | {{$}} | {{$}} | {{$}} | {{ }} | {{date}} |
| {{city 2}} | {{$}} | {{$}} | {{$}} | {{ }} | {{date}} |

## Tier rule
- Entry: price at or below the entry ceiling.
- Mid: between entry ceiling and luxury floor.
- Luxury: at or above the luxury floor.
- "Upper-mid" is a note, not a tier: mid tier, within 15% of the luxury floor.

## Method to refresh
1. Pull active for-sale listings for the city, count only `Active` status (exclude pending, under contract, coming soon).
2. Median and the 25th and 75th percentile of price.
3. Entry ceiling = 25th percentile. Luxury floor = the owner's number, or 150% of median if not set.
4. Write the date. Never bracket placeholders in an email. Compute fresh at stage 03 if the profile is older than 90 days.
