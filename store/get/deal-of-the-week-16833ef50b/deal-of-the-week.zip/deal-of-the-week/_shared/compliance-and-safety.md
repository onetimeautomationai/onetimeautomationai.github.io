# Compliance and safety

Read at stages 02, 04, 05 and 07. These are the lines that cost an owner a client, a complaint, or a license problem. The agent is not a lawyer. Where a rule depends on the owner's state or brokerage, the questionnaire records the answer and the owner's compliance contact decides.

## Marketing and facts
- **C1. Verify, never invent.** Price, original price, price cut, days on market, beds, baths, square feet, HOA, year built: each comes from the source record fetched in this run. If a number is missing, leave it out.
- **C2. Price cuts.** State original price, current price, dollar amount, and reduction date, all from the listing history. If the cut is older than 30 days or the history is missing, pick the next listing. Never say or imply a motivated seller.
- **C3. Status words.** Use the listing's real status. "Off-market" only if it is not actively listed on the MLS. "Coming soon" only if the MLS status is Coming Soon. "New" only if on market 7 days or fewer.
- **C4. Attribution.** If the source requires listing-broker attribution in marketing, the email carries it. If the reply engine sends a listing link, it uses a link the MLS rules permit.
- **C5. Fair housing.** Describe the home, not the buyer. "This one's for you if" lines name lifestyles and features (a home office, a yard to garden, a short commute to a trail), never protected classes or neighborhood character (no "great for families", "safe area", "good schools" without the owner's compliance sign-off, no "exclusive community", no references to religion, race, national origin, disability, or familial status).
- **C6. Required footer.** Unsubscribe link and physical mailing address come from the email platform's footer. Never remove them. Honor unsubscribes immediately.
- **C7. License line.** Include the license number in the signature where the state requires it.

## Sending safety
- **S1. Draft first.** `broadcast_mode` and `reply_mode` ship as `draft`. Switching to the automatic modes is the owner's explicit act, recorded in `logs/feedback-log.md`.
- **S2. Abort window.** Every scheduled broadcast has a report with an abort instruction before send time. If the report fails to send, the broadcast is unscheduled.
- **S3. Verify the schedule.** A created broadcast is not a scheduled broadcast. Check the platform's response says scheduled and has a send time. Anything else is a failure to report, not a success to log.
- **S4. Complaint guard.** Any reply with a complaint, opt-out, wrong-fit, or "is this spam" signal is flagged for the owner and never auto-answered. This check runs first and is code, not judgment (`scripts/classify_reply.py`).
- **S5. Personal contacts.** Anyone in `responder/personal-contacts.txt` (family, friends, peers, past clients the owner wants to answer by hand) is flagged for a personal reply, even when they type the keyword.
- **S6. Match new text only.** Strip the quoted trail before matching any keyword or city, or the original email's copy matches itself.
- **S7. Contaminated keyword.** If the CTA keyword appears in the subject, the matcher disables it for that send and warns.
- **S8. Re-arm every send.** Whenever a broadcast goes out, is re-sent, or its subject or CTA changes, rewrite `responder/active-send.json` from the content that actually went out in the same step. A stale config makes the responder blind.
- **S9. One thread, one live draft.** Before saving a reply draft, check the thread for an existing unsent draft or a newer sent reply from the owner. If the owner already replied, stop and surface it.
- **S10. No volunteered work.** An auto-reply answers only what was asked or typed. It never promises anything the owner did not pre-approve in `stages/07_replies/`.

## Data handling
- **D1. Secrets** live in the environment or a secret store, never in this folder.
- **D2. Subscriber data.** Recipient emails and reply text live only in `responder/sends-history/` on the owner's machine. Never paste them into prompts that go to a third-party tool the owner has not approved, and never ship them with this folder.
- **D3. Reports.** The confirmation report goes only to the report-to address.
