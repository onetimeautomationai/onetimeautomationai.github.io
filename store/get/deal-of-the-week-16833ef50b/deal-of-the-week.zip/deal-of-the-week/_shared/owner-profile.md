# Owner profile (filled by `setup/questionnaire.md`)

Stable across runs. Every `{{ }}` must be replaced before the first cycle.

## Identity
- Owner name (as it signs): {{owner first name}}
- Full name and brokerage: {{full name | brokerage}}
- License line, if your state requires it in marketing: {{license line}}
- Send-from address: {{send-from email}}
- Report-to address (where the confirmation report goes): {{report-to email}}
- Time zone (IANA name, for example America/Chicago): {{time zone}}

## Markets
- Cities in rotation order, one per cycle: {{city 1, city 2, ...}}
- Property focus: {{residential | condo | mixed}}
- Price band for the new construction slot: {{min to max}}
- City price profiles: `city-profiles.md`

## Schedule
- Build day and time: {{for example Tuesday 9:00 PM}}
- Send day and time: {{for example Wednesday 7:30 AM}}
- Abort window: from the report until send time
- Reply check interval: {{10 minutes}} while the last send is under 7 days old
- Reply delay before an auto-reply: {{15 minutes}}

## Modes (the only switches)
- `broadcast_mode`: `draft` (default, owner approves before it is scheduled live) or `auto_schedule` (agent schedules, owner can abort)
- `reply_mode`: `draft` (default, replies are saved as drafts) or `auto_send` (only after the owner has reviewed one full batch of drafts)

## Slots (cadence per `stages/02_source/`)
- New construction: every {{3rd}} send
- Price reduction: every {{4th}} send, never back to back, new construction wins a collision
- Off-market: at most 1 in 4 sends
- Default: newly listed, 7 days or fewer on market
- Listing exclusion window: {{10}} days

## Quality floors
- Any subject or hook shown to the owner scores {{9}}/10 or higher
- The whole assembled email scores {{8.5}}/10 or higher before it can be scheduled

## Platforms (names only, details in `adapters.md`)
- Listing source: {{name}}
- Email platform: {{name}}
- Mailbox: {{name}}
- Scheduler: {{name}}
- Notifier: {{name}}

## Signature
In `signature.md`. Reply engine and email use the same block.

## Personal contacts
Emails that are never auto-answered: `../responder/personal-contacts.txt`.
