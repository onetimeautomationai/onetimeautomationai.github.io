# Price tier language

Tier sets the voice. The variation sets the angle. The city profile sets the framing.

| Tier | Register | Use | Avoid |
|---|---|---|---|
| Entry | Accessible, opportunity, value, monthly payment in plain terms | "under $X", what the money buys, low-maintenance wins, a short path to owning | Condescension, "starter", "cheap", payment math for a number you did not compute |
| Mid | Practical and aspirational: space, flow, schools only if compliance-approved, yard, commute | Room to grow, move-in ready, the price against the city median | Luxury adjectives, hype |
| Luxury | Sensory, design, lifestyle, the one detail that makes someone fall for it | Light, materials, view, setting, privacy | "deal", "under $X", payment math, discount language |

Rules for every tier:
- One concrete number per claim, from the source.
- The price line is one plain sentence that places the price against the city median.
- No tier word ever appears in the email. The register does the work.
