# Signature (one source for the email and every auto-reply)

Replace the placeholders. Keep the layout. If this file and any copy elsewhere disagree, this file wins.

```
Best,

- {{owner first name}}


:: {{full name}} | {{brokerage}} | {{license line}}

:: {{link label 1}}  [link: {{url 1}}]

:: {{link label 2}}  [link: {{url 2}}]
```

Rules:
- Sign-off is `Best,` then `- {{name}}` on consecutive lines (hyphen, not a dash character).
- One blank line, then the `::` lines tight together.
- Links render as clickable anchors with the label as the text. Never show a raw URL.
- Emails are plain text by default (see `voice-rules.md`), so the only markup in the signature is the anchors.
- Auto-replies use the same block and send as HTML so the anchors work.
