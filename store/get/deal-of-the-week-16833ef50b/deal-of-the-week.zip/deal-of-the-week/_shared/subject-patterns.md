# Subject and hook patterns

Adapt to the property. Never ship a bare or hype subject. Every subject here fits `Deal of the week in [City]: [specific]` (voice-rules item 7).

## Subject specifics (the part after the colon, 2 to 3 words)
- A real number: `$1.2M Turnkey`, `4 Beds Under $1.3M`
- A hero feature: `Canyon View`, `Remodeled Kitchen`, `Zero Projects`
- The off-market fact: `Off-Market Find`
- The slot: `New Construction`, `$40K Price Drop`
- Timing, only if true: `Just Listed`

Test before keeping one: would a stranger know what the email is about from the subject alone? Does it survive 45 characters? Is the claim true on the source record?

## Hook line models (line 1 of the body, first person, ends handing off to the deal)
- Take: "I would pick a home that needs nothing over a bigger one that needs everything. This week's deal is ..."
- Contrast: "Some homes start a to-do list the second you walk in. This week's deal is the opposite."
- Observation from the owner's week: "Three of my buyers this month asked for a quiet street before they asked for a pool. This week's deal is ..."
- Scarcity, only if true: "Nothing under $X in [area] has this much space right now. This week's deal is ..."

A hook is the owner's voice. If the owner has not given the agent a take to work from, the agent proposes three and the owner picks or rewrites. Never invent a personal anecdote.

## Learning
After 10 or more sends, `scripts/learn.py` ranks subject formulas by reply rate. Replace models here with the owner's own top performers and log why in `logs/feedback-log.md`.
