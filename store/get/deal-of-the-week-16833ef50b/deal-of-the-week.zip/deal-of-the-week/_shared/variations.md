# Variations and selection

The menu of email shapes. Stage 03 picks one per send from the listing's signals. V2 is the anchor and the safe default. Rotate: the same version never runs twice in a row. The learning loop (`logs/results.tsv` through `scripts/learn.py`) can override the default weights.

## Selection by signal
| Signal | Version |
|---|---|
| Off-market or pocket listing | V1 |
| Anything, safe default | V2 |
| Clear persona fit or move-in ready | V3 |
| Duplex, ADU, rental income | V4 |
| Lowest price or best price per sqft in the area | V5 |
| Luxury, view, waterfront, trophy | V6 |
| On market 7 days or fewer | V7 |
| Open house scheduled | V8 |
| Connection-building week, a relatable lesson | V9 |
| Data-minded audience, rates matter | V10 |
| Price reduction slot | V3 or V5 with the cut as the hero |
| New construction slot | the new construction template below |

## The versions
Every version obeys `voice-rules.md` and `compliance-and-safety.md`. Subject always follows `Deal of the week in [City]: [2-3 word specific]`.

**V1 Off-market heads-up.** Hook: quick heads-up before this goes public. One idea per line, property type, one scarcity line, CTA.

**V2 Deal of the Week (sectioned anchor).** Hook line, `This week's deal is [what it is].` Then `The home:` (beds, square feet, year built, HOA), `My highlights:` (3 to 5 plain `•` bullets), `This one's for you if:` (3 full sentences, compliance C5), `The price:` (asking price against the city median), then `Reply **KEYWORD** and I'll send you the photos and the address.`

**V3 Lifestyle and value story.** A relatable tension then the flip ("Some homes start a to-do list the second you walk in. This one doesn't."). One line what it is, a staccato feature beat (fragments, one per line), one payoff line tied to the strongest desire, one number-anchored value line, a warm CTA.

**V4 Investor numbers.** Specs, `What makes it a deal:` (current or projected rent, condition, occupancy, only numbers you can source), CTA.

**V5 Lowest-price scarcity.** The claim ("the only [type] this size under $X in [area]") must be true on the data you pulled. Specs, CTA. Lean and urgent.

**V6 Luxury aspirational.** Lead with the one detail that makes the home. A few aspirational lines. CTA offers photos and a private look, never "deal" language.

**V7 Just listed.** "If you've been waiting for [feature] in [City], this just hit the market." Standout bullets, self-qualification lines, CTA.

**V8 Open-house driver.** Hook, open house day and time, "I can get you in privately first", CTA.

**V9 Personal story to property.** Two to four lines of a personal observation, the lesson, a bridge to the home, CTA. Higher engagement, lower frequency.

**V10 Market pulse plus this deal.** `The market this week:` (3 full sentences: the 30-year rate with source and date, active inventory count for the city, the median price). Pull all three fresh every send. Never from memory, never bracketed. Then `This week's deal is ...`, `The home:`, one highlights sentence, CTA.

## Slot templates
**New construction.** Sectioned: `The home:`, `The neighborhood:`, `The price:`, `This one's for you if:`. Include builder incentives (rate buydown, closing credits) only if listed on the source page. CTA keyword tied to the home type or a feature. Subject `Deal of the week in [City]: New Construction`.

**Price reduction.** The cut is the hero, stated early with original price, current price, dollar amount, from verified history (compliance C2). Subject `Deal of the week in [City]: $[X]K Price Drop`. CTA keyword never DROP, PRICE, or REDUCED.

## Not part of this ICM
Just-sold social proof, nine-word re-engagement, newsletters. They belong to a general nurture sequence, not the weekly deal.
