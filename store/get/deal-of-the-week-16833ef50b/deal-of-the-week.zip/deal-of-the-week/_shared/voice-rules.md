# Voice rules (defaults from a proven account, owner edits in setup)

These came from many real sends and the owner's corrections. The questionnaire asks the owner to keep, change, or drop each. After setup, the owner's version is the law. Number them in `logs/feedback-log.md` whenever the owner changes one.

## Structure
1. No greeting. No "Hey". Open straight into the hook.
2. Line 1 is a short personal hook in the owner's first person (a take only the owner can make), and it ends by handing off to `This week's deal is [what it is].`
3. One idea per line, blank line between. Scannable on a phone. Do not turn a stat block into a dozen one-liners.
4. State the property type every time: single-family, attached, detached, condo, townhouse.
5. The email ends after the single reply-keyword CTA, then the signature. No reverse CTA ("Not what you're looking for?"), no extra line, no divider.
6. No street address and no link in the body. The reply keyword is the call to action.

## Subject
7. Format: `Deal of the week in [City]: [one concrete specific]`. The specific is 2 to 3 words, a real number, a real feature, or the off-market fact.
8. Short and unambiguous: about 6 words, 45 characters or fewer, survives the phone cutoff. Names the city or the home. Clarity beats clever. Never a bare "Deal of the week".

## CTA
9. One keyword per email, drawn from a main feature of the home (a view, a lake, a remodel), not a generic word. It appears nowhere else in the subject or body, so the reply matcher cannot false-match.
10. Commitment ladder: the reply earns the smallest yes. Photos, the address, or the full details. Never a tour or a showing as the first ask. A tour is the next step after they raise a hand.
11. Reply keywords that collide with copy words are banned for that send (a price-cut email never uses PRICE, DROP, REDUCED).

## Format
12. Plain text by default. The only markup: line breaks, bold on the single CTA keyword, anchors in the signature. No colors, boxes, dividers, bullets styled by markup (use a plain `•` character), or emoji.
13. Only the CTA keyword is bold. Nothing else, including the headline.

## Language
14. Plain words a buyer understands instantly. If a phrase needs insider knowledge to decode, replace it.
15. Read the full listing description and mine real buyer-desire hooks (turnkey, space, views, low maintenance, flex room). Never write from the one-line highlight.
16. Match the price tier register in `price-tier-language.md`.
17. Banned AI tells: "Picture this", "Imagine", "Dive in", "game-changer", "stunning", "nestled", "boasts", em dashes, and any opener that praises the reader. Add the owner's own list to `logs/feedback-log.md`.
18. Off-market framing: when a home is truly off-market, say off-market and say why that matters. Do not call it "coming soon" unless its status is Coming Soon. See `compliance-and-safety.md` C3.

## Sectioned layout (variation V2, the anchor)
Hook line, then `This week's deal is ...`, then `The home:` (4 tight spec lines), `My highlights:` (plain `•` bullets), `This one's for you if:` (3 full sentences, see compliance C5), `The price:` (one sentence, asking price against the city median), the CTA, the signature. Full text in `variations.md`.
