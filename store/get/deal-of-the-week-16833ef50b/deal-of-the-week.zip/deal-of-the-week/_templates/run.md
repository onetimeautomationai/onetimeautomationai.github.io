---
run: YYYY-MM-DD-city
status: new
slot:
send_id:
---

# Run YYYY-MM-DD

## Learn
- Completed sends read:
- Top pick per lever:
- Levers moved this send and why:

## Source
- Slot:
- City:
- Listing id:
- Source link (internal only):
- Hero feature:
- Fact sheet (every number, with where it came from):

## Draft
- Tier:
- Version:
- CTA keyword:
- Offer (photos, address, or details):
- decision_note:
- Subject options:
- Body:

## QA
- Lint:
- Fact check:
- Compliance C1 to C7:
- Scores (each subject, whole email):
- Top pick:

## Schedule
- Broadcast id:
- Subject sent:
- Send time (local and UTC):
- Segment and recipient count:
- verified: no

## Report
- Sent to:
- Abort line included: no

## Replies
(one line per reply action, written by stage 07)
