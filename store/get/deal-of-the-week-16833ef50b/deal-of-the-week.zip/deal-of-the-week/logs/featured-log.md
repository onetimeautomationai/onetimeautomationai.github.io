# Featured log

Append only. Stage 02 reads the last rows to rotate cities, pick slots, and exclude repeats inside the exclusion window. Stage 08 writes.

| Date | City | Address | Listing id | Status | Slot | Version | Drop (price reduction only) | Original | Current |
|---|---|---|---|---|---|---|---|---|---|
