# Feedback log

Append only. One dated line per owner correction, veto, rule change, or mode switch. If a line changes a rule, edit `_shared/voice-rules.md` or `_shared/compliance-and-safety.md` the same turn. The owner's wording wins.

| Date | Owner said | What changed |
|---|---|---|
