# sends-history

Durable, never cleared. One file per send: `<send_id>.json`.

```json
{"send_id": "...", "subject": "...", "cta_keyword": "...", "replies": {"<message-id>": {"sender": "...", "ts": "..."}}, "updated": "..."}
```

Written by stage 07 for every genuine reply, before classification. Reply rate for a send = replies divided by delivered. A send with no file here has reply rate `null` (unknown), never 0. This folder holds subscriber data: keep it local, never ship it with this ICM.
