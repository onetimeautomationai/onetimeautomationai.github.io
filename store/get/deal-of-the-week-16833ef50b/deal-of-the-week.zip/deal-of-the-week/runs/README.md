# runs

One file per send, named `YYYY-MM-DD-city.md`, copied from `../_templates/run.md`. The `status` in the frontmatter walks: new, learn-done, sourced, drafted, qa-passed, scheduled, armed, sent. The example below is fictional and shows the filled shape, including a failed first QA pass.
