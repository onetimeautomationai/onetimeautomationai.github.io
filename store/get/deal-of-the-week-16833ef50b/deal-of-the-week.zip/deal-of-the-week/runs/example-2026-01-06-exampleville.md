---
run: 2026-01-06-exampleville
status: armed
slot: newly listed
send_id: EXAMPLE-BROADCAST-ID
---

# Run 2026-01-06 (fictional example)

## Learn
- Completed sends read: 3 (under 5, rankings are noise)
- Top pick per lever: none yet
- Levers moved this send and why: none, using defaults. V2 anchor.

## Source
- Slot: newly listed (no slot was due this send)
- City: Exampleville (next after Sampletown in rotation)
- Listing id: EX-123
- Source link (internal only): https://example.com/listing/123
- Hero feature: canyon view from the primary suite
- Fact sheet: 4 beds, 2.5 baths, 2,310 sqft, built 2018 (listing record). Asking $1,185,000 (listing record). 3 days on market (listing record). City median $1,060,000 (computed from 88 active listings, 2026-01-05). HOA $85 a month (listing remarks).

## Draft
- Tier: mid
- Version: V2
- CTA keyword: CANYON (appears nowhere else)
- Offer: photos and the address
- decision_note: Defaults, fewer than 5 completed sends.
- Subject options: (1) Deal of the week in Exampleville: Canyon Views (rejected, contains CANYON) (2) Deal of the week in Exampleville: Remodeled Home (3) Deal of the week in Exampleville: 4 Beds, $1.18M
- Body:

I'd take a home that needs nothing over a bigger one that needs everything. This week's deal is a 4-bedroom detached home in Exampleville, listed 3 days ago.

The home:
4 bedrooms, 2.5 baths
2,310 square feet
Built in 2018
HOA is $85 a month

My highlights:
• Primary suite looks out over the canyon
• Open kitchen with a large island
• Two-car garage and a flat backyard

This one's for you if:
You want a home office and a spare room without giving up a yard.
You like cooking while everyone else sits at the island.
You want newer construction without the new construction wait.

The price:
It is listed at $1,185,000, about 12% above the Exampleville median of $1,060,000, for a newer and larger home.

Reply **CANYON** and I'll send you the photos and the address.

Best,

- Sam

:: Sam Example | Example Realty | License 000000

## QA
- Lint: pass on rewrite. First pass failed, the subject contained the CTA keyword (voice-rules item 9). Fixed by choosing option 2.
- Fact check: pass, every number traced to the fact sheet. "About 12% above" recomputed: 1,185,000 / 1,060,000 = 1.118.
- Compliance C1 to C7: pass. C5 clean, lines describe features not people.
- Scores (sample scores to show the format): option 2 9/10 clear and names the home, whole email 8.7/10 plain and specific.
- Top pick: option 2

## Schedule
- Broadcast id: EXAMPLE-BROADCAST-ID
- Subject sent: Deal of the week in Exampleville: Remodeled Home
- Send time: Wednesday 2026-01-07 07:30 local, 2026-01-07T15:30:00Z
- Segment and recipient count: Weekly Deal segment, 600
- verified: yes (status scheduled, send time non-null)

## Report
- Sent to: owner@example.com
- Abort line included: yes

## Replies
- 07:52 CANYON from a subscriber: classified cta, drafted reply with photos (reply_mode draft)
- 08:10 "please unsubscribe" from another: classified complaint, flagged to owner, no reply
