# Scripts

Python 3.9 or newer, standard library only. No installs, no network, no keys.

| Script | Stage | What it does |
|---|---|---|
| `learn.py` | 01 | Ranks every lever in `logs/results.tsv` on reply rate (open rate as gate). Writes `logs/learned-metrics.json`. |
| `classify_reply.py` | 07 | Classifies one reply as complaint, personal, cta, city, or other. Strips the quoted trail first. `--selftest` runs 10 cases. |
| `send_at.py` | 05 | Next weekday and time in the owner's time zone, as UTC. Daylight-saving safe. |

Run `python3 scripts/classify_reply.py --selftest` after any edit to the opt-out list. Add a case for every false-send or missed complaint in `logs/feedback-log.md`.

To schedule recurring runs, point your scheduler at the agent's command that starts stage 01 (weekly) and stage 07 (every 10 minutes). The scheduler entry belongs to your platform. The scripts do not schedule anything.
