#!/usr/bin/env python3
"""Deterministic reply classifier. Standard library only. No model, so it cannot be talked into anything.

Usage:
  python3 scripts/classify_reply.py --config responder/active-send.json \
      --contacts responder/personal-contacts.txt --from person@example.com --text-file reply.txt
  python3 scripts/classify_reply.py --selftest

Prints JSON: {"kind": "complaint|personal|cta|city|other", "detail": ..., "warnings": [...], "delay_minutes": N, "mode": "..."}
Order of checks (first hit wins): complaint, personal, cta, city, other.
Matching uses ONLY the sender's new text (quoted trail stripped).
"""
import argparse, json, re, sys

OPT_OUT = [
    r"\bunsubscribe\b", r"\bstop (emailing|sending|texting)\b", r"\bremove me\b", r"\bspam\b",
    r"\bnot interested\b", r"\bdo not (email|contact)\b", r"\bdon'?t (email|contact)\b",
    r"\bmass email\b", r"\bout of (our |my )?budget\b", r"\btoo expensive\b", r"\bleave me alone\b",
    r"\bstop\b", r"\bharass", r"\breport (you|this)\b", r"\bhow did you get (my|our)\b",
    r"\bwrong (person|number|email)\b", r"\bnot (looking|buying)\b",
]
WROTE = re.compile(r"(?is)\bOn\s[^\n]{0,300}(?:\n[^\n]{0,300}){0,2}?\s*wrote:")
ORIG = re.compile(r"(?im)^\s*-{2,}\s*original message\s*-{2,}\s*$")
HDR = re.compile(r"(?im)^\s*from:\s.+\n\s*(sent|date):\s")


def strip_quoted(text):
    cut = len(text)
    for rx in (WROTE, ORIG, HDR):
        m = rx.search(text)
        if m:
            cut = min(cut, m.start())
    kept = [ln for ln in text[:cut].splitlines() if not ln.lstrip().startswith(">")]
    return "\n".join(kept).strip()


def word_in(word, text):
    return re.search(r"(?<![A-Za-z0-9])" + re.escape(word) + r"(?![A-Za-z0-9])", text, re.I) is not None


def load_contacts(path):
    try:
        with open(path) as f:
            return {ln.strip().lower() for ln in f if ln.strip() and not ln.startswith("#")}
    except FileNotFoundError:
        return set()


def classify(cfg, contacts, sender, raw_text):
    new = strip_quoted(raw_text)
    warnings = []
    base = {"delay_minutes": cfg.get("min_delay_minutes", 15), "mode": cfg.get("mode", "draft")}
    for rx in OPT_OUT:
        if re.search(rx, new, re.I):
            return {**base, "kind": "complaint", "detail": "matched opt-out signal", "warnings": warnings}
    if sender.strip().lower() in contacts:
        return {**base, "kind": "personal", "detail": "sender is a personal contact", "warnings": warnings}
    kw = (cfg.get("cta_keyword") or "").strip()
    subject = cfg.get("subject") or ""
    if kw and word_in(kw, subject):
        warnings.append(f"CTA keyword '{kw}' appears in the subject, keyword matching disabled for this send")
        kw = ""
    if kw and word_in(kw, new):
        return {**base, "kind": "cta", "detail": kw, "warnings": warnings}
    for city in cfg.get("cities", []):
        if word_in(city, new):
            return {**base, "kind": "city", "detail": city, "warnings": warnings}
    return {**base, "kind": "other", "detail": "no rule matched", "warnings": warnings}


def selftest():
    cfg = {"subject": "Deal of the week in Exampleville: Remodeled Home", "cta_keyword": "CANYON",
           "cities": ["Exampleville", "Sampletown"], "min_delay_minutes": 15, "mode": "draft"}
    cfg2 = dict(cfg, cta_keyword="VIEW", subject="Deal of the week in Exampleville: Big View")
    contacts = {"friend@example.com"}
    quoted = "Is this a mass email? way out of budget\n\nOn Tue, Jan 6, 2026 at 7:31 AM Agent <a@example.com>\nwrote:\n> Reply CANYON for photos"
    cases = [
        ("a@x.com", "CANYON", cfg, "cta"),
        ("a@x.com", "canyon please!", cfg, "cta"),
        ("a@x.com", "Love Sampletown, what else?", cfg, "city"),
        ("friend@example.com", "CANYON", cfg, "personal"),
        ("a@x.com", "Congrats on the listing", cfg, "other"),
        ("a@x.com", quoted, cfg, "complaint"),
        ("a@x.com", "Thanks!\n\nOn Tue, Jan 6, 2026 at 7:31 AM Agent wrote:\n> Reply CANYON for photos", cfg, "other"),
        ("a@x.com", "VIEW", cfg2, "other"),
        ("a@x.com", "please unsubscribe me, CANYON", cfg, "complaint"),
        ("a@x.com", "canyons are pretty", cfg, "other"),
    ]
    bad = 0
    for sender, text, c, want in cases:
        got = classify(c, contacts, sender, text)["kind"]
        ok = got == want
        bad += not ok
        print(("PASS" if ok else "FAIL"), want, "<-", repr(text[:40]), "got", got)
    print("selftest:", "ALL PASS" if not bad else f"{bad} FAILED")
    return 1 if bad else 0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config")
    ap.add_argument("--contacts", default="responder/personal-contacts.txt")
    ap.add_argument("--from", dest="sender")
    ap.add_argument("--text-file")
    ap.add_argument("--selftest", action="store_true")
    a = ap.parse_args()
    if a.selftest:
        return selftest()
    if not (a.config and a.sender and a.text_file):
        ap.error("--config, --from and --text-file are required")
    with open(a.config) as f:
        cfg = json.load(f)
    with open(a.text_file) as f:
        text = f.read()
    print(json.dumps(classify(cfg, load_contacts(a.contacts), a.sender, text), indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
