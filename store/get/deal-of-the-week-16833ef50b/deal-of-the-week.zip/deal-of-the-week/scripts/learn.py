#!/usr/bin/env python3
"""Rank every lever in logs/results.tsv. Standard library only.

Usage: python3 scripts/learn.py logs/results.tsv --out logs/learned-metrics.json [--min-delivered 50]

Rules:
- Only rows with status == "sent" count. Drafts and scheduled sends have no results yet.
- Rows whose subject starts with [TEST] or whose delivered < --min-delivered are excluded.
- reply_rate "null" means unknown, never zero. Rows with reply data rank above rows without.
- Within each group: higher avg reply rate first, then higher avg open rate.
  With no reply data anywhere, open rate alone decides.
"""
import argparse, csv, json, sys
from collections import defaultdict

LEVERS = ["version", "tier", "send_day", "cta_keyword", "subject_formula", "offer"]


def num(v):
    if v is None:
        return None
    v = str(v).strip()
    if v == "" or v.lower() in ("null", "none", "n/a"):
        return None
    try:
        return float(v)
    except ValueError:
        return None


def load(path, min_delivered):
    with open(path, newline="") as f:
        rows = list(csv.DictReader(f, delimiter="\t"))
    keep = []
    for r in rows:
        if (r.get("status") or "").strip().lower() != "sent":
            continue
        if (r.get("subject") or "").strip().upper().startswith("[TEST]"):
            continue
        d = num(r.get("delivered"))
        if d is None or d < min_delivered:
            continue
        keep.append(r)
    return keep


def rank(rows, lever):
    groups = defaultdict(list)
    for r in rows:
        key = (r.get(lever) or "").strip()
        if key and key.lower() != "null":
            groups[key].append(r)
    out = []
    for key, rs in groups.items():
        opens = [num(r.get("open_rate")) for r in rs if num(r.get("open_rate")) is not None]
        reps = [num(r.get("reply_rate")) for r in rs if num(r.get("reply_rate")) is not None]
        out.append({
            "key": key,
            "n": len(rs),
            "avg_open_rate": round(sum(opens) / len(opens), 2) if opens else None,
            "avg_reply_rate": round(sum(reps) / len(reps), 2) if reps else None,
        })
    out.sort(key=lambda x: (
        x["avg_reply_rate"] is not None,
        x["avg_reply_rate"] if x["avg_reply_rate"] is not None else -1,
        x["avg_open_rate"] if x["avg_open_rate"] is not None else -1,
    ), reverse=True)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("results")
    ap.add_argument("--out", default=None)
    ap.add_argument("--min-delivered", type=float, default=50)
    a = ap.parse_args()
    rows = load(a.results, a.min_delivered)
    result = {"completed_sends": len(rows), "levers": {}, "top_pick": {}}
    for lv in LEVERS:
        ranked = rank(rows, lv)
        result["levers"][lv] = ranked
        result["top_pick"][lv] = ranked[0]["key"] if ranked else None
    if len(rows) < 5:
        result["note"] = "Fewer than 5 completed sends. Treat rankings as noise and use defaults."
    text = json.dumps(result, indent=2)
    if a.out:
        with open(a.out, "w") as f:
            f.write(text + "\n")
    print(text)


if __name__ == "__main__":
    sys.exit(main())
