#!/usr/bin/env python3
"""Print the next occurrence of a weekday and time in a time zone, as a UTC ISO timestamp.

Usage: python3 scripts/send_at.py --tz America/Chicago --weekday Wednesday --time 07:30
Handles daylight saving, so 7:30 AM local is right all year. Standard library only (Python 3.9+).
"""
import argparse
from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo

DAYS = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tz", required=True)
    ap.add_argument("--weekday", required=True)
    ap.add_argument("--time", required=True, help="HH:MM, 24-hour")
    a = ap.parse_args()
    tz = ZoneInfo(a.tz)
    hh, mm = (int(x) for x in a.time.split(":"))
    now = datetime.now(tz)
    wd = DAYS.index(a.weekday.strip().lower())
    target = (now + timedelta(days=(wd - now.weekday()) % 7)).replace(hour=hh, minute=mm, second=0, microsecond=0)
    if target <= now:
        target += timedelta(days=7)
    print(target.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"))


if __name__ == "__main__":
    main()
