# Setup questionnaire

Ask a few at a time. Write each answer into the file named. Do not move on until every `{{` in `_shared/owner-profile.md` is gone.

## 1. Identity and voice (`_shared/owner-profile.md`, `_shared/signature.md`)
1. What name do you sign with, and what are your full name and brokerage?
2. Does your state require a license number in marketing? What is the line?
3. Which address do you send from, and which address should confirmation reports go to?
4. Which links go in your signature (for example a video, a buyer guide, open houses)? Label and URL for each, two at most.
5. Read `_shared/voice-rules.md` with me. For each rule: keep, change, or drop? (Log changes in `logs/feedback-log.md`.)
6. Give me three emails you sent that got replies, or three lines in your own words about a home you loved. I use them to write your first hooks.

## 2. Markets (`_shared/owner-profile.md`, `_shared/city-profiles.md`, `responder/city-blurbs.json`)
7. Which cities, in what order, one per send?
8. What price bands count as entry, mid, and luxury in each? If you do not know, I compute medians from the listing source and you correct them.
9. For each city, one true, positive line about the place for auto-replies (not about the people who live there).

## 3. Schedule and slots (`_shared/owner-profile.md`)
10. Which day and time should the email send, and what is your time zone?
11. Do you want the new construction slot, the price reduction slot, and an off-market cap? What cadence?
12. How many days before a listing can repeat? (Default 10.)

## 4. Safety (`_shared/owner-profile.md`, `_shared/compliance-and-safety.md`, `responder/personal-contacts.txt`)
13. Confirm both modes stay on `draft` for now. Who approves, and how do I reach you fast on a failure?
14. Who are the people who must never get an auto-reply (family, friends, peers, past clients)? Email for each.
15. Does your brokerage or state have rules for email marketing I should add to `compliance-and-safety.md`? Who is the compliance contact?

## 5. Tools (`_shared/adapters.md`)
16. For each of the five capabilities (listing source, email platform, mailbox, scheduler, notifier): what do you use, and can I call it from here? If not, we use a manual paste step for now.
17. Which segment is the audience, and which template id formats the email?

## Finish
Run `python3 scripts/classify_reply.py --selftest`, copy `responder/active-send.example.json` aside for stage 06, run one cycle in `draft` mode end to end, and ask the owner to approve the first draft before anything is scheduled.
