# 01_learn: open the run and read what the data favors

One job: start a run file, and decide which levers to move this week from real results.

## Inputs
- Working: `../../_templates/run.md` (copy to `../../runs/YYYY-MM-DD-<city-tbd>.md`)
- Reference: `../../logs/results.tsv`, `../../logs/feedback-log.md`
- Tool: `../../scripts/learn.py`

Do NOT load: voice rules, variations, listing data, replies.

## Process
1. If `_shared/PAUSED` exists, stop and tell the owner.
2. Refresh `logs/results.tsv` from the email platform's per-broadcast stats for every send in the log (delivered, open rate, click rate, unsubscribes). Reply counts come from `responder/sends-history/`. Never type a reply rate by hand. If no reply history exists for a send, the value is the literal `null`, never `0`.
3. Run `python3 scripts/learn.py logs/results.tsv --out logs/learned-metrics.json`. It ranks each lever (version, tier, send day, CTA keyword, subject formula, offer) on reply rate, with open rate as the gate and the pre-reply-data fallback.
4. Read `logs/feedback-log.md` for owner corrections since the last run.
5. In the run file's `## Learn` section write: the top pick per lever, the lever or levers you will move this send, and one line of why. Fewer than 5 completed sends means no ranking yet: say so and use the defaults in `_shared/variations.md`.

## Outputs
- A new run file with `status: learn-done` and a filled `## Learn` section.

## Human check
None required. The owner may read `## Learn` and override a lever.
