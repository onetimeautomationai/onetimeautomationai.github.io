# 02_source: pick one verified listing

One job: choose the slot, the city, and one listing, and verify every fact you will use.

## Inputs
- Working: the run file (`## Learn` filled)
- Reference: `../../_shared/owner-profile.md` (cities, slots, windows), `../../_shared/adapters.md`, `../../_shared/compliance-and-safety.md` (C1 to C3), `../../logs/featured-log.md`

Do NOT load: voice rules, variations, results.

## Process
1. **Pick the slot** by priority, using the last rows of `featured-log.md` and the cadences in the owner profile (defaults shown: every 3rd and every 4th, so look back 2 and 3 rows):
   1. New construction is due if none of the last 2 sends was new construction.
   2. Price reduction is due if none of the last 3 was a price reduction. New construction wins a collision.
   3. Off-market is allowed only if none of the last 3 sends was off-market, and only if no fresh listing qualifies.
   4. Otherwise: newly listed, 7 days or fewer on market.
2. **Pick the city.** Rotation order is in the owner profile. Resume after the last city in the log. If the city has nothing qualifying, rotate to the next, once. New construction is not tied to the city rotation, log the real city. The next normal send resumes the loop after the last non-slot city.
3. **Search** with the listing search capability: one source call, one city. Newly listed: status active, 7 days or fewer. Off-market and price reduction: the portal fallback, one call. New construction: the builder directory inside the owner's price band, quick move-in homes, price cuts, and builder incentives first. Check the count is small and every row is in the city (adapters.md gotchas).
4. **Exclude** anything featured in the last 10 days or that the owner already vetoed.
5. **Score and pick one.** Prefer: off-market when allowed, biggest verified price cut (price reduction slot, tiebreak by percent of list price, under $20K rotate one city once, then fall back to the default slot), then value against the city median, then photogenic.
6. **Deep read, one detail call.** Read the full remarks, features, HOA, and for a price reduction the price history. Confirm original price, current price, and reduction date. Older than 30 days or missing history means take the next listing.
7. If nothing in the slot qualifies after one rotation, fall back to the market pulse send (V10) instead of featuring a stale listing.
8. Write `## Source` in the run file: slot, city, listing id, source link (internal only, never goes in the email), the fact sheet (every number with where it came from), and the hero feature.

## Outputs
- `## Source` filled. Rename the run file to `YYYY-MM-DD-<city>.md` now that the city is known. Set `status: sourced`.

## Human check
The owner may veto the listing. A veto is logged in `feedback-log.md` and the stage reruns once with that listing excluded.
