# 03_write: draft the subject and the email

One job: turn the verified fact sheet into one email in the owner's voice.

## Inputs
- Working: the run file (`## Learn`, `## Source`)
- Reference: `../../_shared/voice-rules.md`, `../../_shared/variations.md`, `../../_shared/subject-patterns.md`, `../../_shared/price-tier-language.md`, `../../_shared/city-profiles.md`, `../../_shared/signature.md`

Do NOT load: logs other than the featured-log rows already read, replies, platform docs.

## Process
1. **Tier.** Classify the price against the city profile. If the profile is over 90 days old, recompute the median from the listing source first.
2. **Version.** Choose by signal (`variations.md` table), apply the cooldown (never the same version twice in a row), and apply the lever the learning loop favored, unless `## Learn` says otherwise.
3. **CTA keyword.** A main feature of the home, one word, absent from the subject and the body (voice-rules items 9 to 11). Reward is photos, the address, or details.
4. **Subject.** Write 5 options in the locked format. Keep the best 2 to 3 for the owner. Each scores at the subject floor or better at stage 04.
5. **Body.** Write it in the chosen version's shape. First line is the first-person hook handing off to the deal. Real numbers only, each traceable to the fact sheet. State the property type. Open the full description's strongest desire lever.
6. **Signature** exactly from `signature.md`.
7. Write `## Draft`: tier, version, CTA keyword and the offer, subject options, the body, and a one-line `decision_note` (which levers moved and why, from `## Learn`).

## Outputs
- `## Draft` filled. Set `status: drafted`.

## Human check
None yet. The owner sees the draft after QA.
