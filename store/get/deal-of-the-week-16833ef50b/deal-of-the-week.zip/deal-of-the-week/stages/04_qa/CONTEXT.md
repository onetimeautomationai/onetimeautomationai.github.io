# 04_qa: lint, fact-check, compliance, score

One job: prove the draft is true, on voice, and safe before anyone sees it.

## Inputs
- Working: the run file (`## Source` fact sheet, `## Draft`)
- Reference: `../../_shared/voice-rules.md`, `../../_shared/compliance-and-safety.md`, `../../_shared/owner-profile.md` (score floors)

Do NOT load: logs, replies. If your platform can spawn a separate reader, give it only the draft and the two reference files, so the scoring is not anchored on the writer's reasoning.

## Process
1. **Lint.** Check mechanically: no em dash, no banned AI tell from voice-rules item 17, no greeting, exactly one bold element and it is the CTA keyword, the CTA keyword appears once in the body and never in the subject, subject at or under 45 characters, no street address, no link in the body, property type stated, nothing after the CTA but the signature.
2. **Fact check.** Every number and claim in the draft traces to a line in the fact sheet. Price cut math recomputed. Status word matches compliance C3. Anything untraceable is removed.
3. **Compliance.** Walk C1 to C7. Pay attention to C5 (fair housing) on every `This one's for you if` line.
4. **Voice pass.** Read it as the owner would say it out loud. Cut filler. No volunteered promises (S10).
5. **Score.** Rate each subject option and the whole email out of 10 with one sentence of why. Subjects shown to the owner must meet the subject floor. The whole assembled email must meet the email floor. Under the floor: rewrite and rerun this stage, once. Still under: tell the owner what is blocking and stop.
6. Write `## QA`: lint result, fact-check result, compliance result, scores, top pick, any rewrite made.

## Outputs
- `## QA` filled with passing scores. Set `status: qa-passed`.

## Human check
Show the owner the top pick with its score. They may choose another option or edit the text. Re-run steps 1 to 3 on any edit.
