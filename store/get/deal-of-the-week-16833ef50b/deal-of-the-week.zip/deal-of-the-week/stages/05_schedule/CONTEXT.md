# 05_schedule: create the broadcast, set the time, verify

One job: get the approved email into the email platform as a verified scheduled broadcast. A created broadcast is not a scheduled one.

## Inputs
- Working: the run file (`## Draft`, `## QA`)
- Reference: `../../_shared/owner-profile.md` (send day and time, modes, segment), `../../_shared/adapters.md` (email platform row and gotchas), `../../_shared/compliance-and-safety.md` (S1 to S3, C6)
- Tool: `../../scripts/send_at.py`

Do NOT load: sourcing data, voice rules.

## Process
1. **Mode gate.** If `broadcast_mode` is `draft`, create the broadcast as a draft, then stop and ask the owner to approve it. Only continue on a clear yes. If `auto_schedule`, continue.
2. **Compute the send time:** `python3 scripts/send_at.py --tz <owner time zone> --weekday <send day> --time <HH:MM>`. It prints the UTC timestamp and handles daylight time. Never hard-code an offset.
3. **Create** the broadcast with the chosen subject, the body (text with line breaks only, no inline font size), the owner's template id, and the named audience segment. Capture the broadcast id.
4. **Set the send time** with a second call. Do not rely on the create call to schedule.
5. **Verify.** Read the response: status must say scheduled and the send time must be non-null. Read the recipient count for the segment.
6. **Hard failure.** If verification fails: notify the owner with the broadcast id and the error, do not send the report, do not log success, delete the broadcast if it cannot be fixed.
7. Write `## Schedule`: broadcast id, subject sent, send time (owner's local and UTC), segment, recipient count, `verified: yes`.

## Outputs
- `## Schedule` filled with `verified: yes`. Set `status: scheduled`.

## Human check
The owner approves in `draft` mode (step 1). In every mode the owner has the abort window until send time. Abort = delete the broadcast and confirm it is gone.
