# 06_report-arm: confirm to the owner, arm the reply responder

One job: tell the owner exactly what will go out and when, and give stage 07 the exact subject and keyword that went out.

## Inputs
- Working: the run file (`## Draft`, `## Schedule`, `## Learn`)
- Reference: `../../responder/active-send.example.json`, `../../logs/learned-metrics.json`, `../../_shared/owner-profile.md`

Do NOT load: voice rules, sourcing.

## Process
1. **Arm first.** Copy `responder/active-send.example.json` to `responder/active-send.json` and fill every field from what actually went into the broadcast: send id, date, EXACT subject, EXACT CTA keyword read from the body, the listing link the reply will send, a short listing label, the cities, `mode` from `reply_mode`, `min_delay_minutes`, plus `version`, `offer`, and `decision_note`. Then empty `responder/processed-ids.txt` (a new send is a fresh reply window). Never carry a subject or keyword over from the previous send. Never assume a keyword.
2. **Confirmation report** to the report-to address. It contains: the featured listing and its source link, the broadcast link in the email platform, the exact subject, the version used, the recipient count and segment name, status `scheduled`, the send time, and an abort line: "Reply ABORT and I'll cancel it, or unschedule it here: <broadcast link>". Build the link from what the platform's API returns, never by guessing a URL pattern.
3. **Evaluation and decision block** appended to the same report: what was evaluated (prior completed sends), the current leaderboard from `learned-metrics.json`, this email's template (version, offer, tier, CTA), and the decision and why. Use real numbers. If any section would be empty or a placeholder, stop and fix the order of the stages instead of sending a blank block.
4. **Site link.** If the listing has a public detail link, copy it verbatim. If it does not, write "No public site link available for this listing" and the reply engine falls back to sending the photos by hand. Never invent a link.
5. Write `## Report`: sent time, who it went to, abort instruction included.

## Outputs
- `responder/active-send.json` written, `## Report` filled. Set `status: armed`.

## Human check
The owner reads the report and can abort until send time.

## Re-arm rule (S8)
Any time the broadcast is re-sent, edited, or sent early or late, or the owner changes the subject or keyword, repeat step 1 in the same step. A stale `active-send.json` makes the responder blind to every reply.
