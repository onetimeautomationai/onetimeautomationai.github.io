# 07_replies: answer replies by rule, record every one

One job: for each new genuine reply to the current send, record it, classify it with code, and act. Runs on a timer (every 10 minutes) while the last send is under 7 days old, and does nothing otherwise.

## Inputs
- Working: new replies in the mailbox to the current send's subject
- Reference: `../../responder/active-send.json`, `../../responder/personal-contacts.txt`, `../../responder/city-blurbs.json`, `../../_shared/signature.md`, `../../_shared/compliance-and-safety.md` (S4 to S10)
- Tool: `../../scripts/classify_reply.py`

Do NOT load: voice rules, sourcing, variations.

## Process
1. If `_shared/PAUSED` exists or `active-send.json` is missing or older than 7 days, exit silently.
2. List replies to the current subject. Skip ones whose message id is already in `responder/processed-ids.txt`. Skip auto-responders (out of office, delivery failure).
3. **Record before classifying.** Append each genuine reply to `responder/sends-history/<send_id>.json` (message id, sender, timestamp). This file is never cleared. It is what makes reply rate computable.
4. **Classify** with `python3 scripts/classify_reply.py --config responder/active-send.json --contacts responder/personal-contacts.txt --from <sender> --text-file <reply text file>`. Obey the `kind` it prints. Do not override it with judgment.
5. **Act by kind:**

| kind | Action |
|---|---|
| `complaint` | Flag loudly to the owner "do not auto-send", with the reply text. Never answer. |
| `personal` | Flag "respond personally". Never auto-answer, even if they typed the keyword. |
| `cta` | Wait `min_delay_minutes`, then send: "Here's the full photo set and details: <listing link>. Let me know what you think." plus the signature. No link available: save a draft for the owner to attach photos by hand. |
| `city` | Wait `min_delay_minutes`, then send the city compliment from `city-blurbs.json`, an offer to set up a custom listing alert (average pricing unless they name a price), and one question: "are you just comparing prices, or looking to make a move?" Add a task for the owner to set up the alert and send that city's listings. |
| `other` | Flag only. Never answer (a peer saying "Congrats" gets nothing automatic). |

6. **Mode.** `reply_mode: draft` saves a draft reply for the owner instead of sending. `auto_send` sends. Switching is the owner's explicit act, only after they have reviewed one full batch of drafts (S1).
7. **Reply format.** HTML, threaded into the recipient's thread (References and In-Reply-To chain from their reply back to the original), with their message quoted below in the mail client's style, so it looks exactly like the owner replied by hand. Apply the real-estate label so the owner's inbox rules treat the thread as handled. Before saving or sending, check the thread for an unsent draft or a newer sent reply (S9).
8. Append the message id to `processed-ids.txt`. Add one line per action to the run file's `## Replies`.

## Outputs
- Rows in `responder/sends-history/<send_id>.json`, replies sent or drafted or flagged, `## Replies` log.

## Human check
Every flag goes to the owner through the notifier. The first batch in `draft` mode is the owner's review before `auto_send`.
