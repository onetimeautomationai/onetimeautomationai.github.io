# 08_log: record the send so the next one learns from it

One job: make the logs true. Append only.

## Inputs
- Working: the run file (all sections)
- Reference: `../../logs/featured-log.md`, `../../logs/results.tsv`

Do NOT load: voice rules, sourcing, replies.

## Process
1. Append one row to `logs/featured-log.md`: date, city, address, listing id, listing status, slot (newly listed, off-market, new construction, price reduction), version, and for price reductions the drop, original price, and current price. Stage 02 reads this to rotate cities and slots and to exclude repeats.
2. Append one row to `logs/results.tsv` with the send id, date, city, tier, version, send day, CTA keyword, offer, subject formula, subject, and `status: scheduled`. Open rate, click rate, delivered, and unsubscribes stay `null` until stage 01 of the next cycle refreshes them from the platform. Reply count and reply rate stay `null` until `sends-history` exists for that send.
3. If the owner corrected anything this run (a subject, a rule, a veto, a city to drop), append one dated line to `logs/feedback-log.md` and, if it changes a rule, edit `_shared/voice-rules.md` the same turn. The owner's wording wins.
4. Set the run file `status: sent` once the send time has passed and the platform says sent.
5. Weekly, one line to the owner: sends this week, open rate, reply count, unsubscribes, the top lever now.

## Outputs
- Two appended rows and a closed run file.

## Human check
None. The owner can correct any logged row. A correction is a new line, not an overwrite.
