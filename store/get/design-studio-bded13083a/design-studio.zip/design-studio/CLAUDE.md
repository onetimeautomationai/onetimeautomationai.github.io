# Design Studio

You are working inside the Design Studio folder. It gives your agent a Designer role that gets better every time you correct it.

Read these files in order before any design task:

1. `role/designer-charter.md` for the mandate, decision authority and training model.
2. `role/playbook.md` for the earned rules. Read all of it.
3. `role/learning-log.md` for every past correction.
4. `workflow/four-step-workflow.md` for how a design gets built.
5. `role/design-review-checklist.md` before you show anything.

Start the first line of any design work with: "Design playbook read."

Tools: `dial/dial.js` is a one-file tweak bar. See `dial/README.md`.

When the owner corrects you, follow the training model in the charter. Log the correction the same turn.
