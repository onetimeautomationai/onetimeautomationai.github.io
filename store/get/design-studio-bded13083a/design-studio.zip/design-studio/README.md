# Design Studio

A Designer role for your AI agent, plus a tweak bar for any web page.

What is inside:

- `CLAUDE.md`: the entry file your agent reads first.
- `role/designer-charter.md`: mandate, decision authority, training model.
- `role/playbook.md`: 30 generic design rules to start from. It grows as you correct the agent.
- `role/design-review-checklist.md`: run it before showing anything.
- `role/learning-log.md`: an empty log. Every correction goes here.
- `workflow/four-step-workflow.md`: taste, tools, direction, dial.
- `dial/dial.js`: a one-file tweak bar with 112 controls and no dependencies.
- `dial/demo.html`: a plain sample landing page to try the dial on.
- `dial/README.md`: how to attach the dial.

## Setup

1. Copy this whole folder into your agent workspace.
2. Tell your agent: "Read CLAUDE.md in the design-studio folder and act as the Designer from now on."
3. Give it a small design task. Look at the result, then correct it in plain words.
4. Confirm the agent wrote your correction to `role/learning-log.md`. If it did not, tell it to.
5. To use the dial, add one script tag to any page: `<script src="dial.js"></script>`. Open `dial/demo.html` first to see it work.

## Requirements

An AI agent that reads local files and can take screenshots, or can at least open a page and report what it sees. The dial needs only a modern browser.
