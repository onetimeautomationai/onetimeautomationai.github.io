# The Dial

A one-file tweak bar for any web page. It has 112 controls for spacing, type, color, shape, depth and motion. It has no dependencies and works from a local file.

## Attach it

Put `dial.js` next to your page and add one tag before the closing body tag:

```html
<script src="dial.js"></script>
```

Open the page. Press D to show or hide the panel.

## How it behaves

- Every control starts at the value your page already has. Nothing changes until you touch a control.
- If the dial fails for any reason, your page still renders as you wrote it.
- Your settings are remembered in the browser for that page.
- Use the search box to find a control. Use "Surprise me" for a random pass.
- Export gives you the CSS for the values you changed. Paste it at the end of your page styles.

## Before you publish

Remove the script tag. The dial is a design tool and does not belong on a live page.

## Try it

Open `demo.html` in a browser. It is a plain sample page with no client content.
