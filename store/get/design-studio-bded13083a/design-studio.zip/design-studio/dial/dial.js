/*! T4 Dial: a drop-in tweak bar for any landing page.
 * Attach with one tag: <script src="dial.js"></script>
 * No dependencies. Works from file://. Press D to show or hide.
 * Default state changes nothing: every control starts at "authored" and only
 * emits CSS once it is touched. If the dial fails, the page renders as authored.
 */
(function () {
  'use strict';
  if (window.__dial) return;
  var D = document, R = D.documentElement, W = window;

  /* ---------- hash params (test harness + embed) ---------- */
  var HP = {};
  (location.hash || '').slice(1).split('&').forEach(function (kv) {
    if (!kv) return; var i = kv.indexOf('='), k = i < 0 ? kv : kv.slice(0, i), v = i < 0 ? '1' : kv.slice(i + 1);
    try { HP[k] = decodeURIComponent(v); } catch (e) { HP[k] = v; }
  });
  var EMBED = 'dial-embed' in HP;
  var KEY = 'dial:v1:' + location.pathname;
  var ERRORS = [];
  W.addEventListener('error', function (e) { ERRORS.push(String(e.message || e)); });

  function store(val) {
    try { if (val === undefined) return JSON.parse(localStorage.getItem(KEY) || 'null'); localStorage.setItem(KEY, JSON.stringify(val)); } catch (e) { return null; }
  }
  function cs(el) { return getComputedStyle(el); }
  function clamp(x, a, b) { return Math.max(a, Math.min(b, x)); }
  function px(s) { return parseFloat(s) || 0; }

  /* ---------- color helpers ---------- */
  function parseColor(s) {
    if (!s) return null; s = String(s).trim();
    var m = s.match(/^rgba?\(([^)]+)\)$/);
    if (m) { var p = m[1].split(/[\s,\/]+/).filter(Boolean).map(parseFloat); return [p[0], p[1], p[2], p[3] === undefined ? 1 : p[3]]; }
    m = s.match(/^#([0-9a-f]{3,8})$/i);
    if (m) { var h = m[1]; if (h.length === 3) h = h.replace(/./g, '$&$&'); return [parseInt(h.substr(0, 2), 16), parseInt(h.substr(2, 2), 16), parseInt(h.substr(4, 2), 16), 1]; }
    return null;
  }
  function opaque(s) { var c = parseColor(s); return !!c && c[3] > 0.9; }
  function lum(s) {
    var c = Array.isArray(s) ? s : parseColor(s); if (!c) return 1;
    var f = function (v) { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); };
    return 0.2126 * f(c[0]) + 0.7152 * f(c[1]) + 0.0722 * f(c[2]);
  }
  function ratio(a, b) { var x = lum(a), y = lum(b); return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05); }
  function toHex(s) { var c = parseColor(s); if (!c) return '#000000'; return '#' + c.slice(0, 3).map(function (v) { return ('0' + Math.round(v).toString(16)).slice(-2); }).join(''); }
  function rgbList(s) { var c = parseColor(s) || [20, 26, 40]; return c.slice(0, 3).map(Math.round).join(','); }
  var probe;
  function normColor(v) {
    if (!probe) { probe = D.createElement('i'); probe.style.display = 'none'; D.body.appendChild(probe); }
    probe.style.color = ''; probe.style.color = v; return probe.style.color ? cs(probe).color : null;
  }

  /* ---------- fonts ---------- */
  var GF = [['Inter', 100, 900], ['Figtree', 300, 900], ['Manrope', 200, 800], ['DM Sans', 100, 1000], ['Plus Jakarta Sans', 200, 800], ['Outfit', 100, 900], ['Sora', 100, 800], ['Space Grotesk', 300, 700], ['Bricolage Grotesque', 200, 800], ['Instrument Sans', 400, 700], ['Onest', 100, 900], ['Geist', 100, 900], ['Schibsted Grotesk', 400, 900], ['Hanken Grotesk', 100, 900], ['Urbanist', 100, 900], ['Work Sans', 100, 900], ['IBM Plex Sans', 100, 700], ['Archivo', 100, 900], ['Public Sans', 100, 900], ['Source Sans 3', 200, 900], ['Lexend', 100, 900], ['Rubik', 300, 900], ['Nunito Sans', 200, 1000], ['Karla', 200, 800], ['Familjen Grotesk', 400, 700], ['Albert Sans', 100, 900], ['Red Hat Display', 300, 900], ['Epilogue', 100, 900], ['Unbounded', 200, 900], ['Syne', 400, 800]];
  var SYSF = { 'System UI (SF)': 'system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif', 'Helvetica Neue': '"Helvetica Neue",Helvetica,Arial,sans-serif', 'Avenir Next': '"Avenir Next",Avenir,"Segoe UI",sans-serif', 'Arial': 'Arial,"Helvetica Neue",sans-serif', 'Verdana': 'Verdana,Geneva,sans-serif' };
  var FALL = ',-apple-system,BlinkMacSystemFont,"Helvetica Neue",Arial,sans-serif';
  var PAIRS = [['Bricolage Grotesque', 'Figtree'], ['Space Grotesk', 'Inter'], ['Syne', 'Manrope'], ['Unbounded', 'DM Sans'], ['Sora', 'Instrument Sans'], ['Schibsted Grotesk', 'Source Sans 3'], ['Familjen Grotesk', 'Hanken Grotesk'], ['Epilogue', 'Work Sans'], ['Red Hat Display', 'Public Sans'], ['Archivo', 'Karla'], ['Outfit', 'Onest'], ['Geist', 'Geist'], ['Plus Jakarta Sans', 'Albert Sans'], ['Urbanist', 'Lexend'], ['Manrope', 'Inter']];
  var loadedFonts = {};
  function fontStack(name) { return SYSF[name] || ('"' + name + '"' + FALL); }
  function loadFont(name) {
    if (!name || SYSF[name] || loadedFonts[name]) return;
    var f = GF.filter(function (g) { return g[0] === name; })[0]; if (!f) return;
    loadedFonts[name] = 1;
    var ws = [300, 400, 500, 600, 700, 800, 900].filter(function (w) { return w >= f[1] && w <= f[2]; });
    var l = D.createElement('link'); l.rel = 'stylesheet';
    l.href = 'https://fonts.googleapis.com/css2?family=' + name.replace(/ /g, '+') + ':wght@' + ws.join(';') + '&display=swap';
    D.head.appendChild(l);
  }
  var ACCENTS = [['Coral red', '#ef5b4c'], ['Sunny yellow', '#f4c20d'], ['Orange', '#f07c23'], ['Crimson', '#c0392b'], ['Blue', '#2563eb']];

  /* ---------- measurement (authored values) ---------- */
  var M = { tok: {} }, SECS = [], ORIG_ORDER = [], DATA = new Map();
  var VARS = ['fs', 'pt', 'pb', 'mt', 'rg', 'cg', 'bpy', 'bpx', 'bfs', 'c', 'bgy'];
  function mark(el, n, v) { el.setAttribute('data-dial-' + n, v === undefined ? '' : v); }
  function inHost(el) { return el.closest && el.closest('#dial-host,#dial-layer,#dial-svgfx'); }
  function setVar(el, k, val) { var d = DATA.get(el) || {}; d[k] = val; DATA.set(el, d); el.style.setProperty('--dial-' + k, val); }

  function effBg(el) {
    for (var e = el; e && e.nodeType === 1; e = e.parentElement) { var b = cs(e).backgroundColor; if (opaque(b)) return b; }
    return 'rgb(255, 255, 255)';
  }

  function scan() {
    var body = D.body, all = [].slice.call(body.querySelectorAll('*')).filter(function (e) {
      return !inHost(e) && !/^(SCRIPT|STYLE|LINK|META|BR|NOSCRIPT|TEMPLATE)$/.test(e.tagName) && !(e.closest('svg') && e.tagName.toLowerCase() !== 'svg');
    });
    var bs = cs(body);
    M.bg = opaque(bs.backgroundColor) ? bs.backgroundColor : (opaque(cs(R).backgroundColor) ? cs(R).backgroundColor : 'rgb(255, 255, 255)');
    M.ink = bs.color;
    var h1 = D.querySelector('h1') || D.querySelector('h2');
    M.hFam = h1 ? cs(h1).fontFamily : bs.fontFamily;
    var p1 = D.querySelector('p') || body; M.bFam = cs(p1).fontFamily;
    if (h1) { var hs = cs(h1); M.hWeight = parseInt(hs.fontWeight, 10) || 700; M.hTrack = hs.letterSpacing === 'normal' ? 0 : +(px(hs.letterSpacing) / px(hs.fontSize)).toFixed(3); M.hLead = hs.lineHeight === 'normal' ? 1.15 : +(px(hs.lineHeight) / px(hs.fontSize)).toFixed(2); }
    var ps = cs(p1); M.bLead = ps.lineHeight === 'normal' ? 1.5 : +(px(ps.lineHeight) / px(ps.fontSize)).toFixed(2);
    M.para = +(px(ps.marginBottom) / px(ps.fontSize)).toFixed(2); M.bWeight = parseInt(ps.fontWeight, 10) || 400;

    /* buttons */
    var btns = all.filter(function (e) {
      if (!e.matches('a.btn,button,[class*="btn"],[class*="button"],input[type=submit],input[type=button],[role=button]')) return false;
      var s = cs(e), r = e.getBoundingClientRect();
      return r.height < 140 && r.height > 0 || s.display === 'none' ? (opaque(s.backgroundColor) || px(s.borderTopWidth) > 0 || e.tagName === 'BUTTON') : false;
    });
    btns.forEach(function (b) {
      mark(b, 'btn'); var s = cs(b);
      setVar(b, 'bpy', s.paddingTop); setVar(b, 'bpx', s.paddingLeft); setVar(b, 'bfs', s.fontSize);
      [].forEach.call(b.querySelectorAll('svg,[class*="ar"],[class*="arrow"],[class*="icon"]'), function (a) { mark(a, 'btnarrow'); mark(b, 'hasarrow'); });
    });
    M.hasArrow = !!D.querySelector('[data-dial-hasarrow]');
    var accBtn = btns.filter(function (b) { return opaque(cs(b).backgroundColor); })[0];
    M.accent = accBtn ? cs(accBtn).backgroundColor : 'rgb(37, 92, 142)';
    M.rBtn = accBtn ? Math.min(60, px(cs(accBtn).borderTopLeftRadius)) : 8;

    /* links */
    all.forEach(function (e) { if (e.tagName === 'A' && !e.hasAttribute('data-dial-btn')) mark(e, 'link'); });

    /* sections */
    var secs = all.filter(function (e) { return e.tagName === 'SECTION' && !e.parentElement.closest('section'); });
    if (!secs.length) {
      var root = D.querySelector('main') || body;
      secs = [].slice.call(root.children).filter(function (e) { return !inHost(e) && !/^(HEADER|FOOTER|NAV|SCRIPT|STYLE)$/.test(e.tagName) && e.getBoundingClientRect().height > 200; });
    }
    SECS = secs.map(function (s, i) {
      mark(s, 'sec', i); var cs_ = cs(s);
      setVar(s, 'pt', cs_.paddingTop); setVar(s, 'pb', cs_.paddingBottom); setVar(s, 'mt', cs_.marginTop);
      if (s.previousElementSibling && secs.indexOf(s.previousElementSibling) > -1) mark(s, 'secnext');
      var h = s.querySelector('h2') || s.querySelector('h3');
      var nm = s.id ? s.id.replace(/[-_]+/g, ' ') : (h ? h.textContent.trim() : (s.className || s.tagName.toLowerCase()));
      nm = nm.charAt(0).toUpperCase() + nm.slice(1); if (nm.length > 26) nm = nm.slice(0, 25) + '…';
      return { el: s, id: 's' + i, name: nm, parent: s.parentElement };
    });
    ORIG_ORDER = SECS.map(function (s) { return s.id; });
    var hero = secs.filter(function (s) { return /hero/i.test(s.className + ' ' + s.id); })[0] || secs[0];
    if (hero) { mark(hero, 'hero'); SECS.forEach(function (s) { if (s.el === hero) s.name = 'Hero'; }); }
    SECS.forEach(function (s) {
      if (s.el === hero) return; var h = s.el.querySelector('h2') || s.el.querySelector('h3');
      if (h) { mark(h, 'sech'); h.setAttribute('data-dial-label', s.name); }
    });

    /* header */
    var hdr = D.querySelector('header') || D.querySelector('body > nav'); if (hdr && !inHost(hdr)) mark(hdr, 'hdr');

    /* wrap containers */
    var wcount = {};
    all.forEach(function (e) {
      var s = cs(e); if (s.maxWidth === 'none' || s.maxWidth.indexOf('px') < 0) return;
      var r = e.getBoundingClientRect(); if (r.width < 560) return;
      if (Math.abs(px(s.marginLeft) - px(s.marginRight)) < 1 && (px(s.marginLeft) > 0 || r.width >= W.innerWidth - 1) && px(s.maxWidth) >= 700) {
        mark(e, 'wrap'); wcount[s.maxWidth] = (wcount[s.maxWidth] || 0) + 1; if (M.gutter === undefined) M.gutter = px(s.paddingLeft);
      }
    });
    var wk = Object.keys(wcount).sort(function (a, b) { return wcount[b] - wcount[a]; })[0];
    M.wrapW = wk ? px(wk) : 1160; if (M.gutter === undefined) M.gutter = 24;

    /* images */
    all.forEach(function (e) {
      var r = e.getBoundingClientRect(), s = cs(e);
      var logo = /logo/i.test((e.getAttribute('src') || '') + ' ' + (e.getAttribute('alt') || '') + ' ' + e.className) || e.closest('header,footer,[data-dial-hdr]');
      if (e.tagName === 'IMG' && r.width >= 140 && !logo) { mark(e, 'img'); if (e.parentElement) mark(e.parentElement, 'imgwrap'); }
      if (e.tagName !== 'IMG' && s.backgroundImage.indexOf('url(') > -1 && r.width >= 140 && !logo) {
        mark(e, 'bgimg'); var ys = s.backgroundPositionY.split(','); setVar(e, 'bgy', ys[ys.length - 1].trim());
      }
    });
    var firstImg = D.querySelector('[data-dial-img],[data-dial-bgimg]');
    M.rImg = firstImg ? px(cs(firstImg).borderTopLeftRadius) : 0;

    /* frames */
    all.forEach(function (e) {
      if (/^(IMG|SECTION|MAIN|BODY)$/.test(e.tagName) || e.hasAttribute('data-dial-btn')) return;
      var s = cs(e), r = e.getBoundingClientRect(); if (r.width < 140) return;
      var isTag = /^(FIGURE|VIDEO|IFRAME)$/.test(e.tagName);
      var clip = (s.overflow.indexOf('hidden') > -1 || s.overflow.indexOf('clip') > -1) && px(s.borderTopLeftRadius) > 0;
      var media = [].slice.call(e.querySelectorAll('img,video,iframe,[data-dial-bgimg]')).some(function (m) { return m.getBoundingClientRect().width >= r.width * 0.85; });
      if ((clip && media) || (isTag && (media || e.tagName !== 'FIGURE'))) mark(e, 'frame');
    });
    var fr = D.querySelector('[data-dial-frame]'); M.rFrame = fr ? px(cs(fr).borderTopLeftRadius) : 0;

    /* cards */
    all.forEach(function (e) {
      if (/^(SECTION|MAIN|HEADER|FOOTER|BODY|IMG|INPUT|TEXTAREA|SELECT|BUTTON|A|LABEL|SPAN|B|STRONG|SMALL|LI|P|H1|H2|H3|H4|LEGEND|SVG)$/i.test(e.tagName)) return;
      if (e.closest('header,footer,[data-dial-btn]') || e.hasAttribute('data-dial-frame') || e.hasAttribute('data-dial-sec') || e.hasAttribute('data-dial-wrap')) return;
      var s = cs(e), r = e.getBoundingClientRect();
      if (r.width < 160 || r.height < 80 || r.width > W.innerWidth * 0.92) return;
      var named = /card/i.test(e.className);
      var bgDiff = opaque(s.backgroundColor) && e.parentElement && s.backgroundColor !== effBg(e.parentElement);
      var deco = s.boxShadow !== 'none' || (px(s.borderTopWidth) > 0 && px(s.borderTopLeftRadius) > 0);
      if (named || bgDiff || deco) mark(e, 'card');
    });
    var cd = D.querySelector('[data-dial-card]'); M.rCard = cd ? px(cs(cd).borderTopLeftRadius) : 0;

    /* card grids + gaps */
    all.forEach(function (e) {
      var s = cs(e); if (e.closest('header,footer')) return;
      if (s.display.indexOf('grid') > -1 || s.display.indexOf('flex') > -1) {
        var rg = px(s.rowGap), cg = px(s.columnGap);
        if (rg > 0 || cg > 0) { mark(e, 'gap'); setVar(e, 'rg', (rg || 0) + 'px'); setVar(e, 'cg', (cg || 0) + 'px'); }
      }
      if (s.display.indexOf('grid') > -1) {
        var kids = [].slice.call(e.children).filter(function (k) { return k.tagName !== 'LEGEND'; }), sig = {};
        kids.forEach(function (k) { var key = k.tagName + '.' + k.className; sig[key] = (sig[key] || 0) + 1; });
        if (Object.keys(sig).some(function (k) { return sig[k] >= 3; })) mark(e, 'cgrid');
      }
    });

    /* hero anatomy */
    if (hero) {
      var media = [].slice.call(hero.querySelectorAll('img,video,iframe,[data-dial-bgimg]')).sort(function (a, b) {
        var ra = a.getBoundingClientRect(), rb = b.getBoundingClientRect(); return rb.width * rb.height - ra.width * ra.height;
      })[0];
      if (media && media.getBoundingClientRect().width > 200) {
        mark(media, 'heromedia');
        var fx = /^(IMG|VIDEO|IFRAME)$/.test(media.tagName) ? media.parentElement : media; mark(fx, 'herofx');
        if (cs(fx).position === 'static') mark(fx, 'herorel');
        [].forEach.call(fx.children, function (k) { if (cs(k).position === 'static') mark(k, 'herolift'); });
        for (var a = media; a && a !== hero; a = a.parentElement) {
          var P = a.parentElement; if (!P) break; var ps2 = cs(P);
          if ((ps2.display.indexOf('grid') > -1 || ps2.display.indexOf('flex') > -1) && P.children.length >= 2) {
            mark(P, 'herogrid'); mark(a, 'heromcol');
            [].forEach.call(P.children, function (k) { if (k !== a) mark(k, 'herotxtcol'); });
            break;
          }
        }
      }
      var mcol = hero.querySelector('[data-dial-heromcol]');
      [].forEach.call(hero.querySelectorAll('h1,h2,p,div,ul'), function (e) {
        if ((mcol && mcol.contains(e)) || e.closest('[data-dial-herofx]')) return;
        var s = cs(e);
        if (s.display.indexOf('flex') > -1) mark(e, 'heroflex');
        else if (/^(H1|H2|P|UL)$/.test(e.tagName)) mark(e, 'herotext');
      });
    }

    /* text roles */
    all.forEach(function (e) {
      if (e.closest('[data-dial-btn]')) return;
      if (/^(P|LI|LABEL|SUMMARY|DD|BLOCKQUOTE|FIGCAPTION|TD|SMALL)$/.test(e.tagName)) { mark(e, 'tx'); setVar(e, 'fs', cs(e).fontSize); }
      if (/^(P|LI)$/.test(e.tagName)) mark(e, 'para');
      if (/^H[1-3]$/.test(e.tagName)) { mark(e, 'h'); setVar(e, 'fs', cs(e).fontSize); }
    });

    /* muted color: most common non-ink paragraph color */
    var cc = {};
    all.forEach(function (e) {
      if (!e.hasAttribute('data-dial-para')) return; var c = cs(e).color;
      if (c !== M.ink && lum(c) < 0.45 && ratio(c, M.bg) > 2.5) cc[c] = (cc[c] || 0) + 1;
    });
    M.muted = Object.keys(cc).sort(function (a, b) { return cc[b] - cc[a]; })[0] || M.ink;

    /* color roles + font roots */
    all.forEach(function (e) {
      var s = cs(e), r = e.getBoundingClientRect(), isBtn = e.hasAttribute('data-dial-btn'), bg = s.backgroundColor;
      var named = e.classList.length || /^(H[1-6]|A|B|STRONG|LEGEND|LABEL|SUMMARY|INPUT|TEXTAREA|SELECT|BUTTON|P|LI)$/.test(e.tagName);
      if (s.fontFamily === M.bFam && (named || e.parentElement === D.body)) mark(e, 'ffb');
      if (s.fontFamily === M.hFam && M.hFam !== M.bFam && (named || /^H[1-6]$/.test(e.tagName))) mark(e, 'ffh');
      if (s.color === M.ink && (named || (e.parentElement && cs(e.parentElement).color !== M.ink))) { mark(e, 'ink'); if (/^H[1-3]$/.test(e.tagName)) mark(e, 'hink'); }
      if (s.color === M.muted && M.muted !== M.ink) mark(e, 'muted');
      if (s.color === M.accent && !isBtn) mark(e, 'accfg');
      if (!opaque(bg) || isBtn) return;
      if (bg === M.accent) { mark(e, 'accbg'); return; }
      if (bg === M.bg && s.backgroundImage === 'none') { mark(e, 'bg'); return; }
      var L = lum(bg);
      if (e.hasAttribute('data-dial-sec') && L > 0.45) { mark(e, 'band'); if (!M.band) M.band = bg; return; }
      if (L < 0.12 && r.width >= 120 && r.height >= 60) { mark(e, 'dark'); if (!M.dark) M.dark = bg; return; }
      if (L > 0.45 && r.width >= 100 && r.height >= 36 && !e.closest('footer')) { mark(e, 'surf'); if (!M.surf) M.surf = bg; }
    });
    if (D.body) { mark(D.body, 'bg'); mark(D.body, 'ffb'); }

    /* reveal targets: authored reveal classes first, else auto */
    var rv = all.filter(function (e) { return e.matches('.rv,.reveal,[data-aos],.fade-in,[class*="reveal"],[class*="animate-"]'); });
    if (!rv.length) rv = all.filter(function (e) { return e.closest('[data-dial-sec]') && (e.matches('h1,h2,h3,p,img,figure,[data-dial-card],[data-dial-btn]')) && !e.parentElement.closest('[data-dial-card],p,h1,h2,h3'); });
    rv.forEach(function (e) { mark(e, 'rv'); });

    /* scroll text candidates: big paragraphs and section headings outside the hero */
    all.forEach(function (e) {
      if (e.closest('[data-dial-hero]') || e.closest('footer')) return;
      if ((e.tagName === 'H2' || (e.tagName === 'P' && px(cs(e).fontSize) >= 20)) && e.closest('[data-dial-sec]')) { mark(e, 'srt'); setVar(e, 'c', cs(e).color); }
    });

    /* chip rows (for the marquee extra) and authored marquees */
    all.forEach(function (e) {
      var s = cs(e);
      if (s.display.indexOf('flex') > -1 && s.flexWrap === 'wrap' && e.children.length >= 3 && e.closest('[data-dial-sec]') &&
        [].every.call(e.children, function (k) { return k.getBoundingClientRect().height < 70; })) mark(e, 'chips');
      if (/marquee|ticker/i.test(s.animationName + ' ' + e.className)) mark(e, 'marq');
    });

    /* design tokens on :root */
    var probeFam = function (fam) { return (fam || '').split(',')[0].replace(/["']/g, '').trim().toLowerCase(); };
    try {
      [].forEach.call(D.styleSheets, function (sh) {
        var rules; try { rules = sh.cssRules; } catch (e) { return; }
        [].forEach.call(rules || [], function (ru) {
          if (!ru.style || !/^(:root|html)$/.test((ru.selectorText || '').trim())) return;
          for (var i = 0; i < ru.style.length; i++) {
            var n = ru.style[i]; if (n.indexOf('--') !== 0 || n.indexOf('--dial') === 0) continue;
            var val = ru.style.getPropertyValue(n).trim(), lv = val.toLowerCase();
            if (probeFam(M.hFam) && lv.indexOf(probeFam(M.hFam)) > -1 && lv.indexOf(',') > -1) M.tok.head = n;
            else if (probeFam(M.bFam) && lv.indexOf(probeFam(M.bFam)) > -1 && lv.indexOf(',') > -1) M.tok.body = n;
            var nc = /^(#|rgb|hsl)/.test(lv) ? normColor(val) : null; if (!nc) continue;
            if (nc === M.bg && !M.tok.bg) M.tok.bg = n;
            else if (nc === M.ink && !M.tok.ink) M.tok.ink = n;
            else if (nc === M.muted && !M.tok.muted) M.tok.muted = n;
            else if (nc === M.accent && !M.tok.accent) M.tok.accent = n;
            else if (M.band && nc === M.band && !M.tok.band) M.tok.band = n;
          }
          if (M.tok.accent) for (var j = 0; j < ru.style.length; j++) { if (ru.style[j] === M.tok.accent + '-dark') M.tok.accentDark = ru.style[j]; }
        });
      });
    } catch (e) { /* tokens are a bonus */ }
  }

  /* re-measure the per-element vars with overrides switched off (on resize) */
  function remeasure() {
    if (!ov) return; ov.media = 'not all';
    DATA.forEach(function (d, el) {
      var s = cs(el);
      if ('fs' in d) setVar(el, 'fs', s.fontSize);
      if ('pt' in d) { setVar(el, 'pt', s.paddingTop); setVar(el, 'pb', s.paddingBottom); setVar(el, 'mt', s.marginTop); }
      if ('rg' in d) { setVar(el, 'rg', s.rowGap === 'normal' ? '0px' : s.rowGap); setVar(el, 'cg', s.columnGap === 'normal' ? '0px' : s.columnGap); }
      if ('bpy' in d) { setVar(el, 'bpy', s.paddingTop); setVar(el, 'bpx', s.paddingLeft); setVar(el, 'bfs', s.fontSize); }
    });
    ov.media = '';
  }

  /* ---------- controls ---------- */
  var C = [], CI = {};
  function add(o) { C.push(o); CI[o.id] = o; return o; }
  function Rg(id, g, l, min, max, step, init, u, r, h) { return add({ id: id, g: g, l: l, t: 'range', min: min, max: max, step: step, init: init, u: u || '', r: r, h: h }); }
  function Se(id, g, l, o, r, h) { return add({ id: id, g: g, l: l, t: 'select', o: o, r: r, h: h }); }
  function Tg(id, g, l, init, r, h) { return add({ id: id, g: g, l: l, t: 'toggle', init: init, r: r, h: h }); }
  function Co(id, g, l, init, sw, r, h) { return add({ id: id, g: g, l: l, t: 'color', init: init, sw: sw, r: r, h: h }); }
  function Tx(id, g, l, init, h) { return add({ id: id, g: g, l: l, t: 'text', init: init, h: h }); }
  function Ac(id, g, l, fn, h) { return add({ id: id, g: g, l: l, t: 'action', fn: fn, h: h, noState: 1 }); }
  function Ro(id, g, l, fn) { return add({ id: id, g: g, l: l, t: 'readout', fn: fn, noState: 1 }); }
  function opts(list) { return list.map(function (x) { return Array.isArray(x) ? x : [x, x.charAt(0).toUpperCase() + x.slice(1)]; }); }
  var fontOpts = Object.keys(SYSF).map(function (k) { return [k, k, 'System']; }).concat(GF.map(function (g) { return [g[0], g[0], 'Google']; }));
  var gfNames = GF.map(function (g) { return g[0]; });

  // Type
  Se('headFont', 'Type', 'Heading font', fontOpts, gfNames);
  Se('bodyFont', 'Type', 'Body font', fontOpts, ['Inter', 'Figtree', 'Manrope', 'DM Sans', 'Instrument Sans', 'Hanken Grotesk', 'Source Sans 3', 'Public Sans', 'Work Sans', 'Onest', 'Karla', 'Albert Sans']);
  Ac('pairShuffle', 'Type', 'Shuffle a font pairing', function () { var p = PAIRS[Math.floor(Math.random() * PAIRS.length)]; setMany({ headFont: p[0], bodyFont: p[1] }); }, 'Font pairing randomizer from a curated list');
  Rg('headWeight', 'Type', 'Heading weight', 300, 900, 100, function () { return M.hWeight; }, '', [500, 800]);
  Rg('headScale', 'Type', 'Heading size scale', 0.6, 1.6, 0.02, 1, 'x', [0.85, 1.2]);
  Rg('headTrack', 'Type', 'Heading letter-spacing', -0.08, 0.1, 0.005, function () { return M.hTrack; }, 'em', [-0.045, 0.01]);
  Rg('headLead', 'Type', 'Heading line-height', 0.85, 1.6, 0.01, function () { return M.hLead; }, '', [0.95, 1.15]);
  Se('headCase', 'Type', 'Heading text-transform', opts(['none', 'uppercase', 'lowercase', 'capitalize']), ['none', 'none', 'none', 'uppercase']);
  Tg('headItalic', 'Type', 'Italic headings', false, 0.1);
  Tg('headBalance', 'Type', 'Balanced heading lines', false, 0.5);
  Se('headColor', 'Type', 'Heading color', opts([['ink', 'Ink'], ['accent', 'Accent'], ['gradient', 'Accent to ink gradient']]), ['ink', 'ink', 'accent']);
  Rg('bodySize', 'Type', 'Body size scale', 0.8, 1.3, 0.01, 1, 'x', [0.95, 1.08]);
  Rg('bodyLead', 'Type', 'Body line-height', 1.2, 2.1, 0.01, function () { return M.bLead; }, '', [1.5, 1.8]);
  Rg('measure', 'Type', 'Measure (max line width)', 36, 100, 1, 90, 'ch', [55, 72]);
  Rg('paraSpace', 'Type', 'Paragraph spacing', 0, 2.4, 0.05, function () { return M.para; }, 'em', [0.7, 1.3]);
  Rg('bodyWeight', 'Type', 'Body weight', 300, 600, 100, function () { return M.bWeight; }, '', [400, 500]);
  Se('linkStyle', 'Type', 'Link underline style', opts([['none', 'None'], ['solid', 'Thin underline'], ['thick', 'Thick underline'], ['dotted', 'Dotted'], ['wavy', 'Wavy'], ['highlight', 'Highlighter']]), ['solid', 'thick', 'highlight', 'none']);
  Rg('linkOffset', 'Type', 'Underline offset', 0, 10, 1, 3, 'px', [2, 6]);
  Se('figures', 'Type', 'Number style', opts([['tabular-nums', 'Tabular'], ['oldstyle-nums', 'Old style'], ['lining-nums', 'Lining'], ['slashed-zero', 'Slashed zero']]), false);
  Se('smoothing', 'Type', 'Font smoothing', opts([['antialiased', 'Antialiased'], ['auto', 'Subpixel']]), false);

  // Color
  Co('bg', 'Color', 'Base background', function () { return M.bg; }, null, false);
  Co('surf', 'Color', 'Surface (cards, fields)', function () { return M.surf || '#ffffff'; }, null, false);
  Co('band', 'Color', 'Alternate band color', function () { return M.band || '#f3f3f1'; }, ['#e7eef4', '#f3f1ec', '#eef3ee', '#f5efe6', '#ececf3'], ['#e7eef4', '#f3f1ec', '#eef3ee', '#f5efe6']);
  Co('dark', 'Color', 'Dark panel color', function () { return M.dark || '#2a2f3a'; }, ['#2a2f3a', '#1b1d22', '#2b2238', '#1f3329'], false);
  Co('ink', 'Color', 'Text color', function () { return M.ink; }, null, false);
  Co('muted', 'Color', 'Muted text', function () { return M.muted; }, null, false);
  Co('accent', 'Color', 'Accent color', function () { return M.accent; }, ACCENTS.map(function (a) { return a[1]; }), ACCENTS.map(function (a) { return a[1]; }));
  Se('accentUse', 'Color', 'Accent usage', opts([['btn', 'Buttons only'], ['btnlink', 'Buttons and links'], ['all', 'Buttons, links and highlights']]), ['btn', 'btnlink', 'all']);
  Tg('darkMode', 'Color', 'Dark mode', false, 0.08);
  Rg('contrast', 'Color', 'Contrast boost', 0, 100, 1, 0, '%', [0, 30]);
  Rg('imgSat', 'Color', 'Image saturation', 0, 2, 0.05, 1, 'x', [0.8, 1.2]);
  Rg('imgWarm', 'Color', 'Image warmth', -1, 1, 0.05, 0, '', [-0.3, 0.4]);
  Rg('hue', 'Color', 'Hue shift (whole page)', 0, 360, 1, 0, 'deg', false);

  // Shape
  Rg('rCard', 'Shape', 'Card radius', 0, 48, 1, function () { return M.rCard; }, 'px', [0, 32]);
  Rg('rImg', 'Shape', 'Image radius', 0, 48, 1, function () { return M.rImg; }, 'px', [0, 32]);
  Rg('rBtn', 'Shape', 'Button radius', 0, 60, 1, function () { return M.rBtn; }, 'px', false);
  Rg('rFrame', 'Shape', 'Frame radius (video, figures)', 0, 60, 1, function () { return M.rFrame; }, 'px', [0, 36]);
  Rg('rInput', 'Shape', 'Form field radius', 0, 30, 1, 12, 'px', [4, 18]);
  Se('btnStyle', 'Shape', 'Button style', opts(['pill', 'rounded', 'square', 'outline', 'ghost']), ['pill', 'rounded', 'square', 'pill', 'outline']);
  Tg('btnArrow', 'Shape', 'Arrow icon in buttons', function () { return M.hasArrow; }, 0.6);
  Rg('btnSize', 'Shape', 'Button size', 0.7, 1.4, 0.02, 1, 'x', [0.9, 1.12]);
  Se('btnCase', 'Shape', 'Button text case', opts(['none', 'uppercase', 'capitalize']), ['none', 'uppercase']);
  Rg('borderW', 'Shape', 'Card border width', 0, 4, 0.5, 0, 'px', [0, 1.5]);
  Co('borderC', 'Shape', 'Card border color', '#1f2638', ['#1f2638', '#d5dbe3', '#c0392b', '#ffffff'], false);

  // Depth
  Se('shadow', 'Depth', 'Shadow preset', opts(['none', 'soft', 'layered', 'long', 'glow']), ['none', 'soft', 'layered', 'soft', 'long']);
  Rg('shBlur', 'Depth', 'Shadow blur', 0, 90, 1, 24, 'px', [12, 50]);
  Rg('shY', 'Depth', 'Shadow offset', -10, 40, 1, 12, 'px', [4, 24]);
  Rg('shOp', 'Depth', 'Shadow opacity', 0, 0.6, 0.01, 0.14, '', [0.06, 0.2]);
  Co('shTint', 'Depth', 'Shadow tint', '#141a28', ['#141a28', '#c0392b', '#2563eb', '#3b2a12'], false);
  Se('shTarget', 'Depth', 'Shadow applies to', opts([['cards', 'Cards'], ['media', 'Cards and media'], ['all', 'Cards, media and buttons']]), ['cards', 'media']);
  Rg('hoverLift', 'Depth', 'Card elevation on hover', 0, 16, 1, 0, 'px', [0, 6]);
  Tg('innerEdge', 'Depth', 'Glossy top edge on cards', false, 0.2);

  // Layout
  Rg('wrapW', 'Layout', 'Container width', 820, 1600, 10, function () { return M.wrapW; }, 'px', [1080, 1280]);
  Rg('gutter', 'Layout', 'Container side padding', 8, 80, 1, function () { return M.gutter; }, 'px', [24, 48]);
  Rg('secPad', 'Layout', 'Section vertical padding', 0.3, 2, 0.05, 1, 'x', [0.6, 1.2]);
  Rg('gap', 'Layout', 'Gap scale', 0.4, 2, 0.05, 1, 'x', [0.8, 1.3]);
  Se('cols', 'Layout', 'Card columns', opts([['1', '1'], ['2', '2'], ['3', '3'], ['4', '4']]), false);
  Se('heroAlign', 'Layout', 'Hero text alignment', opts(['left', 'center', 'right']), false);
  Rg('heroH', 'Layout', 'Hero min height', 0, 100, 1, 0, 'vh', false);
  Rg('heroFade', 'Layout', 'Hero photo dark fade', 0, 100, 1, 0, '%', [0, 45]);
  Se('heroDir', 'Layout', 'Hero fade direction', opts([['to top', 'From bottom'], ['to bottom', 'From top'], ['to right', 'From left'], ['to left', 'From right'], ['radial', 'Vignette']]), ['to top', 'to right', 'radial']);
  Se('heroText', 'Layout', 'Text card over the photo', opts([['off', 'Off (side by side)'], ['tl', 'Top left'], ['c', 'Center'], ['bl', 'Bottom left'], ['br', 'Bottom right']]), false);
  Se('hdrMode', 'Layout', 'Header behavior', opts([['sticky', 'Sticky'], ['static', 'Scrolls away']]), false);
  Tg('hdrGlass', 'Layout', 'Frosted glass header', false, 0.3);
  add({ id: 'secHide', g: 'Layout', l: 'Show or hide sections', t: 'sections', r: false });
  add({ id: 'secOrder', g: 'Layout', l: 'Reorder sections (drag)', t: 'order', r: false });

  // Imagery
  Se('aspect', 'Imagery', 'Image aspect ratio', opts([['1/1', '1:1'], ['4/5', '4:5'], ['4/3', '4:3'], ['3/2', '3:2'], ['16/9', '16:9'], ['21/9', '21:9']]), false);
  Se('fit', 'Imagery', 'Object fit', opts(['cover', 'contain']), false);
  Se('objPos', 'Imagery', 'Focal point', opts([['center', 'Center'], ['top', 'Top'], ['bottom', 'Bottom'], ['left', 'Left'], ['right', 'Right']]), false);
  Rg('gray', 'Imagery', 'Grayscale', 0, 1, 0.05, 0, '', [0, 0.3]);
  Rg('sepia', 'Imagery', 'Sepia', 0, 1, 0.05, 0, '', [0, 0.2]);
  Rg('imgBlur', 'Imagery', 'Blur', 0, 10, 0.5, 0, 'px', false);
  Rg('bright', 'Imagery', 'Brightness', 0.5, 1.5, 0.02, 1, 'x', [0.92, 1.08]);
  Rg('imgCon', 'Imagery', 'Image contrast', 0.5, 1.5, 0.02, 1, 'x', [0.95, 1.12]);
  Rg('duo', 'Imagery', 'Duotone with accent', 0, 1, 0.05, 0, '', [0, 0.5]);
  Rg('parallax', 'Imagery', 'Parallax amount', 0, 1, 0.05, 0, '', [0, 0.4]);
  Tg('kenburns', 'Imagery', 'Ken Burns zoom on hero', false, 0.3);
  Se('imgHover', 'Imagery', 'Image hover', opts(['none', 'zoom', 'lift', 'tilt']), ['none', 'zoom', 'lift']);

  // Motion
  Se('motion', 'Motion', 'Motion master', opts([['on', 'On'], ['off', 'Off (kill all motion)']]), false);
  Tg('reduced', 'Motion', 'Respect prefers-reduced-motion', true, false);
  Se('entrance', 'Motion', 'Entrance style', opts([['fade', 'Fade'], ['rise', 'Rise'], ['slide', 'Slide'], ['scale', 'Scale'], ['blur', 'Blur in'], ['clip', 'Clip reveal'], ['none', 'None']]), ['fade', 'rise', 'scale', 'blur', 'clip', 'slide']);
  Rg('dur', 'Motion', 'Entrance duration', 100, 2000, 10, 700, 'ms', [450, 1100]);
  Se('ease', 'Motion', 'Easing curve', opts([['cubic-bezier(.16,1,.3,1)', 'Expo out'], ['cubic-bezier(.22,1,.36,1)', 'Quint out'], ['cubic-bezier(.2,.8,.2,1)', 'Snappy'], ['cubic-bezier(.34,1.56,.64,1)', 'Back (overshoot)'], ['ease', 'Ease'], ['ease-in-out', 'Ease in out'], ['linear', 'Linear'], ['custom', 'Custom bezier']]), ['cubic-bezier(.16,1,.3,1)', 'cubic-bezier(.22,1,.36,1)', 'cubic-bezier(.2,.8,.2,1)', 'cubic-bezier(.34,1.56,.64,1)']);
  Tx('bezier', 'Motion', 'Custom bezier (x1, y1, x2, y2)', '0.2, 0.7, 0.2, 1');
  Rg('stagger', 'Motion', 'Stagger delay', 0, 300, 5, 80, 'ms', [40, 140]);
  Rg('offset', 'Motion', 'Trigger offset', 0, 40, 1, 0, '%', [0, 20]);
  Ac('replay', 'Motion', 'Replay entrances', function () { replayReveal(); });
  Tg('scrollText', 'Motion', 'Grey to dark scroll text reveal', false, 0.3);
  Tg('pillNav', 'Motion', 'Floating pill nav', false, 0.3);
  Se('btnHover', 'Motion', 'Button hover', opts(['none', 'lift', 'grow', 'nudge', 'glow']), ['lift', 'grow', 'nudge', 'glow']);
  Se('smooth', 'Motion', 'Smooth scroll', opts([['on', 'On'], ['off', 'Off']]), false);
  Rg('marquee', 'Motion', 'Marquee speed (seconds per loop)', 5, 80, 1, 30, 's', [18, 40]);
  Tg('chipMarq', 'Motion', 'Turn the proof chips into a marquee', false, 0.15);
  Tg('pageFade', 'Motion', 'Fade the page in on load', false, 0.2);

  // Texture and details
  Rg('grain', 'Texture', 'Grain overlay', 0, 100, 1, 0, '%', [0, 35]);
  Se('pattern', 'Texture', 'Background pattern', opts(['none', 'dots', 'grid', 'topo', 'diagonal']), ['none', 'none', 'dots', 'grid', 'topo']);
  Rg('patOp', 'Texture', 'Pattern strength', 0, 100, 1, 40, '%', [20, 60]);
  Se('divider', 'Texture', 'Section divider', opts(['none', 'line', 'dashed', 'dotted', 'wave']), ['none', 'none', 'line', 'wave']);
  Se('labels', 'Texture', 'Section labels (off by default: an AI-slop tell)', opts([['off', 'Off'], ['num', 'Numbers'], ['numname', 'Number and name'], ['dot', 'Accent dot']]), false);
  Se('cursor', 'Texture', 'Cursor', opts([['crosshair', 'Crosshair'], ['dot', 'Accent dot follower'], ['ring', 'Ring follower']]), false);
  Co('selection', 'Texture', 'Text selection color', function () { return M.accent; }, ACCENTS.map(function (a) { return a[1]; }), false);
  Tg('progress', 'Texture', 'Scroll progress bar', false, 0.3);
  Se('scrollbar', 'Texture', 'Scrollbar', opts([['thin', 'Thin'], ['accent', 'Accent'], ['hidden', 'Hidden']]), false);
  Se('focus', 'Texture', 'Focus ring', opts([['accent', 'Accent outline'], ['soft', 'Soft halo']]), false);

  // Density
  Se('density', 'Density', 'Content density (macro)', opts(['compact', 'comfortable', 'airy']), ['compact', 'comfortable', 'airy'], 'Moves section padding, gaps, line-height and paragraph spacing together. Individual controls win.');

  // Extras
  Tg('squint', 'Extras', 'Squint test (blur the page)', false, false);
  Tg('mobile', 'Extras', 'Mobile 390px preview frame', false, false);
  Tg('gridOv', 'Extras', '12 column grid overlay', false, false);
  Tg('fold', 'Extras', 'Show the fold line', false, false);
  Tg('outlines', 'Extras', 'Outline every box', false, false);
  Tg('spotlight', 'Extras', 'Spotlight the hovered section', false, false);
  Se('cvd', 'Extras', 'Color vision simulation', opts([['none', 'None'], ['deuter', 'Deuteranopia'], ['protan', 'Protanopia'], ['tritan', 'Tritanopia'], ['achro', 'Achromatopsia']]), false);
  Tg('ruler', 'Extras', 'Measure ruler (flag long and short lines)', false, false);
  Tg('cbadge', 'Extras', 'Contrast warning badge on page', false, false);
  Ro('contrastRo', 'Extras', 'Contrast check', function () { return contrastInfo().html; });
  Ro('measureRo', 'Extras', 'Line length', function () { return measureInfo().html; });

  var SETTING_COUNT = C.filter(function (c) { return !c.noState; }).length;
  var GROUPS = ['Type', 'Color', 'Shape', 'Depth', 'Layout', 'Imagery', 'Motion', 'Texture', 'Density', 'Extras'];

  /* ---------- state ---------- */
  var S = {}, L = {}, PRESETS = {}, AB = { a: null, b: null, cur: null }, UI = { open: true, collapsed: false, tab: 'Type', x: null, y: null };
  function initOf(c) { return typeof c.init === 'function' ? c.init() : c.init; }
  function val(id) { return S[id] === undefined || S[id] === null ? null : S[id]; }
  function snap() { return JSON.stringify(S); }

  /* ---------- CSS builder ---------- */
  var ov, JSF = [];
  function bakeSelOf(el) {
    if (el === D.body) return 'body';
    if (el.id && /^[A-Za-z][\w-]*$/.test(el.id)) return '#' + el.id;
    var t = el.tagName.toLowerCase(), cl = [].slice.call(el.classList).filter(function (x) { return !/^(dial-|in$|active$|open$|is-)/.test(x); });
    if (cl.length) return t + '.' + cl.map(function (x) { return CSS.escape(x); }).join('.');
    var p = el.parentElement; if (!p || p === D.body) return t;
    var pc = [].slice.call(p.classList).filter(function (x) { return !/^dial-/.test(x); });
    var ps = p.id ? '#' + p.id : p.tagName.toLowerCase() + (pc.length ? '.' + pc.map(function (x) { return CSS.escape(x); }).join('.') : '');
    return ps + ' > ' + t;
  }
  function buildCSS(St, bake) {
    var out = [], I = ' !important', jsf = [];
    function v(id) { return St[id] === undefined || St[id] === null ? null : St[id]; }
    function els(n) { return [].slice.call(D.querySelectorAll('[data-dial-' + n + ']')); }
    function sx(n, suf) {
      suf = suf || '';
      if (!bake) return '[data-dial-' + n + ']' + suf;
      var seen = {}, list = [];
      els(n).forEach(function (e) { var s = bakeSelOf(e) + suf; if (!seen[s]) { seen[s] = 1; list.push(s); } });
      return list.join(',\n');
    }
    function rule(sel, decl) { if (sel && decl) out.push(sel + '{' + decl + '}'); }
    function dd(o) { return Object.keys(o).filter(function (k) { return o[k] !== null && o[k] !== undefined && o[k] !== ''; }).map(function (k) { return k + ':' + o[k] + I; }).join(';'); }
    function scaleRule(n, tmpl) {
      if (!bake) { rule(sx(n), tmpl(function (k) { return 'var(--dial-' + k + ')'; }) + I); return; }
      var seen = {};
      els(n).forEach(function (e) {
        var d = DATA.get(e) || {}, s = bakeSelOf(e); if (seen[s]) return; seen[s] = 1;
        rule(s, tmpl(function (k) { return d[k] || '0px'; }) + I);
      });
    }
    var dens = v('density'), DM = { compact: { pad: 0.62, gap: 0.75, lead: 1.55, para: 0.7 }, comfortable: { pad: 1, gap: 1, lead: 1.7, para: 1 }, airy: { pad: 1.4, gap: 1.3, lead: 1.85, para: 1.3 } }[dens];
    var dark = v('darkMode') === true;
    var accSet = v('accent'), acc = accSet || M.accent, accDark = 'color-mix(in srgb, ' + acc + ' 80%, black)';
    var accText = lum(normColor(acc) || acc) > 0.45 ? '#16181d' : '#ffffff';
    var bg = v('bg') || (dark ? '#11141b' : null), surf = v('surf') || (dark ? '#1b2029' : null), band = v('band') || (dark ? '#161a22' : null);
    var ink = v('ink') || (dark ? '#eef1f6' : null), muted = v('muted') || (dark ? '#a9b1c2' : null), darkC = v('dark') || (dark ? '#232b3b' : null);
    var cb = v('contrast'); if (cb) muted = 'color-mix(in srgb, ' + (muted || M.muted) + ', ' + (ink || M.ink) + ' ' + cb + '%)';
    var reducedOS = W.matchMedia && W.matchMedia('(prefers-reduced-motion: reduce)').matches;
    var motionOK = v('motion') !== 'off' && !(reducedOS && v('reduced') !== false);

    /* tokens */
    var root = {};
    if (v('headFont') && M.tok.head) root[M.tok.head] = fontStack(v('headFont'));
    if (v('bodyFont') && M.tok.body) root[M.tok.body] = fontStack(v('bodyFont'));
    if (bg && M.tok.bg) root[M.tok.bg] = bg;
    if (ink && M.tok.ink) root[M.tok.ink] = ink;
    if (muted && M.tok.muted) root[M.tok.muted] = muted;
    if (band && M.tok.band) root[M.tok.band] = band;
    var use = v('accentUse');
    if (accSet && M.tok.accent && (!use || use === 'all')) { root[M.tok.accent] = acc; if (M.tok.accentDark) root[M.tok.accentDark] = accDark; }
    rule(':root', dd(root));

    /* Type */
    if (v('headFont')) rule('h1,h2,h3,' + sx('ffh'), dd({ 'font-family': fontStack(v('headFont')) }));
    if (v('bodyFont')) rule(sx('ffb'), dd({ 'font-family': fontStack(v('bodyFont')) }));
    var hd = {};
    if (v('headWeight') !== null) hd['font-weight'] = v('headWeight');
    if (v('headTrack') !== null) hd['letter-spacing'] = v('headTrack') + 'em';
    if (v('headLead') !== null) hd['line-height'] = v('headLead');
    if (v('headCase')) hd['text-transform'] = v('headCase');
    if (v('headItalic') !== null) hd['font-style'] = v('headItalic') ? 'italic' : 'normal';
    if (v('headBalance') !== null) hd['text-wrap'] = v('headBalance') ? 'balance' : 'wrap';
    rule('h1,h2,h3', dd(hd));
    if (v('headWeight') !== null) rule(sx('ffh'), dd({ 'font-weight': v('headWeight') }));
    if (v('headScale') !== null) scaleRule('h', function (g) { return 'font-size:calc(' + g('fs') + ' * ' + v('headScale') + ')'; });
    var hc = v('headColor');
    if (hc === 'ink') rule(sx('hink'), dd({ color: ink || M.ink }));
    if (hc === 'accent') rule(sx('hink'), dd({ color: acc }));
    if (hc === 'gradient') rule(sx('hink'), dd({ background: 'linear-gradient(100deg,' + acc + ',' + (ink || M.ink) + ' 70%)', '-webkit-background-clip': 'text', 'background-clip': 'text', color: 'transparent' }));
    if (v('bodySize') !== null) scaleRule('tx', function (g) { return 'font-size:calc(' + g('fs') + ' * ' + v('bodySize') + ')'; });
    var lead = v('bodyLead') !== null ? v('bodyLead') : (DM ? DM.lead : null);
    if (lead !== null) rule('body,' + sx('tx'), dd({ 'line-height': lead }));
    var para = v('paraSpace') !== null ? v('paraSpace') : (DM ? +(M.para * DM.para).toFixed(2) : null);
    var pd = {}; if (para !== null) pd['margin-bottom'] = para + 'em';
    if (v('measure') !== null) pd['max-width'] = v('measure') + 'ch';
    if (v('bodyWeight') !== null) pd['font-weight'] = v('bodyWeight');
    rule(sx('para'), dd(pd));
    var ls = v('linkStyle'), lk = {};
    if (ls === 'none') lk['text-decoration'] = 'none';
    if (ls === 'solid') { lk['text-decoration'] = 'underline'; lk['text-decoration-thickness'] = '1px'; }
    if (ls === 'thick') { lk['text-decoration'] = 'underline'; lk['text-decoration-thickness'] = '3px'; lk['text-decoration-color'] = 'color-mix(in srgb, currentColor 45%, transparent)'; }
    if (ls === 'dotted' || ls === 'wavy') { lk['text-decoration'] = 'underline ' + ls; lk['text-decoration-thickness'] = '1.5px'; }
    if (ls === 'highlight') { lk['text-decoration'] = 'none'; lk['background'] = 'linear-gradient(transparent 60%, color-mix(in srgb, ' + acc + ' 28%, transparent) 0)'; }
    if (v('linkOffset') !== null) lk['text-underline-offset'] = v('linkOffset') + 'px';
    rule(sx('link'), dd(lk));
    if (v('figures')) rule('body', dd({ 'font-variant-numeric': v('figures') }));
    if (v('smoothing')) rule('body', dd({ '-webkit-font-smoothing': v('smoothing'), '-moz-osx-font-smoothing': v('smoothing') === 'auto' ? 'auto' : 'grayscale' }));

    /* Color */
    if (bg) { rule('html', dd({ 'background-color': bg })); rule(sx('bg'), dd({ 'background-color': bg })); }
    if (band) rule(sx('band'), dd({ 'background-color': band }));
    if (surf) rule(sx('surf'), dd({ 'background-color': surf }));
    if (darkC) rule(sx('dark'), dd({ 'background-color': darkC }));
    if (ink) rule(sx('ink'), dd({ color: ink }));
    if (muted) rule(sx('muted'), dd({ color: muted }));
    if (dark) rule('input,textarea,select', dd({ 'background-color': surf, color: ink, 'border-color': 'rgba(255,255,255,.14)' }));
    if (accSet || use) {
      rule(sx('btn'), dd({ 'background-color': acc, color: accText }));
      rule(sx('btn', ':hover'), dd({ 'background-color': accDark }));
      if (!use || use === 'all') { rule(sx('accbg'), dd({ 'background-color': acc, color: accText })); rule(sx('accfg'), dd({ color: acc })); }
      if (use === 'btn' || use === 'btnlink') { rule(sx('accbg'), dd({ 'background-color': ink || M.ink, color: bg || M.bg })); rule(sx('accfg'), dd({ color: ink || M.ink })); }
      if (use === 'btnlink' || use === 'all') rule(sx('link'), dd({ color: acc }));
      if (use === 'all') { rule('::selection', dd({ 'background-color': acc, color: accText })); rule('input,textarea', dd({ 'accent-color': acc, 'caret-color': acc })); }
    }

    /* Shape */
    if (v('rCard') !== null) rule(sx('card'), dd({ 'border-radius': v('rCard') + 'px' }));
    if (v('rImg') !== null) rule(sx('img') + ',' + sx('bgimg'), dd({ 'border-radius': v('rImg') + 'px' }));
    if (v('rFrame') !== null) rule(sx('frame'), dd({ 'border-radius': v('rFrame') + 'px', overflow: 'hidden' }));
    if (v('rInput') !== null) rule('input:not([type=radio]):not([type=checkbox]):not([type=submit]),textarea,select', dd({ 'border-radius': v('rInput') + 'px' }));
    var bs = v('btnStyle');
    if (bs === 'pill') rule(sx('btn'), dd({ 'border-radius': '999px' }));
    if (bs === 'rounded') rule(sx('btn'), dd({ 'border-radius': '12px' }));
    if (bs === 'square') rule(sx('btn'), dd({ 'border-radius': '0px' }));
    if (bs === 'outline') {
      rule(sx('btn'), dd({ 'background-color': 'transparent', color: acc, 'box-shadow': 'inset 0 0 0 2px ' + acc }));
      rule(sx('btn', ':hover'), dd({ 'background-color': acc, color: accText }));
      rule(sx('btnarrow'), dd({ 'background-color': 'color-mix(in srgb, ' + acc + ' 14%, transparent)' }));
    }
    if (bs === 'ghost') {
      rule(sx('btn'), dd({ 'background-color': 'transparent', color: acc, 'box-shadow': 'none', 'padding-left': '4px', 'padding-right': '4px', 'text-decoration': 'underline', 'text-underline-offset': '6px', 'text-decoration-thickness': '2px' }));
      rule(sx('btn', ':hover'), dd({ 'background-color': 'transparent', color: accDark }));
      rule(sx('btnarrow'), dd({ 'background-color': 'color-mix(in srgb, ' + acc + ' 14%, transparent)' }));
    }
    if (v('rBtn') !== null) rule(sx('btn'), dd({ 'border-radius': v('rBtn') + 'px' }));
    if (v('btnArrow') === false) rule(sx('btnarrow'), dd({ display: 'none' }));
    if (v('btnArrow') === true) rule(sx('btn', ':not([data-dial-hasarrow])::after'), 'content:"\\2192";margin-left:.6em;display:inline-block;transition:transform .2s');
    if (v('btnSize') !== null) scaleRule('btn', function (g) { var k = v('btnSize'); return 'padding:calc(' + g('bpy') + ' * ' + k + ') calc(' + g('bpx') + ' * ' + k + ') !important;font-size:calc(' + g('bfs') + ' * ' + k + ')'; });
    if (v('btnCase')) rule(sx('btn'), dd({ 'text-transform': v('btnCase'), 'letter-spacing': v('btnCase') === 'uppercase' ? '.06em' : null }));
    if (v('borderW') !== null || v('borderC') !== null) rule(sx('card'), dd({ border: (v('borderW') !== null ? v('borderW') : 1) + 'px solid ' + (v('borderC') || 'rgba(31,38,56,.14)') }));

    /* Depth */
    var shOn = v('shadow') || v('shBlur') !== null || v('shY') !== null || v('shOp') !== null || v('shTint') !== null || v('innerEdge') || v('shTarget');
    var shadowStr = null, shadowHover = null;
    if (shOn) {
      var sp = v('shadow') || 'soft', b = v('shBlur') !== null ? v('shBlur') : 24, y = v('shY') !== null ? v('shY') : 12, o = v('shOp') !== null ? v('shOp') : 0.14, t = rgbList(normColor(v('shTint') || '#141a28'));
      var rg = function (a) { return 'rgba(' + t + ',' + (+a).toFixed(3) + ')'; };
      var mk = function (yy, bb, oo) {
        if (sp === 'none') return 'none';
        if (sp === 'soft') return '0 ' + yy + 'px ' + bb + 'px ' + rg(oo);
        if (sp === 'layered') return '0 1px 2px ' + rg(oo * 0.6) + ',0 ' + (yy / 2) + 'px ' + (bb / 2) + 'px ' + rg(oo * 0.6) + ',0 ' + yy + 'px ' + bb + 'px ' + rg(oo) + ',0 ' + (yy * 2) + 'px ' + (bb * 2) + 'px ' + rg(oo * 0.5);
        if (sp === 'long') return (yy * 1.2) + 'px ' + (yy * 1.2) + 'px ' + (bb / 6) + 'px ' + rg(Math.min(1, oo * 2));
        if (sp === 'glow') return '0 0 ' + bb + 'px ' + (yy / 3) + 'px color-mix(in srgb, ' + acc + ' ' + Math.round(Math.min(100, oo * 300)) + '%, transparent)';
      };
      shadowStr = mk(y, b, o); shadowHover = mk(y * 1.6, b * 1.5, o * 1.3);
      if (v('innerEdge')) { var ie = 'inset 0 1px 0 rgba(255,255,255,.55)'; shadowStr = shadowStr === 'none' ? ie : shadowStr + ',' + ie; shadowHover = shadowHover === 'none' ? ie : shadowHover + ',' + ie; }
      var tg = v('shTarget') || 'media';
      var shSel = sx('card') + (tg !== 'cards' ? ',' + sx('frame') : '') + (tg === 'all' ? ',' + sx('btn') : '');
      rule(shSel, dd({ 'box-shadow': shadowStr }));
    }
    if (v('hoverLift') !== null && v('hoverLift') > 0 && motionOK) {
      rule(sx('card'), dd({ transition: 'transform .3s cubic-bezier(.2,.8,.2,1), box-shadow .3s' }));
      rule(sx('card', ':hover'), dd({ transform: 'translateY(-' + v('hoverLift') + 'px)', 'box-shadow': shadowHover || '0 18px 40px rgba(20,26,40,.16)' }));
    }

    /* Layout */
    if (v('wrapW') !== null) rule(sx('wrap'), dd({ 'max-width': v('wrapW') + 'px' }));
    if (v('gutter') !== null) rule(sx('wrap'), dd({ 'padding-left': v('gutter') + 'px', 'padding-right': v('gutter') + 'px' }));
    var pk = v('secPad') !== null ? v('secPad') : (DM ? DM.pad : null);
    if (pk !== null) scaleRule('sec', function (g) { return 'padding-top:calc(' + g('pt') + ' * ' + pk + ') !important;padding-bottom:calc(' + g('pb') + ' * ' + pk + ') !important;margin-top:calc(' + g('mt') + ' * ' + pk + ')'; });
    var gk = v('gap') !== null ? v('gap') : (DM ? DM.gap : null);
    if (gk !== null) scaleRule('gap', function (g) { return 'row-gap:calc(' + g('rg') + ' * ' + gk + ') !important;column-gap:calc(' + g('cg') + ' * ' + gk + ')'; });
    if (v('cols')) out.push('@media (min-width:760px){' + sx('cgrid') + '{grid-template-columns:repeat(' + v('cols') + ',minmax(0,1fr))' + I + '}}');
    var ha = v('heroAlign');
    if (ha) {
      rule(sx('herotext'), dd({ 'text-align': ha, 'margin-left': ha === 'left' ? '0' : 'auto', 'margin-right': ha === 'right' ? '0' : (ha === 'center' ? 'auto' : null) }));
      rule(sx('heroflex'), dd({ 'justify-content': ha === 'center' ? 'center' : (ha === 'right' ? 'flex-end' : 'flex-start'), 'text-align': ha }));
    }
    if (v('heroH') !== null && v('heroH') > 0) { rule(sx('hero'), dd({ 'min-height': v('heroH') + 'vh', display: 'flex', 'flex-direction': 'column', 'justify-content': 'center' })); rule(sx('hero', ' > *'), dd({ width: '100%' })); }
    if (v('heroFade') !== null && v('heroFade') > 0) {
      var a = (v('heroFade') / 100).toFixed(2), dir = v('heroDir') || 'to top';
      var grad = dir === 'radial' ? 'radial-gradient(ellipse at 50% 45%, rgba(10,12,18,0) 35%, rgba(10,12,18,' + a + ') 100%)' : 'linear-gradient(' + dir + ', rgba(10,12,18,' + a + ') 0%, rgba(10,12,18,0) 85%)';
      rule(sx('herorel'), dd({ position: 'relative' }));
      rule(sx('herofx', '::before'), 'content:"";position:absolute;inset:0;z-index:0;pointer-events:none;border-radius:inherit;background:' + grad);
      rule(sx('herofx', ' > *'), dd({ 'z-index': '1' }));
      rule(sx('herolift'), dd({ position: 'relative' }));
    } else if (v('heroDir')) {
      rule(sx('herorel'), dd({ position: 'relative' }));
      rule(sx('herofx', '::before'), 'content:"";position:absolute;inset:0;z-index:0;pointer-events:none;background:' + (v('heroDir') === 'radial' ? 'radial-gradient(ellipse at 50% 45%, transparent 35%, rgba(10,12,18,.35))' : 'linear-gradient(' + v('heroDir') + ', rgba(10,12,18,.35), transparent 85%)'));
      rule(sx('herolift'), dd({ position: 'relative' }));
    }
    var ht = v('heroText');
    if (ht && ht !== 'off') {
      var pos = { tl: ['start', 'start'], c: ['center', 'center'], bl: ['end', 'start'], br: ['end', 'end'] }[ht];
      rule(sx('herogrid'), dd({ display: 'grid', 'grid-template-columns': 'minmax(0,1fr)', 'grid-template-areas': '"x"' }));
      rule(sx('herogrid', ' > *'), dd({ 'grid-area': 'x' }));
      rule(sx('heromcol'), dd({ 'z-index': '1', 'min-height': 'clamp(480px,74vh,860px)', display: 'flex', 'flex-direction': 'column', position: 'relative' }));
      rule(sx('heromedia'), dd({ 'aspect-ratio': 'auto', flex: '1 1 auto', height: '100%', 'min-height': '100%' }));
      rule(sx('herotxtcol'), dd({ 'z-index': '2', position: 'relative', 'align-self': pos[0], 'justify-self': pos[1], 'max-width': '540px', margin: 'clamp(16px,3vw,40px)', padding: 'clamp(22px,3vw,40px)', 'background-color': surf || bg || '#ffffff', 'border-radius': (v('rCard') !== null ? v('rCard') : (M.rCard || 20)) + 'px', 'box-shadow': shadowStr && shadowStr !== 'none' ? shadowStr : '0 24px 60px rgba(10,12,18,.28)' }));
    }
    var hide = v('secHide');
    if (hide && hide.length) hide.forEach(function (id) { var s = SECS.filter(function (x) { return x.id === id; })[0]; if (s) rule(bake ? bakeSelOf(s.el) : '[data-dial-sec="' + id.slice(1) + '"]', dd({ display: 'none' })); });
    if (v('secOrder') && bake) jsf.push('section order: ' + v('secOrder').map(function (id) { var s = SECS.filter(function (x) { return x.id === id; })[0]; return s ? s.name : id; }).join(' > '));
    if (v('hdrMode') === 'sticky') rule(sx('hdr'), dd({ position: 'sticky', top: '0', 'z-index': '50' }));
    if (v('hdrMode') === 'static') rule(sx('hdr'), dd({ position: 'static' }));
    if (v('hdrGlass')) rule(sx('hdr'), dd({ 'background-color': 'color-mix(in srgb, ' + (bg || M.bg) + ' 72%, transparent)', 'backdrop-filter': 'blur(14px) saturate(1.4)', '-webkit-backdrop-filter': 'blur(14px) saturate(1.4)' }));

    /* Imagery */
    var f = [];
    if (v('gray') || v('duo')) f.push('grayscale(' + Math.max(v('gray') || 0, v('duo') || 0) + ')');
    if (v('sepia')) f.push('sepia(' + v('sepia') + ')');
    if (v('imgBlur')) f.push('blur(' + v('imgBlur') + 'px)');
    if (v('bright') !== null) f.push('brightness(' + v('bright') + ')');
    if (v('imgCon') !== null || v('duo')) f.push('contrast(' + ((v('imgCon') || 1) * (v('duo') ? 1 + v('duo') * 0.15 : 1)).toFixed(2) + ')');
    if (v('imgSat') !== null) f.push('saturate(' + v('imgSat') + ')');
    var wm = v('imgWarm'); if (wm) { if (wm > 0) f.push('sepia(' + (wm * 0.35).toFixed(2) + ')', 'saturate(' + (1 + wm * 0.25).toFixed(2) + ')'); f.push('hue-rotate(' + (-wm * 12).toFixed(1) + 'deg)'); }
    if (f.length) rule(sx('img') + ',' + sx('bgimg'), dd({ filter: f.join(' ') }));
    if (v('duo')) {
      var tint = 'color-mix(in srgb, ' + acc + ' ' + Math.round(v('duo') * 100) + '%, white)';
      rule(sx('img'), dd({ 'mix-blend-mode': 'multiply' }));
      rule(sx('imgwrap'), dd({ 'background-color': tint }));
      rule(sx('bgimg'), dd({ 'background-color': tint, 'background-blend-mode': 'multiply' }));
    }
    if (v('aspect')) { rule(sx('img'), dd({ 'aspect-ratio': v('aspect'), width: '100%', height: 'auto', 'object-fit': v('fit') || 'cover' })); rule(sx('bgimg'), dd({ 'aspect-ratio': v('aspect') })); }
    if (v('fit')) { rule(sx('img'), dd({ 'object-fit': v('fit') })); rule(sx('bgimg'), dd({ 'background-size': v('fit') })); }
    if (v('objPos')) { rule(sx('img'), dd({ 'object-position': v('objPos') })); rule(sx('bgimg'), dd({ 'background-position': v('objPos') })); }
    if (v('parallax') && motionOK && !bake) {
      var pa = v('parallax');
      rule(sx('img'), dd({ translate: '0 var(--dial-py,0px)', scale: (1 + pa * 0.18).toFixed(3) }));
      rule(sx('bgimg'), dd({ 'background-position-y': 'calc(var(--dial-bgy,50%) + var(--dial-py,0px))' }));
    } else if (v('parallax') && bake) jsf.push('parallax ' + v('parallax'));
    if (v('kenburns') && motionOK) {
      out.push('@keyframes dial-kb{from{scale:1.04}to{scale:1.16}}@keyframes dial-kbb{from{background-size:104%}to{background-size:122%}}');
      rule(sx('heromedia', ':is(img,video)'), dd({ animation: 'dial-kb 16s ease-in-out infinite alternate' }));
      rule(sx('heromedia', '[data-dial-bgimg]'), dd({ animation: 'dial-kbb 16s ease-in-out infinite alternate' }));
      rule(sx('herofx'), dd({ overflow: 'hidden' }));
    }
    var ih = v('imgHover');
    if (ih && ih !== 'none' && motionOK) {
      if (ih === 'zoom') { rule(sx('img') + ',' + sx('bgimg'), dd({ transition: 'scale .8s cubic-bezier(.2,.8,.2,1), background-size .8s' })); rule(sx('img', ':hover'), dd({ scale: '1.06' })); rule(sx('frame'), dd({ overflow: 'hidden' })); }
      if (ih === 'lift') { rule(sx('frame') + ',' + sx('img'), dd({ transition: 'translate .4s cubic-bezier(.2,.8,.2,1)' })); rule(sx('frame', ':hover'), dd({ translate: '0 -6px' })); }
      if (ih === 'tilt') { rule(sx('frame'), dd({ transition: 'transform .5s cubic-bezier(.2,.8,.2,1)' })); rule(sx('frame', ':hover'), dd({ transform: 'perspective(900px) rotateX(3deg) rotateY(-4deg)' })); }
    }

    /* Motion */
    if (v('motion') === 'off') {
      rule('*,*::before,*::after', dd({ transition: 'none', animation: 'none', 'scroll-behavior': 'auto' }));
      rule('.rv,' + sx('rv'), dd({ opacity: '1', transform: 'none', filter: 'none', 'clip-path': 'none' }));
    }
    var engine = motionOK && !bake && (v('entrance') || v('dur') !== null || v('ease') || v('stagger') !== null || v('offset') !== null);
    if (engine) {
      var en = v('entrance') || 'rise', du = (v('dur') !== null ? v('dur') : 700) + 'ms';
      var ez = v('ease') || 'cubic-bezier(.2,.7,.2,1)'; if (ez === 'custom') ez = 'cubic-bezier(' + (v('bezier') || '0.2,0.7,0.2,1') + ')';
      if (en === 'none') rule(sx('rv'), dd({ opacity: '1', transform: 'none', transition: 'none' }));
      else {
        var from = { fade: { opacity: '0', transform: 'none' }, rise: { opacity: '0', transform: 'translateY(36px)' }, slide: { opacity: '0', transform: 'translateX(-48px)' }, scale: { opacity: '0', transform: 'scale(.92)' }, blur: { opacity: '0', transform: 'translateY(10px)', filter: 'blur(14px)' }, clip: { opacity: '1', transform: 'none', 'clip-path': 'inset(0 0 100% 0)' } }[en];
        rule('html.dial-mo ' + sx('rv'), dd({ transition: 'opacity ' + du + ' ' + ez + ', transform ' + du + ' ' + ez + ', filter ' + du + ' ' + ez + ', clip-path ' + du + ' ' + ez, 'transition-delay': 'var(--dial-d,0ms)' }));
        rule('html.dial-mo ' + sx('rv', ':not(.dial-in)'), dd(from));
        rule('html.dial-mo ' + sx('rv', '.dial-in'), dd({ opacity: '1', transform: 'none', filter: 'none', 'clip-path': 'inset(0 0 0 0)' }));
      }
    } else if (bake && v('entrance')) jsf.push('entrance ' + v('entrance'));
    var bh = v('btnHover');
    if (bh && motionOK) {
      rule(sx('btn'), dd({ transition: 'transform .25s cubic-bezier(.2,.8,.2,1), box-shadow .25s, background-color .2s' }));
      if (bh === 'none') rule(sx('btn', ':hover'), dd({ transform: 'none' }));
      if (bh === 'lift') rule(sx('btn', ':hover'), dd({ transform: 'translateY(-3px)', 'box-shadow': '0 10px 24px color-mix(in srgb, ' + acc + ' 35%, transparent)' }));
      if (bh === 'grow') rule(sx('btn', ':hover'), dd({ transform: 'scale(1.045)' }));
      if (bh === 'nudge') { rule(sx('btn', ':hover'), dd({ transform: 'none' })); rule(sx('btnarrow') + ',' + sx('btn', '::after'), dd({ transition: 'transform .25s cubic-bezier(.2,.8,.2,1)' })); rule(sx('btn', ':hover [data-dial-btnarrow]') + ',' + sx('btn', ':hover::after'), dd({ transform: 'translateX(5px)' })); }
      if (bh === 'glow') rule(sx('btn', ':hover'), dd({ transform: 'none', 'box-shadow': '0 0 0 6px color-mix(in srgb, ' + acc + ' 22%, transparent), 0 0 28px color-mix(in srgb, ' + acc + ' 45%, transparent)' }));
    }
    if (v('smooth')) rule('html', dd({ 'scroll-behavior': v('smooth') === 'on' ? 'smooth' : 'auto' }));
    if (v('marquee') !== null) rule(sx('marq'), dd({ 'animation-duration': v('marquee') + 's' }));
    if (v('chipMarq') && motionOK && !bake) {
      out.push('@keyframes dial-marq{to{transform:translateX(-50%)}}');
      rule('.dial-marq-wrap', 'overflow:hidden;-webkit-mask-image:linear-gradient(90deg,transparent,#000 7%,#000 93%,transparent);mask-image:linear-gradient(90deg,transparent,#000 7%,#000 93%,transparent)');
      rule('.dial-marq-track', dd({ 'flex-wrap': 'nowrap', width: 'max-content', 'white-space': 'nowrap', animation: 'dial-marq ' + (v('marquee') || 30) + 's linear infinite' }));
      rule('.dial-marq-wrap:hover .dial-marq-track', dd({ 'animation-play-state': 'paused' }));
    } else if (v('chipMarq') && bake) jsf.push('chip marquee');
    if (v('scrollText') && !bake) {
      rule(sx('srt'), dd({ color: 'transparent', 'background-image': 'linear-gradient(180deg, var(--dial-c) calc(var(--dial-p,0) * 130% - 20%), color-mix(in srgb, var(--dial-c) 22%, transparent) calc(var(--dial-p,0) * 130% + 5%))', '-webkit-background-clip': 'text', 'background-clip': 'text' }));
    } else if (v('scrollText') && bake) jsf.push('scroll text reveal');
    if (v('pageFade') && motionOK) { out.push('@keyframes dial-pagein{from{opacity:0}to{opacity:1}}'); rule('body', dd({ animation: 'dial-pagein .9s ease both' })); }

    /* Texture */
    var pat = v('pattern');
    if (pat && pat !== 'none') {
      var po = (v('patOp') !== null ? v('patOp') : 40) / 100, pc = 'rgba(' + rgbList(normColor(ink || M.ink)) + ',' + (po * 0.32).toFixed(3) + ')', img, size;
      if (pat === 'dots') { img = 'radial-gradient(' + pc + ' 1.2px, transparent 1.7px)'; size = '22px 22px'; }
      if (pat === 'grid') { img = 'linear-gradient(' + pc + ' 1px, transparent 1px), linear-gradient(90deg, ' + pc + ' 1px, transparent 1px)'; size = '36px 36px'; }
      if (pat === 'diagonal') { img = 'repeating-linear-gradient(45deg, ' + pc + ' 0 1px, transparent 1px 14px)'; size = 'auto'; }
      if (pat === 'topo') {
        var paths = ''; for (var i = 0; i < 6; i++) { var yy = 20 + i * 40; paths += "<path d='M-20 " + yy + " C 50 " + (yy - 30) + ", 110 " + (yy + 34) + ", 170 " + yy + " S 280 " + (yy - 26) + ", 300 " + (yy + 6) + "'/>"; }
        img = 'url("data:image/svg+xml,' + encodeURIComponent("<svg xmlns='http://www.w3.org/2000/svg' width='280' height='240' fill='none' stroke='" + pc + "' stroke-width='1.2'>" + paths + '</svg>') + '")'; size = '280px 240px';
      }
      rule(sx('bg') + ',' + sx('band'), dd({ 'background-image': img, 'background-size': size }));
    }
    var dv = v('divider');
    if (dv && dv !== 'none') {
      var lc = 'rgba(' + rgbList(normColor(ink || M.ink)) + ',.16)';
      if (dv === 'line' || dv === 'dashed' || dv === 'dotted') rule(sx('secnext'), dd({ 'border-top': (dv === 'dotted' ? 3 : 1) + 'px ' + (dv === 'line' ? 'solid' : dv) + ' ' + lc }));
      if (dv === 'wave') {
        rule(sx('secnext'), dd({ position: 'relative' }));
        rule(sx('secnext', '::before'), 'content:"";position:absolute;left:0;right:0;top:-1px;height:16px;pointer-events:none;background:url("data:image/svg+xml,' + encodeURIComponent("<svg xmlns='http://www.w3.org/2000/svg' width='80' height='16'><path d='M0 8 Q 20 0 40 8 T 80 8' fill='none' stroke='" + lc + "' stroke-width='2'/></svg>") + '") repeat-x 0 0/80px 16px');
      }
    }
    var lb = v('labels');
    if (lb && lb !== 'off') {
      rule('body', 'counter-reset:dialsec');
      rule(sx('sec'), 'counter-increment:dialsec');
      var lcont = lb === 'num' ? 'counter(dialsec, decimal-leading-zero)' : lb === 'numname' ? 'counter(dialsec, decimal-leading-zero) "  /  " attr(data-dial-label)' : '""';
      rule(sx('sech', '::before'), 'content:' + lcont + ';display:block;margin-bottom:.9em;font-size:.78rem;font-weight:600;line-height:1.2;letter-spacing:.14em;text-transform:uppercase;color:' + acc + (lb === 'dot' ? ';width:10px;height:10px;border-radius:50%;background:' + acc : ''));
    }
    var cur = v('cursor');
    if (cur === 'crosshair') { rule('html,body', dd({ cursor: 'crosshair' })); rule('a,button,summary,label,input,textarea', dd({ cursor: 'pointer' })); }
    if ((cur === 'dot' || cur === 'ring') && !bake) rule('html,html *', dd({ cursor: 'none' }));
    if (v('selection')) rule('::selection', dd({ 'background-color': v('selection'), color: lum(normColor(v('selection')) || v('selection')) > 0.45 ? '#16181d' : '#ffffff' }));
    var sb = v('scrollbar');
    if (sb === 'thin') rule('html', dd({ 'scrollbar-width': 'thin' }));
    if (sb === 'accent') rule('html', dd({ 'scrollbar-color': acc + ' ' + (bg || M.bg) }));
    if (sb === 'hidden') { rule('html', dd({ 'scrollbar-width': 'none' })); out.push('html::-webkit-scrollbar{display:none}'); }
    if (v('focus') === 'accent') rule(':focus-visible', dd({ outline: '3px solid ' + acc, 'outline-offset': '3px' }));
    if (v('focus') === 'soft') rule(':focus-visible', dd({ outline: 'none', 'box-shadow': '0 0 0 4px color-mix(in srgb, ' + acc + ' 38%, transparent)' }));

    /* Extras (never baked) */
    if (!bake) {
      var pf = [];
      if (v('squint')) pf.push('blur(5px)');
      if (v('hue')) pf.push('hue-rotate(' + v('hue') + 'deg)');
      var cvd = v('cvd'); if (cvd && cvd !== 'none') pf.push(cvd === 'achro' ? 'grayscale(1)' : 'url(#dial-' + cvd + ')');
      if (pf.length) rule('body > :not(#dial-host):not(#dial-layer):not(script):not(style)', dd({ filter: pf.join(' ') }));
      if (v('outlines')) rule('body *', dd({ outline: '1px solid rgba(230,40,100,.38)', 'outline-offset': '-1px' }));
      if (v('spotlight')) { rule(sx('sec'), dd({ transition: 'opacity .35s ease' })); rule('body:has([data-dial-sec]:hover) [data-dial-sec]:not(:hover)', dd({ opacity: '.22' })); }
      if (v('ruler')) { rule('[data-dial-long]', dd({ outline: '2px dashed #e5484d', 'outline-offset': '4px' })); rule('[data-dial-short]', dd({ outline: '2px dashed #f5a524', 'outline-offset': '4px' })); }
    } else if (v('hue')) jsf.push('hue shift ' + v('hue') + 'deg (page filter)');
    ['pillNav', 'progress', 'grain', 'cursor'].forEach(function (k) { if (bake && v(k) && v(k) !== 'off' && v(k) !== 'crosshair') jsf.push(k + ': ' + v(k)); });
    JSF = jsf;
    return out.join('\n');
  }

  /* ---------- JS-driven features ---------- */
  var layer, LR, io, scrollRaf = 0;
  function motionOK() { var r = W.matchMedia && W.matchMedia('(prefers-reduced-motion: reduce)').matches; return val('motion') !== 'off' && !(r && val('reduced') !== false); }
  function engineOn() { return motionOK() && (val('entrance') || val('dur') !== null || val('ease') || val('stagger') !== null || val('offset') !== null); }
  var engineSig = '';
  function setupReveal() {
    var on = engineOn(), sig = on ? [val('offset'), val('stagger')].join('|') : '';
    if (!on) { R.classList.remove('dial-mo'); if (io) { io.disconnect(); io = null; } engineSig = ''; return; }
    var st = val('stagger') !== null ? val('stagger') : 80;
    var groups = new Map();
    [].forEach.call(D.querySelectorAll('[data-dial-rv]'), function (e) {
      var sec = e.closest('[data-dial-sec]') || D.body, n = groups.get(sec) || 0; groups.set(sec, n + 1);
      e.style.setProperty('--dial-d', (n % 5) * st + 'ms');
    });
    if (sig === engineSig && io) return;
    engineSig = sig; if (io) io.disconnect();
    var off = val('offset') || 0;
    if (!('IntersectionObserver' in W)) { [].forEach.call(D.querySelectorAll('[data-dial-rv]'), function (e) { e.classList.add('dial-in'); }); return; }
    io = new IntersectionObserver(function (es) { es.forEach(function (e) { if (e.isIntersecting) { e.target.classList.add('dial-in'); io.unobserve(e.target); } }); }, { rootMargin: '0px 0px -' + off + '% 0px', threshold: 0 });
    [].forEach.call(D.querySelectorAll('[data-dial-rv]'), function (e) {
      var r = e.getBoundingClientRect(); if (r.bottom < 0) e.classList.add('dial-in'); else io.observe(e);
    });
    R.classList.add('dial-mo');
  }
  function replayReveal() {
    if (!engineOn()) { setMany({ entrance: val('entrance') || 'rise' }); }
    [].forEach.call(D.querySelectorAll('[data-dial-rv]'), function (e) { e.classList.remove('dial-in'); });
    engineSig = ''; setTimeout(setupReveal, 60);
  }

  function applyOrder() {
    var ord = val('secOrder') || ORIG_ORDER;
    var byId = {}; SECS.forEach(function (s) { byId[s.id] = s; });
    var parents = new Map();
    ord.forEach(function (id) { var s = byId[id]; if (!s) return; var arr = parents.get(s.parent) || []; arr.push(s.el); parents.set(s.parent, arr); });
    parents.forEach(function (list, P) {
      var cur = [].filter.call(P.children, function (k) { return list.indexOf(k) > -1; });
      if (cur.every(function (k, i) { return k === list[i]; })) return;
      var anchor = cur[cur.length - 1].nextSibling;
      list.forEach(function (el) { P.insertBefore(el, anchor); });
    });
  }

  function applyChipMarquee() {
    var on = val('chipMarq') && motionOK();
    [].forEach.call(D.querySelectorAll('[data-dial-chips]'), function (row) {
      var wrapped = row.parentElement && row.parentElement.classList.contains('dial-marq-wrap');
      if (on && !wrapped) {
        var w = D.createElement('div'); w.className = 'dial-marq-wrap'; row.parentElement.insertBefore(w, row); w.appendChild(row);
        row.classList.add('dial-marq-track');
        [].slice.call(row.children).forEach(function (k) { var c = k.cloneNode(true); c.setAttribute('aria-hidden', 'true'); c.setAttribute('data-dial-clone', ''); row.appendChild(c); });
      } else if (!on && wrapped) {
        var p = row.parentElement; p.parentElement.insertBefore(row, p); p.remove();
        row.classList.remove('dial-marq-track'); [].forEach.call(row.querySelectorAll('[data-dial-clone]'), function (c) { c.remove(); });
      }
    });
  }

  function svgFx() {
    if (D.getElementById('dial-svgfx')) return;
    var m = { deuter: '0.625 0.375 0 0 0 0.7 0.3 0 0 0 0 0.3 0.7 0 0 0 0 0 1 0', protan: '0.567 0.433 0 0 0 0.558 0.442 0 0 0 0 0.242 0.758 0 0 0 0 0 1 0', tritan: '0.95 0.05 0 0 0 0 0.433 0.567 0 0 0 0.475 0.525 0 0 0 0 0 1 0' };
    var s = '<svg id="dial-svgfx" xmlns="http://www.w3.org/2000/svg" width="0" height="0" style="position:absolute;width:0;height:0" aria-hidden="true">';
    Object.keys(m).forEach(function (k) { s += '<filter id="dial-' + k + '"><feColorMatrix type="matrix" values="' + m[k] + '"/></filter>'; });
    D.body.insertAdjacentHTML('beforeend', s + '</svg>');
  }

  function buildLayer() {
    layer = D.createElement('div'); layer.id = 'dial-layer';
    layer.setAttribute('style', 'position:absolute;top:0;left:0;width:100%;height:0;overflow:visible;z-index:2147483000;pointer-events:none');
    LR = layer.attachShadow({ mode: 'open' });
    var navItems = SECS.filter(function (s) { return s.el.id; }).slice(0, 6).map(function (s) { return '<a href="#' + s.el.id + '" data-t="' + s.el.id + '">' + esc(s.name.split(' ').slice(0, 2).join(' ')) + '</a>'; }).join('');
    var cta = D.querySelector('[data-dial-btn][href^="#"]');
    var ctaTxt = cta ? cta.textContent.trim().split(/[:.]/)[0].slice(0, 22) : '';
    LR.innerHTML = '<style>' +
      ':host{font-family:inherit;color:inherit}' +
      '.grain{position:fixed;inset:0;pointer-events:none;mix-blend-mode:multiply;display:none;background-image:url("data:image/svg+xml,' + encodeURIComponent("<svg xmlns='http://www.w3.org/2000/svg' width='180' height='180'><filter id='n'><feTurbulence type='fractalNoise' baseFrequency='.85' numOctaves='3' stitchTiles='stitch'/><feColorMatrix values='0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 .6 0'/></filter><rect width='100%' height='100%' filter='url(#n)'/></svg>") + '")}' +
      '.prog{position:fixed;left:0;top:0;height:3px;width:0;background:var(--acc);display:none;z-index:3}' +
      '.pill{position:fixed;left:50%;top:14px;transform:translate(-50%,-140%);display:none;align-items:center;gap:4px;padding:6px;border-radius:999px;background:rgba(255,255,255,.82);backdrop-filter:blur(14px) saturate(1.5);-webkit-backdrop-filter:blur(14px) saturate(1.5);box-shadow:0 10px 30px rgba(10,14,24,.14),0 0 0 1px rgba(10,14,24,.06);pointer-events:auto;transition:transform .45s cubic-bezier(.2,.8,.2,1),opacity .3s;opacity:0;font-size:14px;z-index:2}' +
      '.pill.show{transform:translate(-50%,0);opacity:1}.pill a{color:#1f2638;text-decoration:none;padding:8px 14px;border-radius:999px;font-weight:600;white-space:nowrap}.pill a:hover{background:rgba(10,14,24,.06)}.pill a.on{background:rgba(10,14,24,.08)}.pill a.cta{background:var(--acc);color:var(--acct)}' +
      '.cur{position:fixed;left:0;top:0;width:12px;height:12px;margin:-6px 0 0 -6px;border-radius:50%;background:var(--acc);display:none;z-index:5;transition:width .2s,height .2s,margin .2s,background .2s}.cur.ring{width:34px;height:34px;margin:-17px 0 0 -17px;background:transparent;border:2px solid var(--acc)}.cur.big{width:48px;height:48px;margin:-24px 0 0 -24px;opacity:.35}' +
      '.grid{position:fixed;inset:0;display:none;justify-content:center}.grid>div{display:grid;grid-template-columns:repeat(12,1fr);gap:24px;height:100%;box-sizing:border-box}.grid i{background:rgba(229,72,77,.08);border-left:1px solid rgba(229,72,77,.25);border-right:1px solid rgba(229,72,77,.25)}' +
      '.fold{position:absolute;left:0;right:0;border-top:2px dashed #e5484d;display:none}.fold span{position:absolute;right:12px;top:-24px;font:600 11px/1 system-ui;background:#e5484d;color:#fff;padding:4px 7px;border-radius:4px}' +
      '.badge{position:fixed;left:16px;bottom:16px;display:none;font:600 12px/1.35 system-ui;background:#16181d;color:#fff;padding:10px 12px;border-radius:10px;box-shadow:0 10px 30px rgba(0,0,0,.25);max-width:260px;pointer-events:auto}.badge b{color:#ff8a8a}' +
      '.mob{position:fixed;left:16px;top:16px;display:none;flex-direction:column;background:#16181d;border-radius:18px;padding:10px;box-shadow:0 20px 60px rgba(0,0,0,.35);pointer-events:auto;font:600 12px system-ui;color:#cfd3da}.mob header{display:flex;justify-content:space-between;align-items:center;padding:0 4px 8px}.mob button{all:unset;cursor:pointer;color:#fff;padding:2px 8px;border-radius:6px;background:#2a2e36}.mob .vp{overflow:hidden;border-radius:12px;background:#fff}.mob iframe{border:0;width:390px;height:844px;transform-origin:0 0;display:block}' +
      '</style><div class="grain"></div><div class="prog"></div><nav class="pill" aria-label="Section navigation">' + navItems + (cta ? '<a class="cta" href="' + cta.getAttribute('href') + '">' + esc(ctaTxt) + '</a>' : '') + '</nav>' +
      '<div class="cur"></div><div class="grid"><div><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i></div></div><div class="fold"><span>fold</span></div><div class="badge"></div>' +
      '<div class="mob"><header><span>390 px preview</span><button type="button">Close</button></header><div class="vp"><iframe title="390px preview"></iframe></div></div>';
    D.body.appendChild(layer);
    LR.querySelector('.mob button').addEventListener('click', function () { setMany({ mobile: null }); });
    [].forEach.call(LR.querySelectorAll('.pill a'), function (a) {
      a.addEventListener('click', function (e) { var t = D.querySelector(a.getAttribute('href')); if (t) { e.preventDefault(); t.scrollIntoView({ behavior: motionOK() ? 'smooth' : 'auto' }); } });
    });
    var cur = LR.querySelector('.cur');
    D.addEventListener('mousemove', function (e) {
      if (cur.style.display !== 'block') return;
      cur.style.transform = 'translate(' + e.clientX + 'px,' + e.clientY + 'px)';
      var t = e.target; cur.classList.toggle('big', !!(t && t.closest && t.closest('a,button,summary,input,label')));
    }, { passive: true });
  }

  function applyLayer() {
    if (!LR) return;
    var acc = val('accent') || M.accent;
    layer.style.setProperty('--acc', acc); layer.style.setProperty('--acct', lum(normColor(acc) || acc) > 0.45 ? '#16181d' : '#fff');
    var q = function (s) { return LR.querySelector(s); };
    var g = q('.grain'); g.style.display = val('grain') ? 'block' : 'none'; g.style.opacity = ((val('grain') || 0) / 100 * 0.5).toFixed(3);
    q('.prog').style.display = val('progress') ? 'block' : 'none';
    q('.pill').style.display = val('pillNav') ? 'flex' : 'none';
    var c = q('.cur'), cv = val('cursor'); c.style.display = (cv === 'dot' || cv === 'ring') && !EMBED ? 'block' : 'none'; c.classList.toggle('ring', cv === 'ring');
    var gr = q('.grid'); gr.style.display = val('gridOv') && !EMBED ? 'flex' : 'none';
    var wrapEl = D.querySelector('[data-dial-wrap]');
    if (wrapEl) { var r = wrapEl.getBoundingClientRect(), s = cs(wrapEl); gr.firstChild.style.width = r.width + 'px'; gr.firstChild.style.padding = '0 ' + s.paddingLeft; gr.firstChild.style.marginLeft = 0; gr.style.justifyContent = 'flex-start'; gr.firstChild.style.transform = 'translateX(' + r.left + 'px)'; }
    var fd = q('.fold'); fd.style.display = val('fold') && !EMBED ? 'block' : 'none'; fd.style.top = W.innerHeight + 'px'; fd.firstChild.textContent = 'fold at ' + W.innerHeight + 'px';
    var mob = q('.mob'), ifr = q('iframe');
    if (val('mobile') && !EMBED) {
      var sc = Math.min(1, (W.innerHeight - 70) / 844);
      ifr.style.transform = 'scale(' + sc + ')'; q('.vp').style.width = 390 * sc + 'px'; q('.vp').style.height = 844 * sc + 'px';
      if (!ifr.getAttribute('src')) { ifr.src = location.href.split('#')[0] + '#dial-embed'; ifr.onload = function () { postEmbed(); }; }
      mob.style.display = 'flex'; postEmbed();
    } else { mob.style.display = 'none'; if (ifr.getAttribute('src')) ifr.removeAttribute('src'); }
    var bd = q('.badge');
    if (val('cbadge') && !EMBED) { var ci = contrastInfo(); bd.innerHTML = ci.fail ? '<b>Contrast warning</b><br>' + ci.short : 'Contrast OK<br>' + ci.short; bd.style.display = 'block'; }
    else bd.style.display = 'none';
  }
  function postEmbed() { try { var f = LR && LR.querySelector('iframe'); if (f && f.contentWindow && f.getAttribute('src')) f.contentWindow.postMessage({ dialState: S }, '*'); } catch (e) { } }

  function onScroll() {
    if (scrollRaf) return;
    scrollRaf = requestAnimationFrame(function () {
      scrollRaf = 0; if (!LR) return;
      var vh = W.innerHeight, sh = R.scrollHeight - vh, y = W.scrollY;
      if (val('progress')) LR.querySelector('.prog').style.width = (sh > 0 ? y / sh * 100 : 0) + '%';
      if (val('pillNav')) {
        var pill = LR.querySelector('.pill'); pill.classList.toggle('show', y > vh * 0.5);
        var cur = null; SECS.forEach(function (s) { if (s.el.id && s.el.getBoundingClientRect().top < vh * 0.4) cur = s.el.id; });
        [].forEach.call(pill.querySelectorAll('a[data-t]'), function (a) { a.classList.toggle('on', a.getAttribute('data-t') === cur); });
      }
      if (val('parallax') && motionOK()) {
        var amt = val('parallax');
        [].forEach.call(D.querySelectorAll('[data-dial-img],[data-dial-bgimg]'), function (e) {
          var r = e.getBoundingClientRect(); if (r.bottom < -100 || r.top > vh + 100) return;
          e.style.setProperty('--dial-py', ((r.top + r.height / 2 - vh / 2) * -0.12 * amt).toFixed(1) + 'px');
        });
      }
      if (val('scrollText')) {
        [].forEach.call(D.querySelectorAll('[data-dial-srt]'), function (e) {
          var r = e.getBoundingClientRect(); if (r.bottom < -50 || r.top > vh + 50) return;
          e.style.setProperty('--dial-p', clamp((vh * 0.88 - r.top) / (r.height + vh * 0.4), 0, 1).toFixed(3));
        });
      }
    });
  }

  function applyRuler() {
    [].forEach.call(D.querySelectorAll('[data-dial-long],[data-dial-short]'), function (e) { e.removeAttribute('data-dial-long'); e.removeAttribute('data-dial-short'); });
    if (!val('ruler')) return;
    measureInfo().list.forEach(function (x) { if (x.cpl > 80) x.el.setAttribute('data-dial-long', ''); else if (x.cpl < 38 && x.lines > 1) x.el.setAttribute('data-dial-short', ''); });
  }
  var cvs;
  function measureInfo() {
    var list = [];
    try {
      cvs = cvs || D.createElement('canvas'); var ctx = cvs.getContext('2d');
      [].forEach.call(D.querySelectorAll('[data-dial-para]'), function (p) {
        if (p.tagName !== 'P' || p.textContent.trim().length < 80) return;
        var s = cs(p), r = p.getBoundingClientRect(); if (!r.width) return;
        ctx.font = s.fontWeight + ' ' + s.fontSize + ' ' + s.fontFamily;
        var t = p.textContent.replace(/\s+/g, ' ').trim(), avg = ctx.measureText(t).width / t.length;
        var lines = Math.max(1, Math.round(r.height / (px(s.lineHeight) || px(s.fontSize) * 1.5)));
        var cpl = Math.round(Math.min(r.width, ctx.measureText(t).width) / avg);
        list.push({ el: p, cpl: cpl, lines: lines });
      });
    } catch (e) { }
    var multi = list.filter(function (x) { return x.lines > 1; });
    var avg = multi.length ? Math.round(multi.reduce(function (a, x) { return a + x.cpl; }, 0) / multi.length) : 0;
    var lng = list.filter(function (x) { return x.cpl > 80; }).length;
    return { list: list, html: multi.length ? 'Average <b>' + avg + '</b> characters per line across ' + multi.length + ' paragraphs. ' + (lng ? '<span class="bad">' + lng + ' over 80.</span>' : '<span class="ok">None over 80.</span>') + ' Target 50 to 75.' : 'No long paragraphs found.' };
  }
  function contrastInfo() {
    var rows = [], fail = false;
    function chk(name, el, min) {
      if (!el) return; var s = cs(el), fg = s.color, bg = s.backgroundColor;
      if (!opaque(bg)) bg = effBg(el.parentElement || el);
      if (!parseColor(fg)) return;
      var r = ratio(fg, bg), ok = r >= min; if (!ok) fail = true;
      rows.push({ name: name, r: r, ok: ok });
    }
    chk('Body text', D.querySelector('p[data-dial-ink],[data-dial-para][data-dial-ink]') || D.querySelector('[data-dial-para]'), 4.5);
    chk('Muted text', D.querySelector('[data-dial-muted]'), 4.5);
    chk('Button label', D.querySelector('[data-dial-btn]'), 4.5);
    chk('Heading', D.querySelector('h1'), 3);
    var html = rows.map(function (x) { return x.name + ': <b class="' + (x.ok ? 'ok' : 'bad') + '">' + x.r.toFixed(1) + ':1 ' + (x.ok ? 'pass' : 'fail') + '</b>'; }).join('<br>');
    var short = rows.map(function (x) { return x.name + ' ' + x.r.toFixed(1) + ':1' + (x.ok ? '' : ' (fail)'); }).join('<br>');
    return { html: html || 'Nothing to check.', short: short, fail: fail };
  }

  /* ---------- apply ---------- */
  var applyRaf = 0;
  function apply(now) {
    if (applyRaf && !now) return;
    var run = function () {
      applyRaf = 0;
      try {
        if (val('headFont')) loadFont(val('headFont'));
        if (val('bodyFont')) loadFont(val('bodyFont'));
        if (val('cvd') && val('cvd') !== 'none' && val('cvd') !== 'achro') svgFx();
        ov.textContent = buildCSS(S, false);
        applyOrder(); applyChipMarquee(); setupReveal(); applyLayer(); applyRuler(); onScroll();
        if (!EMBED) { save(); refreshPanel(); postEmbed(); }
      } catch (e) { ERRORS.push('apply: ' + e.message); try { console.warn('[dial] apply failed', e); } catch (x) { } }
    };
    if (now) run(); else applyRaf = requestAnimationFrame(run);
  }
  var HASH_OPEN = null; // panel visibility forced by a test hash is never persisted
  function save() { var ui = UI; if (HASH_OPEN !== null) { ui = JSON.parse(JSON.stringify(UI)); ui.open = HASH_OPEN; } store({ s: S, l: L, p: PRESETS, ab: { a: AB.a, b: AB.b }, ui: ui }); }

  /* history */
  var UNDO = [], REDO = [], pending = null;
  function begin() { if (pending === null) pending = snap(); }
  function commit() { if (pending !== null && pending !== snap()) { UNDO.push(pending); if (UNDO.length > 200) UNDO.shift(); REDO = []; } pending = null; updateHistBtns(); }
  function setMany(o) { begin(); Object.keys(o).forEach(function (k) { if (o[k] === null || o[k] === undefined) delete S[k]; else S[k] = o[k]; }); commit(); apply(); }
  function undo() { if (!UNDO.length) return; REDO.push(snap()); S = JSON.parse(UNDO.pop()); apply(); updateHistBtns(); }
  function redo() { if (!REDO.length) return; UNDO.push(snap()); S = JSON.parse(REDO.pop()); apply(); updateHistBtns(); }

  /* surprise */
  function surprise() {
    var o = {};
    C.forEach(function (c) {
      if (c.noState || L[c.id] || c.r === false || c.r === undefined && c.t !== 'range') return;
      var r = c.r;
      if (c.t === 'range') { if (!Array.isArray(r)) return; var x = r[0] + Math.random() * (r[1] - r[0]); o[c.id] = +(Math.round(x / c.step) * c.step).toFixed(4); }
      else if (c.t === 'select' || c.t === 'color') { if (!Array.isArray(r)) return; o[c.id] = r[Math.floor(Math.random() * r.length)]; }
      else if (c.t === 'toggle') { if (typeof r !== 'number') return; o[c.id] = Math.random() < r; }
    });
    if (!L.headFont && !L.bodyFont && Math.random() < 0.75) { var p = PAIRS[Math.floor(Math.random() * PAIRS.length)]; o.headFont = p[0]; o.bodyFont = p[1]; }
    if (o.btnStyle === 'pill' && !L.rBtn) delete o.rBtn;
    if (!L.rImg && o.rCard !== undefined) o.rImg = o.rCard; if (!L.rFrame && o.rCard !== undefined) o.rFrame = o.rCard;
    if (o.shadow === 'none') { delete o.shBlur; delete o.shY; delete o.shOp; }
    if (o.darkMode) { delete o.band; }
    if (o.ease === 'cubic-bezier(.34,1.56,.64,1)' && o.entrance === 'clip') o.entrance = 'rise';
    setMany(o);
  }

  /* export / import */
  function exportJSON() { return JSON.stringify({ dial: 1, page: location.pathname.split('/').pop(), settings: S, locks: L }, null, 2); }
  function exportCSS() {
    var css = buildCSS(S, true);
    var head = '/* T4 Dial export: ' + (location.pathname.split('/').pop() || 'page') + '\n * Paste at the end of the page <style>, or fold the values into the authored rules.\n * Touched controls: ' + (Object.keys(S).join(', ') || 'none') + '\n' +
      (JSF.length ? ' * JS-driven settings not expressible as CSS (keep dial.js or port by hand): ' + JSF.join('; ') + '\n' : '') +
      (S.headFont || S.bodyFont ? ' * Google Fonts to load: ' + [S.headFont, S.bodyFont].filter(function (f) { return f && !SYSF[f]; }).join(', ') + '\n' : '') + ' */\n';
    return head + css;
  }
  function importJSON(txt) {
    var o = JSON.parse(txt), s = o && (o.settings || o.s || o);
    if (!s || typeof s !== 'object') throw new Error('No settings object');
    var clean = {}; Object.keys(s).forEach(function (k) { if (CI[k] && !CI[k].noState) clean[k] = s[k]; });
    begin(); S = clean; if (o.locks) L = o.locks; commit(); apply(true);
  }

  /* ---------- panel ---------- */
  var host, PR, panelEl;
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  var ICON = {
    lock: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/></svg>',
    unlock: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 7.5-2"/></svg>',
    reset: '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M3 12a9 9 0 1 0 3-6.7"/><path d="M3 3v6h6"/></svg>',
    undo: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M9 14 4 9l5-5"/><path d="M4 9h11a5 5 0 0 1 0 10h-3"/></svg>',
    redo: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="m15 14 5-5-5-5"/><path d="M20 9H9a5 5 0 0 0 0 10h3"/></svg>',
    dice: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><rect x="3" y="3" width="18" height="18" rx="4"/><circle cx="8.5" cy="8.5" r="1.2" fill="currentColor"/><circle cx="15.5" cy="15.5" r="1.2" fill="currentColor"/><circle cx="12" cy="12" r="1.2" fill="currentColor"/></svg>',
    min: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M5 12h14"/></svg>',
    eye: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M3 3l18 18"/><path d="M10.6 5.1A10 10 0 0 1 12 5c6 0 10 7 10 7a17 17 0 0 1-3.2 3.9M6.6 6.6C3.9 8.4 2 12 2 12s4 7 10 7a9.7 9.7 0 0 0 4.4-1"/></svg>'
  };
  var PCSS = ':host{all:initial}' +
    '.p{position:fixed;top:16px;right:16px;width:344px;max-height:calc(100vh - 32px);display:flex;flex-direction:column;background:#15171c;color:#e6e8ec;font:12.5px/1.4 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif;border-radius:14px;box-shadow:0 22px 60px rgba(0,0,0,.38),0 0 0 1px rgba(255,255,255,.07);overflow:hidden;z-index:2147483646;-webkit-font-smoothing:antialiased}' +
    '.p.col .body,.p.col .tabs,.p.col .srch,.p.col .foot,.p.col .out{display:none}' +
    '.hd{display:flex;align-items:center;gap:4px;padding:9px 8px 9px 12px;background:#1b1e24;cursor:move;user-select:none;border-bottom:1px solid #262a31}' +
    '.hd h1{all:unset;font-weight:700;font-size:13px;letter-spacing:.01em;flex:1;display:flex;align-items:baseline;gap:8px;white-space:nowrap}.hd h1 small{font-weight:500;color:#7d8491;font-size:11px}' +
    '.ab{font:700 10px/1 system-ui;padding:3px 6px;border-radius:5px;background:#f2b36b;color:#1a1206;display:none}' +
    '.ib{all:unset;box-sizing:border-box;cursor:pointer;width:26px;height:26px;display:inline-grid;place-items:center;border-radius:7px;color:#9aa1ad}.ib:hover{background:#2a2e36;color:#fff}.ib[disabled]{opacity:.3;pointer-events:none}' +
    '.sp{all:unset;cursor:pointer;display:inline-flex;align-items:center;gap:6px;padding:5px 10px;border-radius:7px;background:#f2b36b;color:#1a1206;font-weight:700;font-size:12px;margin-right:4px;white-space:nowrap}.sp:hover{background:#ffc27f}' +
    '.srch{padding:8px 10px 4px}.srch input{all:unset;box-sizing:border-box;width:100%;background:#1f2229;border:1px solid #2c3039;border-radius:8px;padding:7px 9px;color:#e6e8ec}.srch input:focus{border-color:#f2b36b}' +
    '.tabs{display:flex;flex-wrap:wrap;gap:4px;padding:6px 10px 8px;border-bottom:1px solid #23262d}.tabs button{all:unset;cursor:pointer;padding:4px 8px;border-radius:6px;color:#9aa1ad;font-weight:600;font-size:11.5px}.tabs button:hover{color:#fff;background:#23262d}.tabs button.on{background:#e6e8ec;color:#15171c}.tabs button i{font-style:normal;color:#f2b36b;margin-left:3px}.tabs button.on i{color:#a2560f}' +
    '.body{overflow:auto;flex:1;overscroll-behavior:contain}.body::-webkit-scrollbar{width:8px}.body::-webkit-scrollbar-thumb{background:#2c3039;border-radius:8px}' +
    '.gl{padding:10px 12px 2px;color:#f2b36b;font-weight:700;font-size:10.5px;letter-spacing:.08em;text-transform:uppercase}' +
    '.row{padding:7px 12px 9px;border-bottom:1px solid #1f2228}.top{display:flex;align-items:center;gap:4px;min-height:22px}.top label{flex:1;color:#c5cad3}.row.on .top label{color:#fff;font-weight:600}' +
    '.val{color:#7d8491;font-variant-numeric:tabular-nums;font-size:11.5px;margin-right:2px}.row.on .val{color:#f2b36b}' +
    '.top .ib{width:20px;height:20px;border-radius:5px;color:#5d6470}.top .lk.on{color:#f2b36b}.top .rs{visibility:hidden}.row.on .top .rs{visibility:visible}' +
    '.ctl{margin-top:4px}input[type=range]{width:100%;margin:2px 0;accent-color:#f2b36b;height:16px}' +
    'select,input.tx{all:unset;box-sizing:border-box;width:100%;background:#1f2229;border:1px solid #2c3039;border-radius:7px;padding:5px 8px;color:#e6e8ec;font-size:12px}select{background-image:linear-gradient(45deg,transparent 50%,#7d8491 50%),linear-gradient(135deg,#7d8491 50%,transparent 50%);background-position:calc(100% - 13px) 50%,calc(100% - 9px) 50%;background-size:4px 4px;background-repeat:no-repeat}select option{background:#1f2229;color:#e6e8ec}' +
    '.sw{position:relative;width:34px;height:20px;border-radius:20px;background:#2c3039;cursor:pointer;flex:none;transition:background .15s}.sw::after{content:"";position:absolute;left:3px;top:3px;width:14px;height:14px;border-radius:50%;background:#9aa1ad;transition:transform .15s,background .15s}.sw.on{background:#f2b36b}.sw.on::after{transform:translateX(14px);background:#1a1206}' +
    '.cl{display:flex;align-items:center;gap:6px;flex-wrap:wrap}.cl input[type=color]{all:unset;width:30px;height:22px;border-radius:6px;cursor:pointer;border:1px solid #2c3039}.cl input[type=color]::-webkit-color-swatch-wrapper{padding:0}.cl input[type=color]::-webkit-color-swatch{border:0;border-radius:5px}' +
    '.chip{all:unset;width:18px;height:18px;border-radius:50%;cursor:pointer;box-shadow:inset 0 0 0 1px rgba(255,255,255,.18)}.chip:hover{transform:scale(1.15)}' +
    '.act{all:unset;cursor:pointer;display:block;text-align:center;padding:6px 8px;border-radius:7px;background:#23262d;color:#e6e8ec;font-weight:600}.act:hover{background:#2c3039}' +
    '.ro{color:#aab0bb;font-size:12px;line-height:1.55}.ro b.ok,.ro .ok{color:#7ee2a8}.ro b.bad,.ro .bad{color:#ff8a8a}' +
    '.secl{display:flex;flex-direction:column;gap:3px}.si{display:flex;align-items:center;gap:8px;padding:4px 6px;border-radius:6px;background:#1c1f25}.si.dragging{opacity:.4}.si.over{box-shadow:inset 0 2px 0 #f2b36b}.si .hdl{cursor:grab;color:#5d6470;letter-spacing:-2px}.si span{flex:1;color:#c5cad3}.si input{accent-color:#f2b36b}' +
    '.foot{display:grid;grid-template-columns:1fr 1fr 1fr 1fr;gap:6px;padding:8px 10px;border-top:1px solid #23262d;background:#1b1e24}.foot button{all:unset;cursor:pointer;text-align:center;padding:6px 4px;border-radius:7px;background:#23262d;font-weight:600;font-size:11.5px}.foot button:hover{background:#2c3039}' +
    '.out{display:none;padding:8px 10px;border-top:1px solid #23262d;background:#111317}.out.show{display:block}.out textarea{all:unset;box-sizing:border-box;width:100%;height:120px;background:#1b1e24;border:1px solid #2c3039;border-radius:7px;padding:7px;font:11px/1.45 ui-monospace,Menlo,monospace;color:#cfd3da;white-space:pre;overflow:auto}.out .bar{display:flex;gap:6px;align-items:center;margin-top:6px}.out .bar span{flex:1;color:#7ee2a8}' +
    '.pre{display:flex;gap:6px;padding:10px 12px}.pre input{all:unset;box-sizing:border-box;flex:1;background:#1f2229;border:1px solid #2c3039;border-radius:7px;padding:6px 8px}' +
    '.pr{display:flex;align-items:center;gap:4px;padding:6px 12px;border-bottom:1px solid #1f2228}.pr span{flex:1}.pr button{all:unset;cursor:pointer;padding:3px 7px;border-radius:5px;background:#23262d;font-size:11px;font-weight:600}.pr button.on{background:#f2b36b;color:#1a1206}' +
    '.hint{color:#7d8491;padding:8px 12px;font-size:11.5px}.hint kbd{font:600 10.5px system-ui;background:#2a2e36;border-radius:4px;padding:1px 5px;color:#e6e8ec}' +
    '.help{color:#6d7480;font-size:11px;margin-top:3px}';

  function buildPanel() {
    host = D.createElement('div'); host.id = 'dial-host';
    host.setAttribute('style', 'position:fixed;top:0;left:0;width:0;height:0;z-index:2147483646');
    PR = host.attachShadow({ mode: 'open' });
    PR.innerHTML = '<style>' + PCSS + '</style><div class="p"><div class="hd"><h1>Dial <small>' + SETTING_COUNT + ' controls</small><span class="ab"></span></h1>' +
      '<button class="sp" data-a="surprise" title="Surprise me (locked controls are skipped)">' + ICON.dice + 'Surprise me</button>' +
      '<button class="ib" data-a="undo" title="Undo (Cmd/Ctrl+Z)">' + ICON.undo + '</button><button class="ib" data-a="redo" title="Redo (Shift+Cmd/Ctrl+Z)">' + ICON.redo + '</button>' +
      '<button class="ib" data-a="collapse" title="Collapse">' + ICON.min + '</button><button class="ib" data-a="hide" title="Hide for screenshots (press D to bring back)">' + ICON.eye + '</button></div>' +
      '<div class="srch"><input type="search" placeholder="Search ' + SETTING_COUNT + ' controls" aria-label="Search controls"></div><div class="tabs"></div><div class="body"></div>' +
      '<div class="out"><textarea spellcheck="false"></textarea><div class="bar"><span></span><button class="act" data-a="outapply" style="display:none">Apply import</button><button class="act" data-a="outclose">Close</button></div></div>' +
      '<div class="foot"><button data-a="json" title="Copy settings as JSON">Copy JSON</button><button data-a="css" title="Copy a CSS block of the final values">Copy CSS</button><button data-a="import" title="Paste JSON settings">Import</button><button data-a="resetall" title="Reset every control to authored">Reset all</button></div></div>';
    D.body.appendChild(host);
    panelEl = PR.querySelector('.p');
    PR.addEventListener('click', onPanelClick);
    PR.querySelector('.srch input').addEventListener('input', renderBody);
    dragInit(PR.querySelector('.hd'));
    renderTabs(); renderBody(); placePanel();
  }
  function placePanel() {
    panelEl.classList.toggle('col', !!UI.collapsed);
    host.style.display = UI.open ? '' : 'none';
    if (UI.x !== null && UI.y !== null) { panelEl.style.left = clamp(UI.x, 0, W.innerWidth - 120) + 'px'; panelEl.style.top = clamp(UI.y, 0, W.innerHeight - 40) + 'px'; panelEl.style.right = 'auto'; }
    else { panelEl.style.left = ''; panelEl.style.top = ''; panelEl.style.right = ''; }
    reserveSpace();
  }
  // Docked right + open + expanded: push the page left so the panel never covers it (like DevTools).
  // Collapsed, hidden, or dragged free: page gets its full width back.
  var RES_W = -1, RES_FIX = [];
  function reserveSpace(force) {
    var w = (UI.open && !UI.collapsed && UI.x === null && W.innerWidth > 900) ? 376 : 0;
    if (w === RES_W && !force) return; RES_W = w;
    RES_FIX.forEach(function (o) { o.el.style.left = o.l; o.el.style.right = o.r; o.el.style.maxWidth = o.mw; });
    RES_FIX = [];
    D.documentElement.style.marginRight = w ? w + 'px' : '';
    if (!w) return;
    Array.prototype.forEach.call(D.body.querySelectorAll('*'), function (el) {
      if (inHost(el)) return;
      var cs = W.getComputedStyle(el); if (cs.position !== 'fixed') return;
      RES_FIX.push({ el: el, l: el.style.left, r: el.style.right, mw: el.style.maxWidth });
      var vw = W.innerWidth, avail = vw - w;
      el.style.maxWidth = (avail - 32) + 'px';
      var left = parseFloat(cs.left), centered = cs.transform !== 'none' && Math.abs(left - vw / 2) < 2;
      if (centered) el.style.left = (avail / 2) + 'px';
      else if (cs.right !== 'auto') el.style.right = (parseFloat(cs.right) + w) + 'px';
    });
  }
  W.addEventListener('resize', function () { reserveSpace(true); });
  function dragInit(h) {
    var sx, sy, ox, oy, on = false;
    h.addEventListener('mousedown', function (e) {
      if (e.target.closest('button')) return; on = true; var r = panelEl.getBoundingClientRect(); sx = e.clientX; sy = e.clientY; ox = r.left; oy = r.top; e.preventDefault();
    });
    D.addEventListener('mousemove', function (e) { if (!on) return; UI.x = ox + e.clientX - sx; UI.y = oy + e.clientY - sy; placePanel(); });
    D.addEventListener('mouseup', function () { if (on) { on = false; save(); } });
    h.addEventListener('dblclick', function () { UI.x = UI.y = null; placePanel(); save(); });
  }
  function touchedIn(g) { return C.filter(function (c) { return c.g === g && !c.noState && S[c.id] !== undefined; }).length; }
  function renderTabs() {
    var t = PR.querySelector('.tabs');
    t.innerHTML = GROUPS.concat(['Presets']).map(function (g) { var n = g === 'Presets' ? 0 : touchedIn(g); return '<button data-tab="' + g + '" class="' + (UI.tab === g ? 'on' : '') + '">' + g + (n ? '<i>' + n + '</i>' : '') + '</button>'; }).join('');
  }
  function fmt(c, v) {
    if (v === null || v === undefined) return 'authored';
    if (c.t === 'range') { var d = c.step < 0.01 ? 3 : c.step < 0.1 ? 2 : c.step < 1 ? 1 : 0; return (+v).toFixed(d) + (c.u === 'x' ? 'x' : c.u); }
    if (c.t === 'toggle') return v ? 'on' : 'off';
    if (c.t === 'select') { var o = (c.o || []).filter(function (x) { return x[0] === v; })[0]; return o ? o[1] : v; }
    if (c.t === 'sections') return v.length + ' hidden';
    if (c.t === 'order') return 'custom';
    return String(v);
  }
  function rowHTML(c, showGroup) {
    var v = val(c.id), on = v !== null, iv = on ? v : initOf(c), ctl = '';
    if (c.t === 'range') ctl = '<input type="range" min="' + c.min + '" max="' + c.max + '" step="' + c.step + '" value="' + (iv === null || iv === undefined ? c.min : iv) + '" aria-label="' + esc(c.l) + '">';
    if (c.t === 'select') {
      var groups = {}, order = [];
      c.o.forEach(function (o) { var g = o[2] || ''; if (!groups[g]) { groups[g] = []; order.push(g); } groups[g].push(o); });
      ctl = '<select aria-label="' + esc(c.l) + '"><option value="">Authored</option>' + order.map(function (g) {
        var inner = groups[g].map(function (o) { return '<option value="' + esc(o[0]) + '"' + (o[0] === v ? ' selected' : '') + '>' + esc(o[1]) + '</option>'; }).join('');
        return g ? '<optgroup label="' + g + '">' + inner + '</optgroup>' : inner;
      }).join('') + '</select>';
    }
    if (c.t === 'toggle') ctl = '';
    if (c.t === 'color') ctl = '<div class="cl"><input type="color" value="' + toHex(normColor(iv) || iv) + '" aria-label="' + esc(c.l) + '">' + (c.sw || []).map(function (s) { return '<button class="chip" data-sw="' + s + '" title="' + s + '" style="background:' + s + '"></button>'; }).join('') + '</div>';
    if (c.t === 'text') ctl = '<input class="tx" type="text" value="' + esc(on ? v : c.init) + '" aria-label="' + esc(c.l) + '">';
    if (c.t === 'action') ctl = '<button class="act" data-act="' + c.id + '">' + esc(c.l) + '</button>';
    if (c.t === 'readout') ctl = '<div class="ro">' + c.fn() + '</div>';
    if (c.t === 'sections') { var hid = v || []; ctl = '<div class="secl">' + SECS.map(function (s) { return '<label class="si"><input type="checkbox" data-sec="' + s.id + '"' + (hid.indexOf(s.id) < 0 ? ' checked' : '') + '><span>' + esc(s.name) + '</span></label>'; }).join('') + '</div>'; }
    if (c.t === 'order') { var ord = v || ORIG_ORDER; ctl = '<div class="secl">' + ord.map(function (id) { var s = SECS.filter(function (x) { return x.id === id; })[0]; return s ? '<div class="si" draggable="true" data-oid="' + id + '"><span class="hdl">:::</span><span>' + esc(s.name) + '</span></div>' : ''; }).join('') + '</div>'; }
    var tools = c.noState ? '' : '<span class="val">' + esc(fmt(c, v)) + '</span>' + (c.r === false || c.t === 'sections' || c.t === 'order' ? '' : '<button class="ib lk' + (L[c.id] ? ' on' : '') + '" data-lock="' + c.id + '" title="' + (L[c.id] ? 'Locked: Surprise me skips this' : 'Lock from Surprise me') + '">' + (L[c.id] ? ICON.lock : ICON.unlock) + '</button>') + '<button class="ib rs" data-reset="' + c.id + '" title="Reset to authored">' + ICON.reset + '</button>';
    var sw = c.t === 'toggle' ? '<span class="sw' + ((on ? v : initOf(c)) ? ' on' : '') + '" role="switch" tabindex="0" data-tg="' + c.id + '" aria-checked="' + !!(on ? v : initOf(c)) + '" aria-label="' + esc(c.l) + '"></span>' : '';
    var lab = c.t === 'action' ? '' : '<div class="top"><label>' + (showGroup ? '<span style="color:#7d8491">' + c.g + ' / </span>' : '') + esc(c.l) + '</label>' + tools + sw + '</div>';
    return '<div class="row' + (on ? ' on' : '') + '" data-id="' + c.id + '">' + lab + (ctl ? '<div class="ctl">' + ctl + '</div>' : '') + (c.h ? '<div class="help">' + esc(c.h) + '</div>' : '') + '</div>';
  }
  function renderBody() {
    var b = PR.querySelector('.body'), q = PR.querySelector('.srch input').value.trim().toLowerCase(), html = '';
    if (q) {
      var hits = C.filter(function (c) { return (c.l + ' ' + c.g + ' ' + c.id).toLowerCase().indexOf(q) > -1; });
      html = hits.length ? hits.map(function (c) { return rowHTML(c, true); }).join('') : '<div class="hint">No control matches "' + esc(q) + '".</div>';
    } else if (UI.tab === 'Presets') html = presetsHTML();
    else html = C.filter(function (c) { return c.g === UI.tab; }).map(function (c) { return rowHTML(c, false); }).join('') +
      (UI.tab === 'Extras' ? '<div class="hint">Keys: <kbd>D</kbd> show or hide panel, <kbd>B</kbd> flip A/B presets, <kbd>Cmd/Ctrl+Z</kbd> undo, <kbd>Shift</kbd> to redo. Double-click the header to redock.</div>' : '');
    var st = b.scrollTop; b.innerHTML = html; b.scrollTop = st;
    bindBody(b);
  }
  function presetsHTML() {
    var names = Object.keys(PRESETS);
    return '<div class="pre"><input placeholder="Name this look" aria-label="Preset name"><button class="act" data-a="psave">Save</button></div>' +
      (names.length ? names.map(function (n) {
        return '<div class="pr"><span>' + esc(n) + ' <small style="color:#7d8491">' + Object.keys(PRESETS[n]).length + ' set</small></span><button data-pload="' + esc(n) + '">Load</button><button data-pa="' + esc(n) + '" class="' + (AB.a === n ? 'on' : '') + '">A</button><button data-pb="' + esc(n) + '" class="' + (AB.b === n ? 'on' : '') + '">B</button><button data-pdel="' + esc(n) + '">Delete</button></div>';
      }).join('') : '<div class="hint">No presets yet. Save the current look, tweak, save again.</div>') +
      '<div class="hint">Mark one preset A and another B, then press <kbd>B</kbd> to flip between them.</div>';
  }
  function bindBody(b) {
    [].forEach.call(b.querySelectorAll('.row'), function (row) {
      var id = row.getAttribute('data-id'), c = CI[id]; if (!c) return;
      var inp = row.querySelector('.ctl input[type=range]');
      if (inp) { inp.addEventListener('input', function () { begin(); S[id] = +inp.value; liveRow(row, c); apply(); }); inp.addEventListener('change', commit); }
      var sel = row.querySelector('.ctl select');
      if (sel) sel.addEventListener('change', function () { setMany(kv(id, sel.value || null)); });
      var col = row.querySelector('input[type=color]');
      if (col) { col.addEventListener('input', function () { begin(); S[id] = col.value; liveRow(row, c); apply(); }); col.addEventListener('change', commit); }
      var tx = row.querySelector('input.tx');
      if (tx) tx.addEventListener('change', function () { setMany(kv(id, tx.value.trim() || null)); });
      [].forEach.call(row.querySelectorAll('[data-sec]'), function (cb) {
        cb.addEventListener('change', function () { var hid = (val('secHide') || []).slice(), sid = cb.getAttribute('data-sec'), i = hid.indexOf(sid); if (cb.checked && i > -1) hid.splice(i, 1); if (!cb.checked && i < 0) hid.push(sid); setMany({ secHide: hid.length ? hid : null }); });
      });
      var drag = null;
      [].forEach.call(row.querySelectorAll('[data-oid]'), function (it) {
        it.addEventListener('dragstart', function (e) { drag = it; it.classList.add('dragging'); try { e.dataTransfer.setData('text/plain', it.getAttribute('data-oid')); } catch (x) { } });
        it.addEventListener('dragend', function () { it.classList.remove('dragging'); });
        it.addEventListener('dragover', function (e) { e.preventDefault(); it.classList.add('over'); });
        it.addEventListener('dragleave', function () { it.classList.remove('over'); });
        it.addEventListener('drop', function (e) {
          e.preventDefault(); it.classList.remove('over'); if (!drag || drag === it) return;
          var ord = (val('secOrder') || ORIG_ORDER).slice(), from = ord.indexOf(drag.getAttribute('data-oid')); ord.splice(from, 1);
          ord.splice(ord.indexOf(it.getAttribute('data-oid')), 0, drag.getAttribute('data-oid'));
          setMany({ secOrder: ord.join() === ORIG_ORDER.join() ? null : ord });
        });
      });
    });
  }
  function kv(k, v) { var o = {}; o[k] = v; return o; }
  function liveRow(row, c) { row.classList.add('on'); var vl = row.querySelector('.val'); if (vl) vl.textContent = fmt(c, val(c.id)); }
  var refreshT = 0;
  function refreshPanel() {
    if (!PR) return;
    var active = PR.activeElement;
    if (active && active.matches && active.matches('input[type=range],input[type=color]') && pending !== null) { renderTabs(); return; }
    clearTimeout(refreshT); refreshT = setTimeout(function () { renderTabs(); renderBody(); updateHistBtns(); updateAB(); }, 0);
  }
  function updateHistBtns() { if (!PR) return; PR.querySelector('[data-a=undo]').disabled = !UNDO.length; PR.querySelector('[data-a=redo]').disabled = !REDO.length; }
  function updateAB() { if (!PR) return; var e = PR.querySelector('.ab'); e.style.display = AB.cur ? 'inline-block' : 'none'; e.textContent = AB.cur ? AB.cur.toUpperCase() + ': ' + (AB[AB.cur] || '') : ''; }
  function showOut(text, msg, isImport) {
    var o = PR.querySelector('.out'), ta = o.querySelector('textarea'); o.classList.add('show'); ta.value = text; o.querySelector('.bar span').textContent = msg || '';
    o.querySelector('[data-a=outapply]').style.display = isImport ? '' : 'none'; ta.readOnly = !isImport;
    if (isImport) ta.focus(); else { ta.focus(); ta.select(); }
  }
  function copy(text, label) {
    var done = function (ok) { showOut(text, ok ? label + ' copied to clipboard.' : 'Select all and copy.', false); };
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(text).then(function () { done(true); }, function () { done(legacyCopy(text)); });
      else done(legacyCopy(text));
    } catch (e) { done(legacyCopy(text)); }
  }
  function legacyCopy(t) { try { var a = D.createElement('textarea'); a.value = t; a.style.position = 'fixed'; a.style.opacity = '0'; D.body.appendChild(a); a.select(); var ok = D.execCommand('copy'); a.remove(); return ok; } catch (e) { return false; } }
  function onPanelClick(e) {
    var t = e.target.closest('button,[data-tg],.sw'); if (!t) return;
    var a = t.getAttribute('data-a');
    if (t.hasAttribute('data-tab')) { UI.tab = t.getAttribute('data-tab'); PR.querySelector('.srch input').value = ''; renderTabs(); renderBody(); PR.querySelector('.body').scrollTop = 0; save(); return; }
    if (t.hasAttribute('data-tg')) { var id = t.getAttribute('data-tg'), cur = val(id) !== null ? val(id) : !!initOf(CI[id]); setMany(kv(id, !cur)); return; }
    if (t.hasAttribute('data-reset')) { setMany(kv(t.getAttribute('data-reset'), null)); return; }
    if (t.hasAttribute('data-lock')) { var l = t.getAttribute('data-lock'); if (L[l]) delete L[l]; else L[l] = 1; save(); renderBody(); return; }
    if (t.hasAttribute('data-sw')) { var row = t.closest('.row'); setMany(kv(row.getAttribute('data-id'), t.getAttribute('data-sw'))); return; }
    if (t.hasAttribute('data-act')) { CI[t.getAttribute('data-act')].fn(); return; }
    if (t.hasAttribute('data-pload')) { var n = t.getAttribute('data-pload'); begin(); S = JSON.parse(JSON.stringify(PRESETS[n])); commit(); apply(); return; }
    if (t.hasAttribute('data-pa')) { AB.a = AB.a === t.getAttribute('data-pa') ? null : t.getAttribute('data-pa'); save(); renderBody(); return; }
    if (t.hasAttribute('data-pb')) { AB.b = AB.b === t.getAttribute('data-pb') ? null : t.getAttribute('data-pb'); save(); renderBody(); return; }
    if (t.hasAttribute('data-pdel')) { var dn = t.getAttribute('data-pdel'); delete PRESETS[dn]; if (AB.a === dn) AB.a = null; if (AB.b === dn) AB.b = null; save(); renderBody(); return; }
    if (a === 'psave') { var inp = PR.querySelector('.pre input'), nm = (inp.value || '').trim() || ('Look ' + (Object.keys(PRESETS).length + 1)); PRESETS[nm] = JSON.parse(JSON.stringify(S)); save(); renderBody(); return; }
    if (a === 'surprise') return surprise();
    if (a === 'undo') return undo();
    if (a === 'redo') return redo();
    if (a === 'collapse') { UI.collapsed = !UI.collapsed; placePanel(); save(); return; }
    if (a === "hide") { HASH_OPEN = null; UI.open = false; placePanel(); save(); return; }
    if (a === 'json') return copy(exportJSON(), 'JSON');
    if (a === 'css') return copy(exportCSS(), 'CSS');
    if (a === 'import') return showOut('', 'Paste exported JSON, then Apply.', true);
    if (a === 'outapply') { try { importJSON(PR.querySelector('.out textarea').value); PR.querySelector('.out').classList.remove('show'); } catch (er) { PR.querySelector('.out .bar span').textContent = 'Could not read that JSON: ' + er.message; } return; }
    if (a === 'outclose') { PR.querySelector('.out').classList.remove('show'); return; }
    if (a === 'resetall') { setMany(Object.keys(S).reduce(function (o, k) { o[k] = null; return o; }, {})); return; }
  }
  function flipAB() {
    if (!AB.a || !AB.b || !PRESETS[AB.a] || !PRESETS[AB.b]) return;
    AB.cur = AB.cur === 'a' ? 'b' : 'a'; S = JSON.parse(JSON.stringify(PRESETS[AB[AB.cur]])); apply(); updateAB();
  }
  function onKey(e) {
    var path = e.composedPath ? e.composedPath() : [e.target], t = path[0] || e.target;
    if (t && (t.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName))) return;
    if (e.metaKey || e.ctrlKey) {
      if ((e.key === 'z' || e.key === 'Z') && UI.open) { e.preventDefault(); if (e.shiftKey) redo(); else undo(); }
      return;
    }
    if (e.altKey) return;
    if (e.key === "d" || e.key === "D") { HASH_OPEN = null; UI.open = !UI.open; placePanel(); save(); }
    else if (e.key === 'b' || e.key === 'B') flipAB();
  }

  /* ---------- boot ---------- */
  function boot() {
    try {
      ov = D.createElement('style'); ov.id = 'dial-overrides';
      scan();
      D.head.appendChild(ov);
      var saved = EMBED ? null : store();
      if (saved) { S = saved.s || {}; L = saved.l || {}; PRESETS = saved.p || {}; if (saved.ab) { AB.a = saved.ab.a; AB.b = saved.ab.b; } if (saved.ui) for (var k in saved.ui) UI[k] = saved.ui[k]; }
      if (EMBED) { var par = null; try { par = JSON.parse(localStorage.getItem(KEY) || 'null'); } catch (e) { } S = (par && par.s) || {}; }
      if (HP.dial) { try { var hs = JSON.parse(HP.dial); S = hs.settings || hs; } catch (e) { ERRORS.push('hash state: ' + e.message); } }
      if (HP.dialtab) UI.tab = HP.dialtab;
      if (HP.dialopen) { HASH_OPEN = UI.open; UI.open = HP.dialopen !== "0"; }
      if (HP.dialsearch !== undefined) UI.search = HP.dialsearch;
      Object.keys(S).forEach(function (k) { if (!CI[k] || CI[k].noState) delete S[k]; });
      buildLayer();
      if (!EMBED) {
        buildPanel();
        if (UI.search) { PR.querySelector('.srch input').value = UI.search; renderBody(); }
        D.addEventListener('keydown', onKey);
      } else {
        W.addEventListener('message', function (e) { if (e.data && e.data.dialState) { S = e.data.dialState; delete S.mobile; apply(); } });
      }
      W.addEventListener('scroll', onScroll, { passive: true });
      var rt; W.addEventListener('resize', function () { clearTimeout(rt); rt = setTimeout(function () { remeasure(); apply(); }, 150); });
      apply(true);
      if (HP.dialscroll) { var yy = +HP.dialscroll; R.style.scrollBehavior = "auto"; W.scrollTo(0, yy); R.style.scrollBehavior = ""; onScroll(); }
      if (HP.dialtest === 'roundtrip') roundTrip();
      W.__dial = { version: '1.0.0', controls: C, count: SETTING_COUNT, get state() { return JSON.parse(snap()); }, set: function (o) { setMany(o); }, exportJSON: exportJSON, exportCSS: exportCSS, importJSON: importJSON, reset: function () { setMany(Object.keys(S).reduce(function (o, k) { o[k] = null; return o; }, {})); }, surprise: surprise, errors: ERRORS, measured: M };
    } catch (e) {
      ERRORS.push('boot: ' + e.message);
      try { if (ov) ov.textContent = ''; R.classList.remove('dial-mo'); console.warn('[dial] disabled, page left as authored', e); } catch (x) { }
    }
  }
  function roundTrip() {
    var before = snap(), cssBefore = ov.textContent, json = exportJSON(), bakedCSS = exportCSS();
    setMany(Object.keys(S).reduce(function (o, k) { o[k] = null; return o; }, {})); apply(true);
    var cleared = ov.textContent.trim() === '';
    importJSON(json);
    var after = snap(), cssAfter = ov.textContent;
    var pass = before === after && cssBefore === cssAfter && cleared;
    var res = 'DIAL-RT:' + (pass ? 'PASS' : 'FAIL') + ' keys=' + Object.keys(S).length + ' cssLen=' + cssAfter.length + ' bakedLen=' + bakedCSS.length + ' clearedEmpty=' + cleared + ' errors=' + ERRORS.length + ' controls=' + SETTING_COUNT;
    D.title = res; R.setAttribute('data-dial-test', res);
    try { console.log(res); } catch (e) { }
  }
  if (D.readyState === 'loading') D.addEventListener('DOMContentLoaded', boot); else boot();
})();
