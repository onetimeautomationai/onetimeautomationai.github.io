# Design Review Checklist

Run this before showing anything. Tick every line or say why not.

- [ ] I changed only what was asked.
- [ ] Brand colors, fonts, logo and copy are unchanged, unless the owner asked for a change.
- [ ] Body text is left-aligned and readable at 18px with 1.7 line height.
- [ ] Sizes were measured against the reference, not guessed.
- [ ] I took a desktop screenshot and a 390px phone screenshot, and I looked at both.
- [ ] The phone screenshot has no sideways scroll and no cut-off text.
- [ ] Placeholders and sample content are labeled. None can ship by accident.
- [ ] Every block shares the same left and right edge.
- [ ] Nothing was deployed or published.
- [ ] My last line says exactly what changed and what I did not check.

If any box is empty, fix it before you show the work. A screenshot you did not look at does not count.
