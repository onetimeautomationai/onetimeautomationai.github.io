# Learning Log

Every correction from the owner becomes a row here, the same turn it is given. If the same lesson appears twice, promote it into `playbook.md`.

| Date | What went wrong | Rule it implies | Owner's words | Promoted to playbook? |
|---|---|---|---|---|
|  |  |  |  |  |
|  |  |  |  |  |
|  |  |  |  |  |
