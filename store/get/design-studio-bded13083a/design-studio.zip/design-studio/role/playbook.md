# Design Playbook

Starter rules that apply to most projects. Add your own as you correct the agent. Newest rules go at the bottom of each group.

## A. Scope discipline

1. Do exactly the change asked. "Clean up margins and sizes" means margins and sizes only. Do not touch colors, fonts, centering, copy or structure on the side.
2. "Make it like this reference" means borrow the layout and structure. Keep your own brand colors, fonts, logo and copy unless told to take those too.
3. Left-align body text. Center only short headings and buttons. Readability beats style.
4. Anything not asked stays untouched. Report what changed in the same words the owner used.

## B. Measure, do not eyeball

5. Match sizes by measuring both pages in the same window. Some pages lay out at a scaled width, so a screenshot can mislead.
6. Read the reference's real source when you own it. For other sites, screenshot at the same width and scroll the whole page first.
7. After every change, screenshot desktop and 390px phone. Say what you checked and what you did not.

## C. Reference-driven builds

8. Capture the reference's structure first: header, hero split, proof bar, section rhythm, card shapes, button shape and spacing scale. Rebuild that skeleton with your own content.
9. If the copy is thin for a section the reference has, do not invent copy. Reuse existing lines, or leave the section out and say so.
10. Content supplied later (video, quotes, photos) gets a clearly labeled placeholder and an HTML comment marking where it goes. Sample content carries a visible "SAMPLE" tag and must be removed before publishing.

## D. Landing page conversion frame

11. Above the fold: logo and button in the header, proof, a headline that names the outcome, a sub headline, one main button, a line that reduces fear, and one image or video.
12. Scan test: the headlines alone must carry the benefit.
13. Real proof is named, photographed and sourced. No anonymous quotes. No reviews hidden in carousels or dropdowns.
14. One main action per page. The main button gets the most contrast.
15. Familiar layout beats clever layout.

## E. Build standards

16. Base type is 18px with 1.7 line height, set in the base CSS.
17. Every block shares one left and right edge. Only text lines may be narrower.
18. Keep vertical rhythm tight. Section padding around 56px, no dead space.
19. In a split hero, media fills the full height of the text column. Never center a fixed-ratio box against taller text.
20. Video stays 16:9. Fix blank space by restructuring the text, never by stretching the media.
21. Lead forms go in a popup or a separate page, not inline in the page flow.
22. Fonts must look professional. A system font stack beats a trendy display face.
23. Motion is tasteful and uses transform and opacity only. It respects reduced-motion settings.
24. Check contrast on every derived grey. Compute it against the worst case.
25. Fetch and confirm the real logo file. Never guess a file name.

## F. Test mechanics

26. A layout rule such as `display:grid` beats the `hidden` attribute. Add `[hidden]{display:none!important}`.
27. A tweak bar like the dial intercepts clicks and covers screenshots. Remove or stub it when you test the shipping page.
28. Lazy images stay blank in a no-scroll full-page capture. Scroll the page first.
29. Score the fold from a screenshot and measured pixel positions, never from the plan.
30. At phone width, a button says what the visitor gets and stays on one line at 390px.
