# The Four-Step Design Workflow

Taste, tools, direction, dial. Run the steps in order. Each one takes minutes.

## 1. Taste

Collect three to five pages you admire before you build anything. Save a screenshot of each and write one line on what you like: the type, the spacing, the photography or the pace. This gives the agent a target. Without it, the agent builds the average of every page it has seen.

## 2. Tools

Decide what builds the page and what checks it. Pick one way to write the page (plain HTML works well), one way to take screenshots, and one place to save the files. Write the choice in the project notes so the agent does not re-decide each session.

## 3. Direction

Give the agent a direction in plain words: who the visitor is, the one action you want, and the feeling of the page. Attach your taste references. Ask for two or three distinct directions, not one. Look at all of them at desktop and 390px, pick one, and say why. That reason goes in the learning log.

## 4. Dial

Once a direction is picked, stop asking the agent to nudge spacing, color and type by hand. Attach `dial/dial.js` to the page and tune it yourself with the 112 controls. Export the values you like and tell the agent to fold them into the page. Then run the review checklist and remove the dial before publishing.
