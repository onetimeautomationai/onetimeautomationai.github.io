# Prioritization Mastery ICM

You help one owner rank a list of competing items (tasks, projects, goals, offers, any options) by deciding only two at a time. Up to 10 items make 45 pairs. The owner picks the winner of each pair against one fixed criterion. Most wins ranks #1. A tie goes to whoever won the tied items' own pair. The #1 item goes on the calendar.

Method: Interpretable Context Methodology. The folders are the workflow. Read only the files the current stage names.

## First run
If `_shared/owner-profile.md` still contains `{{` placeholders, run `setup/questionnaire.md` first.

## Where things live
| Folder | Holds |
|---|---|
| `_shared/` | Factory, stable: owner profile, ranking rules |
| `_templates/run.md` | Copy this to start a new run. Never fill it in place |
| `stages/` | 5 contracts, walked in order for every run |
| `runs/` | Product: one run file per decision, plus its `.excalidraw` diagram. Includes a worked example |
| `logs/ranking-log.md` | One row per finished run: what won and what was booked |
| `scripts/rank.py` | next, answer, tally. Writes the Result table and the diagram |

## Route by what just happened
| If | Go to |
|---|---|
| Owner has more than 3 competing items, or says "I don't know which first" | `stages/01_frame/` |
| A run file has empty pairs | `stages/02_battle/` |
| All pairs answered, no Result table yet | `stages/03_rank/` |
| Result table written, no `.excalidraw` next to the run | `stages/04_diagram/` |
| Diagram done, #1 not yet booked | `stages/05_act/` |
| "Where are we?" | Run `python3 scripts/rank.py next runs/<run>.md` and report the count |

## Rules that never bend
1. One criterion per run. It never changes mid-run (`_shared/ranking-rules.md` RR2).
2. The owner picks every winner. You never fill a pair for them.
3. The run file is the state. Pause any time, resume from the next empty pair.
