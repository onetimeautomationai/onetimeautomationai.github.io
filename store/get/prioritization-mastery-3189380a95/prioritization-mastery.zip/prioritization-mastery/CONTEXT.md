# Workspace definition

**Repeating unit:** a run. One run = one list, one criterion, one ranking, one booked #1.

| # | Stage | Output | Human gate |
|---|---|---|---|
| 01 | frame | `runs/<run>.md` with items and criterion filled | Owner approves the list and the criterion |
| 02 | battle | Every pair in the run file has a winner letter | Owner answers every pair (that is the whole stage) |
| 03 | rank | `## Result` table in the run file | Owner reads the order and says if it feels wrong |
| 04 | diagram | `runs/<run>.excalidraw` | Owner opens it once |
| 05 | act | #1 on the calendar + `logs/ranking-log.md` row | Owner confirms the calendar slot |

**Factory:** `_shared/`, `_templates/`, `scripts/`. **Product:** `runs/`, `logs/`.

**Status is in the files.** Empty pairs mean stage 02. No Result table means stage 03. No `.excalidraw` means stage 04. No log row means stage 05.

Pairs with the **AI Time Manager** ICM: stage 05 hands #1 to its slot stage. Pairs with the **AI Leadership Team** ICM: the CEO agent can call a run whenever its inbox holds more than 3 competing ideas.
