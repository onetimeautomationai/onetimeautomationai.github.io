# Prioritization Mastery ICM (exportable)

A folder you drop into your AI operating system. When you have too many competing things and can't pick what comes first, your AI runs a Prioritization Mastery with you:

- You list up to 10 items (A to J) and pick **one question** to judge them by, for example "Which one moves my #1 goal forward most?"
- Your AI shows you **two items at a time**, 9 pairs per message. You reply with one string of letters, like `ACADAEAFG`. 10 items take 45 pairs, about 5 replies.
- Pause any time. The answers live in the run file, so you resume exactly where you stopped.
- When every pair is answered, a script **counts the wins**. Most wins is #1. A tie goes to whichever of the two won their own pair.
- It draws an **Excalidraw diagram**: the triangular winner grid, the totals and rank, and the ranked list with arrows, top 3 highlighted.
- Your AI puts **#1 on your calendar**. Everything else waits for your weekly review.

This is also known as a pairwise prioritization matrix or paired comparison analysis.

## Install
1. Copy this folder into your AI workspace. Point your agent at `CLAUDE.md` (rename it `AGENTS.md` if your tool expects that).
2. Say "run setup". The agent walks `setup/questionnaire.md` (6 questions) and fills `_shared/owner-profile.md`.
3. Make sure your agent can run Python 3.8+. `scripts/rank.py` uses only the standard library.
4. Optional: give your agent calendar access so stage 05 can book #1 for you. Without it, the agent tells you exactly what to add.
5. Look at `runs/example-home-projects.md` and its `.excalidraw` to see a finished run. Delete them once you have your own.

No folder support? Paste `INJECT-PROMPT.md` into your AI's custom instructions. The AI then keeps the grid in the chat and draws the result as a table.

## The 5 stages
| # | Stage | You do |
|---|---|---|
| 01 | frame | Approve the list and the question |
| 02 | battle | Pick a winner in every pair |
| 03 | rank | Read the order |
| 04 | diagram | Open the picture once |
| 05 | act | Confirm the slot for #1 |

## Why it works
- Choosing between two things is easy. Choosing among ten causes paralysis. Pairs remove the paralysis.
- One fixed question keeps every choice comparable. Change the question and you start a new run.
- Every item fights every other item once, so the ranking reflects 45 small honest calls instead of one big guess.
- Booking only #1 turns the ranking into action today and leaves room for the list to change by next week.

## Credit
The method comes from JashiiCorrin, "My Favourite Prioritisation Tool": https://www.youtube.com/watch?v=4eiZKX89U_s. The worked example uses the video's home projects idea.

Workspace method: Interpretable Context Methodology (Van Clief & McDermott, arXiv:2603.16021). Pairs with the **AI Time Manager** and **AI Leadership Team** ICMs.
