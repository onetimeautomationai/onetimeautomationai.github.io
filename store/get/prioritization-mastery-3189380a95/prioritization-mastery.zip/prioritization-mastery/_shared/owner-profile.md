---
type: factory
filled_by: setup/questionnaire.md
---

# Owner profile (ranking)

If the AI Leadership Team or AI Time Manager ICM is installed, put its profile path here instead and keep one copy: {{path or "this file"}}

- **Owner name:** {{name}}
- **#1 goal (number + deadline):** {{goal 1}}
- **Default criterion:** {{Which one moves my #1 goal forward most?}}
- **Where #1 gets booked:** {{e.g. the next deep work block on the work calendar}}
- **Weekly review day:** {{e.g. Sunday}}
- **Batch size:** {{9 pairs per message, or fewer}}

## When to offer a run
- {{e.g. more than 3 competing projects at once}}
- {{e.g. the weekly review, to rank the idea inbox}}
- {{e.g. picking between offers, hires, vendors}}
