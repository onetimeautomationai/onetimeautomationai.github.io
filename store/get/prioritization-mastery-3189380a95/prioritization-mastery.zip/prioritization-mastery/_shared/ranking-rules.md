---
type: factory
---

# Ranking rules

- **RR1. Two at a time, never the full list.** Choosing between A and B is easy. Choosing among A to J causes paralysis. Only ever show pairs.
- **RR2. One criterion, fixed up front.** More important, more urgent, or better for one named goal. Write it at the top of the run file. It never changes mid-run. If the owner wants a different question, start a new run.
- **RR3. Every pair once.** 10 items make 45 pairs. Each item fights 9 battles, so it scores 0 to 9 wins. N items make N x (N - 1) / 2 pairs.
- **RR4. Cap at 10.** Cut the list to 10 before the run starts. Merge duplicates and drop anything already decided.
- **RR5. No ties inside a pair.** The owner must pick one letter. If they stall, ask "If you could only do one this week, which?"
- **RR6. Wins = rank.** Most wins is #1.
- **RR7. Tie-break by head-to-head.** If two items have the same wins, the one that won their own pair ranks higher. In a three-way loop, the script falls back to letter order. Say so and let the owner choose.
- **RR8. Batches of 9.** Show 9 pairs per message, numbered in file order. The owner replies with one string of letters, for example `ACADAEAFG`. A letter that is not in its pair stops the write.
- **RR9. The template stays clean.** Copy `_templates/run.md` for each run. Never fill the template itself.
- **RR10. Only #1 gets booked now.** The rest wait for the weekly review, where the list may have changed.
