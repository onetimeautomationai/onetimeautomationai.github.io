---
type: ranking-run
status: framing
created: {{YYYY-MM-DD}}
criterion: "{{Which one moves my #1 goal forward most?}}"
---

# Run {{N}}: {{the decision in a few words}}

Criterion for every pair: **{{Which one moves my #1 goal forward most?}}** Pick one letter per pair. No ties.

## Items

Up to 10. Fewer is fine: delete the unused rows here. The script ignores pairs that name a missing letter.

| Key | Item |
|---|---|
| A | {{item}} |
| B | {{item}} |
| C | {{item}} |
| D | {{item}} |
| E | {{item}} |
| F | {{item}} |
| G | {{item}} |
| H | {{item}} |
| I | {{item}} |
| J | {{item}} |

## Head-to-head (winner letter)

Keep this order. The script fills the next empty rows in order, 9 per batch.

| Pair | Winner |
|---|---|
| A-B |  |
| A-C |  |
| A-D |  |
| A-E |  |
| A-F |  |
| A-G |  |
| A-H |  |
| A-I |  |
| A-J |  |
| B-C |  |
| B-D |  |
| B-E |  |
| B-F |  |
| B-G |  |
| B-H |  |
| B-I |  |
| B-J |  |
| C-D |  |
| C-E |  |
| C-F |  |
| C-G |  |
| C-H |  |
| C-I |  |
| C-J |  |
| D-E |  |
| D-F |  |
| D-G |  |
| D-H |  |
| D-I |  |
| D-J |  |
| E-F |  |
| E-G |  |
| E-H |  |
| E-I |  |
| E-J |  |
| F-G |  |
| F-H |  |
| F-I |  |
| F-J |  |
| G-H |  |
| G-I |  |
| G-J |  |
| H-I |  |
| H-J |  |
| I-J |  |
