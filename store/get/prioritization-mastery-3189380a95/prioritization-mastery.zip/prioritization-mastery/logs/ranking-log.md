# Ranking log

| Date | Run file | Criterion | #1 | Booked slot | Parked for review |
|---|---|---|---|---|---|
| 2026-01-16 | runs/example-home-projects.md | Which one moves my #1 goal forward most? | B: Fix the leak in the bathroom | Saturday 9:00 to 11:00 | A, G, D, H, F, E, I, C, J |
