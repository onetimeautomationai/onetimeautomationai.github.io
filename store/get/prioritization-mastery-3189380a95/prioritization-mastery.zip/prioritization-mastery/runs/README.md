# runs

One file per decision, copied from `../_templates/run.md` and named `YYYY-MM-DD-<short-name>.md`. The `.excalidraw` with the same name is its diagram, written by `scripts/rank.py tally`.

`example-home-projects.md` is a finished worked example: 10 home projects ranked against "Which one moves my #1 goal forward most?" with the goal "Get the house ready for summer". It shows two ties broken by head-to-head (A over G on 7 wins, D over H on 6 wins). Delete it once you have run your own.
