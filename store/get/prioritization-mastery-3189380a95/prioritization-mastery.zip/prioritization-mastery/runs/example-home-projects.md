---
type: ranking-run
status: done
created: 2026-01-16
goal: "Get the house ready for summer"
criterion: "Which one moves my #1 goal forward most?"
---

# Run 1 (worked example): which home project first

Goal: get the house ready for summer. Criterion for every pair: **Which one moves my #1 goal forward most?** Pick one letter per pair. No ties.

Home projects example from the method's source video (JashiiCorrin, "My Favourite Prioritisation Tool").

## Items

| Key | Item |
|---|---|
| A | Get the air conditioner serviced |
| B | Fix the leak in the bathroom |
| C | Wash the curtains |
| D | Clean the gutters |
| E | Repaint the front door |
| F | Declutter the garage |
| G | Replace the smoke alarm batteries |
| H | Reseal the deck |
| I | Organize the pantry |
| J | Fix the squeaky closet door |

## Head-to-head (winner letter)

Keep this order. The script fills the next empty rows in order, 9 per batch.

| Pair | Winner |
|---|---|
| A-B | B |
| A-C | A |
| A-D | A |
| A-E | A |
| A-F | A |
| A-G | A |
| A-H | H |
| A-I | A |
| A-J | A |
| B-C | B |
| B-D | B |
| B-E | B |
| B-F | B |
| B-G | B |
| B-H | B |
| B-I | B |
| B-J | B |
| C-D | D |
| C-E | E |
| C-F | F |
| C-G | G |
| C-H | H |
| C-I | I |
| C-J | C |
| D-E | D |
| D-F | D |
| D-G | G |
| D-H | D |
| D-I | D |
| D-J | D |
| E-F | F |
| E-G | G |
| E-H | H |
| E-I | E |
| E-J | E |
| F-G | G |
| F-H | H |
| F-I | F |
| F-J | F |
| G-H | G |
| G-I | G |
| G-J | G |
| H-I | H |
| H-J | H |
| I-J | I |

## Result

| Rank | Item | Wins |
|---|---|---|
| 1 | B: Fix the leak in the bathroom | 9 |
| 2 | A: Get the air conditioner serviced | 7 |
| 3 | G: Replace the smoke alarm batteries | 7 |
| 4 | D: Clean the gutters | 6 |
| 5 | H: Reseal the deck | 6 |
| 6 | F: Declutter the garage | 4 |
| 7 | E: Repaint the front door | 3 |
| 8 | I: Organize the pantry | 2 |
| 9 | C: Wash the curtains | 1 |
| 10 | J: Fix the squeaky closet door | 0 |
