# scripts

`rank.py` walks and scores a run file. Python 3.8+, standard library only.

| Command | Does |
|---|---|
| `python3 scripts/rank.py next runs/<run>.md [N]` | Prints answered count and the next N empty pairs (default 9) |
| `python3 scripts/rank.py answer runs/<run>.md LETTERS` | Fills the next empty pairs in order. Stops at a letter that is not in its pair |
| `python3 scripts/rank.py tally runs/<run>.md` | Writes the `## Result` table into the run file and builds `runs/<run>.excalidraw` |

- The run file must keep the template's table shapes: `| A | item |` rows and `| A-B | winner |` rows.
- Pairs that name a letter with no item row are ignored, so shorter lists work.
- `tally` refuses to run while any pair is empty.
- Running `tally` again replaces the old Result table and diagram.
