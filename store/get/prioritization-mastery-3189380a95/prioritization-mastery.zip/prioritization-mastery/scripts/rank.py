#!/usr/bin/env python3
"""rank.py: Prioritization Mastery (pairwise prioritization matrix, paired comparison analysis).

Usage:
  rank.py next   RUN.md [N]      print the next N unanswered pairs (default 9)
  rank.py answer RUN.md LETTERS  fill the next unanswered pairs in order with LETTERS (for example "BACAE")
  rank.py tally  RUN.md          count wins, rank (tie-break by head-to-head), write the Result table + RUN.excalidraw

A run file is markdown with an items table `| A | item text |` and a pairs table `| A-B | winner |`.
Copy _templates/run.md to start one. Fewer than 10 items is fine: pairs that name a missing item are ignored.
Needs Python 3.8+ and nothing else."""
import json, re, sys, os

ITEM = re.compile(r"^\| ([A-J]) \| (.+?) \|\s*$")
PAIR = re.compile(r"^\| ([A-J])-([A-J]) \| ([A-J]?) \|\s*$")


def load(path):
    lines = open(path).read().split("\n")
    items, pairs = {}, {}
    for i, l in enumerate(lines):
        if m := PAIR.match(l):
            pairs[(m[1], m[2])] = (m[3], i)
        elif m := ITEM.match(l):
            items[m[1]] = m[2].strip()
    pairs = {p: v for p, v in pairs.items() if p[0] in items and p[1] in items}
    return lines, items, pairs


def label(items, k):
    return f"{k} ({items[k]})"


def cmd_next(path, n=9):
    _, items, pairs = load(path)
    todo = [p for p, (w, _) in pairs.items() if not w]
    print(f"{len(pairs) - len(todo)}/{len(pairs)} answered")
    for a, b in todo[:n]:
        print(f"{a}-{b}: {label(items, a)}  vs  {label(items, b)}")


def cmd_answer(path, letters):
    lines, items, pairs = load(path)
    todo = [p for p, (w, _) in pairs.items() if not w]
    letters = re.sub(r"[^A-Ja-j]", "", letters).upper()
    for (a, b), w in zip(todo, letters):
        if w not in (a, b):
            sys.exit(f"STOP: {w} is not in pair {a}-{b}. Nothing after it was written.")
        lines[pairs[(a, b)][1]] = f"| {a}-{b} | {w} |"
        open(path, "w").write("\n".join(lines))
    cmd_next(path)


def rank(items, pairs):
    wins = {k: 0 for k in items}
    for (a, b), (w, _) in pairs.items():
        if w:
            wins[w] += 1

    def beats(x, y):
        w = pairs.get((x, y), pairs.get((y, x), ("", 0)))[0]
        return 1 if w == x else 0

    order = sorted(items, key=lambda k: (-wins[k], -sum(beats(k, o) for o in items if o != k and wins[o] == wins[k]), k))
    return wins, order


def excalidraw(items, pairs, wins, order, out):
    els, seed = [], 1
    base = {"angle": 0, "fillStyle": "solid", "strokeWidth": 1, "strokeStyle": "solid", "roughness": 0,
            "opacity": 100, "groupIds": [], "roundness": None, "version": 1, "isDeleted": False,
            "boundElements": None, "updated": 1, "link": None, "locked": False, "frameId": None}

    def rect(x, y, w, h, bg="transparent", stroke="#1e1e1e"):
        nonlocal seed
        seed += 1
        els.append({**base, "type": "rectangle", "id": f"r{seed}", "x": x, "y": y, "width": w, "height": h,
                    "strokeColor": stroke, "backgroundColor": bg, "seed": seed, "versionNonce": seed})

    def text(x, y, s, size=18, color="#1e1e1e"):
        nonlocal seed
        seed += 1
        els.append({**base, "type": "text", "id": f"t{seed}", "x": x, "y": y,
                    "width": max(20, len(s) * size * 0.55), "height": size * 1.3, "strokeColor": color,
                    "backgroundColor": "transparent", "seed": seed, "versionNonce": seed, "text": s,
                    "fontSize": size, "fontFamily": 2, "textAlign": "left", "verticalAlign": "top",
                    "containerId": None, "originalText": s, "lineHeight": 1.25})

    def arrow(x, y, h):
        nonlocal seed
        seed += 1
        els.append({**base, "type": "arrow", "id": f"a{seed}", "x": x, "y": y, "width": 0, "height": h,
                    "strokeColor": "#868e96", "backgroundColor": "transparent", "seed": seed,
                    "versionNonce": seed, "points": [[0, 0], [0, h]], "lastCommittedPoint": None,
                    "startBinding": None, "endBinding": None, "startArrowhead": None, "endArrowhead": "arrow"})

    keys, C = sorted(items), 56
    text(0, -60, "Prioritization Mastery: winner of each pair", 24)
    for j, b in enumerate(keys):          # rows
        for i, a in enumerate(keys):      # columns
            if i < j:
                w = pairs[(a, b)][0]
                top = order.index(w) < 3 if w else False
                rect(i * C, j * C, C, C, "#ffd8a8" if top else "#f8f9fa")
                text(i * C + 20, j * C + 16, w or "?", 20)
            elif i == j:
                rect(i * C, j * C, C, C, "#a5d8ff")
                text(i * C + 20, j * C + 16, a, 20)
    y = len(keys) * C + 10
    for i, k in enumerate(keys):
        text(i * C + 18, y, str(wins[k]), 18, "#1971c2")
        text(i * C + 14, y + 30, f"#{order.index(k) + 1}", 16, "#e8590c")
    text(-90, y, "Total", 16)
    text(-90, y + 30, "Rank", 16)
    x0 = len(keys) * C + 80
    text(x0, -60, "Ranked: do in this order", 24)
    for r, k in enumerate(order):
        rect(x0, r * 52, 620, 44, "#ffd8a8" if r < 3 else "#ffffff")
        text(x0 + 12, r * 52 + 11, f"{r + 1}. {k}  {items[k][:52]}  ({wins[k]} wins)", 18)
        if r:
            arrow(x0 - 20, (r - 1) * 52 + 22, 52)
    json.dump({"type": "excalidraw", "version": 2, "source": "prioritization-mastery", "elements": els,
               "appState": {"viewBackgroundColor": "#ffffff", "gridSize": None}, "files": {}},
              open(out, "w"), indent=1)


def cmd_tally(path):
    lines, items, pairs = load(path)
    open_ = [f"{a}-{b}" for (a, b), (w, _) in pairs.items() if not w]
    if open_:
        sys.exit(f"STOP: {len(open_)} pairs unanswered: {', '.join(open_[:10])}")
    wins, order = rank(items, pairs)
    res = ["## Result", "", "| Rank | Item | Wins |", "|---|---|---|"] + \
          [f"| {r + 1} | {k}: {items[k]} | {wins[k]} |" for r, k in enumerate(order)]
    body = "\n".join(lines)
    body = re.sub(r"\n## Result\n.*?(?=\n## |\Z)", "", body, flags=re.S).rstrip() + "\n\n" + "\n".join(res) + "\n"
    open(path, "w").write(body)
    out = os.path.splitext(path)[0] + ".excalidraw"
    excalidraw(items, pairs, wins, order, out)
    print("\n".join(res))
    print("diagram:", out)


if __name__ == "__main__":
    if len(sys.argv) < 3 or sys.argv[1] not in ("next", "answer", "tally"):
        sys.exit(__doc__)
    c, p = sys.argv[1], sys.argv[2]
    {"next": lambda: cmd_next(p, int(sys.argv[3]) if len(sys.argv) > 3 else 9),
     "answer": lambda: cmd_answer(p, sys.argv[3]), "tally": lambda: cmd_tally(p)}[c]()
