# Setup questionnaire

Ask a few at a time. Write the answers into `../_shared/owner-profile.md`.

1. What is your #1 goal, with a number and a deadline?
2. What question should every pair be judged on by default? (Suggested: "Which one moves my #1 goal forward most?")
3. When #1 is picked, where should it go on your calendar? (For example: the next deep work block.)
4. Which weekday is your weekly review? The rest of each ranking waits for it.
5. How many pairs do you want per message? (9 is the default. 45 pairs then take 5 replies.)
6. When should the agent offer a run without being asked? (For example: more than 3 competing projects, picking between offers, the weekly review.)
