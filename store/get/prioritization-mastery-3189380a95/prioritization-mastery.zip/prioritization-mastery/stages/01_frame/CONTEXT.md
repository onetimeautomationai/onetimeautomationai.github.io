# 01_frame: set the list and the question

One job: a new run file with up to 10 items (A to J) and one fixed criterion, approved by the owner.

## Inputs
- Working: the owner's dump of competing items (a message, a backlog, an idea inbox)
- Reference: `../../_shared/owner-profile.md` (goal and default criterion), `../../_shared/ranking-rules.md` (RR2, RR4, RR9)
- Template: `../../_templates/run.md`

Do NOT load: past runs, the logs, the script.

## Process
1. Draft the list. Merge duplicates, drop anything already decided, cut to 10 (RR4). Write each item as a short action the owner would recognize.
2. Propose the criterion. Default to the owner's from the profile, for example "Which one moves my #1 goal forward most?" One criterion only (RR2).
3. Show both. The owner may swap, add or cut any item, and may rewrite the criterion.
4. Copy `_templates/run.md` to `runs/YYYY-MM-DD-<short-name>.md` (RR9). Fill the items table and the criterion in two places (frontmatter and the line under the title). With fewer than 10 items, delete the unused item rows.
5. Set `status: battling`.

## Outputs
- `runs/YYYY-MM-DD-<short-name>.md` with items and criterion filled, every pair empty.

## Human check
The owner approves the list and the criterion before the first pair is shown. Edit the run file in place if anything changes.
