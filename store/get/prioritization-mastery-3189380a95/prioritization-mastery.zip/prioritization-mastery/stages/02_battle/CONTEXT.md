# 02_battle: the owner picks every pair

One job: every pair in the run file gets a winner letter, chosen by the owner, 9 pairs per message.

## Inputs
- Working: `../../runs/<run>.md`
- Reference: `../../_shared/ranking-rules.md` (RR1, RR5, RR8)
- Tool: `../../scripts/rank.py`

Do NOT load: other runs, the logs, the diagram code.

## Process
1. Run `python3 scripts/rank.py next runs/<run>.md`. It prints how many pairs are answered and the next 9.
2. Show the 9 pairs numbered 1 to 9, each with both item names, and the criterion above them. Ask for one string of 9 letters.
3. The owner replies, for example `ACADAEAFG`. Run `python3 scripts/rank.py answer runs/<run>.md ACADAEAFG`. Spaces and commas are ignored.
4. If the script prints STOP, a letter was not in its pair. Show which pair and ask again. Nothing after the bad letter was written.
5. Repeat until `next` prints 45/45 (or N x (N - 1) / 2 for a shorter list).
6. Pausing is free. The answers live in the run file. To resume, start again at step 1.

## Outputs
- The same run file, every pair filled. Set `status: ranked-pending`.

## Human check
This stage is the human check. Never pick a winner for the owner. If they stall on a pair, use RR5.
