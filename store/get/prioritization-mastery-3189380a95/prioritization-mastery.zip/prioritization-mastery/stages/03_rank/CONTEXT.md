# 03_rank: count wins and break ties

One job: a Result table in the run file, ranked by wins, with ties broken by head-to-head.

## Inputs
- Working: `../../runs/<run>.md` (every pair filled)
- Reference: `../../_shared/ranking-rules.md` (RR6, RR7)
- Tool: `../../scripts/rank.py`

Do NOT load: other runs, the logs.

## Process
1. Run `python3 scripts/rank.py tally runs/<run>.md`. If it prints STOP, some pairs are empty. Go back to stage 02.
2. The script counts each letter's wins, sorts most to fewest, and breaks a tie by the tied items' own pair (RR7). It writes a `## Result` table at the end of the run file (replacing any old one) and also builds the diagram for stage 04.
3. Read the order back to the owner in one short list. Name every tie and how it was broken.
4. If three or more items tie in a loop, say so and let the owner pick the order. Edit the Result table by hand to match.

## Outputs
- `## Result` table in the run file: Rank | Item | Wins. Set `status: ranked`.

## Human check
The owner reads the order. If a ranking feels wrong, ask which pair they would flip, edit that pair in the run file, and run tally again.
