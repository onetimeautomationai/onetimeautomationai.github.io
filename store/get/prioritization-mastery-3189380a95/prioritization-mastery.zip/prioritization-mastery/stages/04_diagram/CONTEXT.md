# 04_diagram: draw the ranking

One job: an Excalidraw diagram next to the run file that shows the whole decision on one screen.

## Inputs
- Working: `../../runs/<run>.md` with its Result table
- Tool: `../../scripts/rank.py` (the `tally` command writes the diagram)

Do NOT load: other runs, the logs.

## Process
1. Check that `runs/<run>.excalidraw` exists. Stage 03's `tally` already wrote it. If it is missing or stale (pairs edited after tally), run `python3 scripts/rank.py tally runs/<run>.md` again.
2. Confirm it is valid JSON, for example `python3 -m json.tool runs/<run>.excalidraw > /dev/null`.
3. Open it for the owner: drag it into excalidraw.com, or open it in any editor with an Excalidraw plugin.
4. What the owner should see:
   - Left: the triangular winner grid. Item letters on the diagonal. Each box below the diagonal holds the winner of that pair. Boxes won by a top 3 item are highlighted.
   - Under the grid: a Total row (wins per letter) and a Rank row.
   - Right: the ranked list, top to bottom, joined by arrows. The top 3 are highlighted.

## Outputs
- `runs/<run>.excalidraw`

## Human check
The owner opens the diagram once. They may move or restyle anything in Excalidraw. The run file stays the source of truth.
