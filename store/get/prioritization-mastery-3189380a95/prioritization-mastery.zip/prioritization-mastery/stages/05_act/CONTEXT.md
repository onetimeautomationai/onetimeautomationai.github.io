# 05_act: book #1, park the rest

One job: the #1 item gets a real time on the calendar. Everything else waits for the weekly review.

## Inputs
- Working: `../../runs/<run>.md` Result table
- Reference: `../../_shared/owner-profile.md` (where #1 gets booked, weekly review day), `../../_shared/ranking-rules.md` (RR10)

Do NOT load: the script, the diagram, other runs.

## Process
1. Check the real clock. Find the next slot that fits #1 (from the profile, for example the next deep work block). If the AI Time Manager ICM is installed, hand #1 to its slot stage instead.
2. Propose the slot to the owner. Book it once they confirm. If the agent has no calendar access, give the owner the exact title, day and time to add.
3. Do not book #2 and below (RR10). Add them to the weekly review agenda in ranked order. At the review, the owner either keeps the order or starts a new run.
4. Add a row to `logs/ranking-log.md`. Set the run file's `status: done`.

## Outputs
- One calendar event for #1.
- `logs/ranking-log.md` row: date | run file | criterion | #1 | booked slot | parked for review.

## Human check
The owner confirms the slot for #1 before it is booked.
