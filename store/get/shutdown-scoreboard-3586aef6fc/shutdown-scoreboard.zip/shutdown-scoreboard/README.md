# Shutdown Scoreboard

A small workspace that closes your day in five minutes. It counts what you did, tells you if you moved your goal, and names one change for tomorrow.

## Setup
1. Copy this whole folder to a place you can open with Claude.
2. Open it and say: "Set up my scoreboard." Claude asks for your one goal metric and fills in `_shared/scoreboard-metrics.md`.
3. At the end of each work day, say "shutdown".
4. After a long work session, say "rate this" for a score and one fix.

## What is inside
| File | Use |
|---|---|
| `CLAUDE.md` | The entry file Claude reads first |
| `stages/05_shutdown/CONTEXT.md` | The close-the-day steps |
| `stages/06_session-rating/CONTEXT.md` | The session rating steps |
| `_shared/scoreboard-metrics.md` | Your metrics and the row format |
| `_shared/rating-rubric.md` | How sessions are scored |
| `logs/scoreboard.md` | One row per day, starts empty |
| `logs/session-ratings.md` | One row per session, starts empty |

## Tips
- Pick one goal metric. Add leading actions you control and one result that proves they work.
- Count a conversation when the other person replies, not when you send.
