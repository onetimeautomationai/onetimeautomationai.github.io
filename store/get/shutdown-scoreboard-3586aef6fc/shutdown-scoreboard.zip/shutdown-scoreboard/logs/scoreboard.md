# Scoreboard

Format: `_shared/scoreboard-metrics.md`. One row per work day, written at shutdown. Starts empty.

| Row | Did the goal move? | Change for tomorrow | Top 3 for tomorrow |
|---|---|---|---|
